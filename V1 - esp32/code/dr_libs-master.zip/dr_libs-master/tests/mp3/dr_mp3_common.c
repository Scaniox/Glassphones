#define DR_MP3_IMPLEMENTATION
#include "../../dr_mp3.h"

#include "../common/dr_common.c"
