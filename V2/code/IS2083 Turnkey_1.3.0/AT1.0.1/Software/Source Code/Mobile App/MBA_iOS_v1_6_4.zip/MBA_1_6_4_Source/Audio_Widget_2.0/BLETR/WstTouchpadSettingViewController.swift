//
//  WstTouchpadSettingViewController.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/9/18.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import CoreBluetooth

class WstTouchpadSettingViewController: UIViewController, WST_TouchpadSetting_Delegate, UITextFieldDelegate{
    @IBOutlet var leftEarbudImageView: UIImageView!
    @IBOutlet var rightEarbudImageView: UIImageView!
    @IBOutlet var wstConnectionStatusImageView: UIImageView!
    @IBOutlet var leftLongPressStandbyTextField: UITextField!
    @IBOutlet var leftLongPressCallActiveTextField: UITextField!
    
    @IBOutlet var rightLongPressStandbyTextField: UITextField!
    @IBOutlet var rightLongPressCallActiveTextField: UITextField!
    @IBOutlet var leftTouchPadSettingBtn: UIButton!
    @IBOutlet var rightTouchPadSettingBtn: UIButton!
    
    @IBAction func leftLongPressStandbyActionPressed(_ sender: Any) {
        if leftEnable == false{
            return
        }
        self.selectedTextField = sender as? UITextField
        actionArray = standbyActionArray
        let recordGroup = UserDefaults.standard
        if recordGroup.value(forKey: RECORD_L_LONG_PRESS_STANDBY_ACTION_KEY) != nil {
            actionArray?.append("Factory Value")
        }
        performSegue(withIdentifier: "FORCE_TO_BUTTON_ACTION", sender: self)
    }
    @IBAction func leftLongPressCallActiveActionPressed(_ sender: Any) {
        if leftEnable == false{
            return
        }
        self.selectedTextField = sender as? UITextField
        actionArray = callActiveActionArray
        let recordGroup = UserDefaults.standard
        if recordGroup.value(forKey: RECORD_L_LONG_PRESS_CALL_ACTIVE_ACTION_KEY) != nil {
            actionArray?.append("Factory Value")
        }
        performSegue(withIdentifier: "FORCE_TO_BUTTON_ACTION", sender: self)
    }
    
    @IBAction func rightLongPressStandbyActionPressed(_ sender: Any) {
        if rightEnable == false{
            return
        }
        self.selectedTextField = sender as? UITextField
        actionArray = standbyActionArray
        let recordGroup = UserDefaults.standard
        if recordGroup.value(forKey: RECORD_R_LONG_PRESS_STANDBY_ACTION_KEY) != nil {
            actionArray?.append("Factory Value")
        }
        performSegue(withIdentifier: "FORCE_TO_BUTTON_ACTION", sender: self)
    }
    
    @IBAction func rightLongPressCallActiveActionPressed(_ sender: Any) {
        if rightEnable == false{
            return
        }
        self.selectedTextField = sender as? UITextField
        actionArray = callActiveActionArray
        let recordGroup = UserDefaults.standard
        if recordGroup.value(forKey: RECORD_R_LONG_PRESS_CALL_ACTIVE_ACTION_KEY) != nil {
            actionArray?.append("Factory Value")
        }
        performSegue(withIdentifier: "FORCE_TO_BUTTON_ACTION", sender: self)
    }
    
    @IBAction func setLeftLongPressTouchpadSetting(_ sender: Any) {
        if leftEnable == false{
            return
        }
        var btnSetting:[BUTTON_SETTING] = []
        btnSetting.append(BUTTON_SETTING(callState: CALL_STATE.STANDBY.rawValue, action: m_lLongPressStandbyAction))
        btnSetting.append(BUTTON_SETTING(callState: CALL_STATE.CALL_ACTIVE.rawValue, action: m_lLongPressCallActiveAction))
        //btnSetting.append(BUTTON_SETTING(callState: CALL_STATE.CALL_ACTIVE.rawValue, action: 0xFC))
        m_wstPeripheral?.command_SetButtonSetting(role: DESTINATION.LEFT_SIDE.rawValue, btnOperation: UInt8(BUTTON0_LONG_PRESS), btnSetting: btnSetting)
        
        /*var testSetting:[BUTTON_SETTING] = []
        testSetting.append(BUTTON_SETTING(callState: CALL_STATE.STANDBY.rawValue, action: MMI_ACTION.ENTER_PAIRING.rawValue))
        testSetting.append(BUTTON_SETTING(callState: CALL_STATE.CALL_ACTIVE.rawValue, action: MMI_ACTION.VOICE_DIAL.rawValue))
        reportButtonSetting(role: DESTINATION.RIGHT_SIDE.rawValue, btnOperation: UInt8(BUTTON0_LONG_PRESS), btnSetting: testSetting)*/
    }
    
    @IBAction func setRightLongPressTouchpadSetting(_ sender: Any) {
        if rightEnable == false{
            return
        }
        var btnSetting:[BUTTON_SETTING] = []
        btnSetting.append(BUTTON_SETTING(callState: CALL_STATE.STANDBY.rawValue, action: m_rLongPressStandbyAction))
        btnSetting.append(BUTTON_SETTING(callState: CALL_STATE.CALL_ACTIVE.rawValue, action: m_rLongPressCallActiveAction))
        //btnSetting.append(BUTTON_SETTING(callState: CALL_STATE.CALL_ACTIVE.rawValue, action: 0xFC))
        m_wstPeripheral?.command_SetButtonSetting(role: DESTINATION.RIGHT_SIDE.rawValue, btnOperation: UInt8(BUTTON0_LONG_PRESS), btnSetting: btnSetting)
    }
    enum MMI_ACTION : UInt8 {
        case NONE = 0x00
        case VOICE_DIAL = 0x0A
        case ENTER_PAIRING = 0x5D
        case VOLUME_UP = 0x30
        case VOLUME_DOWN = 0x31
    }
    
    enum DESTINATION : UInt8 {
        case LOCAL_SIDE = 0x00
        case LEFT_SIDE = 0x01
        case RIGHT_SIDE = 0x02
    }
    
    enum CALL_STATE : UInt8 {
        case STANDBY = 0x00
        case CALL_ACTIVE = 0x04
    }
    
    let BUTTON0_LONG_PRESS = 0x02
    
    let LEFT_SIDE = 0x00
    let RIGHT_SIDE = 0x01
    let WST_CONNECTED = 0x01
    let WST_DISCONNECTED = 0x00
    let STATE_IDLE = 0x00
    let STATE_CONNECTED = 0x01
    
    var m_wstPeripheral : WstPeripheral?
    var m_parentView: WstViewController?
    var m_primaryEarbudStatus_side: UInt8 = 0
    var m_primaryEarbudStatus_wstState: UInt8 = 0
    let leftEarbudImage = ["iconfinder_airpod_left_idle","iconfinder_airpod_left_connect"]
    let rightEarbudImage = ["iconfinder_airpod_right_idle","iconfinder_airpod_right_connect"]
    let standbyActionArray = ["None","Voice Control","Enter Pairing","Volume Up","Volume Down"]
    let callActiveActionArray = ["None","Volume Up","Volume Down"]
    
    let RECORD_L_LONG_PRESS_STANDBY_ACTION_KEY = "RECORD_L_LONG_PRESS_STANDBY_ACTION"
    let RECORD_L_LONG_PRESS_CALL_ACTIVE_ACTION_KEY = "RECORD_L_LONG_PRESS_CALL_ACTIVE_ACTION"
    let RECORD_R_LONG_PRESS_STANDBY_ACTION_KEY = "RECORD_R_LONG_PRESS_STANDBY_ACTION"
    let RECORD_R_LONG_PRESS_CALL_ACTIVE_ACTION_KEY = "RECORD_R_LONG_PRESS_CALL_ACTIVE_ACTION"
    let ActionDictionary: [UInt8: String] = [0x00:"None", 0x0A:"Voice Control", 0x5D:"Enter Pairing", 0x30:"Volume Up", 0x31:"Volume Down"]
    
    var m_lLongPressStandbyAction:UInt8 = 0
    var m_lLongPressCallActiveAction:UInt8 = 0
    var m_rLongPressStandbyAction:UInt8 = 0
    var m_rLongPressCallActiveAction:UInt8 = 0
    
    var selectedTextField: UITextField?
    var actionArray: Array<Any>?
    
    var leftEnable:Bool = false
    var rightEnable:Bool = false
    
    /*var leftLongPressStandbybutton = DropdownButton()
    var leftLongPressCallActivebutton = DropdownButton()
    var rightLongPressStandbybutton = DropdownButton()
    var rightLongPressCallActivebutton = DropdownButton()*/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.hideKeyboardWhenTappedAround()
        self.title = "Touchpad Setting"
        
        m_wstPeripheral?.wstTouchpadSettingDelegate = self
        
        wstConnectionStatusImageView.isHidden = true
        
        leftTouchPadSettingBtn.layer.borderWidth = 1
        leftTouchPadSettingBtn.layer.cornerRadius = 5.0
        rightTouchPadSettingBtn.layer.borderWidth = 1
        rightTouchPadSettingBtn.layer.cornerRadius = 5.0
        
        if m_primaryEarbudStatus_side ==  LEFT_SIDE{
            leftEnable = true
            if m_primaryEarbudStatus_wstState == WST_CONNECTED{
                rightEnable = true
            }
        }else{
            rightEnable = true
            if m_primaryEarbudStatus_wstState == WST_CONNECTED{
                leftEnable = true
            }
        }
        /*leftLongPressStandbyTextField.textColor = .gray
        leftLongPressCallActiveTextField.textColor = .gray
        leftTouchPadSettingBtn.tintColor = .gray*/
        
        self.updateView()

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if(self.isMovingFromParent) {
            m_wstPeripheral?.wstTouchpadSettingDelegate = nil
        }
    }
    
    func updateView(){
        
        
        if leftEnable{
            leftEarbudImageView.image = UIImage(named: leftEarbudImage[STATE_CONNECTED])
            var callState:[UInt8] = []
            callState.append(CALL_STATE.STANDBY.rawValue)
            callState.append(CALL_STATE.CALL_ACTIVE.rawValue)
            m_wstPeripheral?.command_ReadButtonSetting(role: DESTINATION.LEFT_SIDE.rawValue, btnOperation: UInt8(BUTTON0_LONG_PRESS), callState: callState)
        }else{
            leftEarbudImageView.image = UIImage(named: leftEarbudImage[STATE_IDLE])
            leftLongPressStandbyTextField.textColor = .gray
            leftLongPressCallActiveTextField.textColor = .gray
            leftLongPressStandbyTextField.isEnabled = false
            leftLongPressCallActiveTextField.isEnabled = false
            leftTouchPadSettingBtn.tintColor = .gray
        }
        
        if rightEnable{
            rightEarbudImageView.image = UIImage(named: rightEarbudImage[STATE_CONNECTED])
            var callState:[UInt8] = []
            callState.append(CALL_STATE.STANDBY.rawValue)
            callState.append(CALL_STATE.CALL_ACTIVE.rawValue)
            m_wstPeripheral?.command_ReadButtonSetting(role: DESTINATION.RIGHT_SIDE.rawValue, btnOperation: UInt8(BUTTON0_LONG_PRESS), callState: callState)
        }else{
            rightEarbudImageView.image = UIImage(named: rightEarbudImage[STATE_IDLE])
            rightLongPressStandbyTextField.textColor = .gray
            rightLongPressCallActiveTextField.textColor = .gray
            rightLongPressStandbyTextField.isEnabled = false
            rightLongPressCallActiveTextField.isEnabled = false
            rightTouchPadSettingBtn.tintColor = .gray
        }
        
        if m_primaryEarbudStatus_wstState == WST_CONNECTED{
            wstConnectionStatusImageView.isHidden = false
        }
    }
    
    @objc func setBackgroundMode(background:Bool){
        m_parentView!.setBackgroundMode(background:background)
    }
    
    @objc func terminateBle(){
        m_parentView!.terminateBle()
    }
    
    @objc func didSelectAction(action:String?){
        self.selectedTextField?.text = action
        var value: UInt8 = 0x00
        if action == "None"{
            value = MMI_ACTION.NONE.rawValue
        }else if action == "Voice Control"{
            value = MMI_ACTION.VOICE_DIAL.rawValue
        }else if action == "Enter Pairing"{
            value = MMI_ACTION.ENTER_PAIRING.rawValue
        }else if action == "Volume Up"{
            value = MMI_ACTION.VOLUME_UP.rawValue
        }else if action == "Volume Down"{
            value = MMI_ACTION.VOLUME_DOWN.rawValue
        }else if action == "Factory Value"{
            let recordGroup = UserDefaults.standard
            if selectedTextField == leftLongPressStandbyTextField {
                value = recordGroup.value(forKey: RECORD_L_LONG_PRESS_STANDBY_ACTION_KEY) as! UInt8
                //m_lLongPressStandbyAction = value
            }else if selectedTextField == leftLongPressCallActiveTextField {
                value = recordGroup.value(forKey: RECORD_L_LONG_PRESS_CALL_ACTIVE_ACTION_KEY) as! UInt8
                
            }else if selectedTextField == rightLongPressStandbyTextField {
                value = recordGroup.value(forKey: RECORD_R_LONG_PRESS_STANDBY_ACTION_KEY) as! UInt8
                
            }else if selectedTextField == rightLongPressCallActiveTextField {
                value = recordGroup.value(forKey: RECORD_R_LONG_PRESS_CALL_ACTIVE_ACTION_KEY) as! UInt8
            }
        }
        
        if selectedTextField == leftLongPressStandbyTextField {
            m_lLongPressStandbyAction = value
        }else if selectedTextField == leftLongPressCallActiveTextField {
            m_lLongPressCallActiveAction = value
        }else if selectedTextField == rightLongPressStandbyTextField {
            m_rLongPressStandbyAction = value
        }else if selectedTextField == rightLongPressCallActiveTextField {
            m_rLongPressCallActiveAction = value
        }
        //print("Value = \(value)")
        let array = navigationController?.viewControllers
        if let object = array?[2] {
            navigationController?.popToViewController(object, animated: true)
        }
    }
    
    // MARK: - Nevagation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "FORCE_TO_BUTTON_ACTION" {
            let controller = segue.destination as? WstButtonActionTableViewController
            controller?.m_parentView = self
            controller?.actionArray = self.actionArray
        }
    }
    
    // MARK: - WstPeripheral WST_TouchpadSetting_Delegate
    func didUpdateMessage(message: String?) {
        showToast(message: message!, font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
    }
    
    func reportButtonSetting(role: UInt8, btnOperation: UInt8, btnSetting: Array<Any>) {
        if btnOperation != BUTTON0_LONG_PRESS{
            return
        }
        
        if role == DESTINATION.LEFT_SIDE.rawValue{ // 0x01
            for i in 0..<btnSetting.count{
                let setting:BUTTON_SETTING = btnSetting[i] as! BUTTON_SETTING
                if setting.callState == CALL_STATE.STANDBY.rawValue{
                    if let str = ActionDictionary[setting.action]{
                        leftLongPressStandbyTextField.text = str
                        m_lLongPressStandbyAction = setting.action
                    }else{
                        leftLongPressStandbyTextField.text = "Factory Value"
                        m_lLongPressStandbyAction = setting.action
                        let defaults = UserDefaults.standard
                        defaults.set(setting.action, forKey: RECORD_L_LONG_PRESS_STANDBY_ACTION_KEY)
                    }
                }else if setting.callState == CALL_STATE.CALL_ACTIVE.rawValue{
                    if let str = ActionDictionary[setting.action]{
                        leftLongPressCallActiveTextField.text = str
                        m_lLongPressCallActiveAction = setting.action
                    }else{
                        leftLongPressCallActiveTextField.text = "Factory Value"
                        m_lLongPressCallActiveAction = setting.action
                        let defaults = UserDefaults.standard
                        defaults.set(setting.action, forKey: RECORD_L_LONG_PRESS_CALL_ACTIVE_ACTION_KEY)
                    }
                
                }
            }
        }else{ //DESTINATION.RIGHT_SIDE.rawValue
            for i in 0..<btnSetting.count{
                let setting:BUTTON_SETTING = btnSetting[i] as! BUTTON_SETTING
                if setting.callState == CALL_STATE.STANDBY.rawValue{
                    if let str = ActionDictionary[setting.action]{
                        rightLongPressStandbyTextField.text = str
                        m_rLongPressStandbyAction = setting.action
                    }else{
                        rightLongPressStandbyTextField.text = "Factory Value"
                        m_rLongPressStandbyAction = setting.action
                        let defaults = UserDefaults.standard
                        defaults.set(setting.action, forKey: RECORD_R_LONG_PRESS_STANDBY_ACTION_KEY)
                    }
                }else if setting.callState == CALL_STATE.CALL_ACTIVE.rawValue{
                    if let str = ActionDictionary[setting.action]{
                        rightLongPressCallActiveTextField.text = str
                        m_rLongPressCallActiveAction = setting.action
                    }else{
                        rightLongPressCallActiveTextField.text = "Factory Value"
                        m_rLongPressCallActiveAction = setting.action
                        let defaults = UserDefaults.standard
                        defaults.set(setting.action, forKey: RECORD_R_LONG_PRESS_CALL_ACTIVE_ACTION_KEY)
                    }
                }
            }
        }
    }
}

