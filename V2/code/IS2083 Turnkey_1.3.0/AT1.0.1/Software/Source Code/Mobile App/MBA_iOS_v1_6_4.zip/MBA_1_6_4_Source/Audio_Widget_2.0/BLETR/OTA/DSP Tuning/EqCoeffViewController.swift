//
//  EqCoeffViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/7/12.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class EqCoeffViewController: UIViewController, UITextFieldDelegate{
    @IBOutlet var Frequency_1: UITextField!
    @IBOutlet var Frequency_2: UITextField!
    @IBOutlet var Frequency_3: UITextField!
    @IBOutlet var Frequency_4: UITextField!
    @IBOutlet var Frequency_5: UITextField!
    @IBOutlet var Gain_1: UITextField!
    @IBOutlet var Gain_2: UITextField!
    @IBOutlet var Gain_3: UITextField!
    @IBOutlet var Gain_4: UITextField!
    @IBOutlet var Gain_5: UITextField!
    @IBOutlet var Q_1: UITextField!
    @IBOutlet var Q_2: UITextField!
    @IBOutlet var Q_3: UITextField!
    @IBOutlet var Q_4: UITextField!
    @IBOutlet var Q_5: UITextField!
    @IBOutlet var global_gain: UITextField!
    @IBOutlet var sample_frequency: UITextField!
    @IBOutlet var stage: DropDown!
    @IBOutlet var defaultCoeff: DropDown!
    @IBOutlet var QR_ImageView: UIImageView!
    
    var DSPManager: TuneDSPManager?
    var EQMode: UInt8?
    var Audio_MCU_Option3: UInt8?
    
    var Sample_Freq: Double?
    
    let stage_table = ["1", "2", "3", "4", "5"]
    let stage_table_ids = [1, 2, 3, 4, 5]
    
    let defaultCoeff_table = ["Flat", "Boost", "Treble", "Pop", "Rock", "Classic", "Jazz", "Dance", "R&B"]
    let defaultCoeff_table_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[EqCoeffViewController] viewDidLoad")
        
        DSPManager = TuneDSPManager.sharedInstance()
        
        Frequency_1.delegate = self
        Frequency_2.delegate = self
        Frequency_3.delegate = self
        Frequency_4.delegate = self
        Frequency_5.delegate = self
        Gain_1.delegate = self
        Gain_2.delegate = self
        Gain_3.delegate = self
        Gain_4.delegate = self
        Gain_5.delegate = self
        Q_1.delegate = self
        Q_2.delegate = self
        Q_3.delegate = self
        Q_4.delegate = self
        Q_5.delegate = self
        
        global_gain.delegate = self
        sample_frequency.delegate = self
        
        global_gain.tag = 100
        sample_frequency.tag = 200
        
        Frequency_1.keyboardType = .numbersAndPunctuation
        Frequency_2.keyboardType = .numbersAndPunctuation
        Frequency_3.keyboardType = .numbersAndPunctuation
        Frequency_4.keyboardType = .numbersAndPunctuation
        Frequency_5.keyboardType = .numbersAndPunctuation
        
        Gain_1.keyboardType = .numbersAndPunctuation
        Gain_2.keyboardType = .numbersAndPunctuation
        Gain_3.keyboardType = .numbersAndPunctuation
        Gain_4.keyboardType = .numbersAndPunctuation
        Gain_5.keyboardType = .numbersAndPunctuation
        
        Q_1.keyboardType = .numbersAndPunctuation
        Q_2.keyboardType = .numbersAndPunctuation
        Q_3.keyboardType = .numbersAndPunctuation
        Q_4.keyboardType = .numbersAndPunctuation
        Q_5.keyboardType = .numbersAndPunctuation
        
        self.stage.isSearchEnable = false
        self.defaultCoeff.isSearchEnable = false
        
        self.stage.optionArray = stage_table
        self.stage.optionIds = stage_table_ids
        
        self.defaultCoeff.optionArray = defaultCoeff_table
        self.defaultCoeff.optionIds = defaultCoeff_table_ids
        
        self.stage.selectedIndex = 4
        self.defaultCoeff.selectedIndex = 0
        
        self.stage.text = stage_table[self.stage.selectedIndex!]
        self.defaultCoeff.text = defaultCoeff_table[self.defaultCoeff.selectedIndex!]
        
        self.stage.didSelect{(selectedText , index , id) in
            if(self.stage.text != self.stage_table[self.stage.selectedIndex!]){
                print("[stage]Selected string = \(self.stage_table[self.stage.selectedIndex!])")
                let new_stage = self.stage_table[self.stage.selectedIndex!]
                
                if(new_stage == "5"){
                    self.UpdateStage(stage: 5)
                }
                else if(new_stage == "4"){
                    self.UpdateStage(stage: 4)
                }
                else if(new_stage == "3"){
                    self.UpdateStage(stage: 3)
                }
                else if(new_stage == "2"){
                    self.UpdateStage(stage: 2)
                }
                else if(new_stage == "1"){
                    self.UpdateStage(stage: 1)
                }
            }
        }
        
        self.defaultCoeff.didSelect{(selectedText , index , id) in
            if(self.defaultCoeff.text != self.defaultCoeff_table[self.defaultCoeff.selectedIndex!]){
                print("[defaultCoeff]Selected string = \(self.defaultCoeff_table[self.defaultCoeff.selectedIndex!])")
                
                self.defaultCoeffDidSelect()
            }
        }
        
        self.stage.listWillAppear {
            print("stage.listWillAppear")
            
        }
        
        self.stage.listDidDisappear {
            print("stage.listDidDisappear")
            
        }
        
        self.defaultCoeff.listWillAppear {
            print("defaultCoeff.listWillAppear")
            
        }
     
        self.defaultCoeff.listDidDisappear {
            print("defaultCoeff.listDidDisappear")
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[EqCoeffViewController] viewWillAppear")
        print("EQMode = \(EQMode!)")
        
        if(EQMode! == 0x01){
            QR_ImageView.image = UIImage(named: "Voice_EQ.png")
            //QR_ImageView.image = UIImage(named: "AudioEQ_new.png")
        }
        else{
            QR_ImageView.image = UIImage(named: "Voice_EQ.png")
            
            Audio_MCU_Option3 = DSPManager?.GetAudioMCUOption3()
            
            print("Audio_MCU_Option3 = \(Audio_MCU_Option3)")
        }
        
        if(EQMode! == 0x01){
            self.title = "Audio EQ"
            
            /*
            //Debug, Test data
            Frequency_1.text = "5000"
            Frequency_2.text = "20000"
            Frequency_3.text = "10000"
            Frequency_4.text = "15000"
            Frequency_5.text = "23000"
            
            Gain_1.text = "-5.0"
            Gain_2.text = "5.0"
            Gain_3.text = "5.0"
            Gain_4.text = "0"
            Gain_5.text = "0"
            
            Q_1.text = "1.0"
            Q_2.text = "1.0"
            Q_3.text = "1.0"
            Q_4.text = "1.0"
            Q_5.text = "1.0"
            */
            
            global_gain.text = "0"
            sample_frequency.text = "48000"
            Sample_Freq = 48000
            
            //DSPManager?.Get_Audio_DSP_CustomEQ_SPK()
            
            ///*
            //Default
            Frequency_1.text = "1000"
            Frequency_2.text = "2000"
            Frequency_3.text = "5000"
            Frequency_4.text = "10000"
            Frequency_5.text = "16000"
            
            Gain_1.text = "0"
            Gain_2.text = "0"
            Gain_3.text = "0"
            Gain_4.text = "0"
            Gain_5.text = "0"
            
            Q_1.text = "1.0"
            Q_2.text = "1.0"
            Q_3.text = "1.0"
            Q_4.text = "1.0"
            Q_5.text = "1.0"
            //*/
        }
        else if(EQMode! == 0x02 || EQMode! == 0x03){
            if(EQMode! == 0x02){
                self.title = "SPK EQ"
            }
            else{
                self.title = "MIC EQ"
            }
            
            Frequency_1.text = "100"
            Frequency_2.text = "200"
            Frequency_3.text = "500"
            Frequency_4.text = "1000"
            Frequency_5.text = "2000"
            
            Gain_1.text = "0"
            Gain_2.text = "0"
            Gain_3.text = "0"
            Gain_4.text = "0"
            Gain_5.text = "0"
            
            Q_1.text = "1.0"
            Q_2.text = "1.0"
            Q_3.text = "1.0"
            Q_4.text = "1.0"
            Q_5.text = "1.0"
            
            print("Audio_MCU_Option3 = \(String(format: "0x%02X",self.Audio_MCU_Option3!))")
            
            if(Audio_MCU_Option3 != nil){
                if((Audio_MCU_Option3! & 0x02) == 0x02){
                    sample_frequency.text = "48000"
                    Sample_Freq = 48000
                }
                else{
                    sample_frequency.text = "8000"
                    Sample_Freq = 8000
                }
            }
        }
        else if(EQMode! == 0x04 || EQMode! == 0x05){
            if(EQMode! == 0x04){
                self.title = "SPK_mSBC EQ"
            }
            else{
                self.title = "MIC_mSBC EQ"
            }
            
            Frequency_1.text = "100"
            Frequency_2.text = "200"
            Frequency_3.text = "500"
            Frequency_4.text = "1000"
            Frequency_5.text = "2000"
            
            Gain_1.text = "0"
            Gain_2.text = "0"
            Gain_3.text = "0"
            Gain_4.text = "0"
            Gain_5.text = "0"
            
            Q_1.text = "1.0"
            Q_2.text = "1.0"
            Q_3.text = "1.0"
            Q_4.text = "1.0"
            Q_5.text = "1.0"
            
            if(Audio_MCU_Option3 != nil){
                if((Audio_MCU_Option3! & 0x02) == 0x02){
                    sample_frequency.text = "48000"
                    Sample_Freq = 48000
                }
                else{
                    sample_frequency.text = "16000"
                    Sample_Freq = 16000
                }
            }
        }
        else if(EQMode! == 0x06){
            self.title = "LineIn Rx EQ"
            
            Frequency_1.text = "1000"
            Frequency_2.text = "2000"
            Frequency_3.text = "5000"
            Frequency_4.text = "10000"
            Frequency_5.text = "16000"
            
            Gain_1.text = "0"
            Gain_2.text = "0"
            Gain_3.text = "0"
            Gain_4.text = "0"
            Gain_5.text = "0"
            
            Q_1.text = "1.0"
            Q_2.text = "1.0"
            Q_3.text = "1.0"
            Q_4.text = "1.0"
            Q_5.text = "1.0"
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func Calculate(_ sender: Any) {
        /*
        //Test data
        var gain = [-5.0, 5.0, 5.0, 0, 0]
        var Freq = [5000.0, 20000.0, 10000.0, 15000.0, 23000.0]
        var QQ = [1.0, 1.0, 1.0, 1.0, 1.0]
        let EQ_Calculate_Data = getEqualizerParameters(&gain , &Freq, &QQ)
        print("EQ_Calculate_Data = \(EQ_Calculate_Data!)")
        let EQ_Data_Array = Array(UnsafeBufferPointer(start: EQ_Calculate_Data, count: 84))
        print("EQ_Data_Array = \(EQ_Data_Array)")
        //EQ_Data_Array = [45, 74, 245, 49, 169, 74, 204, 229, 34, 33, 127, 249, 178, 37, 198, 45, 24, 155, 145, 173, 76, 188, 140, 11, 38, 102, 102, 102, 88, 174, 86, 26, 4, 220, 43, 116, 238, 45, 126, 114, 22, 80, 77, 239, 233, 169, 14, 58, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 83, 61, 148, 243]
        
        //getEqualizerParameters:84 bytes = <2d4af531 a94acce5 22217ff9 b225c62d 189b91ad 4cbc8c0b 26666666 58ae561a 04dc2b74 ee2d7e72 16504def e9a90e3a 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 533d94f3>
        */
        
        var Freq_array = [Double]()
        var Gain_array = [Double]()
        var Q_array = [Double]()
        
        var Calculate_Data: [UInt8] = [UInt8]()
        
        let m_global_gain = Double(global_gain.text!)
        let stage_num = Int(stage.text!)
        Sample_Freq = Double(sample_frequency.text!)
        
        if(Sample_Freq == nil){
            print("[Sample_Freq]Not a valid number!")
            return
        }
        
        if let freq1 = Double(Frequency_1.text!){
            Freq_array.append(freq1)
        }
        else{
            print("[Freq 1]Not a valid number: \(Frequency_1.text!)")
            return
        }
        
        if let freq2 = Double(Frequency_2.text!){
            Freq_array.append(freq2)
        }
        else{
            print("[Freq 2]Not a valid number: \(Frequency_2.text!)")
            return
        }
        
        if let freq3 = Double(Frequency_3.text!){
            Freq_array.append(freq3)
        }
        else{
            print("[Freq 3]Not a valid number: \(Frequency_3.text!)")
            return
        }
        
        if let freq4 = Double(Frequency_4.text!){
            Freq_array.append(freq4)
        }
        else{
            print("[Freq 4]Not a valid number: \(Frequency_4.text!)")
            return
        }
        
        if let freq5 = Double(Frequency_5.text!){
            Freq_array.append(freq5)
        }
        else{
            print("[Freq 5]Not a valid number: \(Frequency_5.text!)")
            return
        }
        
        if let gain1 = Double(Gain_1.text!){
            Gain_array.append(gain1)
        }
        else{
            print("[Gain 1]Not a valid number: \(Gain_1.text!)")
            return
        }
        
        if let gain2 = Double(Gain_2.text!){
            Gain_array.append(gain2)
        }
        else{
            print("[Gain 2]Not a valid number: \(Gain_2.text!)")
            return
        }
        
        if let gain3 = Double(Gain_3.text!){
            Gain_array.append(gain3)
        }
        else{
            print("[Gain 3]Not a valid number: \(Gain_3.text!)")
            return
        }
        
        if let gain4 = Double(Gain_4.text!){
            Gain_array.append(gain4)
        }
        else{
            print("[Gain 4]Not a valid number: \(Gain_4.text!)")
            return
        }
        
        if let gain5 = Double(Gain_5.text!){
            Gain_array.append(gain5)
        }
        else{
            print("[Gain 5]Not a valid number: \(Gain_5.text!)")
            return
        }
        
        if let q1 = Double(Q_1.text!){
            Q_array.append(q1)
        }
        else{
            print("[Q 1]Not a valid number: \(Q_1.text!)")
            return
        }
        
        if let q2 = Double(Q_2.text!){
            Q_array.append(q2)
        }
        else{
            print("[Q 2]Not a valid number: \(Q_2.text!)")
            return
        }
        
        if let q3 = Double(Q_3.text!){
            Q_array.append(q3)
        }
        else{
            print("[Q 3]Not a valid number: \(Q_3.text!)")
            return
        }
        
        if let q4 = Double(Q_4.text!){
            Q_array.append(q4)
        }
        else{
            print("[Q 4]Not a valid number: \(Q_4.text!)")
            return
        }
        
        if let q5 = Double(Q_5.text!){
            Q_array.append(q5)
        }
        else{
            print("[Q 5]Not a valid number: \(Q_5.text!)")
            return
        }
        
        print("[EqCoeff] Calculation")
        
        print("Freq array = \(Freq_array)")
        print("Gain array = \(Gain_array)")
        print("Q array = \(Q_array)")
        print("Global_Gain = \(m_global_gain)")
        print("Stage = \(stage_num!)")
        print("Sample Frequency = \(Sample_Freq!)")
        
        //EQ_Data.removeAll()
        
        //let p_EQ_Calculate_Data = BM83_getEqualizerParameters(&Gain_array , &Freq_array, &Q_array, m_global_gain!, Int32(stage_num!))
        let p_EQ_Calculate_Data = BM83_getEqualizerParameters(&Gain_array , &Freq_array, &Q_array, m_global_gain!, Int32(stage_num!), Double(sample_frequency.text!)! )
        
        if(p_EQ_Calculate_Data != nil){
            //print("EQ_Calculate_Data = \(EQ_Calculate_Data!)")
            let EQ_Data_Array = Array(UnsafeBufferPointer(start: p_EQ_Calculate_Data, count: 84))
            //print("EQ_Data_Array = \(EQ_Data_Array)")
        
            for i in 0..<84 {
                //EQ_Data.append(UInt8(EQ_Data_Array[i]))
                Calculate_Data.append(UInt8(EQ_Data_Array[i]))
            }
            print("Calculate_Data = \(Calculate_Data)")
            
        }
        else{
            //print("Filter central frequency incorrect")
            //return
        }
        
        let error_code = BM83_GetErrorCode()
        if(error_code != 0){
            print("EQ_Error_Code = \(error_code)")
            
            var str:String!
            
            if(error_code == 2){
                str = "The Maximum Gain cannot over 12 dB!"
            }
            else if(error_code == 1){
                str = "Filter central frequency incorrect"
            }
            
            let alertController = UIAlertController(
                title: str,
                message: "",
                preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
                print("okAction")
            }
            
            alertController.addAction(okAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
        else{
            let alertController = UIAlertController(
                title: "Calculation is done",
                message: "Save EQ coefficients",
                preferredStyle: .alert)
        
            let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
                print("okAction")
                if(self.DSPManager?.EQ_Data.count != 0){
                    self.DSPManager?.EQ_Data.removeAll()
                }
                self.DSPManager?.EQ_Data = Calculate_Data
                self.DSPManager?.EQMode = self.EQMode
            }
        
            let cancelAction = UIAlertAction(title: "Cancel", style: .default) { (UIAlertAction) in
                print("Cancel")
                self.DSPManager?.EQ_Data.removeAll()
                self.DSPManager?.EQMode = nil
            }
        
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
        
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func UpdateStage(stage:Int){
        if(stage == 1){
            self.Frequency_1.isEnabled = true
            self.Gain_1.isEnabled = true
            self.Q_1.isEnabled = true
            self.Frequency_2.isEnabled = false
            self.Gain_2.isEnabled = false
            self.Q_2.isEnabled = false
            self.Frequency_3.isEnabled = false
            self.Gain_3.isEnabled = false
            self.Q_3.isEnabled = false
            self.Frequency_4.isEnabled = false
            self.Gain_4.isEnabled = false
            self.Q_4.isEnabled = false
            self.Frequency_5.isEnabled = false
            self.Gain_5.isEnabled = false
            self.Q_5.isEnabled = false
        }
        else if(stage == 2){
            self.Frequency_1.isEnabled = true
            self.Gain_1.isEnabled = true
            self.Q_1.isEnabled = true
            self.Frequency_2.isEnabled = true
            self.Gain_2.isEnabled = true
            self.Q_2.isEnabled = true
            self.Frequency_3.isEnabled = false
            self.Gain_3.isEnabled = false
            self.Q_3.isEnabled = false
            self.Frequency_4.isEnabled = false
            self.Gain_4.isEnabled = false
            self.Q_4.isEnabled = false
            self.Frequency_5.isEnabled = false
            self.Gain_5.isEnabled = false
            self.Q_5.isEnabled = false
        }
        else if(stage == 3){
            self.Frequency_1.isEnabled = true
            self.Gain_1.isEnabled = true
            self.Q_1.isEnabled = true
            self.Frequency_2.isEnabled = true
            self.Gain_2.isEnabled = true
            self.Q_2.isEnabled = true
            self.Frequency_3.isEnabled = true
            self.Gain_3.isEnabled = true
            self.Q_3.isEnabled = true
            self.Frequency_4.isEnabled = false
            self.Gain_4.isEnabled = false
            self.Q_4.isEnabled = false
            self.Frequency_5.isEnabled = false
            self.Gain_5.isEnabled = false
            self.Q_5.isEnabled = false
        }
        else if(stage == 4){
            self.Frequency_1.isEnabled = true
            self.Gain_1.isEnabled = true
            self.Q_1.isEnabled = true
            self.Frequency_2.isEnabled = true
            self.Gain_2.isEnabled = true
            self.Q_2.isEnabled = true
            self.Frequency_3.isEnabled = true
            self.Gain_3.isEnabled = true
            self.Q_3.isEnabled = true
            self.Frequency_4.isEnabled = true
            self.Gain_4.isEnabled = true
            self.Q_4.isEnabled = true
            self.Frequency_5.isEnabled = false
            self.Gain_5.isEnabled = false
            self.Q_5.isEnabled = false
        }
        else if(stage == 5){
            self.Frequency_1.isEnabled = true
            self.Gain_1.isEnabled = true
            self.Q_1.isEnabled = true
            self.Frequency_2.isEnabled = true
            self.Gain_2.isEnabled = true
            self.Q_2.isEnabled = true
            self.Frequency_3.isEnabled = true
            self.Gain_3.isEnabled = true
            self.Q_3.isEnabled = true
            self.Frequency_4.isEnabled = true
            self.Gain_4.isEnabled = true
            self.Q_4.isEnabled = true
            self.Frequency_5.isEnabled = true
            self.Gain_5.isEnabled = true
            self.Q_5.isEnabled = true
        }
    }
    
    func defaultCoeffDidSelect(){
        print("defaultCoeffDidSelect")
        let defaultCoeff_Name = self.defaultCoeff_table[self.defaultCoeff.selectedIndex!]
        
        if(EQMode! == 0x01){
            //Audio EQ
            
            if(defaultCoeff_Name == "Flat"){
                Frequency_1.text = "1000"
                Frequency_2.text = "2000"
                Frequency_3.text = "4000"
                Frequency_4.text = "8000"
                Frequency_5.text = "16000"
                Gain_1.text = String(GTodB(1.0))
                Gain_2.text = String(GTodB(1.0))
                Gain_3.text = String(GTodB(1.0))
                Gain_4.text = String(GTodB(1.0))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = "1.0"
                Q_2.text = "1.0"
                Q_3.text = "1.0"
                Q_4.text = "1.0"
                Q_5.text = "1.0"
                stage.selectedIndex = 4
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 5)
            }
            else if(defaultCoeff_Name == "Boost"){
                Frequency_1.text = "32"
                Frequency_2.text = "250"
                Frequency_3.text = "1000"
                Frequency_4.text = "8000"
                Frequency_5.text = "16000"
                Gain_1.text = String(GTodB(1.92866228512964))
                Gain_2.text = String(GTodB(1.31707666338300))
                Gain_3.text = String(GTodB(0.89032258594553))
                Gain_4.text = String(GTodB(1.0))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(0.43293644239969)
                Q_2.text = String(0.35638544866886)
                Q_3.text = String(0.74086372129852)
                Q_4.text = "1.0"
                Q_5.text = "1.0"
                stage.selectedIndex = 2 //"stage = 3"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 3)
            }
            else if(defaultCoeff_Name == "Treble"){
                Frequency_1.text = "500"
                Frequency_2.text = "1000"
                Frequency_3.text = "4000"
                Frequency_4.text = "16000"
                Frequency_5.text = "20000"
                Gain_1.text = String(GTodB(0.98658758766945))
                Gain_2.text = String(GTodB(1.00878203417550))
                Gain_3.text = String(GTodB(1.29198710848956))
                Gain_4.text = String(GTodB(1.96821721203325))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(1.01016346823979)
                Q_2.text = String(1.15128009113710)
                Q_3.text = String(0.49213181332384)
                Q_4.text = String(0.49349647103298)
                Q_5.text = "1.0"
                stage.selectedIndex = 3 //"stage = 4"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 4)
            }
            else if(defaultCoeff_Name == "Pop"){
                Frequency_1.text = "32"
                Frequency_2.text = "125"
                Frequency_3.text = "750"
                Frequency_4.text = "4000"
                Frequency_5.text = "16000"
                Gain_1.text = String(GTodB(0.98856685820696))
                Gain_2.text = String(GTodB(1.09005980510416))
                Gain_3.text = String(GTodB(1.75408420359879))
                Gain_4.text = String(GTodB(1.09005980510416))
                Gain_5.text = String(GTodB(0.98691533400276))
                Q_1.text = String(0.98620270998901)
                Q_2.text = String(0.41931697684387)
                Q_3.text = String(0.58185820541141)
                Q_4.text = String(0.41931697684387)
                Q_5.text = String(0.80454192483280)
                stage.selectedIndex = 4 //"stage = 5"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(0.84))
                UpdateStage(stage: 5)
            }
            else if(defaultCoeff_Name == "Rock"){
                Frequency_1.text = "32"
                Frequency_2.text = "250"
                Frequency_3.text = "1000"
                Frequency_4.text = "4000"
                Frequency_5.text = "16000"
                Gain_1.text = String(GTodB(1.97695226195262))
                Gain_2.text = String(GTodB(1.08916167643889))
                Gain_3.text = String(GTodB(0.84955461886004))
                Gain_4.text = String(GTodB(1.05051608753516))
                Gain_5.text = String(GTodB(1.99446106397164))
                Q_1.text = String(0.40267199696855)
                Q_2.text = String(0.31218212846435)
                Q_3.text = String(0.32220330969738)
                Q_4.text = String(0.61265796514266)
                Q_5.text = String(0.36854006186122)
                stage.selectedIndex = 4 //"stage = 5"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 5)
            }
            else if(defaultCoeff_Name == "Classic"){
                Frequency_1.text = "250"
                Frequency_2.text = "750"
                Frequency_3.text = "16000"
                Frequency_4.text = "20000"
                Frequency_5.text = "22000"
                Gain_1.text = String(GTodB(1.25308149309474))
                Gain_2.text = String(GTodB(0.42952440917061))
                Gain_3.text = String(GTodB(1.00627225160375))
                Gain_4.text = String(GTodB(1.0))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(1.84047455179705)
                Q_2.text = String(0.21370992368501)
                Q_3.text = String(0.11611675014813)
                Q_4.text = String(1.0)
                Q_5.text = String(1.0)
                stage.selectedIndex = 2 //"stage = 3"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.68))
                UpdateStage(stage: 3)
            }
            else if(defaultCoeff_Name == "Jazz"){
                Frequency_1.text = "125"
                Frequency_2.text = "250"
                Frequency_3.text = "750"
                Frequency_4.text = "16000"
                Frequency_5.text = "20000"
                Gain_1.text = String(GTodB(0.80807222401813))
                Gain_2.text = String(GTodB(1.19993741976506))
                Gain_3.text = String(GTodB(0.51932714953227))
                Gain_4.text = String(GTodB(1.00345679502982))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(0.86264758926996)
                Q_2.text = String(1.13540466707967)
                Q_3.text = String(0.27313980983445)
                Q_4.text = String(0.18446552753420)
                Q_5.text = String(1.0)
                stage.selectedIndex = 3 //"stage = 4"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.585))
                UpdateStage(stage: 4)
            }
            else if(defaultCoeff_Name == "Dance"){
                Frequency_1.text = "64"
                Frequency_2.text = "250"
                Frequency_3.text = "2000"
                Frequency_4.text = "16000"
                Frequency_5.text = "20000"
                Gain_1.text = String(GTodB(2.05339743428121))
                Gain_2.text = String(GTodB(0.74175797823560))
                Gain_3.text = String(GTodB(1.68327534931948))
                Gain_4.text = String(GTodB(0.98185132489032))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(0.51647294364063)
                Q_2.text = String(0.69485573711835)
                Q_3.text = String(0.51283185235765)
                Q_4.text = String(0.38117808090389)
                Q_5.text = String(1.0)
                stage.selectedIndex = 3 //"stage = 4"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 4)
            }
            else if(defaultCoeff_Name == "R&B"){
                Frequency_1.text = "64"
                Frequency_2.text = "500"
                Frequency_3.text = "4000"
                Frequency_4.text = "16000"
                Frequency_5.text = "20000"
                Gain_1.text = String(GTodB(1.79448846234098))
                Gain_2.text = String(GTodB(0.55980089306381))
                Gain_3.text = String(GTodB(1.00717135310177))
                Gain_4.text = String(GTodB(1.10121648869244))
                Gain_5.text = String(GTodB(1.06542494612799))
                Q_1.text = String(2.88385310493725)
                Q_2.text = String(0.68953348916826)
                Q_3.text = String(0.20725350274938)
                Q_4.text = String(0.88950806827823)
                Q_5.text = String(1.02619582010820)
                stage.selectedIndex = 4 //"stage = 5"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 5)
            }
        }
        else{
            var multiFactor = 1
            if(EQMode! == 0x04 || EQMode! == 0x05){
                multiFactor = 2
            }
            
            if(Audio_MCU_Option3 != nil){
                if((Audio_MCU_Option3! & 0x02) == 0x02){
                    multiFactor = 6
                }
            }
            
            if(defaultCoeff_Name == "Flat"){
                Frequency_1.text = String(1000*multiFactor)
                Frequency_2.text = String(1200*multiFactor)
                Frequency_3.text = String(2000*multiFactor)
                Frequency_4.text = String(3500*multiFactor)
                Frequency_5.text = String(4900*multiFactor)
                Gain_1.text = String(GTodB(1.0))
                Gain_2.text = String(GTodB(1.0))
                Gain_3.text = String(GTodB(1.0))
                Gain_4.text = String(GTodB(1.0))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = "1.0"
                Q_2.text = "1.0"
                Q_3.text = "1.0"
                Q_4.text = "1.0"
                Q_5.text = "1.0"
                stage.selectedIndex = 4
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 5)
                //SampleFreq = 8000 * multiFactor
            }
            else if(defaultCoeff_Name == "Boost"){
                Frequency_1.text = String(32*multiFactor)
                Frequency_2.text = String(250*multiFactor)
                Frequency_3.text = String(1000*multiFactor)
                Frequency_4.text = String(2000*multiFactor)
                Frequency_5.text = String(3900*multiFactor)
                Gain_1.text = String(GTodB(1.92866228512964))
                Gain_2.text = String(GTodB(1.31707666338300))
                Gain_3.text = String(GTodB(0.89032258594553))
                Gain_4.text = String(GTodB(1.0))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(0.43293644239969)
                Q_2.text = String(0.35638544866886)
                Q_3.text = String(0.74086372129852)
                Q_4.text = "1.0"
                Q_5.text = "1.0"
                stage.selectedIndex = 2 //"stage = 3"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 3)
                //SampleFreq = 8000 * multiFactor
            }
            else if(defaultCoeff_Name == "Treble"){
                Frequency_1.text = String(500*multiFactor)
                Frequency_2.text = String(1000*multiFactor)
                Frequency_3.text = String(2500*multiFactor)
                Frequency_4.text = String(3000*multiFactor)
                Frequency_5.text = String(3900*multiFactor)
                Gain_1.text = String(GTodB(0.98658758766945))
                Gain_2.text = String(GTodB(1.00878203417550))
                Gain_3.text = String(GTodB(1.29198710848956))
                Gain_4.text = String(GTodB(1.96821721203325))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(1.01016346823979)
                Q_2.text = String(1.15128009113710)
                Q_3.text = String(0.49213181332384)
                Q_4.text = String(0.49349647103298)
                Q_5.text = "1.0"
                stage.selectedIndex = 3 //"stage = 4"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 4)
                //SampleFreq = 8000 * multiFactor
            }
            else if(defaultCoeff_Name == "Pop"){
                Frequency_1.text = String(32*multiFactor)
                Frequency_2.text = String(125*multiFactor)
                Frequency_3.text = String(750*multiFactor)
                Frequency_4.text = String(2500*multiFactor)
                Frequency_5.text = String(3500*multiFactor)
                Gain_1.text = String(GTodB(0.98856685820696))
                Gain_2.text = String(GTodB(1.09005980510416))
                Gain_3.text = String(GTodB(1.75408420359879))
                Gain_4.text = String(GTodB(1.09005980510416))
                Gain_5.text = String(GTodB(0.98691533400276))
                Q_1.text = String(0.98620270998901)
                Q_2.text = String(0.41931697684387)
                Q_3.text = String(0.58185820541141)
                Q_4.text = String(0.41931697684387)
                Q_5.text = String(0.80454192483280)
                stage.selectedIndex = 4 //"stage = 5"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(0.84))
                UpdateStage(stage: 5)
                //SampleFreq = 8000 * multiFactor
            }
            else if(defaultCoeff_Name == "Rock"){
                Frequency_1.text = String(32*multiFactor)
                Frequency_2.text = String(250*multiFactor)
                Frequency_3.text = String(1000*multiFactor)
                Frequency_4.text = String(1500*multiFactor)
                Frequency_5.text = String(3000*multiFactor)
                Gain_1.text = String(GTodB(1.97695226195262))
                Gain_2.text = String(GTodB(1.08916167643889))
                Gain_3.text = String(GTodB(0.84955461886004))
                Gain_4.text = String(GTodB(1.05051608753516))
                Gain_5.text = String(GTodB(1.99446106397164))
                Q_1.text = String(0.40267199696855)
                Q_2.text = String(0.31218212846435)
                Q_3.text = String(0.32220330969738)
                Q_4.text = String(0.61265796514266)
                Q_5.text = String(0.36854006186122)
                stage.selectedIndex = 4 //"stage = 5"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 5)
                //SampleFreq = 8000 * multiFactor
            }
            else if(defaultCoeff_Name == "Classic"){
                Frequency_1.text = String(250*multiFactor)
                Frequency_2.text = String(750*multiFactor)
                Frequency_3.text = String(1000*multiFactor)
                Frequency_4.text = String(2500*multiFactor)
                Frequency_5.text = String(3900*multiFactor)
                Gain_1.text = String(GTodB(1.25308149309474))
                Gain_2.text = String(GTodB(0.42952440917061))
                Gain_3.text = String(GTodB(1.00627225160375))
                Gain_4.text = String(GTodB(1.0))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(1.84047455179705)
                Q_2.text = String(0.21370992368501)
                Q_3.text = String(0.11611675014813)
                Q_4.text = String(1.0)
                Q_5.text = String(1.0)
                stage.selectedIndex = 2 //"stage = 3"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.68))
                UpdateStage(stage: 3)
                //SampleFreq = 8000 * multiFactor
            }
            else if(defaultCoeff_Name == "Jazz"){
                Frequency_1.text = String(125*multiFactor)
                Frequency_2.text = String(250*multiFactor)
                Frequency_3.text = String(750*multiFactor)
                Frequency_4.text = String(2500*multiFactor)
                Frequency_5.text = String(3800*multiFactor)
                Gain_1.text = String(GTodB(0.80807222401813))
                Gain_2.text = String(GTodB(1.19993741976506))
                Gain_3.text = String(GTodB(0.51932714953227))
                Gain_4.text = String(GTodB(1.00345679502982))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(0.86264758926996)
                Q_2.text = String(1.13540466707967)
                Q_3.text = String(0.27313980983445)
                Q_4.text = String(0.18446552753420)
                Q_5.text = String(1.0)
                stage.selectedIndex = 3 //"stage = 4"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.585))
                UpdateStage(stage: 4)
                //SampleFreq = 8000 * multiFactor
            }
            else if(defaultCoeff_Name == "Dance"){
                Frequency_1.text = String(64*multiFactor)
                Frequency_2.text = String(250*multiFactor)
                Frequency_3.text = String(2000*multiFactor)
                Frequency_4.text = String(3000*multiFactor)
                Frequency_5.text = String(3900*multiFactor)
                Gain_1.text = String(GTodB(2.05339743428121))
                Gain_2.text = String(GTodB(0.74175797823560))
                Gain_3.text = String(GTodB(1.68327534931948))
                Gain_4.text = String(GTodB(0.98185132489032))
                Gain_5.text = String(GTodB(1.0))
                Q_1.text = String(0.51647294364063)
                Q_2.text = String(0.69485573711835)
                Q_3.text = String(0.51283185235765)
                Q_4.text = String(0.38117808090389)
                Q_5.text = String(1.0)
                stage.selectedIndex = 3 //"stage = 4"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 4)
                //SampleFreq = 8000 * multiFactor
            }
            else if(defaultCoeff_Name == "R&B"){
                Frequency_1.text = String(64*multiFactor)
                Frequency_2.text = String(500*multiFactor)
                Frequency_3.text = String(1500*multiFactor)
                Frequency_4.text = String(2400*multiFactor)
                Frequency_5.text = String(3900*multiFactor)
                Gain_1.text = String(GTodB(1.79448846234098))
                Gain_2.text = String(GTodB(0.55980089306381))
                Gain_3.text = String(GTodB(1.00717135310177))
                Gain_4.text = String(GTodB(1.10121648869244))
                Gain_5.text = String(GTodB(1.06542494612799))
                Q_1.text = String(2.88385310493725)
                Q_2.text = String(0.68953348916826)
                Q_3.text = String(0.20725350274938)
                Q_4.text = String(0.88950806827823)
                Q_5.text = String(1.02619582010820)
                stage.selectedIndex = 4 //"stage = 5"
                stage.text = stage_table[stage.selectedIndex!]
                global_gain.text = String(GTodB(1.0))
                UpdateStage(stage: 5)
                //SampleFreq = 8000 * multiFactor
            }
        }
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if(sample_frequency.text != nil && textField.tag == 200){
            if let Freq_value = Double(sample_frequency.text!){
                if(Freq_value >= 1 && Freq_value <= 200000){
                    print("New Sample Freq = \(Freq_value)")
                }
                else{
                    sample_frequency.text = "48000"
                }
            }
            else{
                sample_frequency.text = "48000"
            }
        }
        else if(global_gain.text != nil && textField.tag == 100){
            if let GG_value = Double(global_gain.text!){
                if(GG_value >= -100 && GG_value <= 40){
                    print("New GGain = \(GG_value)")
                }
                else{
                    global_gain.text = "0"
                }
            }
            else{
                global_gain.text = "0"
            }
        }
        
        return true
    }
}
