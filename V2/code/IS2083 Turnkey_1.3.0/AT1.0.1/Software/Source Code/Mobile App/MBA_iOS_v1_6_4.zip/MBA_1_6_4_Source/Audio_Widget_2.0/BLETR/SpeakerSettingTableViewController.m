//
//  SpeakerSettingTableViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 22/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "SpeakerSettingTableViewController.h"
#import "UIView+Toast.h"

@interface SpeakerSettingTableViewController (){
    NSString *deviceName;
    NSString *fwVersion;
}

@end

@implementation SpeakerSettingTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _connectedPeripheral.fWVersionDelegate = self;
   
    myTableView.delegate = self;
    myTableView.dataSource = self;
    deviceName = [[NSString alloc]init];
    NSString *GAP_Name = _connectedPeripheral.deviceName;
    deviceName = _connectedPeripheral.advName;
    
    if(!([deviceName isEqualToString:GAP_Name])) {
        deviceName = _connectedPeripheral.deviceName;
        NSLog(@"Speaker name = %@",deviceName);
    }
    
    fwVersion = [[NSString alloc]init];
    [_connectedPeripheral sendReadICVersionInformation];
    //[_connectedPeripheral sendReadBTMVersion:0x01];
    self.title = @"Speaker Setting";
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button:%d - Entered: %@",(unsigned char)buttonIndex,[[alertView textFieldAtIndex:0] text]);
    if (buttonIndex == 1) {
        int limit = 26;
        NSMutableString *temp = [[[alertView textFieldAtIndex:0] text] mutableCopy];
        NSData *temp_data = [temp dataUsingEncoding:NSUTF8StringEncoding];
        while ([temp_data length]>limit) {
            [temp deleteCharactersInRange:NSMakeRange(temp.length -1, 1)];
            temp_data = [temp dataUsingEncoding:NSUTF8StringEncoding];
        }
        deviceName = [[[alertView textFieldAtIndex:0] text] mutableCopy];
        if(deviceName.length == 0){
            [self.navigationController.view makeToast:@"deviceName error"
                                             duration:1.5
                                             position:CSToastPositionBottom];
            return;
        }
        NSLog(@"devName = %@",deviceName);
        [_connectedPeripheral configureVendorParameter:0 deviceName:temp];
        [self.navigationController.view makeToast:@"Command has been send"
                                         duration:1.5
                                         position:CSToastPositionBottom];
        [myTableView reloadData];
        
        
    }
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSUInteger newLength = [textField.text length] + [string length] - range.length;
    return (newLength > 26) ? NO:YES;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    NSString *title = nil;
    title = @"Speaker Setting";
    return title;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell;// = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier" forIndexPath:indexPath];
    
    
    switch (indexPath.row) {
        case 0:{
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"IndicatorCell"];
            cell.textLabel.text = deviceName;
            cell.detailTextLabel.text = @"Edit";
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
            break;
            
        case 1:{
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"IndicatorCell"];
            cell.textLabel.text = @"Speaker Version";
            cell.detailTextLabel.text = fwVersion;
        }
            break;
            
        default:{
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"IndicatorCell"];
            cell.textLabel.text = @"";
        }

            break;
    }
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    switch (indexPath.row) {
        case 0:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Change Name" message:@"Please Enter new name:" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Done", nil];
            alert.alertViewStyle = UIAlertViewStylePlainTextInput;
            UITextField *alertTextField = [alert textFieldAtIndex:0];
            alertTextField.text = deviceName;
            alertTextField.keyboardType = UIKeyboardTypeDefault;
            alertTextField.placeholder = @"Enter speaker name";
            alertTextField.delegate = self;
            [alert show];
            [alert release];
        }
            break;
        default:
            break;
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - MyPeripheral fwVersion delegate
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateFwVersion:(unsigned char)version subVersion:(unsigned char)subVersion{
    
    fwVersion = [[NSString alloc] initWithFormat:@"v%02X.%02X",version,subVersion];
    [myTableView reloadData];
}

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateIcVersionIn:(NSString *)bodyVersion romVersion:(unsigned char)romVersion romSubVersion:(unsigned char)romSubVersion segment:(unsigned char)segment eepromTableVersion:(unsigned char)eepromTableVersion eepromTableSubVersion:(unsigned char)eepromTableSubVersion dspVersion:(unsigned char)dspVersion{
    if ([bodyVersion isEqualToString:@"5506_ROM_104"]) {
        fwVersion = [[NSString alloc] initWithFormat:@"v%02X.%02X",romVersion,romSubVersion];
        [myTableView reloadData];
    }else{
        [_connectedPeripheral sendReadBTMVersion:0x01];
    }
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)dealloc {
    [myTableView release];
    _connectedPeripheral.fWVersionDelegate = nil;
    [super dealloc];
}
@end
