//
//  MainMenuCell.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/7/19.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit

class MainMenuCell: UICollectionViewCell {
    
    @IBOutlet weak var appNameLabel: UILabel!
    @IBOutlet var evbNameLabel: UILabel!
    @IBOutlet var appImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        appNameLabel.lineBreakMode = .byWordWrapping // notice the 'b' instead of 'B'
        appNameLabel.numberOfLines = 0
        // Initialization code
    }
    
    func setAppName(name: String) {
        self.appNameLabel.text = name
    }
    
    func setEvbName(name: String) {
        self.evbNameLabel.text = name
    }
    
    func setAppImage(imageName: String) {
        let myImage: UIImage = UIImage(named: imageName)!
        self.appImage.image = myImage
    }
    
}

