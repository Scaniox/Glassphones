//
//  HomeScreenViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 25/01/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CBController.h"
//#import "DeviceInfo.h"

@class MainViewController;

@interface HomeScreenViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CBPeripheralManagerDelegate,CBControllerDelegate,UIGestureRecognizerDelegate,UIActionSheetDelegate>{
    MyPeripheral *controlPeripheral;
    CBPeripheralManager *pmgr;
}
@property (retain, nonatomic) IBOutlet UITableView *DeviceTableView;
@property (retain, nonatomic) IBOutlet UITableView *PersonalGroupingRecordTableView;
@property (retain, nonatomic) IBOutlet UIButton *ScanButton;
@property (assign) CBManagerState BtState;
- (IBAction)ScanButtonPressed:(id)sender;

@end
