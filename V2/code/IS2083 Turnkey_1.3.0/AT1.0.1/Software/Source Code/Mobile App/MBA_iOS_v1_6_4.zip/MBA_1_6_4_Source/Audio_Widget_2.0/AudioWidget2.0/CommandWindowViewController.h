//
//  CommandWindowViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 05/12/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPeripheral.h"

@interface CommandWindowViewController : UIViewController<UITextFieldDelegate,UITextViewDelegate,MyPeripheralDelegate>{
    IBOutlet UITextView *logTextView;
    IBOutlet UIButton *sendCommandButton;
    IBOutlet UITextField *commandField;
    UIBarButtonItem *clearButton;
}
@property(retain) MyPeripheral    *connectedPeripheral;
- (IBAction)pressSendCommandButton:(id)sender;
@end
