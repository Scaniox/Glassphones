//
//  EqualizerManualSettingViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 14/03/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPeripheral.h"

@interface EqualizerManualSettingViewController : UIViewController<MyPeripheralDelegate,UITextFieldDelegate>{
    
    IBOutlet UISlider *gainSlider5;
    IBOutlet UISlider *gainSlider4;
    IBOutlet UISlider *gainSlider3;
    IBOutlet UISlider *gainSlider2;
    IBOutlet UISlider *gainSlider1;
    IBOutlet UITextField *qField5;
    IBOutlet UITextField *qField4;
    IBOutlet UITextField *qField3;
    IBOutlet UITextField *qField2;
    IBOutlet UITextField *qField1;
    IBOutlet UITextField *freqTextField5;
    IBOutlet UITextField *freqTextField4;
    IBOutlet UITextField *freqTextField3;
    IBOutlet UITextField *freqTextField1;
    IBOutlet UITextField *freqTextField2;
}
@property(retain) MyPeripheral    *connectedPeripheral;
- (IBAction)gain1ValueChanged:(id)sender;
- (IBAction)gain5ValueChanged:(id)sender;
- (IBAction)gain2ValueChanged:(id)sender;
- (IBAction)gain3ValueChanged:(id)sender;
- (IBAction)gain4ValueChanged:(id)sender;


@end
