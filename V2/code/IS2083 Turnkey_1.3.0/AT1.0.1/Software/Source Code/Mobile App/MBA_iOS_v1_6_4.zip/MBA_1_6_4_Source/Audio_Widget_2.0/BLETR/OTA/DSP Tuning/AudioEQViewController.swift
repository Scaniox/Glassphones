//
//  AudioEQViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/5/28.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class AudioEQViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, DSPTuningDelegate {

    @IBOutlet var Equalizer: VKCheckbox!
    @IBOutlet var EQ_Setting: DropDown!
    @IBOutlet var EQ_Mask_Table: UITableView!
    @IBOutlet var TuneDSP: UIButton!
    @IBOutlet var CustomEQ_Button: UIButton!
    @IBOutlet var DSPState: UILabel!
    
    var DSPManager: TuneDSPManager?
    
    var EQ_Mask: UInt16 = 0
    var EQ_State: [Bool] = [Bool]()
    
    var selectedRows = [Int]()
    
    let EQ_table = ["Off", "SOFT", "BASS", "TREBLE", "CLASSICAL", "ROCK", "JAZZ", "POP", "DANCE", "Rhythm and Blues", "Custom EQ"]
    
    let ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[AudioEQViewController]viewDidLoad")
        
        TuneDSP.layer.cornerRadius = 15.0
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.AudioEQ_Delegate = self
        
        EQ_Mask_Table.delegate = self
        EQ_Mask_Table.dataSource = self
        
        Equalizer.checkboxValueChangedBlock = {
            isOn in
            print("Basic checkbox is \(isOn ? "ON" : "OFF")")
        }
        
        EQ_Setting.optionArray = EQ_table
        EQ_Setting.optionIds = ids
        
        EQ_Setting.isSearchEnable = false
        
        EQ_Setting.didSelect{(selectedText , index , id) in
            print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")}
        
        EQ_Setting.listWillAppear {
            self.EQ_Mask_Table.isHidden = true
        }
        
        EQ_Setting.listDidDisappear {
            if(self.EQ_Mask_Table.isHidden == true){
                self.EQ_Mask_Table.isHidden = false
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPState.text = DSPManager?.DSP_DUT_State
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "Audio EQ")
        
        if(DSPManager?.BLE_Connection != nil && DSPManager?.BLE_Connection == false){
            self.navigationController?.popViewController(animated: true)
            return
        }
        
        Audio_EQ_Init()
        
        /*
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport){
            CustomEQ_Button.isEnabled = false
            DSPTuningDisable()
        }*/
        
        if(DSPState.text == "DSP Status: "){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
        
        if((DSPManager?.EQMode != nil) && (DSPManager?.EQ_Data.count == 0x54)){
            DSPTuningEnable()
        }
        else{
            DSPTuningDisable()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[AudioEQ]viewWillDisappear")
        
        if((DSPManager?.EQMode != nil) && (DSPManager?.EQ_Data.count == 0x54)){
            if(DSPManager?.EQMode! == 0x01){
                //Audio EQ
                DSPManager?.DSPQueueData(module: 0x0C, cfg: 0x04, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
            /*
            else if(DSPManager?.EQMode! == 0x02){
                //SPK EQ
                DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x0F, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x03){
                //MIC EQ
                DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x11, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x04){
                //SPK_mSBC EQ
                DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x10, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x05){
                //MIC_mSBC EQ
                DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x12, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }*/
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "AudioEQ_Segue") {
            print("prepareForSegue:AudioEQ")
            let vc = segue.destination as? EqCoeffViewController
            if(vc != nil){
                vc?.EQMode = 0x01
            }
        }
    }
    
    func Audio_EQ_Init(){
        print("Audio_EQ_Init")
        
        let (EQ_OnOff,Default_EQ) = (DSPManager?.GetDefaultEqualizerMode())!
        
        if(EQ_OnOff == 0x20){
            Equalizer.setOn(true)
        }
        else{
            Equalizer.setOn(false)
        }
        Equalizer.isUserInteractionEnabled = false
        
        EQ_Setting.selectedIndex = Int(Default_EQ!)
        EQ_Setting.text = EQ_table[EQ_Setting.selectedIndex!]
        EQ_Setting.isEnabled = false
        
        EQ_Mask = (DSPManager?.GetAudioEQMask())!
        
        print("EQ_Mask = \(EQ_Mask)")
        
        let EQ_check1 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check1 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check1, EQ_State = \(EQ_check1)")
        
        let EQ_check2 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check2 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check2, EQ_State = \(EQ_check2)")
        
        let EQ_check3 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check3 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check3, EQ_State = \(EQ_check3)")
        
        let EQ_check4 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check4 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check4, EQ_State = \(EQ_check4)")
        
        let EQ_check5 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check5 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check5, EQ_State = \(EQ_check5)")
        
        let EQ_check6 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check6 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check6, EQ_State = \(EQ_check6)")
        
        let EQ_check7 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check7 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check7, EQ_State = \(EQ_check7)")
        
        let EQ_check8 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check8 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check8, EQ_State = \(EQ_check8)")
        
        let EQ_check9 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check9 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check9, EQ_State = \(EQ_check9)")
        
        let EQ_check10 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check10 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check10, EQ_State = \(EQ_check10)")
        
        let EQ_check11 = EQ_Mask & 1
        EQ_Mask = EQ_Mask >> 1
        if(EQ_check11 != 0){
            EQ_State.append(true)
        }
        else{
            EQ_State.append(false)
        }
        print("EQ_check11, EQ_State = \(EQ_check11)")
        
        EQ_Mask_Table.reloadData()
        
        //EQ_Mask_Table.isUserInteractionEnabled = false;
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "EQ Mask Selection"
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return 3
        
        return 11
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! EQTableViewCell
        
        cell.setTitle(EQ_table[indexPath.row])
        cell.Setting.setOn(EQ_State[indexPath.row])
        cell.isUserInteractionEnabled = false
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 30 //or whatever you need
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if !self.selectedRows.contains(indexPath.row)
        {
            self.selectedRows.append(indexPath.row)
        }
        else
        {
            let index = self.selectedRows.index(of: indexPath.row)!
            self.selectedRows.remove(at: index)
        }
        
        let selected = self.selectedRows.contains(indexPath.row)
        let cell = tableView.cellForRow(at: indexPath) as! EQTableViewCell
        cell.Setting.setOn(selected, animated: true)
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }

    @IBAction func DSPTuning(_ sender: Any) {
        
        if((DSPManager?.EQMode != nil) && (DSPManager?.EQ_Data.count == 0x54)){
            if(DSPManager?.EQMode! == 0x01){
                print("[Audio EQ]DSP Tuning...")
                DSPManager?.DSPTuning(module: 0x0C, cfg: 0x04, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
        }
    }
    
    @IBAction func CustomEQ(_ sender: Any) {
        print("Custom EQ")
        
        //EQ_Mask_Table.isHidden = true
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[AudioEQ] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        print("[Audio EQ] RefreshModuleData")
    }
    
    func RefreshParametersData(dat:Data) {
        
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            CustomEQ_Button.isEnabled = false
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            CustomEQ_Button.isEnabled = true
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
