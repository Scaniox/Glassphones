//
//  SlidingTabsTab.h
//  SlidingTabs
//
//  Created by Mathew Piccinato on 5/12/11.
//  Copyright 2011 Constructt. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SlidingTabsTab : UIView {
    
}

@end
