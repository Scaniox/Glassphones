//
//  MBDRCViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/5.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class MBDRCViewController: UIViewController, DSPTuningDelegate{
    
    @IBOutlet var parameters: DropDown!
    @IBOutlet var Low_band: DropDown!
    @IBOutlet var Middle_band: DropDown!
    @IBOutlet var High_band: DropDown!
    @IBOutlet var Bass_enhancement: DropDown!
    @IBOutlet var Cutoff_Freq: DropDown!
    @IBOutlet var TuneDSP: UIButton!
    @IBOutlet var Cutoff_freq_label: UILabel!
    @IBOutlet var DSPState: UILabel!
    
    var DSPManager: TuneDSPManager?
    var MBDRC_Data: [UInt8] = [UInt8]()
    //var MBDRC_Prev_Data: [UInt8] = [UInt8]()
    
    var Parameters_List: Bool!
    var Low_band_List: Bool!
    var Middle_band_List: Bool!
    var High_band_List: Bool!
    var Bass_List: Bool!
    var Cutoff_freq_List: Bool!
    
    let param_table = ["Knee Th", "Compression Ratio", "Make-Up Gain", "Attack Time", "Release Time"]
    let param_ids = [1, 2, 3, 4, 5]
    
    let Knee_Th_table = ["-6dBov", "-12dBov", "-18dBov", "-24dBov"]
    let Knee_Th_ids = [1, 2, 3, 4]
    let CR_table = ["2/3", "1/2", "1/3", "1/4"] //Compression Ratio
    let CR_ids = [1, 2, 3, 4]
    let Gain_table = ["0dB", "1dB", "2dB", "3dB", "4dB", "5dB", "6dB", "7dB", "8dB", "9dB", "10dB", "11dB"]   //Make-Up Gain
    let Gain_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    let Attack_time_table = ["10ms", "20ms", "50ms", "100ms"]
    let Attack_time_ids = [1, 2, 3, 4]
    let Release_time_table = ["50ms", "100ms", "200ms", "700ms"]
    let Release_time_ids = [1, 2, 3, 4]
    
    let Bass_table = ["0x00", "0x01", "0x02", "0x03", "0x04", "0x05", "0x06", "0x07"]
    let Bass_ids = [1, 2, 3, 4, 5, 6, 7, 8]
    let Cutoff_freq_table = ["100Hz", "150Hz", "200Hz", "300Hz"]
    let Cutoff_freq_ids = [1, 2, 3, 4]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("[MBDRCViewController] viewDidLoad")

        // Do any additional setup after loading the view.
        TuneDSP.layer.cornerRadius = 15.0
        
        DSPManager = TuneDSPManager.sharedInstance()
        DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "MBDRC")
        
        Parameters_List = false
        Low_band_List = false
        Middle_band_List = false
        High_band_List = false
        Bass_List = false
        Cutoff_freq_List = false
        
        parameters.isSearchEnable = false
        Low_band.isSearchEnable = false
        Middle_band.isSearchEnable = false
        High_band.isSearchEnable = false
        Bass_enhancement.isSearchEnable = false
        Cutoff_Freq.isSearchEnable = false
        
        parameters.optionArray = param_table
        parameters.optionIds = param_ids
        
        Low_band.optionArray = param_table
        Low_band.optionIds = param_ids
        
        Middle_band.optionArray = param_table
        Middle_band.optionIds = param_ids
        
        High_band.optionArray = param_table
        High_band.optionIds = param_ids
        
        Bass_enhancement.optionArray = Bass_table
        Bass_enhancement.optionIds = Bass_ids
        
        Cutoff_Freq.optionArray = Cutoff_freq_table
        Cutoff_Freq.optionIds = Cutoff_freq_ids
        
        parameters.didSelect{(selectedText , index , id) in
            print("[parameters]Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            print("param index = \(self.parameters.selectedIndex!)")
            
            if(selectedText == "Knee Th"){
                self.Low_band.optionArray = self.Knee_Th_table
                self.Low_band.optionIds = self.Knee_Th_ids
                
                self.Middle_band.optionArray = self.Knee_Th_table
                self.Middle_band.optionIds = self.Knee_Th_ids
                
                self.High_band.optionArray = self.Knee_Th_table
                self.High_band.optionIds = self.Knee_Th_ids
                
                print("MBDRC byte 1 = \(self.MBDRC_Data[0])")
                print("bit[0:1] = \(Int(self.MBDRC_Data[0] & 0x03))")
                self.Low_band.selectedIndex = Int(self.MBDRC_Data[0] & 0x03)
                self.Low_band.text = self.Knee_Th_table[self.Low_band.selectedIndex!]
                print("bit[2:3] = \((Int(self.MBDRC_Data[0] & 0x0C)) >> 2)")
                self.Middle_band.selectedIndex = (Int(self.MBDRC_Data[0] & 0x0C)) >> 2
                self.Middle_band.text = self.Knee_Th_table[self.Middle_band.selectedIndex!]
                print("bit[4:5] = \((Int(self.MBDRC_Data[0] & 0x30)) >> 4)")
                self.High_band.selectedIndex = (Int(self.MBDRC_Data[0] & 0x30)) >> 4
                self.High_band.text = self.Knee_Th_table[self.High_band.selectedIndex!]
            }
            else if(selectedText == "Compression Ratio"){
                self.Low_band.optionArray = self.CR_table
                self.Low_band.optionIds = self.CR_ids
                
                self.Middle_band.optionArray = self.CR_table
                self.Middle_band.optionIds = self.CR_ids
                
                self.High_band.optionArray = self.CR_table
                self.High_band.optionIds = self.CR_ids
                
                print("MBDRC byte 2 = \(self.MBDRC_Data[1])")
                print("bit[0:1] = \(Int(self.MBDRC_Data[1] & 0x03))")
                self.Low_band.selectedIndex = Int(self.MBDRC_Data[1] & 0x03)
                self.Low_band.text = self.CR_table[self.Low_band.selectedIndex!]
                print("bit[2:3] = \((Int(self.MBDRC_Data[1] & 0x0C)) >> 2)")
                self.Middle_band.selectedIndex = (Int(self.MBDRC_Data[1] & 0x0C)) >> 2
                self.Middle_band.text = self.CR_table[self.Middle_band.selectedIndex!]
                print("bit[4:5] = \((Int(self.MBDRC_Data[1] & 0x30)) >> 4)")
                self.High_band.selectedIndex = (Int(self.MBDRC_Data[1] & 0x30)) >> 4
                self.High_band.text = self.CR_table[self.High_band.selectedIndex!]
                print("bit[6:7] = \((Int(self.MBDRC_Data[1] & 0xC0)) >> 6)")
                
            }
            else if(selectedText == "Make-Up Gain"){
                self.Low_band.optionArray = self.Gain_table
                self.Low_band.optionIds = self.Gain_ids
                
                self.Middle_band.optionArray = self.Gain_table
                self.Middle_band.optionIds = self.Gain_ids
                
                self.High_band.optionArray = self.Gain_table
                self.High_band.optionIds = self.Gain_ids
                
                print("MBDRC byte 3 = \(self.MBDRC_Data[2])")
                print("bit[0:3] = \(Int(self.MBDRC_Data[2] & 0x0f))")
                self.Low_band.selectedIndex = Int(self.MBDRC_Data[2] & 0x0f)
                self.Low_band.text = self.Gain_table[self.Low_band.selectedIndex!]
                print("bit[4:7] = \((Int(self.MBDRC_Data[2] & 0xf0)) >> 4)")
                self.Middle_band.selectedIndex = (Int(self.MBDRC_Data[2] & 0xf0)) >> 4
                self.Middle_band.text = self.Gain_table[self.Middle_band.selectedIndex!]
                print("MBDRC byte 4 = \(self.MBDRC_Data[3])")
                print("bit[0:3] = \(Int(self.MBDRC_Data[3] & 0x0f))")
                self.High_band.selectedIndex = Int(self.MBDRC_Data[3] & 0x0f)
                self.High_band.text = self.Gain_table[self.High_band.selectedIndex!]
            }
            else if(selectedText == "Attack Time"){
                self.Low_band.optionArray = self.Attack_time_table
                self.Low_band.optionIds = self.Attack_time_ids
                
                self.Middle_band.optionArray = self.Attack_time_table
                self.Middle_band.optionIds = self.Attack_time_ids
                
                self.High_band.optionArray = self.Attack_time_table
                self.High_band.optionIds = self.Attack_time_ids
                
                print("MBDRC byte 7 = \(self.MBDRC_Data[6])")
                print("bit[0:1] = \(Int(self.MBDRC_Data[6] & 0x03))")
                self.Low_band.selectedIndex = Int(self.MBDRC_Data[6] & 0x03)
                self.Low_band.text = self.Attack_time_table[self.Low_band.selectedIndex!]
                print("bit[2:3] = \((Int(self.MBDRC_Data[6] & 0x0C)) >> 2)")
                self.Middle_band.selectedIndex = (Int(self.MBDRC_Data[6] & 0x0C)) >> 2
                self.Middle_band.text = self.Attack_time_table[self.Middle_band.selectedIndex!]
                print("bit[4:5] = \((Int(self.MBDRC_Data[6] & 0x30)) >> 4)")
                self.High_band.selectedIndex = (Int(self.MBDRC_Data[6] & 0x30)) >> 4
                self.High_band.text = self.Attack_time_table[self.High_band.selectedIndex!]
                
            }
            else if(selectedText == "Release Time"){
                self.Low_band.optionArray = self.Release_time_table
                self.Low_band.optionIds = self.Release_time_ids
                
                self.Middle_band.optionArray = self.Release_time_table
                self.Middle_band.optionIds = self.Release_time_ids
                
                self.High_band.optionArray = self.Release_time_table
                self.High_band.optionIds = self.Release_time_ids
                
                print("MBDRC byte 4 = \(self.MBDRC_Data[3])")
                print("bit[4:5] = \((Int(self.MBDRC_Data[3] & 0x30)) >> 4)")
                self.Low_band.selectedIndex = (Int(self.MBDRC_Data[3] & 0x30)) >> 4
                self.Low_band.text = self.Release_time_table[self.Low_band.selectedIndex!]
                print("bit[6:7] = \((Int(self.MBDRC_Data[3] & 0xC0)) >> 6)")
                self.Middle_band.selectedIndex = (Int(self.MBDRC_Data[3] & 0xC0)) >> 6
                self.Middle_band.text = self.Release_time_table[self.Middle_band.selectedIndex!]
                print("MBDRC byte 7 = \(self.MBDRC_Data[6])")
                print("bit[6:7] = \((Int(self.MBDRC_Data[6] & 0xC0)) >> 6)")
                self.High_band.selectedIndex = (Int(self.MBDRC_Data[6] & 0xC0)) >> 6
                self.High_band.text = self.Release_time_table[self.High_band.selectedIndex!]
            }
        }
        
        Low_band.didSelect{(selectedText , index , id) in
            print("[Low_band]Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            
            if(self.parameters.selectedIndex == 0){
                if(self.Low_band.text != self.Knee_Th_table[self.Low_band.selectedIndex!]){
                    print("[Knee Th] Low band data changed! = \(self.Knee_Th_table[self.Low_band.selectedIndex!])")
                    print("MBDRC_Data[0] = \(String(format: "0x%02X",self.MBDRC_Data[0]))")
                    self.MBDRC_Data[0] &= ~(0x03)
                    self.MBDRC_Data[0] |= UInt8(self.Low_band.selectedIndex!)
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[0]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 1){
                if(self.Low_band.text != self.CR_table[self.Low_band.selectedIndex!]){
                    print("[Compression Ratio] Low band data changed! = \(self.CR_table[self.Low_band.selectedIndex!])")
                    print("MBDRC_Data[1] = \(String(format: "0x%02X",self.MBDRC_Data[1]))")
                    self.MBDRC_Data[1] &= ~(0x03)
                    self.MBDRC_Data[1] |= UInt8(self.Low_band.selectedIndex!)
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[1]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 2){
                if(self.Low_band.text != self.Gain_table[self.Low_band.selectedIndex!]){
                    print("[Make-Up Gain] Low band data changed! = \(self.Gain_table[self.Low_band.selectedIndex!])")
                    print("MBDRC_Data[2] = \(String(format: "0x%02X",self.MBDRC_Data[2]))")
                    self.MBDRC_Data[2] &= ~(0x0f)
                    self.MBDRC_Data[2] |= UInt8(self.Low_band.selectedIndex!)
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[2]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 3){
                if(self.Low_band.text != self.Attack_time_table[self.Low_band.selectedIndex!]){
                    print("[Attack Time] Low band data changed! = \(self.Attack_time_table[self.Low_band.selectedIndex!])")
                    print("MBDRC_Data[6] = \(String(format: "0x%02X",self.MBDRC_Data[6]))")
                    self.MBDRC_Data[6] &= ~(0x03)
                    self.MBDRC_Data[6] |= UInt8(self.Low_band.selectedIndex!)
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[6]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 4){
                if(self.Low_band.text != self.Release_time_table[self.Low_band.selectedIndex!]){
                    print("[Release Time] Low band data changed! = \(self.Release_time_table[self.Low_band.selectedIndex!])")
                    print("MBDRC_Data[3] = \(String(format: "0x%02X",self.MBDRC_Data[3]))")
                    self.MBDRC_Data[3] &= ~(0x30)
                    self.MBDRC_Data[3] |= UInt8(self.Low_band.selectedIndex!) << 4
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[3]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
        }
        
        Middle_band.didSelect{(selectedText , index , id) in
            print("[Middle_band]Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            
            if(self.parameters.selectedIndex == 0){
                if(self.Middle_band.text != self.Knee_Th_table[self.Middle_band.selectedIndex!]){
                    print("[Knee Th] Middle band data changed! = \(self.Knee_Th_table[self.Middle_band.selectedIndex!])")
                    print("MBDRC_Data[0] = \(String(format: "0x%02X",self.MBDRC_Data[0]))")
                    self.MBDRC_Data[0] &= ~(0x0C)
                    self.MBDRC_Data[0] |= UInt8(self.Middle_band.selectedIndex!) << 2
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[0]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 1){
                if(self.Middle_band.text != self.CR_table[self.Middle_band.selectedIndex!]){
                    print("[Compression Ratio] Middle band data changed! = \(self.CR_table[self.Middle_band.selectedIndex!])")
                    print("MBDRC_Data[1] = \(String(format: "0x%02X",self.MBDRC_Data[1]))")
                    self.MBDRC_Data[1] &= ~(0x0C)
                    self.MBDRC_Data[1] |= UInt8(self.Middle_band.selectedIndex!) << 2
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[1]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 2){
                if(self.Middle_band.text != self.Gain_table[self.Middle_band.selectedIndex!]){
                    print("[Make-Up Gain] Middle band data changed! = \(self.Gain_table[self.Middle_band.selectedIndex!])")
                    print("MBDRC_Data[2] = \(String(format: "0x%02X",self.MBDRC_Data[2]))")
                    self.MBDRC_Data[2] &= ~(0xf0)
                    self.MBDRC_Data[2] |= UInt8(self.Middle_band.selectedIndex!) << 4
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[2]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 3){
                if(self.Middle_band.text != self.Attack_time_table[self.Middle_band.selectedIndex!]){
                    print("[Attack Time] Middle band data changed! = \(self.Attack_time_table[self.Middle_band.selectedIndex!])")
                    print("MBDRC_Data[6] = \(String(format: "0x%02X",self.MBDRC_Data[6]))")
                    self.MBDRC_Data[6] &= ~(0x0C)
                    self.MBDRC_Data[6] |= UInt8(self.Middle_band.selectedIndex!) << 2
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[6]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 4){
                if(self.Middle_band.text != self.Release_time_table[self.Middle_band.selectedIndex!]){
                    print("[Release Time] Middle band data changed! = \(self.Release_time_table[self.Middle_band.selectedIndex!])")
                    print("MBDRC_Data[3] = \(String(format: "0x%02X",self.MBDRC_Data[3]))")
                    self.MBDRC_Data[3] &= ~(0xC0)
                    self.MBDRC_Data[3] |= UInt8(self.Middle_band.selectedIndex!) << 6
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[3]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
        }
        
        High_band.didSelect{(selectedText , index , id) in
            print("[High_band]Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            
            if(self.parameters.selectedIndex == 0){
                if(self.High_band.text != self.Knee_Th_table[self.High_band.selectedIndex!]){
                    print("[Knee Th] High band data changed! = \(self.Knee_Th_table[self.High_band.selectedIndex!])")
                    print("MBDRC_Data[0] = \(String(format: "0x%02X",self.MBDRC_Data[0]))")
                    self.MBDRC_Data[0] &= ~(0x30)
                    self.MBDRC_Data[0] |= UInt8(self.High_band.selectedIndex!) << 4
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[0]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 1){
                if(self.High_band.text != self.CR_table[self.High_band.selectedIndex!]){
                    print("[Compression Ratio] High band data changed! = \(self.CR_table[self.High_band.selectedIndex!])")
                    print("MBDRC_Data[1] = \(String(format: "0x%02X",self.MBDRC_Data[1]))")
                    self.MBDRC_Data[1] &= ~(0x30)
                    self.MBDRC_Data[1] |= UInt8(self.High_band.selectedIndex!) << 4
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[1]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 2){
                if(self.High_band.text != self.Gain_table[self.High_band.selectedIndex!]){
                    print("[Make-Up Gain] High band data changed! = \(self.Gain_table[self.High_band.selectedIndex!])")
                    print("MBDRC_Data[3] = \(String(format: "0x%02X",self.MBDRC_Data[3]))")
                    self.MBDRC_Data[3] &= ~(0x0f)
                    self.MBDRC_Data[3] |= UInt8(self.High_band.selectedIndex!)
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[3]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 3){
                if(self.High_band.text != self.Attack_time_table[self.High_band.selectedIndex!]){
                    print("[Attack Time] High band data changed! = \(self.Attack_time_table[self.High_band.selectedIndex!])")
                    print("MBDRC_Data[6] = \(String(format: "0x%02X",self.MBDRC_Data[6]))")
                    self.MBDRC_Data[6] &= ~(0x30)
                    self.MBDRC_Data[6] |= UInt8(self.High_band.selectedIndex!) << 4
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[6]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
            else if(self.parameters.selectedIndex == 4){
                if(self.High_band.text != self.Release_time_table[self.High_band.selectedIndex!]){
                    print("[Release Time] High band data changed! = \(self.Release_time_table[self.High_band.selectedIndex!])")
                    print("MBDRC_Data[6] = \(String(format: "0x%02X",self.MBDRC_Data[6]))")
                    self.MBDRC_Data[6] &= ~(0xC0)
                    self.MBDRC_Data[6] |= UInt8(self.High_band.selectedIndex!) << 6
                    print("New value = \(String(format: "0x%02X",self.MBDRC_Data[6]))")
                    self.DSPTuningEnable()
                    self.Update_MBDRC_Param()
                }
            }
        }
        
        Cutoff_Freq.didSelect{(selectedText , index , id) in
            //print("[Cutoff_Freq]Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.Cutoff_Freq.text != self.Cutoff_freq_table[self.Cutoff_Freq.selectedIndex!]){
                print("[Cutoff_Freq] Data changed! = \(self.Cutoff_freq_table[self.Cutoff_Freq.selectedIndex!])")
                //let old_value = self.MBDRC_Data[0]
                print("MBDRC_Data[0] = \(String(format: "0x%02X",self.MBDRC_Data[0]))")
                self.MBDRC_Data[0] &= ~(0xC0)
                self.MBDRC_Data[0] |= UInt8(self.Cutoff_Freq.selectedIndex!) << 6
                //print("\(old_value),\(self.MBDRC_Data[0])")
                print("New value = \(String(format: "0x%02X",self.MBDRC_Data[0]))")
                self.DSPTuningEnable()
                self.Update_MBDRC_Param()
            }
        }
        
        Bass_enhancement.didSelect{(selectedText , index , id) in
            print("[Bass_enhancement]Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.Bass_enhancement.text != self.Bass_table[self.Bass_enhancement.selectedIndex!]){
                print("MBDRC_Data[7] = \(String(format: "0x%02X",self.MBDRC_Data[7]))")
                self.MBDRC_Data[7] = (0xC0 + UInt8(self.Bass_enhancement.selectedIndex!))
                print("New value = \(String(format: "0x%02X",self.MBDRC_Data[7]))")
                self.DSPTuningEnable()
                self.Update_MBDRC_Param()
            }
        }
        
        parameters.listWillAppear {
            print("parameters_List appear")
            self.Parameters_List = true
            
            if(self.Low_band_List){
                self.Low_band.hideList()
            }
            
            if(self.Middle_band_List){
                self.Middle_band.hideList()
            }
            
            if(self.High_band_List){
                self.High_band.hideList()
            }
            
            if(self.Bass_List){
                self.Bass_enhancement.hideList()
            }
            
            self.Low_band.isHidden = true
            self.Middle_band.isHidden = true
            self.High_band.isHidden = true
            self.Bass_enhancement.isHidden = true
        }
        
        parameters.listDidDisappear {
            print("parameters_List disappear")
            self.Parameters_List = false
            
            if(self.Low_band.isHidden == true){
                self.Low_band.isHidden = false
            }
            
            if(self.Middle_band.isHidden == true){
                self.Middle_band.isHidden = false
            }
            
            if(self.High_band.isHidden == true){
                self.High_band.isHidden = false
            }
            
            if(self.Bass_enhancement.isHidden == true){
                self.Bass_enhancement.isHidden = false
            }
        }
        
        Low_band.listWillAppear {
            print("lowband_List appear")
            self.Low_band_List = true
            
            if(self.Middle_band_List){
                self.Middle_band.hideList()
            }
            
            if(self.High_band_List){
                self.High_band.hideList()
            }
            
            if(self.Bass_List){
                self.Bass_enhancement.hideList()
            }
            
            self.Middle_band.isHidden = true
            self.High_band.isHidden = true
            self.Bass_enhancement.isHidden = true
        }
        
        Low_band.listDidDisappear {
            print("lowband_List disappear")
            self.Low_band_List = false
            
            if(self.Middle_band.isHidden == true && self.Parameters_List == false){
                self.Middle_band.isHidden = false
            }
            
            if(self.High_band.isHidden == true && self.Parameters_List == false){
                self.High_band.isHidden = false
            }
            
            if(self.Bass_enhancement.isHidden == true && self.Parameters_List == false){
                self.Bass_enhancement.isHidden = false
            }
        }
        
        Middle_band.listWillAppear {
            print("middleband_List appear")
            self.Middle_band_List = true
            
            if(self.High_band_List){
                self.High_band.hideList()
            }
            
            if(self.Bass_List){
                self.Bass_enhancement.hideList()
            }
            
            if(self.Cutoff_freq_List){
                self.Cutoff_Freq.hideList()
            }
            
            self.Cutoff_freq_label.isHidden = true
            self.Cutoff_Freq.isHidden = true
            self.High_band.isHidden = true
            self.Bass_enhancement.isHidden = true
        }
        
        Middle_band.listDidDisappear {
            print("middleband_List disappear")
            self.Middle_band_List = false
            
            if(self.High_band.isHidden == true && self.Parameters_List == false && self.Low_band_List == false){
                self.High_band.isHidden = false
            }
            
            if(self.Bass_enhancement.isHidden == true && self.Parameters_List == false && self.Low_band_List == false){
                self.Bass_enhancement.isHidden = false
            }
            
            if(self.Cutoff_Freq.isHidden == true){
                self.Cutoff_Freq.isHidden = false
            }
            self.Cutoff_freq_label.isHidden = false
            
        }
        
        High_band.listWillAppear {
            print("highband_List appear")
            self.High_band_List = true
            
            if(self.Bass_List){
                self.Bass_enhancement.hideList()
            }
            
            self.Cutoff_freq_label.isHidden = true
            self.Cutoff_Freq.isHidden = true
            
            self.Bass_enhancement.isHidden = true
            self.TuneDSP.isHidden = true
        }
        
        High_band.listDidDisappear {
            print("highband_List disappear")
            self.High_band_List = false
            
            if(self.Bass_enhancement.isHidden == true && self.Parameters_List == false && self.Low_band_List == false && self.Middle_band_List == false){
                self.Bass_enhancement.isHidden = false
            }
            
            if(self.Middle_band_List == false){
                if(self.Cutoff_Freq.isHidden == true){
                    self.Cutoff_Freq.isHidden = false
                }
                self.Cutoff_freq_label.isHidden = false
            }
            
            if(self.TuneDSP.isHidden == true && self.Cutoff_freq_List == false){
                self.TuneDSP.isHidden = false
            }
        }
        
        Bass_enhancement.listWillAppear {
            print("Bass_List appear")
            self.Bass_List = true
            
            self.TuneDSP.isHidden = true
        }
        
        Bass_enhancement.listDidDisappear {
            print("Bass_List disappear")
            self.Bass_List = false
            
            if(self.TuneDSP.isHidden == true && self.Cutoff_freq_List == false){
                self.TuneDSP.isHidden = false
            }
        }
        
        Cutoff_Freq.listWillAppear {
            print("Cutoff_Freq_List appear")
            self.Cutoff_freq_List = true
            self.TuneDSP.isHidden = true
        }
        
        Cutoff_Freq.listDidDisappear {
            print("Cutoff_Freq_List disappear")
            self.Cutoff_freq_List = false
            
            if(self.TuneDSP.isHidden == true && self.Bass_List == false){
                self.TuneDSP.isHidden = false
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.title = "MB-DRC"
        
        DSPManager?.DSPTuningDelegate = self
        
        if(parameters.text == "" && DSPManager?.Audio_Config != nil){
            print("Set default value")
            parameters.selectedIndex = 0
            parameters.text = param_table[parameters.selectedIndex!]
            
            self.Low_band.optionArray = self.Knee_Th_table
            self.Low_band.optionIds = self.Knee_Th_ids
            
            self.Middle_band.optionArray = self.Knee_Th_table
            self.Middle_band.optionIds = self.Knee_Th_ids
            
            self.High_band.optionArray = self.Knee_Th_table
            self.High_band.optionIds = self.Knee_Th_ids
            print("Get MB-DRC config data")
            
            DSPTuningDisable()  //If MBDRC parameter has been changed?
            
            MBDRC_Init()
        }
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        if(DSPState.text == "MB-DRC Parameters"){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
        
        /*
        //Simulator
        parameters.selectedIndex = 0
        parameters.text = param_table[parameters.selectedIndex!]
        
        self.Low_band.optionArray = self.Knee_Th_table
        self.Low_band.optionIds = self.Knee_Th_ids
        
        self.Middle_band.optionArray = self.Knee_Th_table
        self.Middle_band.optionIds = self.Knee_Th_ids
        
        self.High_band.optionArray = self.Knee_Th_table
        self.High_band.optionIds = self.Knee_Th_ids
        
        Low_band.selectedIndex = 0
        Low_band.text = Knee_Th_table[Low_band.selectedIndex!]
        Middle_band.selectedIndex = 0
        Middle_band.text = Knee_Th_table[Middle_band.selectedIndex!]
        High_band.selectedIndex = 0
        High_band.text = Knee_Th_table[High_band.selectedIndex!]
        
        Bass_enhancement.selectedIndex = 0
        Bass_enhancement.text = Bass_table[Bass_enhancement.selectedIndex!]
        
        Cutoff_Freq.selectedIndex = 0
        Cutoff_Freq.text = Cutoff_freq_table[Cutoff_Freq.selectedIndex!]
        */
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[MBDRC]viewWillDisappear")
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func ResetParameters(_ sender: Any) {
        
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        //parameters.text = "Knee Th"
        
        //print("param index = \(parameters.selectedIndex!)")
        
        if(MBDRC_Data.count != 0){
            print("[DSPTuning] MBDRC data = \(MBDRC_Data)")
            
            DSPManager?.DSPTuning(module: 0x0C, cfg: 0x02, len: UInt8(MBDRC_Data.count), data: MBDRC_Data)
        }
    }
    
    func Update_MBDRC_Param(){
        DSPManager?.MBDRC_Data.removeAll()
        
        DSPManager?.MBDRC_Data = MBDRC_Data
        
        print("MBDRC update data = \(DSPManager?.MBDRC_Data)")
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    func MBDRC_Init() {
        
        MBDRC_Data = DSPManager!.MBDRC_Data
        
        print("@@\(MBDRC_Data.count)")
        print("[MBDRC_Init]MBDRC_Data = \(MBDRC_Data)")
        
        if(parameters.selectedIndex == 0){  //Knee Th
            print("MBDRC byte 1 = \(MBDRC_Data[0])")
            print("bit[0:1] = \(Int(MBDRC_Data[0] & 0x03))")
            Low_band.selectedIndex = Int(MBDRC_Data[0] & 0x03)
            Low_band.text = Knee_Th_table[Low_band.selectedIndex!]
            print("bit[2:3] = \((Int(MBDRC_Data[0] & 0x0C)) >> 2)")
            Middle_band.selectedIndex = (Int(MBDRC_Data[0] & 0x0C)) >> 2
            Middle_band.text = Knee_Th_table[Middle_band.selectedIndex!]
            print("bit[4:5] = \((Int(MBDRC_Data[0] & 0x30)) >> 4)")
            High_band.selectedIndex = (Int(MBDRC_Data[0] & 0x30)) >> 4
            High_band.text = Knee_Th_table[High_band.selectedIndex!]
            print("bit[6:7] = \((Int(MBDRC_Data[0] & 0xC0)) >> 6)")
            Cutoff_Freq.selectedIndex = (Int(MBDRC_Data[0] & 0xC0)) >> 6
            Cutoff_Freq.text = Cutoff_freq_table[Cutoff_Freq.selectedIndex!]
        }
        
        if((MBDRC_Data[1] & 0x40) == 0x40){
            Bass_enhancement.selectedIndex = Int(MBDRC_Data[7]&0x07)
            Bass_enhancement.text = Bass_table[Bass_enhancement.selectedIndex!]
        }
        else{
            Bass_enhancement.selectedIndex = 0
            Bass_enhancement.text = Bass_table[Bass_enhancement.selectedIndex!]
        }
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[MB-DRC] BLE_ConnectionStatus = \(status)")
        
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        
    }
    
    func RefreshParametersData(dat:Data) {
        
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 1)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            if(Parameters_List == true){
                Parameters_List = false
                parameters.hideList()
            }
            parameters.isUserInteractionEnabled = false
            if(Low_band_List == true){
                Low_band_List = false
                Low_band.hideList()
            }
            Low_band.isUserInteractionEnabled = false
            if(Middle_band_List == true){
                Middle_band_List = false
                Middle_band.hideList()
            }
            Middle_band.isUserInteractionEnabled = false
            if(High_band_List == true){
                High_band_List = false
                High_band.hideList()
            }
            High_band.isUserInteractionEnabled = false
            if(Bass_List == true){
                Bass_List = false
                Bass_enhancement.hideList()
            }
            Bass_enhancement.isUserInteractionEnabled = false
            if(Cutoff_freq_List == true){
                Cutoff_freq_List = false
                Cutoff_Freq.hideList()
            }
            Cutoff_Freq.isUserInteractionEnabled = false
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            parameters.isUserInteractionEnabled = true
            Low_band.isUserInteractionEnabled = true
            Middle_band.isUserInteractionEnabled = true
            High_band.isUserInteractionEnabled = true
            Bass_enhancement.isUserInteractionEnabled = true
            Cutoff_Freq.isUserInteractionEnabled = true
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
