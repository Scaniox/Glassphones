//
//  SYSViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/8/19.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class SYSViewController: UIViewController, DSPTuningDelegate, UITextFieldDelegate {
    var DSPManager: TuneDSPManager?

    @IBOutlet var DSPState: UILabel!
    
    @IBOutlet var TuneDSP: UIButton!
    
    @IBOutlet var param_1: DropDown!        //Mono/stereo mode selection
    @IBOutlet var param_2: UITextField!     //MIDI Mode B Tone type control(0-255)
    @IBOutlet var param_3: UITextField!     //Silence data reversion and Fade-out of data(0-255)
    @IBOutlet var param_4: UITextField!     //Silence supp threshold(0-255)
    @IBOutlet var param_5: UITextField!     //Silence supp MeanVariance thrd(0-255)
    @IBOutlet var param_6: UITextField!     //Silence supp fadeout step(0-255)
    @IBOutlet var param_7: UITextField!     //Silence supp tuning counter(0-255)
    @IBOutlet var param_8: UITextField!     //Line-in supp minimum gain(0-255)
    @IBOutlet var param_9: UITextField!     //Silence supp fadein base step(0-255)
    @IBOutlet var Silence_supp_label: UILabel!
    
    let param_1_table = ["0x1 L only", "0x2 R only", "0x3 (L+R)/2 ->L,(L+R)/2 ->R"]
    let param_1_ids = [1, 2, 3]
    
    var param_1_List: Bool!
    
    var SYS_PARA_Data: [UInt8] = [UInt8]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        param_2.tag = 200
        param_3.tag = 300
        param_4.tag = 400
        param_5.tag = 500
        param_6.tag = 600
        param_7.tag = 700
        param_8.tag = 800
        param_9.tag = 900
        
        param_2.delegate = self
        param_3.delegate = self
        param_4.delegate = self
        param_5.delegate = self
        param_6.delegate = self
        param_7.delegate = self
        param_8.delegate = self
        param_9.delegate = self
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.HiddenSYS_Delegate = self
        
        param_1.isSearchEnable = false
        param_1_List = false
        
        param_1.optionArray = param_1_table
        param_1.optionIds = param_1_ids
        
        param_1.didSelect{(selectedText , index , id) in
            if(self.param_1.text != self.param_1_table[self.param_1.selectedIndex!]){
                if(self.SYS_PARA_Data.count != 0){
                    self.SYS_PARA_Data[8] &= ~(0x03)
                    self.SYS_PARA_Data[8] |= (UInt8(self.param_1.selectedIndex!) & 0x03)
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_1.listWillAppear {
            self.param_1_List = true
            self.Silence_supp_label.isHidden = true
            self.param_2.isHidden = true
            self.param_3.isHidden = true
        }
        
        param_1.listDidDisappear {
            self.param_1_List = false
            self.Silence_supp_label.isHidden = false
            self.param_2.isHidden = false
            self.param_3.isHidden = false
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    
        print("[MVDRViewController] viewWillAppear")
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "SYS_PARA")
        
        if(param_1.text == ""){
            DSPManager?.Get_Voice_SYS_PARA()
            DSPTuningDisable()
        }
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        DSPState.text = DSPManager?.DSP_DUT_State
        
        if(DSPManager?.RefreshGUIData(UIView_index: 0x0C) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 0x0C)
            DSPTuningDisable()
            DSPManager?.Get_Voice_SYS_PARA()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    
        if(TuneDSP.isEnabled == true){
            if(SYS_PARA_Data.count != 0){
                DSPManager?.DSPQueueData(module:0x0D, cfg:0x0D, len:UInt8(SYS_PARA_Data.count), data:SYS_PARA_Data)
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    func GUI_Data_Update(){
        if(SYS_PARA_Data.count != 0){
            print("GUI_Data_Update")
            
            param_2.text = String(SYS_PARA_Data[0])
            param_3.text = String(SYS_PARA_Data[1])
            param_4.text = String(SYS_PARA_Data[2])
            param_5.text = String(SYS_PARA_Data[3])
            param_6.text = String(SYS_PARA_Data[4])
            param_7.text = String(SYS_PARA_Data[5])
            param_8.text = String(SYS_PARA_Data[6])
            param_9.text = String(SYS_PARA_Data[7])
            
            param_1.selectedIndex = Int(SYS_PARA_Data[8] & 0x03)
            param_1.text = param_1_table[param_1.selectedIndex!]
        }
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        if(SYS_PARA_Data.count != 0){
            print("DSPTuning")
            
            DSPManager?.DSPTuning(module: 0x0D, cfg: 0x0D, len: UInt8(SYS_PARA_Data.count), data: SYS_PARA_Data)
        }
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if(SYS_PARA_Data.count != 0){
            print("textFieldShouldReturn")
            if(param_2.text != nil && textField.tag == 200){
                if let param_2_value = Int(param_2.text!){
                    if(param_2_value >= 0 && param_2_value <= 255){
                        SYS_PARA_Data[0] = UInt8(param_2_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_2.text = String(SYS_PARA_Data[0])
                    }
                }
                else{
                    param_2.text = String(SYS_PARA_Data[0])
                }
            }
            else if(param_3.text != nil && textField.tag == 300){
                if let param_3_value = Int(param_3.text!){
                    if(param_3_value >= 0 && param_3_value <= 255){
                        SYS_PARA_Data[1] = UInt8(param_3_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_3.text = String(SYS_PARA_Data[1])
                    }
                }
                else{
                    param_3.text = String(SYS_PARA_Data[1])
                }
            }
            else if(param_4.text != nil && textField.tag == 400){
                if let param_4_value = Int(param_4.text!){
                    if(param_4_value >= 0 && param_4_value <= 255){
                        SYS_PARA_Data[2] = UInt8(param_4_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_4.text = String(SYS_PARA_Data[2])
                    }
                }
                else{
                    param_4.text = String(SYS_PARA_Data[2])
                }
            }
            else if(param_5.text != nil && textField.tag == 500){
                if let param_5_value = Int(param_5.text!){
                    if(param_5_value >= 0 && param_5_value <= 255){
                        SYS_PARA_Data[3] = UInt8(param_5_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_5.text = String(SYS_PARA_Data[3])
                    }
                }
                else{
                    param_5.text = String(SYS_PARA_Data[3])
                }
            }
            else if(param_6.text != nil && textField.tag == 600){
                if let param_6_value = Int(param_6.text!){
                    if(param_6_value >= 0 && param_6_value <= 255){
                        SYS_PARA_Data[4] = UInt8(param_6_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_6.text = String(SYS_PARA_Data[4])
                    }
                }
                else{
                    param_6.text = String(SYS_PARA_Data[4])
                }
            }
            else if(param_7.text != nil && textField.tag == 700){
                if let param_7_value = Int(param_7.text!){
                    if(param_7_value >= 0 && param_7_value <= 255){
                        SYS_PARA_Data[5] = UInt8(param_7_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_7.text = String(SYS_PARA_Data[5])
                    }
                }
                else{
                    param_7.text = String(SYS_PARA_Data[5])
                }
            }
            else if(param_8.text != nil && textField.tag == 800){
                if let param_8_value = Int(param_8.text!){
                    if(param_8_value >= 0 && param_8_value <= 255){
                        SYS_PARA_Data[6] = UInt8(param_8_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_8.text = String(SYS_PARA_Data[6])
                    }
                }
                else{
                    param_8.text = String(SYS_PARA_Data[6])
                }
            }
            else if(param_9.text != nil && textField.tag == 900){
                if let param_9_value = Int(param_9.text!){
                    if(param_9_value >= 0 && param_9_value <= 255){
                        SYS_PARA_Data[7] = UInt8(param_9_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_9.text = String(SYS_PARA_Data[7])
                    }
                }
                else{
                    param_9.text = String(SYS_PARA_Data[7])
                }
            }
        }
        
        return true
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        print("[Hidden SYS] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 13){
                if(buffer[k+2] == 10){
                    SYS_PARA_Data.removeAll()
                    for index in 0..<10 {
                        SYS_PARA_Data.append(buffer[k+3+index])
                    }
                }
            }
            
            k += Int(3+len)
        }
        
        GUI_Data_Update()
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 0x0C)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func BLE_ConnectionStatus(status: Bool) {
        print("[SYS] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func DSPTuningState(state: String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(param_1_List)
            {
                param_1.hideList()
            }
            param_1.isUserInteractionEnabled = false
            param_2.isEnabled = false
            param_3.isEnabled = false
            param_4.isEnabled = false
            param_5.isEnabled = false
            param_6.isEnabled = false
            param_7.isEnabled = false
            param_8.isEnabled = false
            param_9.isEnabled = false
            
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            param_1.isUserInteractionEnabled = true
            param_2.isEnabled = true
            param_3.isEnabled = true
            param_4.isEnabled = true
            param_5.isEnabled = true
            param_6.isEnabled = true
            param_7.isEnabled = true
            param_8.isEnabled = true
            param_9.isEnabled = true
        }
    }
    
    func ExportDSPTuningResult() {
    }
}
