//
//  WstViewController.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/7/18.
//  Copyright © 2019 ISSC. All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth
import CallKit

//import CoreTelephony

enum FEATURE_LIST: Int{
    case EQ = 0
    case EARBUDS
    case TOUCHPAD
    case FIND_ME
}

enum EARBUD_POSITION : UInt8 {
    case NOTE_DEFINED = 0x00
    case LEFT_SIDE = 0x01
    case RIGHT_SIDE = 0x02
}

extension UIViewController {
    
    func showToast(message : String, font: UIFont) {
        
        let toastLabel = UILabel(frame: CGRect(x: 0/*self.view.frame.size.width/2 - 75*/, y: self.view.frame.size.height-100, width: self.view.frame.size.width, height: 35))
        toastLabel.backgroundColor = UIColor.black
        toastLabel.textColor = UIColor.white
        toastLabel.font = font
        toastLabel.textAlignment = .center
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 3, delay: 0, options: .curveLinear, animations: {
            toastLabel.alpha = 0.0}, completion: {(isCompleted) in toastLabel.removeFromSuperview()})
    }
    
}

class WstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource ,WST_Delegate,UIApplicationDelegate,CXCallObserverDelegate{
    
    @IBOutlet var reconnectButton: UIButton!
    @IBOutlet var budStatusUiView: UIView!
    @IBOutlet var leftBudImageView: UIImageView!
    @IBOutlet var leftBudBatteryImageView: UIImageView!
    @IBOutlet var rightBudImageView: UIImageView!
    @IBOutlet var rightBudBatteryImageView: UIImageView!
    
    @IBOutlet var wstLinkStateImage: UIImageView! //icon resource : https://www.iconfinder.com/appercuts
    @IBOutlet var leftBudBatteryLevelLabel: UILabel!
    @IBOutlet var rightBudBatteryLevelLabel: UILabel!
    @IBOutlet var featureListTableView: UITableView!
    
    @IBAction func reconnectButtonTouchDown(_ sender: Any) {
        self.StartScan()
        
    }
    var m_wstPeripheral : WstPeripheral?
    
    var cannotuseCallKit : Bool! = false
    
    //var callObserver = CXCallObserver()
    var callObserver : CXCallObserver?
    
    //var callObserver:CXCallObserver!// = CXCallObserver()
    //private var callCenter = CTCallCenter()
    //var eqModePickView:UIPickerView = UIPickerView()
    //var peripheralsArray: NSMutableArray = []
    //var advArray: NSMutableArray = []
    
    let featureListArray = ["Equalizer Settings", "Earbuds Settings","Touchpad Settings","Find My Earbuds"]
    let featureListImageArray = ["equalizer", "iconfinder_setting","iconfinder_airpod_touch","iconfinder_airpods_signal"]
    
    let batteryLevelImage = ["battery0","battery1","battery2","battery3","battery4","battery5"]
    
    let leftEarbudImage = ["iconfinder_airpod_left_idle","iconfinder_airpod_left_connect"]
    let rightEarbudImage = ["iconfinder_airpod_right_idle","iconfinder_airpod_right_connect"]
    let eqModeArray = ["OFF","Soft Mode","Bass Mode","Treble Mode","Classical Mode","Rock Mode","Jazz Mode","POP Mode","Dance Mode","R&B Mode","","Custom Mode"]
    let LEFT_SIDE = 0x00
    let RIGHT_SIDE = 0x01
    let IN_BOX = 0x00
    let OUT_OF_BOX = 0x01
    let WST_CONNECTED = 0x01
    let WST_DISCONNECTED = 0x00
    let STATE_IDLE = 0x00
    let STATE_CONNECTED = 0x01
    let PLAYING_STREAMING = 0x01
    let BTM_STATUS_CONNECTED = 0x01
    
    var m_batteryLevel: UInt8 = 0
    var m_dataCategory: UInt8 = 0
    var m_btmStatus: UInt8 = 0
    var m_playStatus: UInt8 = 0
    var m_primaryEarbudStatus_side: UInt8 = 0
    var m_primaryEarbudStatus_boxState: UInt8 = 0
    var m_primaryEarbudStatus_wstState: UInt8 = 0
    var m_secondaryBatteryLevel: UInt8 = 0
    var m_groupID: String = ""
    var m_EQModeIdx:UInt8 = 0
    var m_btConnected: Bool = false
    var m_SCO_Connected: Bool = false
    var m_bleConnected: Bool = false
    var m_foundDevice:Bool = false
    
    var control: Bool = true
    var scanTimer: Timer? = nil
    var isBackground: Bool = false
    //var m_primaryEarbudbatteryLevelValue: UInt8 = 0
    //var m_secondaryEarbudbatteryLevelValue: UInt8 = 0

    // MARK: - viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "< Back", style: .plain, target: self, action: #selector(backAction))
        self.title = "WST"
        budStatusUiView.layer.cornerRadius = 20
        budStatusUiView.layer.borderWidth = 1
        //featureListTableView.layer.cornerRadius = 5
        //featureListTableView.h
        
        featureListTableView.dataSource = self
        featureListTableView.delegate = self
        featureListTableView.backgroundColor = .clear
        featureListTableView.layer.borderWidth = 1
        //featureListTableView.layer.borderColor = CGColor
        featureListTableView.layer.cornerRadius = 10
        wstLinkStateImage.isHidden = true
        control = false
        updateEarbudsStatus()
        let ScanButton = UIBarButtonItem(title: "New Device", style: UIBarButtonItem.Style.plain, target: self, action: #selector(DeviceTableViewController.ScanbuttonTapped(_:)))
        
        self.navigationItem.rightBarButtonItem = ScanButton
        
        reconnectButton.isHidden = true
        reconnectButton.isEnabled = false
        
        m_wstPeripheral = WstPeripheral.sharedInstance()
        m_wstPeripheral?.wstDelegate = self
                
        cannotuseCallKit = false
        let locale = Locale.current
        print("country = \(locale.regionCode)")
        if(locale.regionCode != nil){
            if((locale.regionCode!.contains("CN")) || (locale.regionCode!.contains("CHN"))){
                cannotuseCallKit = true
            }
            
            if((locale.regionCode!.contains("HK")) || (locale.regionCode!.contains("HKG"))){
                cannotuseCallKit = true
            }
        }
        
        if(!cannotuseCallKit){
            print("Enable CallKit")
            callObserver = CXCallObserver()
            callObserver!.setDelegate(self, queue: nil) //Set delegate to self to call delegate method.
        }
        else{
            print("currentLocale is China so we cannot use CallKit")
        }
        
        updateCallState()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        
        print("viewWillDisappear")
        
        if(self.isMovingFromParent) {
            control = false
            m_wstPeripheral?.disconnectPeripheral()
            m_wstPeripheral?.deleteInstance()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("viewWillAppear")
        
        super.viewWillAppear(animated)
        updateEarbudsStatus()
        updateCallState()
        //m_wstPeripheral?.wstDelegate = self
        if m_wstPeripheral?.isConnected() == false {
            let recordGroup = UserDefaults.standard
            if recordGroup.string(forKey: RECORD_GROUP_ID_KEY) != nil{
                Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.StartScan), userInfo: nil, repeats: false)
            }else{
                let controller = UIAlertController(title: "No Bundled Device", message: "Direct to add a new device?", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default) { (_) in
                    Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.ScanbuttonTapped(_:)), userInfo: nil, repeats: false)
                }
                controller.addAction(okAction)
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                controller.addAction(cancelAction)
                present(controller, animated: true, completion: nil)
            }
        }else{
            self.wstInitial()
        }
        
//        let recordGroup = UserDefaults.standard
//        if let recordGroupID = recordGroup.string(forKey: RECORD_GROUP_ID_KEY){
//            print(recordGroupID)
//            if m_wstPeripheral?.isConnected() == false {
//                Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.StartScan), userInfo: nil, repeats: false)
//            }else{
//                self.wstInitial()
//            }
//        }else{
//
//            let controller = UIAlertController(title: "No Bundled Device", message: "Direct to add a new device?", preferredStyle: .alert)
//            let okAction = UIAlertAction(title: "OK", style: .default) { (_) in
//                Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.ScanbuttonTapped(_:)), userInfo: nil, repeats: false)
//            }
//            controller.addAction(okAction)
//            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
//            controller.addAction(cancelAction)
//            present(controller, animated: true, completion: nil)
//        }
    }
    
    @objc func updateEarbudsStatus() {
        var batteryLevelIdx = 0
        if (m_batteryLevel == 0x00) {
            batteryLevelIdx = 0
        }else if (m_batteryLevel <= 0x03){
            batteryLevelIdx = 1
        }else if (m_batteryLevel <= 0x06){
            batteryLevelIdx = 2
        }else if (m_batteryLevel <= 0x09){
            batteryLevelIdx = 3
        }else if (m_batteryLevel <= 0x0B){
            batteryLevelIdx = 4
        }else{
            batteryLevelIdx = 5
        }
        
        var secondaryBatteryLevelIdx = 0
        
        if m_primaryEarbudStatus_side == LEFT_SIDE{
            
            if m_btConnected == true{
                self.leftBudImageView.image = UIImage(named: leftEarbudImage[STATE_CONNECTED])
                if m_primaryEarbudStatus_wstState == WST_CONNECTED{
                    self.rightBudImageView.image = UIImage(named: rightEarbudImage[STATE_CONNECTED])
                }else{
                    self.rightBudImageView.image = UIImage(named: rightEarbudImage[STATE_IDLE])
                }
            }else{
                self.leftBudImageView.image = UIImage(named: leftEarbudImage[STATE_IDLE])
                self.rightBudImageView.image = UIImage(named: rightEarbudImage[STATE_IDLE])
            }
            
            if m_primaryEarbudStatus_wstState == WST_CONNECTED{
                wstLinkStateImage.isHidden = false
                if m_secondaryBatteryLevel == 0x0C{
                    self.rightBudBatteryLevelLabel.text = String(format: "100%%")
                }else{
                    self.rightBudBatteryLevelLabel.text = String(format: "%d%%",m_secondaryBatteryLevel*9)
                }
                
                if (m_secondaryBatteryLevel == 0x00) {
                    secondaryBatteryLevelIdx = 0
                }else if (m_secondaryBatteryLevel <= 0x03){
                    secondaryBatteryLevelIdx = 1
                }else if (m_secondaryBatteryLevel <= 0x06){
                    secondaryBatteryLevelIdx = 2
                }else if (m_secondaryBatteryLevel <= 0x09){
                    secondaryBatteryLevelIdx = 3
                }else if (m_secondaryBatteryLevel <= 0x0B){
                    secondaryBatteryLevelIdx = 4
                }else{
                    secondaryBatteryLevelIdx = 5
                }
                self.rightBudBatteryImageView.image = UIImage(named: batteryLevelImage[secondaryBatteryLevelIdx])!
                
                
            }else{ // WST Not Connected
                self.rightBudImageView.image = UIImage(named: rightEarbudImage[STATE_IDLE])
                self.rightBudBatteryLevelLabel.text = ""
                self.rightBudBatteryImageView.image = UIImage(named: batteryLevelImage[0])!
                wstLinkStateImage.isHidden = true
            }
            self.leftBudBatteryImageView.image = UIImage(named: batteryLevelImage[batteryLevelIdx])!
            if m_batteryLevel == 0x0c{
                self.leftBudBatteryLevelLabel.text = String(format: "100%%")
            }else{
                self.leftBudBatteryLevelLabel.text = String(format: "%d%%", m_batteryLevel*9)
            }
            
        }else{ // m_primaryEarbudStatus_side == RIGHT_SIDE
            if m_btConnected == true{
                self.rightBudImageView.image = UIImage(named: rightEarbudImage[STATE_CONNECTED])
                if m_primaryEarbudStatus_wstState == WST_CONNECTED{
                    self.leftBudImageView.image = UIImage(named: leftEarbudImage[STATE_CONNECTED])
                }else{
                    self.leftBudImageView.image = UIImage(named: leftEarbudImage[STATE_IDLE])
                }
            }else{
                self.rightBudImageView.image = UIImage(named: rightEarbudImage[STATE_IDLE])
                self.leftBudImageView.image = UIImage(named: leftEarbudImage[STATE_IDLE])
            }
            if m_primaryEarbudStatus_wstState == WST_CONNECTED{
                wstLinkStateImage.isHidden = false
                
                if m_secondaryBatteryLevel == 0x0C{
                    self.leftBudBatteryLevelLabel.text = String(format: "100%%")
                }else{
                    self.leftBudBatteryLevelLabel.text = String(format: "%d%%",m_secondaryBatteryLevel*9)
                }
                
                if (m_secondaryBatteryLevel == 0x00) {
                    secondaryBatteryLevelIdx = 0
                }else if (m_secondaryBatteryLevel <= 0x03){
                    secondaryBatteryLevelIdx = 1
                }else if (m_secondaryBatteryLevel <= 0x06){
                    secondaryBatteryLevelIdx = 2
                }else if (m_secondaryBatteryLevel <= 0x09){
                    secondaryBatteryLevelIdx = 3
                }else if (m_secondaryBatteryLevel <= 0x0B){
                    secondaryBatteryLevelIdx = 4
                }else{
                    secondaryBatteryLevelIdx = 5
                }
                self.leftBudBatteryImageView.image = UIImage(named: batteryLevelImage[secondaryBatteryLevelIdx])!
            }else{
                wstLinkStateImage.isHidden = true
                self.leftBudImageView.image = UIImage(named: leftEarbudImage[STATE_IDLE])
                self.leftBudBatteryLevelLabel.text = ""
                self.leftBudBatteryImageView.image = UIImage(named: batteryLevelImage[0])!
            }
            self.rightBudBatteryImageView.image = UIImage(named: batteryLevelImage[batteryLevelIdx])!
            if m_batteryLevel == 0x0c{
                self.rightBudBatteryLevelLabel.text = String(format: "100%%")
            }else{
                self.rightBudBatteryLevelLabel.text = String(format: "%d%%", m_batteryLevel*9)
            }
        }
        featureListTableView.reloadData()
    }
    
    @objc func StartScan() {
        updateCallState()
        if m_SCO_Connected{
            let controller = UIAlertController(title: "The Phone Call is Active", message: "For the quality of call, Please try connect after call end.", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            controller.addAction(okAction)
            present(controller, animated: true, completion: nil)
            reconnectButton.isHidden = false
            reconnectButton.isEnabled = true
        }else{
            print("StartScan")
            var result:Int = 0
            m_foundDevice = false
            reconnectButton.isHidden = true
            reconnectButton.isEnabled = false
            result = (m_wstPeripheral?.StartScan())!
            if result != 0 {
                m_wstPeripheral?.deleteInstance()
                self.navigationController?.popToRootViewController(animated: true)
            }else{
                scanTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(self.scanTimeout), userInfo: nil, repeats: false)
            }
        }
    }
    
    @objc func StopScan() {
        print("StopDevice")
        m_wstPeripheral?.StopScan()
    }
    
    @objc func scanTimeout(){
        if m_foundDevice {
            showToast(message: "cannot connect to bundle device", font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
        }else{
            showToast(message: "Cannot find bundled device", font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
        }
        reconnectButton.isHidden = false
        reconnectButton.isEnabled = true
        self.StopScan()
    }
    
    @objc func ReadLinkStatus() {
        m_wstPeripheral?.command_ReadLinkStatus()
    }
    
    @objc func wstInitial(){
        m_wstPeripheral?.command_ReadEarbudPosition()
        m_wstPeripheral?.command_ReadLinkStatus()
        m_wstPeripheral?.command_ReadWstLinkStatus()
        m_wstPeripheral?.command_ReadPrimaryBatteryLevel()
    }
    
    @objc func updateEqMode(mode:UInt8){
        m_EQModeIdx = mode
        featureListTableView.reloadData()
    }
    
    @objc func resetStatus(){
        m_batteryLevel = 0
        m_dataCategory = 0
        m_btmStatus = 0
        m_playStatus = 0
        m_primaryEarbudStatus_side = 0
        m_primaryEarbudStatus_boxState = 0
        m_primaryEarbudStatus_wstState = 0
        m_secondaryBatteryLevel = 0
        m_EQModeIdx = 0
        m_btConnected = false
        m_bleConnected = false
        //m_SCO_Connected = false
        wstLinkStateImage.isHidden = true
        updateEarbudsStatus()
    }
    
    @objc func updateConnectionState(connected:Bool){
        NSLog("WstScanDeviceTableViewController - updateConnectionState")
        if connected {
            m_wstPeripheral?.wstDelegate = self
            didConnected()
            let array = navigationController?.viewControllers
            if let object = array?[1] {
                navigationController?.popToViewController(object, animated: true)
            }
        }else{
            resetStatus()
        }
    }
    
    @objc func setBackgroundMode(background:Bool){
        isBackground = background
        updateCallState()
        checkConnection()
    }
    
    @objc func checkConnection(){
        //print("checkConnection!!!!!!!!!!!!!!!")
        //print("m_SCO_Connected = \(m_SCO_Connected) , isBackground =  \(isBackground)")
        
        if isBackground && m_btConnected == false{
            m_wstPeripheral?.disconnectPeripheral()
        }else if m_SCO_Connected && m_bleConnected{
            m_wstPeripheral?.disconnectPeripheral()
        }else if isBackground == false && m_bleConnected == false{
            StartScan()
        }
    }
    
    @objc func updateCallState()
    {
        //print("updateCallState!!!!!!!!!!!!!!! ")
        m_SCO_Connected = false
        //print("m_SCO_Connected = false ")
        
        if(!cannotuseCallKit){
            callObserver = CXCallObserver()
            if callObserver!.calls.count > 0{
                for i in 0..<callObserver!.calls.count{//[0].hasConnected{
                    if callObserver!.calls[i].hasConnected || callObserver!.calls[i].isOutgoing || callObserver!.calls[i].isOnHold{
                        m_SCO_Connected = true
                    }
                }
            }
        }
    }
    
    @objc func terminateBle(){
        m_wstPeripheral?.disconnectPeripheral()
        m_wstPeripheral?.deleteInstance()
    }
    
    // MARK: - CXCallObserverDelegate
    func callObserver(_ callObserver: CXCallObserver, callChanged call: CXCall) {
        //print("callObserver!!!!!!!!!!!!!!!!!!!!!!!!")
        let state = UIApplication.shared.applicationState
        if state == .background || state == .inactive{
            DispatchQueue.global(qos: .background).async {
                //background code
                DispatchQueue.main.async {
                    if call.hasConnected {
                        self.m_SCO_Connected = true
                        self.checkConnection()
                    }else if call.hasEnded {
                        self.m_SCO_Connected = false
                    }
                }
            }
        }else if state == .active{
            if call.hasConnected {
                m_SCO_Connected = true
                checkConnection()
            }else if call.hasEnded {
                m_SCO_Connected = false
            }
        }
        
    }
    
    // MARK: - Nevagation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "FORCE_TO_WST_SCAN_DEVICE" {
            StopScan()
            let controller = segue.destination as? WstScanDeviceTableViewController
            controller?.m_wstPeripheral = m_wstPeripheral
            controller?.m_parentView = self
        }else if segue.identifier == "FORCE_TO_WST_EARBUD_SETTING"{
            let controller = segue.destination as? WstEarbudSettingViewController
            controller?.m_wstPeripheral = m_wstPeripheral
            controller?.m_parentView = self
        }else if segue.identifier == "FORCE_TO_WST_EQ_MODE_SETTING"{
            let controller = segue.destination as? WstEqModeTableViewController
            controller?.m_wstPeripheral = m_wstPeripheral
            controller?.m_parentView = self
        }else if segue.identifier == "FORCE_TO_WST_FINDME_PAGE"{
            let controller = segue.destination as? WstFindMyEarbudsViewController
            controller?.m_wstPeripheral = m_wstPeripheral
            
            controller?.m_parentView = self
            controller?.m_primaryEarbudStatus_side = m_primaryEarbudStatus_side
            controller?.m_primaryEarbudStatus_wstState = m_primaryEarbudStatus_wstState
        }else if segue.identifier == "FORCE_TO_WST_TOUCHPAD_SETTING"{
            let controller = segue.destination as? WstTouchpadSettingViewController
            controller?.m_wstPeripheral = m_wstPeripheral
            controller?.m_parentView = self
            controller?.m_primaryEarbudStatus_side = m_primaryEarbudStatus_side
            controller?.m_primaryEarbudStatus_wstState = m_primaryEarbudStatus_wstState
        }
        
    }
    
    @objc func ScanbuttonTapped(_ sender:UIBarButtonItem!) {
        updateCallState()
        if m_SCO_Connected{
            let controller = UIAlertController(title: "The Phone Call is Active", message: "For the quality of call, Please try connect after call end.", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            controller.addAction(okAction)
            present(controller, animated: true, completion: nil)
        }else{
            performSegue(withIdentifier: "FORCE_TO_WST_SCAN_DEVICE", sender: self)
        }
    }
    
    // MARK: - Table view data source
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  featureListArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case FEATURE_LIST.EQ.rawValue:
            let cell = featureListTableView.dequeueReusableCell(withIdentifier: "FEATURE_CELL2", for: indexPath) as! WST_FeatureCell
            cell.setFeatureName(name: self.featureListArray[indexPath.row])
            cell.setFeatureOptionName(name: self.eqModeArray[Int(m_EQModeIdx)])
            cell.setFeatureImage(imageName: self.featureListImageArray[indexPath.row])
            cell.backgroundColor = .groupTableViewBackground
//            cell.layer.borderWidth = 0.5
//            cell.layer.cornerRadius = 10
            if m_bleConnected && m_playStatus == PLAYING_STREAMING{
                cell.isUserInteractionEnabled = true
                cell.setFeatureNameEnable(enable: true)
            }else{
                cell.isUserInteractionEnabled = false
                cell.setFeatureNameEnable(enable: false)
            }
            return cell
        case FEATURE_LIST.EARBUDS.rawValue:
            let cell = featureListTableView.dequeueReusableCell(withIdentifier: "FEATURE_CELL", for: indexPath) as! WST_FeatureCell
            cell.setFeatureName(name: self.featureListArray[indexPath.row])
            cell.setFeatureImage(imageName: self.featureListImageArray[indexPath.row])
            cell.backgroundColor = .groupTableViewBackground
//            cell.layer.borderWidth = 0.5
//            cell.layer.cornerRadius = 5
            if m_bleConnected && (m_primaryEarbudStatus_wstState == WST_CONNECTED){
                cell.isUserInteractionEnabled = true
                cell.setFeatureNameEnable(enable: true)
            }else{
                cell.isUserInteractionEnabled = false
                cell.setFeatureNameEnable(enable: false)
            }
            return cell
        case FEATURE_LIST.TOUCHPAD.rawValue:
            let cell = featureListTableView.dequeueReusableCell(withIdentifier: "FEATURE_CELL", for: indexPath) as! WST_FeatureCell
            cell.setFeatureName(name: self.featureListArray[indexPath.row])
            cell.setFeatureImage(imageName: self.featureListImageArray[indexPath.row])
            cell.backgroundColor = .groupTableViewBackground
            if m_bleConnected {
                cell.isUserInteractionEnabled = true
                cell.setFeatureNameEnable(enable: true)
            }else{
                cell.isUserInteractionEnabled = false
                cell.setFeatureNameEnable(enable: false)
            }

            return cell
        case FEATURE_LIST.FIND_ME.rawValue:
            let cell = featureListTableView.dequeueReusableCell(withIdentifier: "FEATURE_CELL", for: indexPath) as! WST_FeatureCell
            cell.setFeatureName(name: self.featureListArray[indexPath.row])
            cell.setFeatureImage(imageName: self.featureListImageArray[indexPath.row])
            cell.backgroundColor = .groupTableViewBackground
            cell.isUserInteractionEnabled = m_bleConnected
            cell.setFeatureNameEnable(enable: m_bleConnected)
//            cell.layer.borderWidth = 0.5
//            cell.layer.cornerRadius = 5
            
            return cell
        default:
            let cell = featureListTableView.dequeueReusableCell(withIdentifier: "FEATURE_CELL", for: indexPath) as! WST_FeatureCell
            cell.setFeatureName(name: self.featureListArray[0])
            cell.setFeatureImage(imageName: self.featureListImageArray[0])
            cell.backgroundColor = .groupTableViewBackground
//            cell.layer.borderWidth = 0.5
//            cell.layer.cornerRadius = 5
            return cell
        }
    }
    
    
    
    // MARK: - Table view delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Select device:\(indexPath.row)")
        featureListTableView.deselectRow(at: indexPath, animated: false)
        switch indexPath.row {
        case FEATURE_LIST.EQ.rawValue:
            print("EQ")
            performSegue(withIdentifier: "FORCE_TO_WST_EQ_MODE_SETTING", sender: self)
        case FEATURE_LIST.EARBUDS.rawValue:
            print("Earbud")
            performSegue(withIdentifier: "FORCE_TO_WST_EARBUD_SETTING", sender: self)
        case FEATURE_LIST.TOUCHPAD.rawValue:
            print("Touchpad")
            performSegue(withIdentifier: "FORCE_TO_WST_TOUCHPAD_SETTING", sender: self)
        case FEATURE_LIST.FIND_ME.rawValue:
            print("Find me")
            performSegue(withIdentifier: "FORCE_TO_WST_FINDME_PAGE", sender: self)
        default:
                return
        }
    }
    
    // MARK: - WstPeripheral WstBleAdapterDelegate
    func didDiscoverPeripheral(Peripheral peripheral: CBPeripheral, AdvertisementData advertisementData: [String : Any], Rssi RSSI: NSNumber) {
        //bleAdapter?.connectPeripheral(indexPath.row)
        print(" wst_didDiscoverPeripheral")
        let recordGroup = UserDefaults.standard
        if let recordGroupID = recordGroup.string(forKey: RECORD_GROUP_ID_KEY){
            let advdata = advertisementData
            if let Service_data_dic = advdata["kCBAdvDataServiceData"] as? [NSObject:AnyObject] {
                if let Service_data = Service_data_dic[CBUUID(string:"FEDA")] as? NSData {
                    var dataByte = [UInt8] (Service_data as Data)
                    let wst_beacon = WST_BEACON_FORMAT(UnsafeMutablePointer<UInt8>(&dataByte))
                    if wst_beacon.groupID_Str == recordGroupID {
                        m_batteryLevel = wst_beacon.batteryLevel
                        m_btmStatus = wst_beacon.btmStatus
                        m_primaryEarbudStatus_side = wst_beacon.primaryEarbudStatus_side
                        m_primaryEarbudStatus_boxState = wst_beacon.primaryEarbudStatus_boxState
                        m_primaryEarbudStatus_wstState = wst_beacon.primaryEarbudStatus_wstState
                        m_secondaryBatteryLevel = wst_beacon.secondaryBatteryLevel
                        m_foundDevice = true
                        
                        if let connectable = advdata["kCBAdvDataIsConnectable"] as? NSNumber{
                            let isConnectable = connectable.intValue == 1
                            if isConnectable{
                                m_wstPeripheral?.connecPeripheral(peripheral)
                            }else{
                                showToast(message: "Earbuds is not connectable", font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
                            }
                        }
                    }
                }
            }
            updateEarbudsStatus()
        }
    }
    
    func didConnected(){
        print("didConnected")
        //NSLog("WstViewController - didConnected")
        if (scanTimer != nil){
            scanTimer?.invalidate()
            scanTimer = nil
        }
        let array = navigationController?.viewControllers
        if array!.count>2{
            if let object = array?[1] {
                navigationController?.popToViewController(object, animated: true)
            }
        }
        showToast(message: "LE Connected", font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
        StopScan()
        reconnectButton.isHidden = true
        reconnectButton.isEnabled = false
        m_bleConnected = true
        control = true
        wstInitial()
    }
    
    func didDisconnected(){
        print("didDisconnected")
        m_bleConnected = false
        resetStatus()
        showToast(message: "LE Disconnected", font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
        if(control == false){
            return
        }
        let array = navigationController?.viewControllers
        if array!.count>2{
            if let object = array?[1] {
                navigationController?.popToViewController(object, animated: true)
            }
        }
        
        if isBackground {
            return
        }
        
        if m_SCO_Connected{
            return
        }
        StartScan()
    }
    
    func didUpdateMessage( message: String?){
        showToast(message: message!, font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
    }
    
    func reportEarbudPosition(position:UInt8){
        print("reportEarbudPosition")
        if position == EARBUD_POSITION.LEFT_SIDE.rawValue{
            m_primaryEarbudStatus_side = UInt8(LEFT_SIDE)
        }else if position == EARBUD_POSITION.RIGHT_SIDE.rawValue{
            m_primaryEarbudStatus_side = UInt8(RIGHT_SIDE)
        }
        updateEarbudsStatus()
    }
    
    func reportPrimaryEarbudBatteryLevel(status:UInt8, level:UInt8){
        print("reportPrimaryEarbudBatteryLevel")
        m_batteryLevel = level
        updateEarbudsStatus()
        if m_primaryEarbudStatus_wstState == WST_CONNECTED{
            m_wstPeripheral?.command_ReadSecondaryEarbudStatus()
        }
    }
    
    /*func reportEqMode(mode:UInt8){
        print("reportEqMode")
        m_EQModeIdx = mode
        featureListTableView.reloadData()
    }*/
    
    func reportBtmStatus(status:UInt8 , linkInfo:UInt8){
        print("reportBtmStatus")
        print("reportBtmStatus = \(status)")
        m_btmStatus = status
        if m_btmStatus == BTM_STATE.HS_CONNECTED.rawValue || m_btmStatus == BTM_STATE.A2DP_CONNECTED.rawValue {
            m_btConnected = true
        }else if m_btmStatus == BTM_STATE.POWEROFF.rawValue || m_btmStatus == BTM_STATE.HS_DISCONNECTED.rawValue || m_btmStatus == BTM_STATE.A2DP_DISCONNECTED.rawValue || m_btmStatus == BTM_STATE.ACL_DISCONNECTED.rawValue{
            m_btConnected = false
            checkConnection()
        }/*else if m_btmStatus == BTM_STATE.SCO_CONNECTED.rawValue{
            m_SCO_Connected = true
            checkConnection()
            
        }else if m_btmStatus == BTM_STATE.SCO_DISCONNECTED.rawValue{
            m_SCO_Connected = false
            checkConnection()
        }*/
        updateEarbudsStatus()
    }
    
    func reportCallStatus(status:UInt8){
        print("reportCallStatus")
        if status != 0x00 {
            m_SCO_Connected = true
        }else{
            m_SCO_Connected = false
        }
        checkConnection()
    }
    
    func reportWstStatus(status:UInt8){
        print("reportWstStatus")
        m_primaryEarbudStatus_wstState = status
        updateEarbudsStatus()
    }
    
    func reportLinkStatus(linkStatus:UInt8,playStatus:UInt8){
        print("reportLinkStatus")
        if (linkStatus == 0x03) || (linkStatus == 0x04) || (linkStatus == 0x05) || (linkStatus == 0x06) {
            m_btConnected = true
        }else{
            m_btConnected = false
        }
        updateEarbudsStatus()
        m_playStatus = playStatus
        self.featureListTableView.reloadData()
        if m_btConnected == false {
            let controller = UIAlertController(title: "Bluetooth is not connected", message: "Please establish the BT link from Settings -> Bluetooth Settings", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            controller.addAction(okAction)
            present(controller, animated: true, completion: nil)
            
            /*let controller = UIAlertController(title: "Bluetooth is not connected", message: "Please establish the BT link from Settings -> Bluetooth Settings", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Yes", style: .default) { (_) in
                guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                    return
                }
                if UIApplication.shared.canOpenURL(settingsUrl) {
                    UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                        print("Settings opened: \(success)") // Prints true
                    })
                }
            }
            controller.addAction(okAction)
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            controller.addAction(cancelAction)
            present(controller, animated: true, completion: nil)*/
        }
        
        //m_wstPeripheral?.command_ReadPrimaryBatteryLevel()
    }
    
    func reportSecondaryEarbudBatteryLevel(level:UInt8){
        print("reportSecondaryEarbudBatteryLevel")
        m_secondaryBatteryLevel = level
        updateEarbudsStatus()
    }
    
    /*func reportLocalName(name:String){
        //deviceNameLabel.text = name
    }*/
    
    func reportPlayStatus(status:UInt8){
        m_playStatus = status
        self.featureListTableView.reloadData()
    }
}
