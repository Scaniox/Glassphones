//
//  OTASecurity.m
//  TestOTA
//
//  Created by TestPC on 12/04/2018.
//  Copyright © 2018 TestPC. All rights reserved.
//

#import "OTASecurity.h"
#import <CommonCrypto/CommonCryptor.h>

#define encryptSize kCCBlockSizeAES128

@implementation OTASecurity

+ (NSData *)convertHexToData:(NSString *)hexString
{
    NSMutableData *data = [[NSMutableData alloc] init];
    @try {
        NSUInteger location = 0;
        NSString *substring;
        unsigned intValue;
        while (1) {
            substring = [hexString substringWithRange:NSMakeRange(location, 2)];
            location+=2;
            NSScanner *scanner = [NSScanner scannerWithString:[NSString stringWithFormat:@"0x%@", substring]];
            if ([scanner scanHexInt:&intValue]) {
                [data appendBytes:&intValue length:1];
            }
            if (location >= [hexString length]) {
                break;
            }
        }
    }
    @catch (NSException * e) {
        NSLog(@"Can't convert the Hex string.");
    }
    return data;
}

+ (NSData *)CBCWithOperation:(BOOL)operation ivString:(NSString *)ivString andKey:(NSString *)keyString andInput1:(NSString *)PlaintextString andInput2:(NSData *)Plaintext2
{
    const char *iv = [[self convertHexToData:(ivString)] bytes];
    //NSLog(@"iv = %@",[self convertHexToData:(ivString)]);
    
    NSData *Key = [self convertHexToData:(keyString)];
    
    const char *key = [Key bytes];
    
    CCCryptorRef cryptor;
    
    NSData *inputData;
    
    NSLog(@"key = %@",Key);
    
    if(Plaintext2 == nil) {
        inputData = [self convertHexToData:(PlaintextString)];
        //NSLog(@"plaintext = %@",inputData);
    }
    
    if(PlaintextString == nil) {
        inputData = [NSData dataWithData:Plaintext2];
        //NSLog(@"*plaintext = %@",inputData);
    }
    
    if(operation){
        //Encrypt
        CCCryptorCreateWithMode(kCCEncrypt, kCCModeCFB, kCCAlgorithmAES, ccNoPadding, iv, key, Key.length, NULL, 0, 0, 0, &cryptor);
    }
    else {
        CCCryptorCreateWithMode(kCCDecrypt, kCCModeCFB, kCCAlgorithmAES, ccNoPadding, iv, key, Key.length, NULL, 0, 0, 0, &cryptor);
    }
    
    NSUInteger inputLength = inputData.length;
    
    char *outData = malloc(inputLength);
    
    memset(outData, 0, inputLength);
    
    size_t outLength = 0;
    
    CCCryptorUpdate(cryptor, inputData.bytes, inputLength, outData, inputLength, &outLength);
    
    NSData *data = [NSData dataWithBytes: outData length: outLength];
    
    CCCryptorRelease(cryptor);
    
    free(outData);
    
    //NSLog(@"AES oupput = %@",data);
    
    return data;
    
}
@end
