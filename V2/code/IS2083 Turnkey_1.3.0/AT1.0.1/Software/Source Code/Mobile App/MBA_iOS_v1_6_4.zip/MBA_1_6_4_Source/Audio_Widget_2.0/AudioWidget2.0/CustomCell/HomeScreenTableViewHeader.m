//
//  HomeScreenTableViewHeader.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 02/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "HomeScreenTableViewHeader.h"

@implementation HomeScreenTableViewHeader

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [imageView release];
    [_groupIdentifierLabel release];
    [super dealloc];
}
@end
