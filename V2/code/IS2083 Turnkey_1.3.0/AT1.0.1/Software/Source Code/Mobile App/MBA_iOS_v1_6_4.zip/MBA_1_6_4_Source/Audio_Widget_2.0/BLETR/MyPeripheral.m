//
//  MyPeripheral.m
//  BLETR
//
//  Created by D500 user on 13/5/30.
//  Copyright (c) 2013年 ISSC. All rights reserved.
//

#import "MyPeripheral.h"
#import "ISError.h"
#import "ReliableBurstData.h"
@interface MyPeripheral () {
    BOOL isEndableTransparent;
}
@end

@implementation MyPeripheral
@synthesize peripheral;
@synthesize transDataDelegate;
//@synthesize proprietaryDelegate;
//@synthesize deviceInfoDelegate;
@synthesize DevelopeLogDelegate;
//@synthesize LeDataDelegate;
//@synthesize multipleAudioServiceDelegate;
@synthesize fWVersionDelegate;
@synthesize playbackControlDelegate;
@synthesize groupSettingDelegate;

//@synthesize airPatchChar;
@synthesize transparentDataWriteChar;
@synthesize transparentDataReadChar;
@synthesize connectionParameterChar;
//@synthesize backupConnectionParameter;
//@synthesize connectionParameter;

/*@synthesize manufactureNameChar;
@synthesize modelNumberChar;
@synthesize serialNumberChar;
@synthesize hardwareRevisionChar;
@synthesize firmwareRevisionChar;
@synthesize softwareRevisionChar;
@synthesize systemIDChar;
@synthesize certDataListChar;
@synthesize specificChar1;
@synthesize specificChar2;*/

/*@synthesize btConnectionChar;
@synthesize btModeChar;

@synthesize MasterCapabilityChar;
@synthesize GroupControlChar;
@synthesize GroupStateChar;
@synthesize RoleOfGroupChar;
@synthesize NumberOfPlayerChar;*/
@synthesize waitACK;
@synthesize advName;

- (MyPeripheral *)init {
    self = [super init];
    if (self) {
        transDataDelegate = nil;
        /*proprietaryDelegate = nil;
        deviceInfoDelegate = nil;*/
        DevelopeLogDelegate = nil;
        queuedTask = [[NSMutableArray alloc] init];
        queuedData = [[NSMutableArray alloc] init];
        self.transparentDataWriteChar = nil;
        self.transparentDataReadChar = nil;
        self.connectStatus = MYPERIPHERAL_CONNECT_STATUS_IDLE;
        _canSendData = NO;
        /*_isReadAddress = NO;*/
        waitACK = NO;
        _transmit = [[ReliableBurstData alloc] init];
        
        //NSLog(@"%@",[_transmit version]);
    }
    return self;
}

-(void)dealloc {
    //[queuedTask release];
    //[_transmit release];
    _transmit = nil;
    //[super dealloc];
}

- (NSString *)advName {
    NSString *name = nil;
    name = [self.advertiseData valueForKey:CBAdvertisementDataLocalNameKey];
    if (name == nil || [name length] == 0) {
        name = [peripheral name];
    }
    return name;
}

- (NSString *)deviceName {
    return [peripheral name];
}

- (NSData *)manuData {
    return [self.advertiseData objectForKey:CBAdvertisementDataManufacturerDataKey];
}

- (NSArray *)serviceUUIDs {
    return [self.advertiseData objectForKey:CBAdvertisementDataServiceUUIDsKey];
}

- (NSDictionary *)serviceData {
    return [self.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
}

- (NSString *)uuidString {
    NSString *str = nil;
    if ([peripheral respondsToSelector:@selector(identifier)]) {
        NSLog(@"uuidString iOS 7 later, %@, %@", peripheral.identifier, [peripheral.identifier UUIDString]);
        str = [peripheral.identifier UUIDString];
    }
    /*else {
        str = (__bridge_transfer NSString*)CFUUIDCreateString(NULL, peripheral.UUID);
        NSLog(@"uuidString iOS 6");
    }*/
    return str;
}

//DIS
/*- (void)readManufactureName {
    // NSLog(@"[MyPeripheral] readManufactureName");
    if (manufactureNameChar == nil) {
    }
    [peripheral readValueForCharacteristic:manufactureNameChar];
}

- (void)readModelNumber {
    // NSLog(@"[MyPeripheral] readModelNumber");
    [peripheral readValueForCharacteristic:modelNumberChar];
    
}

- (void)readSerialNumber {
    // NSLog(@"[MyPeripheral] readSerialNumber");
    [peripheral readValueForCharacteristic:serialNumberChar];
}

- (void)readHardwareRevision {
    //NSLog(@"[MyPeripheral] readHardwareRevision");
    [peripheral readValueForCharacteristic:hardwareRevisionChar];
}

- (void)readFirmwareRevision {
    //NSLog(@"[MyPeripheral] readFirmwareRevision");
    [peripheral readValueForCharacteristic:firmwareRevisionChar];
}

- (void)readSoftwareRevison {
    //NSLog(@"[MyPeripheral] readSoftwareRevison");
    [peripheral readValueForCharacteristic:softwareRevisionChar];
}

- (void)readSystemID {
    //NSLog(@"[MyPeripheral] readSystemID");
    [peripheral readValueForCharacteristic:systemIDChar];
}

- (void)readCertificationData {
    //NSLog(@"[MyPeripheral] readCertificationData");
    [peripheral readValueForCharacteristic:certDataListChar];
}

- (void)readSpecificUUID1 {
    //NSLog(@"[MyPeripheral] readCertificationData");
    [peripheral readValueForCharacteristic:specificChar1];
}

- (void)readSpecificUUID2 {
    //NSLog(@"[MyPeripheral] readCertificationData");
    [peripheral readValueForCharacteristic:specificChar2];
}*/

/*- (void)readMasterCapability {
    if (MasterCapabilityChar == nil) {
        return;
    }
    [peripheral readValueForCharacteristic:MasterCapabilityChar];
}

- (void)readRoleOfgroup {
    if (RoleOfGroupChar == nil) {
        return;
    }
    [peripheral readValueForCharacteristic:RoleOfGroupChar];
}

- (void)readNumberOfGroup {
    if (NumberOfPlayerChar == nil) {
        return;
    }
    [peripheral readValueForCharacteristic:NumberOfPlayerChar];
}

- (void)readGroupState {
    if (GroupStateChar == nil) {
        return;
    }
    [peripheral readValueForCharacteristic:GroupStateChar];
}*/

//Proprietary
- (CBCharacteristicWriteType)sendTransparentData:(NSData *)data type:(CBCharacteristicWriteType)type {
    NSLog(@"[MyPeripheral] sendTransparentData:%@", data);
    if (!_canSendData) {
        return CBCharacteristicWriteWithResponse;
    }
    if (transparentDataWriteChar == nil) {
        return CBCharacteristicWriteWithResponse;
    }
    CBCharacteristicWriteType actualType = type;
    if (type == CBCharacteristicWriteWithResponse) {
        if (!(transparentDataWriteChar.properties & CBCharacteristicPropertyWrite))
            actualType = CBCharacteristicWriteWithoutResponse;
    }
    else {
        if (!(transparentDataWriteChar.properties & CBCharacteristicPropertyWriteWithoutResponse))
            actualType = CBCharacteristicWriteWithResponse;
    }
    if (actualType == CBCharacteristicWriteWithoutResponse) {
        [_transmit reliableBurstTransmit:data withTransparentCharacteristic:transparentDataWriteChar];
    }
    else {
        [peripheral writeValue:data forCharacteristic:transparentDataWriteChar type:actualType];
    }

    return actualType;
}

- (void)setServiceNotification:(BOOL)notify {
    NSLog(@"[MyPeripheral] setServiceNotification");
    
    
    if(_isNotifying != notify){
        ///Transparent
        NSLog(@"Transparent Char UUID = %@",transparentDataReadChar.UUID);
        if (transparentDataReadChar != nil) {
            [peripheral setNotifyValue:notify forCharacteristic:transparentDataReadChar];
        }

        ///Group State
        /*NSLog(@"Group State Char UUID = %@",GroupStateChar.UUID);
        if (GroupStateChar != nil) {
            [peripheral setNotifyValue:notify forCharacteristic:GroupStateChar];
        }*/
    }
}


- (void)checkIsAllowUpdateConnectionParameter {
    [self setUpdateConnectionParameterStep:UPDATE_PARAMETERS_STEP_PREPARE];
    [self readConnectionParameters];
}

/*- (NSError *)setMaxConnectionInterval:(unsigned short)maxInterval connectionTimeout:(unsigned short)connectionTimeout connectionLatency:(unsigned short)connectionLatency{
    if (backupConnectionParameter.status == 0x01) {
        ISError *error = [[ISError alloc] initWithDomain:@"Last operation does not complete yet!" code:-1 userInfo:nil];
        [error setErrorDescription:@"Last operation does not complete yet!"];
        return error;
    }
    if (self.connectionParameterChar == nil) {
        ISError *error = [[ISError alloc] initWithDomain:@"Can't get the characteristic!" code:-1 userInfo:nil];
        [error setErrorDescription:@"Can't get the characteristic!"];
        return error;
    }
    
    if (maxInterval < 20) {
        ISError *error = [[ISError alloc] initWithDomain:@"Max Connection Interval must not be less than 20 ms!" code:-1 userInfo:nil];
        [error setErrorDescription:@"Max Connection Interval must not be less than 20 ms!"];
        return error;
    }
    else if (maxInterval > 2000) {
        ISError *error = [[ISError alloc] initWithDomain:@"Max Connection Interval must be less than 2000 ms!" code:-2 userInfo:nil];
        [error setErrorDescription:@"Max Connection Interval must be less than 2000 ms!"];
        return error;
    }
    else if (connectionTimeout < 500) {
        ISError *error = [[ISError alloc] initWithDomain:@"Connection Timeout must not be less than 500 ms!" code:-3 userInfo:nil];
        [error setErrorDescription:@"Connection Timeout must not be less than 500 ms!"];
        return error;
    }
    else if (connectionTimeout > 6000) {
        ISError *error = [[ISError alloc] initWithDomain:@"Connection Timeout must be less than 6000 ms!" code:-4 userInfo:nil];
        [error setErrorDescription:@"Connection Timeout must be less than 6000 ms!"];
        return error;
    }
    else if (connectionTimeout < maxInterval*3) {
        ISError *error = [[ISError alloc] initWithDomain:@"Connection Timeout must greater than three times Max Connection Interval!" code:-4 userInfo:nil];
        [error setErrorDescription:@"Connection Timeout must greater than three times Max Connection Interval!"];
        return error;
    }
    if (backupConnectionParameter.status != 0xff) {
        backupConnectionParameter.status = 0x01;
    }
    connectionParameter.status = 0xff;
    connectionParameter.maxInterval = maxInterval/1.25 + 0.5; //unit:1.25ms
    if (connectionParameter.maxInterval*1.25 > 2000) {
        connectionParameter.maxInterval--;
    }
    connectionParameter.minInterval = (maxInterval - 20)/1.25;
    if (connectionParameter.minInterval < 8) {
        connectionParameter.minInterval = 8;
    }
    connectionParameter.connectionTimeout = connectionTimeout/10; //unit:10ms
    int latency = 0;
    for (latency = 4; latency >= 0; latency--) {
        if (maxInterval * (latency+1) > 2000) {
            continue;
        }
        else if(connectionTimeout >= (maxInterval * (latency+1) *3)) {
            connectionParameter.latency = latency;
            break;
        }
    }
    
    if(connectionParameter.latency > connectionLatency){
        connectionParameter.latency = connectionLatency;
    }
    char *p = (char *)&connectionParameter;
    NSData *data = [[NSData alloc] initWithBytes:p length:sizeof(connectionParameter)];
    
    [peripheral writeValue:data forCharacteristic:self.connectionParameterChar type:CBCharacteristicWriteWithResponse];
    
    [self setUpdateConnectionParameterStep:UPDATE_PARAMETERS_STEP_CHECK_RESULT];
    [self checkConnectionParameterStatus];
    
    //  }
    
    return nil;
}*/

- (void)readConnectionParameters {
    [peripheral readValueForCharacteristic:self.connectionParameterChar];
}

- (void)checkConnectionParameterStatus {
    //NSLog(@"[MyPeripheral] checkConnectionParameterStatus");
    [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(readConnectionParameters) userInfo:nil repeats:NO];
}

/*- (CONNECTION_PARAMETER_FORMAT *)retrieveBackupConnectionParameter {
    return &backupConnectionParameter;
}*/

/*- (BOOL)compareBackupConnectionParameter:(CONNECTION_PARAMETER_FORMAT *)parameter {
    backupConnectionParameter.status = 0x00; //set result to success for comapre because only compare when success
    if (memcmp(&backupConnectionParameter, parameter, sizeof(CONNECTION_PARAMETER_FORMAT)))
        return FALSE;
    else
        return TRUE;
}*/

/*- (void)updateBackupConnectionParameter:(CONNECTION_PARAMETER_FORMAT *)parameter {
    backupConnectionParameter.status = parameter->status;
    backupConnectionParameter.minInterval = parameter->minInterval;
    backupConnectionParameter.maxInterval = parameter->maxInterval;
    backupConnectionParameter.latency = parameter->latency;
    backupConnectionParameter.connectionTimeout = parameter->connectionTimeout;
}*/

/*- (void)sendVendorMPEnable {
    NSLog(@"[MyPeripheral] sendVendorMPEnable");
    if (self.airPatchChar == nil) {
        return;
    }
    [self.peripheral setNotifyValue:TRUE forCharacteristic:self.airPatchChar];
    [self.transmit enableReliableBurstTransmit:self.peripheral andAirPatchCharacteristic:self.airPatchChar];
    
}*/

/*- (void)writeE2promValue: (short)address length:(short)length data:(char *)data {
    if (self.airPatchChar == nil) {
        return;
    }
    if (self.vendorMPEnable ==false)
        [self sendVendorMPEnable];
    struct _AIR_PATCH_COMMAND_FORMAT command;
    command.commandID = AIR_PATCH_COMMAND_E2PROM_WRITE;
    struct _WRITE_EEPROM_COMMAND_FORMAT *parameter = (struct _WRITE_EEPROM_COMMAND_FORMAT *)command.parameters;
    parameter->addr[0] = address >> 8;
    parameter->addr[1] = address & 0xff;
    int dataLen = (length > 16) ? 16 : length;
    parameter->length = dataLen;
    memcpy(parameter->data, data, dataLen);
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:length+4];
    //NSLog(@"[MyPeripheral] writeE2promValue address = %x, data = %@", address, commandData);
    [peripheral writeValue:commandData forCharacteristic:self.airPatchChar type:CBCharacteristicWriteWithResponse];
}*/

/*- (void)readE2promValue: (short)address length:(short)length {
    NSLog(@"[MyPeripheral] readE2promValue");
    if (self.airPatchChar == nil) {
        return;
    }
    if (self.vendorMPEnable ==false)
        [self sendVendorMPEnable];
    struct _AIR_PATCH_COMMAND_FORMAT command;
    command.commandID = AIR_PATCH_COMMAND_E2PROM_READ;
    struct _WRITE_EEPROM_COMMAND_FORMAT *parameter = (struct _WRITE_EEPROM_COMMAND_FORMAT *)command.parameters;
    parameter->addr[0] = address >> 8;
    parameter->addr[1] = address & 0xff;
    parameter->length = length;
    NSData *data = [[NSData alloc] initWithBytes:&command length:4];
    [peripheral writeValue:data forCharacteristic:self.airPatchChar type:CBCharacteristicWriteWithResponse];
}*/

/*- (void)writeMemoryValue: (short)address length:(short)length data:(char *)data {
    NSLog(@"[MyPeripheral] writeMemoryValue");
    if (self.airPatchChar == nil) {
        return;
    }
    if (self.vendorMPEnable ==false)
        [self sendVendorMPEnable];
    struct _AIR_PATCH_COMMAND_FORMAT command;
    command.commandID = AIR_PATCH_COMMAND_XMEMOTY_WRITE;
    struct _WRITE_EEPROM_COMMAND_FORMAT *parameter = (struct _WRITE_EEPROM_COMMAND_FORMAT *)command.parameters;
    parameter->addr[0] = address >> 8;
    parameter->addr[1] = address & 0xff;
    int dataLen = (length > 16) ? 16 : length;
    parameter->length = dataLen;
    memcpy(parameter->data, data, dataLen);
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:length+4];
    //NSLog(@"[MyPeripheral] writeE2promValue address = %x, data = %@", address, commandData);
    [peripheral writeValue:commandData forCharacteristic:self.airPatchChar type:CBCharacteristicWriteWithResponse];
}*/

/*- (void)readMemoryValue: (short)address length:(short)length {
    NSLog(@"[MyPeripheral] readMemoryValue");
    if (self.airPatchChar == nil) {
        return;
    }
    if (self.vendorMPEnable ==false)
        [self sendVendorMPEnable];
    struct _AIR_PATCH_COMMAND_FORMAT command;
    command.commandID = AIR_PATCH_COMMAND_XMEMOTY_READ;
    struct _WRITE_EEPROM_COMMAND_FORMAT *parameter = (struct _WRITE_EEPROM_COMMAND_FORMAT *)command.parameters;
    parameter->addr[0] = address >> 8;
    parameter->addr[1] = address & 0xff;
    parameter->length = length;
    NSData *data = [[NSData alloc] initWithBytes:&command length:4];
    [peripheral writeValue:data forCharacteristic:self.airPatchChar type:CBCharacteristicWriteWithResponse];
}*/

/*- (void)changePeripheralName: (NSString *)name {
    NSLog(@"[MyPeripheral] changePeripheralName");
    if (self.airPatchChar == nil) {
        return;
    }
    
    if (self.vendorMPEnable ==false) {
        [self sendVendorMPEnable];
        NSMethodSignature *sgn = [[self class] instanceMethodSignatureForSelector:@selector(changePeripheralName:)];
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:sgn];
        [invocation setTarget:self];
        [invocation setSelector:@selector(changePeripheralName:)];
        [invocation setArgument:&name atIndex:2];
        [invocation retainArguments];
        [queuedTask addObject:invocation];
        return;
    }
    
    struct _AIR_PATCH_COMMAND_FORMAT command;
    command.commandID = AIR_PATCH_COMMAND_E2PROM_WRITE;
    struct _WRITE_EEPROM_COMMAND_FORMAT *parameter = (struct _WRITE_EEPROM_COMMAND_FORMAT *)command.parameters;
    parameter->addr[0] = 0x00;
    parameter->addr[1] = 0x0b;
    parameter->length = 16;
    memset(parameter->data, 0x00, 16);
    memset(deviceName, 0x20, 16);
    int dataLen = ([name length] > 16) ? 16 : (int)[name length];
    memcpy(parameter->data, [name UTF8String], dataLen);
    memcpy(deviceName, parameter->data, dataLen);
    
    NSData *data = [[NSData alloc] initWithBytes:&command length:20];
    NSLog(@"[MyPeripheral] changePeripheralName data = %@, %x %x %x %x, %@", data, parameter->data[0], parameter->data[1], parameter->data[2], parameter->data[3], name);
    [peripheral writeValue:data forCharacteristic:self.airPatchChar type:CBCharacteristicWriteWithResponse];
    self.airPatchAction = AIR_PATCH_ACTION_CHANGE_DEVICE_NAME;
    //[data release];
    //NSLog(@"[MyPeripheral] addQueue:readHardwareRevision_AirPatch");
    NSMethodSignature *sgn = [[self class] instanceMethodSignatureForSelector:@selector(readHardwareRevision_AirPatch)];
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:sgn];
    [invocation setTarget:self];
    [invocation setSelector:@selector(readHardwareRevision_AirPatch)];
    [queuedTask addObject:invocation];
    
    //NSLog(@"[MyPeripheral] addQueue:changePeripheralNameMemory:");
    NSMethodSignature *sgn2 = [[self class] instanceMethodSignatureForSelector:@selector(changePeripheralNameMemory:)];
    NSInvocation *invocation2 = [NSInvocation invocationWithMethodSignature:sgn2];
    [invocation2 setTarget:self];
    [invocation2 setSelector:@selector(changePeripheralNameMemory:)];
    [invocation2 setArgument:&name atIndex:2];
    [invocation2 retainArguments];
    [queuedTask addObject:invocation2];
}*/

/*- (void)changePeripheralNameMemory:(NSString *)name {
    NSLog(@"[MyPeripheral] changePeripheralNameMemory");
    if (self.airPatchChar == nil) {
        return;
    }
    
    if (self.vendorMPEnable ==false) {
        [self sendVendorMPEnable];
        NSMethodSignature *sgn = [[self class] instanceMethodSignatureForSelector:@selector(changePeripheralNameMemory:)];
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:sgn];
        [invocation setTarget:self];
        [invocation setSelector:@selector(changePeripheralNameMemory:)];
        [invocation setArgument:&name atIndex:2];
        [invocation retainArguments];
        [queuedTask addObject:invocation];
        return;
    }

    struct _AIR_PATCH_COMMAND_FORMAT command;
    command.commandID = AIR_PATCH_COMMAND_XMEMOTY_WRITE;
    struct _WRITE_EEPROM_COMMAND_FORMAT *parameter = (struct _WRITE_EEPROM_COMMAND_FORMAT *)command.parameters;
    //parameter->addr[0] = 0x4E;
    //parameter->addr[1] = 0x0b;
    parameter->addr[0] = deviceNameMemoryAddr >> 8;
    parameter->addr[1] = deviceNameMemoryAddr & 0xFF;
    parameter->length = 16;
    memset(parameter->data, 0x00, 16);
    int dataLen = ([name length] > 16) ? 16 : (int)[name length];
    memcpy(parameter->data, [name UTF8String], dataLen);
    NSData *data = [[NSData alloc] initWithBytes:&command length:20];
    NSLog(@"[MyPeripheral] changePeripheralNameMemory data = %@, %x %x %x %x, len=%d", data, parameter->data[0], parameter->data[1], parameter->data[2], parameter->data[3], dataLen);
    
    [peripheral writeValue:data forCharacteristic:self.airPatchChar type:CBCharacteristicWriteWithResponse];
    //[data release];
    self.airPatchAction = AIR_PATCH_ACTION_CHANGE_DEVICE_NAME_MEMORY;
}*/

/*- (void)readHardwareRevision_AirPatch{
    NSLog(@"[MyPeripheral] readHardwareRevision_AirPatch");
    if (self.airPatchChar == nil) {
        return;
    }
    if (self.vendorMPEnable ==false)
        [self sendVendorMPEnable];
    struct _AIR_PATCH_COMMAND_FORMAT command;
    command.commandID = AIR_PATCH_COMMAND_READ_HW_VERSION;
    NSData *data = [[NSData alloc] initWithBytes:&command length:1];
    [peripheral writeValue:data forCharacteristic:self.airPatchChar type:CBCharacteristicWriteWithResponse];
}*/

/*- (void)readBtAddress{
    if (self.airPatchChar == nil) {
        return;
    }
    if (self.vendorMPEnable ==false)
        [self sendVendorMPEnable];
    struct _AIR_PATCH_COMMAND_FORMAT command;
    command.commandID = AIR_PATCH_COMMAND_E2PROM_READ;
    struct _WRITE_EEPROM_COMMAND_FORMAT *parameter = (struct _WRITE_EEPROM_COMMAND_FORMAT *)command.parameters;
    parameter->addr[0] = 0x00;
    parameter->addr[1] = 0x00;
    parameter->length = 0x06;
    NSData *data = [[NSData alloc] initWithBytes:&command length:4];
    _isReadAddress = YES;
    [peripheral writeValue:data forCharacteristic:self.airPatchChar type:CBCharacteristicWriteWithResponse];
}*/

- (void)checkQueuedTask {
    NSLog(@"[MyPeripheral] checkQueuedTask");
    if ([queuedTask count]) {
        NSInvocation *invocation = [queuedTask objectAtIndex:0];
        [invocation invoke];
        [queuedTask removeObjectAtIndex:0];
    }
}

- (void)checkQueuedData {
    NSLog(@"[MyPeripheral] checkQueuedData");
    if ([queuedData count]>0) {
        NSData *data = [queuedData firstObject];
        [queuedData removeObjectAtIndex:0];
        [self sendData:data];
    }
}

-(void)sendData:(NSData*)data{
    if (waitACK) {
        NSLog(@"Mypheriperal: sendData - Wait Ack");
        /*if ((transDataDelegate) && ([(NSObject *)transDataDelegate respondsToSelector:@selector(MyPeripheral:waitAck:)])) {
            [transDataDelegate MyPeripheral:self waitAck:waitACK];
        }*/
        [queuedData addObject:data];
        return;
    }
    
    [peripheral writeValue:data forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
    unsigned char *commandData = malloc([data length]);
    [data getBytes:commandData length:[data length]];
    unsigned char cmdID = commandData[3];
    //if (cmdID != 0x14){ //&& (cmdID != 0xCC)){///AUDIO_COMMAND_ID_EVENT_ACK
    //if ((cmdID != 0x14) && (cmdID != 0x1C)){//Audio DSP Test2
    if ((cmdID != 0x14) && (cmdID != 0x16)){//BTAS-484
        waitACK = TRUE;
    }
    
    if ((transDataDelegate) && ([(NSObject *)transDataDelegate respondsToSelector:@selector(MyPeripheral:checkAck:)])) {
        [transDataDelegate MyPeripheral:self checkAck:cmdID];
    }
    
    
    /*** Call the Dalegate for Write Data to File Here*/
    if ((transDataDelegate) && ([(NSObject *)transDataDelegate respondsToSelector:@selector(MyPeripheral:didUpdateLogForCommand:)])) {
        [transDataDelegate MyPeripheral:self didUpdateLogForCommand:data];
    }
}

- (void)changeDeviceName: (NSData *)deviceNameData {
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 33;
    command.commandID = 0x05;
    //command.commandParameters[index++] = 00; ///data_base Index
    //command.commandParameters[index++] = parameter;
    if ([deviceNameData length] > 32)
        [deviceNameData getBytes:&command.commandParameters[index] length:32];
    else
        [deviceNameData getBytes:&command.commandParameters[index] length:[deviceNameData length]];
    index += 32;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendReadLinkStatus{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x0D;
    command.commandParameters[index++] = 0x00; ///Reserved
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendReadLocalBDAddress{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x0F;
    command.commandParameters[index++] = 0x00; ///Reserved
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendReadICVersionInformation{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x32;
    command.commandParameters[index++] = 0x00; ///Reserved
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendReadnSPKStatus{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x2B;
    command.commandParameters[index++] = 0x00; ///Reserved
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendReadFeatureList{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x39;
    command.commandParameters[index++] = 0x00; ///Reserved
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}


- (void)sendReadLocalDeviceName{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x10;
    command.commandParameters[index++] = 0x00; ///Reserved
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

//- (void)sendReadLinkedDeviceInformation:(unsigned char)type{
- (void)sendReadLinkedDeviceInformation:(unsigned char)type database:(unsigned char)database{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    NSLog(@"sendReadLinkedDeviceInformation , %d",database);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x03;
    command.commandID = 0x16;
    //command.commandParameters[index++] = 0x00; ///Reserved
    command.commandParameters[index++] = database;
    command.commandParameters[index++] = type;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}


- (void)sendReadBTMBatteryChargerStatus:(unsigned char)type{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x25;
    command.commandParameters[index++] = type;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];

}

- (void)sendReadBTMVersion:(unsigned char)type{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x08;
    command.commandParameters[index++] = type;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendReadAuxInStatus{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x03;
    command.commandID = 0xCC;
    command.commandParameters[index++] = 0x00;
    command.commandParameters[index++] = 0x00;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendToggleAudioSource{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x03;
    command.commandID = 0xCC;
    command.commandParameters[index++] = 0x01;
    command.commandParameters[index++] = 0x02;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}



- (void)sendMusicControl:(unsigned char)parameter{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x03;
    command.commandID = 0x04;
    command.commandParameters[index++] = 00; ///data_base Index
    command.commandParameters[index++] = parameter;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendMmiAction:(unsigned char)parameter databaseIndex:(unsigned char)databaseIndex{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x03;
    command.commandID = 0x02;
    command.commandParameters[index++] = databaseIndex; ///data_base Index
    command.commandParameters[index++] = parameter;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
}

- (void)sendMmiAction:(unsigned char)parameter{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x03;
    command.commandID = 0x02;
    command.commandParameters[index++] = 00; ///data_base Index
    command.commandParameters[index++] = parameter;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendEventAck:(unsigned char)eventID{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x14;
    command.commandParameters[index++] = eventID;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    //[self sendData:commandData];
    
    [peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
    
    /*** Call the Dalegate for Write Data to File Here*/
    if ((transDataDelegate) && ([(NSObject *)transDataDelegate respondsToSelector:@selector(MyPeripheral:didUpdateLogForCommand:)])) {
        [transDataDelegate MyPeripheral:self didUpdateLogForCommand:commandData];
    }

    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendDspNRControl:(unsigned char)parameter{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x1D;
    command.commandParameters[index++] = parameter;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendEqModeSetting:(unsigned char)parameter{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x03;
    command.commandID = 0x1C;
    command.commandParameters[index++] = parameter;
    command.commandParameters[index++] = 0x00; ///Reserved

    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    NSLog(@"sendEqModeSetting = %@",commandData);
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendSetOverallGain:(unsigned char)mask type:(unsigned char)type gain1:(NSData*)gain1 gain2:(NSData*)gain2 gain3:(NSData*)gain3{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    
    int len = 4;
    
    command.start = 0xAA;
    command.length_H = 0x00;
    
    command.commandID = 0x23;
    command.commandParameters[index++] = 0x00; ///Reserved
    command.commandParameters[index++] = mask;
    command.commandParameters[index++] = type;
    if(gain1 != nil){
        len++;
        unsigned char *data;
        data = malloc([gain1 length]);
        [gain1 getBytes:data length:[gain1 length]];
        command.commandParameters[index++] = data[0];
    }
    if(gain2 != nil){
        len++;
        unsigned char *data;
        data = malloc([gain2 length]);
        [gain2 getBytes:data length:[gain2 length]];
        command.commandParameters[index++] = data[0];
    }
    if(gain3 != nil){
        len++;
        unsigned char *data;
        data = malloc([gain3 length]);
        [gain3 getBytes:data length:[gain3 length]];
        command.commandParameters[index++] = data[0];
    }
    command.length_L = len;

    len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendBTMUtilityFunction:(unsigned char)type parameter:(unsigned char)parameter{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x03;
    command.commandID = 0x13;
    command.commandParameters[index++] = type;
    command.commandParameters[index++] = parameter;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendDisconnectionFlag:(unsigned char)parameter{
    
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x02;
    command.commandID = 0x18;
    command.commandParameters[index++] = parameter;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    NSLog(@"sendDisconnection = %@",commandData);
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendGpioControl:(NSData *)parameters{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    unsigned char *data;
    data = malloc([parameters length]);
    [parameters getBytes:data length:[parameters length]];
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x0D;
    command.commandID = 0x1E;
    command.commandParameters[index++] = data[0];
    command.commandParameters[index++] = data[1];
    command.commandParameters[index++] = data[2];
    command.commandParameters[index++] = data[3];
    command.commandParameters[index++] = data[4];
    command.commandParameters[index++] = data[5];
    command.commandParameters[index++] = data[6];
    command.commandParameters[index++] = data[7];
    command.commandParameters[index++] = data[8];
    command.commandParameters[index++] = data[9];
    command.commandParameters[index++] = data[10];
    command.commandParameters[index++] = data[11];

    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendEventFilter:(NSData *)eventFilters{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    unsigned char *data;
    data = malloc([eventFilters length]);
    [eventFilters getBytes:data length:[eventFilters length]];
    
    command.start = 0xAA;
    command.length_H = 0x00;
    command.length_L = 0x05;
    command.commandID = 0x03;
    command.commandParameters[index++] = data[0];
    command.commandParameters[index++] = data[1];
    command.commandParameters[index++] = data[2];
    command.commandParameters[index++] = data[3];

    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}


/*- (void)createBtConnection: (NSData *)address{
    if (btConnectionChar == nil) {
        return;
    }
    [peripheral writeValue:address forCharacteristic:btConnectionChar type:CBCharacteristicWriteWithoutResponse];
}

- (void)sendBtMode:(unsigned char)parameter{
    if (btModeChar == nil) {
        return;
    }
    NSData *commandData = [NSMutableData dataWithBytes:&parameter length:sizeof(parameter)];
    [peripheral writeValue:commandData forCharacteristic:btModeChar type:CBCharacteristicWriteWithoutResponse];
}

- (void)sendGroupControl:(unsigned char)parameter{
    if (GroupControlChar == nil) {
        return;
    }
    NSData *commandData = [NSMutableData dataWithBytes:&parameter length:sizeof(parameter)];
    [peripheral writeValue:commandData forCharacteristic:GroupControlChar type:CBCharacteristicWriteWithoutResponse];
}*/

- (void)configureVendorParameter:(unsigned char)parameter deviceName:(NSString *)name{
    int index = 0;
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 0x00;
    //command.length_L = 0x03;
    command.commandID = 0x35;
    command.commandParameters[index++] = parameter;
    command.commandParameters[index++] = 0x00; ///option_reserved
    
    if(parameter == 0x00){
        command.length_L = 4 + [name length];
        command.commandParameters[index++] = [name length]; ///len
        memcpy(&command.commandParameters[index], [name UTF8String], [name length]);
        index+= [name length];
    }
    else{
        command.length_L = 0x03;
    }
    
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendNSPKExchangeLinkInfo: (NSData *)data{
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = 00;
    command.length_L = 0x11;
    command.commandID = 0x37;
    [data getBytes:&command.commandParameters length:[data length]];
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[len-3] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
    
    /*if ((DevelopeLogDelegate) && ([(NSObject *)DevelopeLogDelegate respondsToSelector:@selector(MyPeripheral:didUpdateDevelopLog:output:)])) {
        [DevelopeLogDelegate MyPeripheral:self didUpdateDevelopLog:commandData output:YES];
    }*/
}
- (void)sendPersonalGroupControl:(unsigned char)enable btAddress:(NSData *)addr{
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    int index = 0;
    
    command.start = 0xAA;
    command.length_H = 00;
    command.length_L = 0x08;
    command.commandID = 0x3A;
    command.commandParameters[index++] = enable;
    [addr getBytes:&command.commandParameters[index] length:[addr length]];
   // memcpy(&command.commandParameters[index], addr, [addr length]);
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[len-3] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
}

- (void)sendIndividualVolumeControl:(unsigned char)control btAddress:(NSData *)addr{
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    int index = 0;
    
    command.start = 0xAA;
    command.length_H = 00;
    command.length_L = 0x0C;//(0x04 + [addr length]);
    command.commandID = 0xCC;
    command.commandParameters[index++] = 0x01;
    command.commandParameters[index++] = 0x7A;
    [addr getBytes:&command.commandParameters[index] length:[addr length]];
    index += 6;//[addr length];
    command.commandParameters[index++] = 0x02;
    command.commandParameters[index++] = 0x00;
    command.commandParameters[index++] = control;
    // memcpy(&command.commandParameters[index], addr, [addr length]);
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[len-3] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
}


- (void)sendDspRuntimeProgram:(unsigned char)type data:(NSData *)data{
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    int index = 0;
    command.start = 0xAA;
    command.length_H = [data length]>>8;
    if (type == 0x2D) {
        command.length_L = 9;
    }else{
        command.length_L = 86;
    }
    //command.length_L = (([data length]&0xFF)+7);
    command.commandID = 0x30;
    command.commandParameters[index++] = type;
    
    [data getBytes:&command.commandParameters[index] length:[data length]];
    index+=[data length];
    //index += command.length_L;
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
}

- (void)sendLEData:(unsigned char)type data:(NSData *)data{
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    int index = 0;
    command.start = 0xAA;
    command.length_H = [data length]>>8;
    command.length_L = (([data length]&0xFF)+7);
    command.commandID = 0x12;
    command.commandParameters[index++] = 0x04; ///Channel Index: LE Connection indicator
    command.commandParameters[index++] = type;
    command.commandParameters[index++] = [data length]>>8; ///Total Length
    command.commandParameters[index++] = [data length]&0xFF; ///Total Length
    command.commandParameters[index++] = [data length]>>8; ///Payload Length
    command.commandParameters[index++] = [data length]&0xFF; ///Payload Length
    
    [data getBytes:&command.commandParameters[index] length:[data length]];
    index+=[data length];
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[index++] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
    
    /*if ((LeDataDelegate) && ([(NSObject *)LeDataDelegate respondsToSelector:@selector(MyPeripheral:didUpdateLeData:output:)])) {
        [LeDataDelegate MyPeripheral:self didUpdateLeData:data output:YES];
    }*/
}

- (void)sendDevelopeData:(NSData *)data{
    struct _AUDIO_UART_COMMAND_FORMAT command;
    memset(&command.start,0x00, 260);
    
    command.start = 0xAA;
    command.length_H = [data length]>>8;
    command.length_L = [data length]&0xFF;
    
    [data getBytes:&command.commandID length:[data length]];
    
    int len = (((command.length_H<<8) | (command.length_L))+2);
    unsigned char buf[260];
    memcpy(&buf[0], &command.start, 260);
    
    unsigned char chkSum=0;
    for(int i =1;i<len+1;i++)
        chkSum += buf[i];
    
    command.commandParameters[[data length]-1] = ~chkSum+1;
    
    NSData *commandData = [[NSData alloc] initWithBytes:&command length:len+2];
    [self sendData:commandData];
    //[peripheral writeValue:commandData forCharacteristic:transparentDataWriteChar type:CBCharacteristicWriteWithResponse];
    
    if ((DevelopeLogDelegate) && ([(NSObject *)DevelopeLogDelegate respondsToSelector:@selector(MyPeripheral:didUpdateDevelopLog:output:)])) {
        [DevelopeLogDelegate MyPeripheral:self didUpdateDevelopLog:commandData output:YES];
    }
}
@end
