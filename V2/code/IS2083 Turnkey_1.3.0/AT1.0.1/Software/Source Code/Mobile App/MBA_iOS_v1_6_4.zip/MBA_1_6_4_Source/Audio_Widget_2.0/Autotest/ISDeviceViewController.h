//
//  ISDeviceViewController.h
//  AutoTest
//
//  Created by Rick on 13/12/23.
//  Copyright (c) 2013年 Rick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ISDeviceViewController : UIViewController

@end
