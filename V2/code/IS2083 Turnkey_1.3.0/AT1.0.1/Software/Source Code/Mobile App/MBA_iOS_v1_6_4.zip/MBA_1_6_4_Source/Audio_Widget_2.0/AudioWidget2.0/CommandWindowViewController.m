//
//  CommandWindowViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 05/12/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "CommandWindowViewController.h"
#import "MRHexKeyboard.h"
#import "ISUtility.h"

@interface CommandWindowViewController ()

@end

@implementation CommandWindowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    sendCommandButton.layer.cornerRadius = 10.0;
    //sendCommandButton.layer.borderWidth = 2.0;
    
    commandField.delegate = self;
    commandField.inputView = [[MRHexKeyboard alloc] init];
    commandField.backgroundColor = [UIColor clearColor];
    
    logTextView.scrollEnabled = YES;
    logTextView.delegate = self;
    logTextView.editable = FALSE;
    logTextView.backgroundColor = [UIColor clearColor];
    
    UIBarButtonItem *clearButton = [[UIBarButtonItem alloc] init];
    clearButton.title = @"Clear";
    clearButton.target = self;
    [clearButton setAction:@selector(clearLogView)];
    self.navigationItem.rightBarButtonItem = clearButton;
    
    self.title = @"Command Window";
    _connectedPeripheral.DevelopeLogDelegate = self;
    [self clearLogView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [logTextView release];
    //[clearViewButton release];
    [sendCommandButton release];
    _connectedPeripheral.DevelopeLogDelegate = nil;
    [super dealloc];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark Responding to keyboard events
- (void) animateTextField:(UITextField*)textField up: (BOOL) up{
    const int movementDistance = 250;
    const float movementDuration = 0.3f;
    int movement = (up ? -movementDistance : movementDistance);
    [UIView beginAnimations:@"anim" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSCharacterSet *unacceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"1234567890aAbBcCdDeEfF"] invertedSet];
    if ([[string componentsSeparatedByCharactersInSet:unacceptedInput] count] > 1)
        return NO;
    else {
        return YES;
    }
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [self animateTextField:textField up:YES];
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    [self animateTextField:textField up:NO];
}

- (IBAction)pressSendCommandButton:(id)sender {
    [_connectedPeripheral sendDevelopeData:[ISUtility hexStrToData:commandField.text]];
    [commandField resignFirstResponder];
}

- (void)clearLogView{
    NSLog(@"Clear Log View");
    logTextView.text = @"";
}

#pragma mark - [MyPeripheralDelegate] DevelopeLogDelegate
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateDevelopLog:(NSData *)log output:(BOOL)output{
    NSString *data = [ISUtility convertDataToHexString:log];
    NSMutableAttributedString *message = [[NSMutableAttributedString alloc] initWithAttributedString:[logTextView attributedText]];
    NSString *logStr = [NSString stringWithFormat:@"0x%@\n",data];
    if (output) {
        
        NSAttributedString *str = [[NSAttributedString alloc] initWithString:logStr
                                                                attributes:@{NSForegroundColorAttributeName : [UIColor blueColor],
                                                                             NSFontAttributeName : [UIFont boldSystemFontOfSize:14]
                                                                             }];
        [message appendAttributedString:str];
    }else{
        NSAttributedString *str = [[NSAttributedString alloc] initWithString:logStr
                                                                  attributes:@{NSForegroundColorAttributeName : [UIColor redColor],
                                                                               NSFontAttributeName : [UIFont boldSystemFontOfSize:14]
                                                                               }];
        [message appendAttributedString:str];
    }
    logTextView.attributedText = message;
    [logTextView scrollRangeToVisible:NSMakeRange(logTextView.text.length -1,0)];
}




@end
