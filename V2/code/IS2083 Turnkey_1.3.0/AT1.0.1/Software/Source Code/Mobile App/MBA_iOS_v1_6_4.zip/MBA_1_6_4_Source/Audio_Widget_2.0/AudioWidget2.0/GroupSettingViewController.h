//
//  GroupSettingViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 24/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPeripheral.h"
#import "UIView+Toast.h"
@interface GroupSettingViewController : UIViewController<MyPeripheralDelegate,UIActionSheetDelegate,UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>{
    IBOutlet UITableView *myTableView;
}
@property(retain) MyPeripheral    *connectedPeripheral;
@property(assign) unsigned char speakerRole;
@property(assign) BOOL Feature_ConcertMode;
@property(assign) unsigned char _csbState;
@property(assign) BOOL Feature_StereoMode;


@end
