//
//  FilterViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/6.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class FilterViewController: UIViewController, DSPTuningDelegate{
    var DSPManager: TuneDSPManager?
    
    @IBOutlet var SPK_Filter: DropDown!
    @IBOutlet var MIC_Filter: DropDown!
    @IBOutlet var TuneDSP: UIButton!
    @IBOutlet var DSPState: UILabel!
    
    var SPK_Filter_List: Bool!
    var MIC_Filter_List: Bool!
    
    var HPF_Data: UInt8 = 0x00
    var HPF_Prev_Data: UInt8 = 0x00
    
    let filter_table = ["Cutoff Freq:50Hz", "Cutoff Freq:80Hz", "Cutoff Freq:120Hz", "Cutoff Freq:180Hz", "Cutoff Freq:210Hz", "Cutoff Freq:300Hz", "Cutoff Freq:400Hz"]
    
    let filter_ids = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        TuneDSP.layer.cornerRadius = 15.0
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.VoiceFilter_Delegate = self
        
        SPK_Filter.isSearchEnable = false
        MIC_Filter.isSearchEnable = false
        
        SPK_Filter_List = false
        MIC_Filter_List = false
        
        SPK_Filter.optionArray = filter_table
        SPK_Filter.optionIds = filter_ids
        
        MIC_Filter.optionArray = filter_table
        MIC_Filter.optionIds = filter_ids
        
        SPK_Filter.didSelect{(selectedText , index , id) in
            print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.SPK_Filter.text != self.filter_table[self.SPK_Filter.selectedIndex!]){
                self.DSPTuningEnable()
                print("HPF data =\(String(format: "0x%02X",self.HPF_Data))")
                self.HPF_Data &= ~(0xF0)
                self.HPF_Data |= UInt8(self.SPK_Filter.selectedIndex!) << 4
                print("New HPF data =\(String(format: "0x%02X",self.HPF_Data))")
            }
        }
        
        MIC_Filter.didSelect{(selectedText , index , id) in
            print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.MIC_Filter.text != self.filter_table[self.MIC_Filter.selectedIndex!]){
                self.DSPTuningEnable()
                print("HPF data =\(String(format: "0x%02X",self.HPF_Data))")
                self.HPF_Data &= ~(0x0F)
                self.HPF_Data |= UInt8(self.MIC_Filter.selectedIndex!)
                print("New HPF data =\(String(format: "0x%02X",self.HPF_Data))")
            }
        }
        
        SPK_Filter.listWillAppear {
            self.SPK_Filter_List = true
            
            if(self.MIC_Filter_List == true){
                self.MIC_Filter.hideList()
            }
            
            self.MIC_Filter.isHidden = true
            self.TuneDSP.isHidden = true
        }
        
        SPK_Filter.listDidDisappear {
            self.SPK_Filter_List = false
            
            if(self.MIC_Filter.isHidden == true){
                self.MIC_Filter.isHidden = false
            }
            
            if(self.TuneDSP.isHidden == true){
                self.TuneDSP.isHidden = false
            }
        }
        
        MIC_Filter.listWillAppear {
            self.MIC_Filter_List = true
            
            self.TuneDSP.isHidden = true
        }
        
        MIC_Filter.listDidDisappear {
            self.MIC_Filter_List = false
            
            if(self.TuneDSP.isHidden == true && self.SPK_Filter_List == false){
                self.TuneDSP.isHidden = false
            }
        }
        
        DSPTuningDisable()
        
        DSPManager?.DSP_Init()
        let device_capability = DSPManager?.Get_Device_Capability()
        print("device_capability = \(device_capability!)")
        
        if(DSPManager?.Audio_Config == nil){
            LoadDSPConfigData()
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[FilterViewController] viewWillAppear")
        
        DSPManager?.Restore_DSP_State()
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        print("HPF data =\(HPF_Data)")
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "Filter")
        
        if(SPK_Filter.text == "" || HPF_Data == 0x00){
            DSPTuningDisable()
            self.DSPManager?.Get_Voice_DSP_Setting_Filter()
        }
        
        /*
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport){
            SPK_Filter.isUserInteractionEnabled = false
            MIC_Filter.isUserInteractionEnabled = false
            DSPTuningDisable()
        }*/
        
        if(DSPState.text == "DSP Status: "){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
        
        if(DSPManager?.RefreshGUIData(UIView_index: 3) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 3)
            DSPTuningDisable()
            self.DSPManager?.Get_Voice_DSP_Setting_Filter()
        }
        
        
        
        /*
        //Simulator
        SPK_Filter.selectedIndex = 0
        SPK_Filter.text = filter_table[SPK_Filter.selectedIndex!]
        MIC_Filter.selectedIndex = 0
        MIC_Filter.text = filter_table[MIC_Filter.selectedIndex!]
        */
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[Filter]viewWillDisappear")
        
        if(TuneDSP.isEnabled == true){
            if(HPF_Data != HPF_Prev_Data){
                DSPManager?.DSPQueueData(module:0x0D, cfg:0x09, len:0x01, data:[HPF_Data])
                HPF_Prev_Data = HPF_Data
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func ResetParameters(_ sender: Any) {
        if(TuneDSP.isEnabled == true && HPF_Data != HPF_Prev_Data){
            print("ResetParameters")
            
            ResetGUIData()
        }
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        print("DSPTuning..")
        
        DSPManager?.DSPTuning(module: 0x0D, cfg: 0x09, len: 0x01, data: [HPF_Data])
    }
    
    func ResetGUIData(){
        HPF_Data = HPF_Prev_Data
        DSPTuningDisable()
        
        let spk_hpf = (HPF_Data & 0xf0) >> 4
        let mic_hpf = HPF_Data & 0x0f
        
        print("spk_hpf = \(spk_hpf),mic_hpf = \(mic_hpf)")
        
        SPK_Filter.selectedIndex = Int(spk_hpf)
        SPK_Filter.text = filter_table[SPK_Filter.selectedIndex!]
        
        MIC_Filter.selectedIndex = Int(mic_hpf)
        MIC_Filter.text = filter_table[MIC_Filter.selectedIndex!]
    }
    
    func LoadDSPConfigData() {
        let alertController = UIAlertController(
            title: nil,
            message: "Load DSP Configuration\n\n\n",
            preferredStyle: .alert)
        
        let activityIndicator : UIActivityIndicatorView = UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.whiteLarge)
        
        activityIndicator.color = UIColor.black
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        alertController.view.addSubview(activityIndicator)
        
        let centerHorizontally = NSLayoutConstraint(item: activityIndicator,
                                                    attribute: .centerX,
                                                    relatedBy: .equal,
                                                    toItem: activityIndicator.superview,
                                                    attribute: .centerX,
                                                    multiplier: 1.0,
                                                    constant: 0.0)
        
        let centerVertically = NSLayoutConstraint(item: activityIndicator,
                                                  attribute: .centerY,
                                                  relatedBy: .equal,
                                                  toItem: activityIndicator.superview,
                                                  attribute: .centerY,
                                                  multiplier: 1.0,
                                                  constant: 0.0)
        
        NSLayoutConstraint.activate([centerHorizontally, centerVertically])
        
        activityIndicator.startAnimating()
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func Filter_Init(){
        
        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
            print("**UIAlertController is presenting here!")
            self.dismiss(animated: true, completion: nil)
        }
        
        let spk_hpf = (HPF_Data & 0xf0) >> 4
        let mic_hpf = HPF_Data & 0x0f
        
        print("spk_hpf = \(spk_hpf),mic_hpf = \(mic_hpf)")
        
        SPK_Filter.selectedIndex = Int(spk_hpf)
        SPK_Filter.text = filter_table[SPK_Filter.selectedIndex!]
        
        MIC_Filter.selectedIndex = Int(mic_hpf)
        MIC_Filter.text = filter_table[MIC_Filter.selectedIndex!]
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[Filter] BLE_ConnectionStatus = \(status)")
        
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
        print("BLE_ServiceReady")
        
        if(DSPManager?.Audio_Config == nil){
            DSPManager?.Read_Module_Audio_MCU()
        }
        else{
            self.DSPManager?.Get_Voice_DSP_Setting_Filter()
        }
    }
    
    func RefreshModuleData() {
        print("[Voice Filter] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 9){
                if(buffer[k+2] == 1){
                    HPF_Data = buffer[k+3]
                    HPF_Prev_Data = HPF_Data
                    print("HPF data =\(HPF_Data)")
                    Filter_Init()
                    break
                }
            }
            
            k += Int(3+len)
        }
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            if(result != 0x01){
                self.ResetGUIData()
            }
            self.DSPManager?.ClearRefreshFlag(UIView_index: 3)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String) {
        print("Filter: DSP State")
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(SPK_Filter_List == true){
                SPK_Filter_List = false
                SPK_Filter.hideList()
            }
            SPK_Filter.isUserInteractionEnabled = false
            if(MIC_Filter_List == true){
                MIC_Filter_List = false
                MIC_Filter.hideList()
            }
            MIC_Filter.isUserInteractionEnabled = false
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            SPK_Filter.isUserInteractionEnabled = true
            MIC_Filter.isUserInteractionEnabled = true
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
