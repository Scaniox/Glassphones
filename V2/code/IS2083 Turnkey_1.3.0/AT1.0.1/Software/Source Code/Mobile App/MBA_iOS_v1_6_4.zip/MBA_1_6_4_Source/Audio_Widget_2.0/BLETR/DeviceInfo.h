//
//  DeviceInfo.h
//  BLETR
//
//  Created by d500_MacMini on 13/6/19.
//  Copyright (c) 2013年 ISSC. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "ViewController.h"
#import "CBController.h"
//#import "InfoViewController.h"
//#import "UartCommandTableViewController.h"
//#import "GSDRootViewController.h"

@interface DeviceInfo : NSObject

@property(retain) MyPeripheral *myPeripheral;
//@property(retain) UartCommandTableViewController *uartCommandTableViewController;
//@property(retain) GSDRootViewController *gsdViewController;

@end
