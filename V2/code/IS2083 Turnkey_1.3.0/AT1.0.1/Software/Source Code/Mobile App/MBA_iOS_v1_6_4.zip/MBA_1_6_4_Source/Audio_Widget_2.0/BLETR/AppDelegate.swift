//
//  AppDelegate.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/8/27.
//  Copyright © 2019 ISSC. All rights reserved.
//

import Foundation
import UIKit
//import CallKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        //iOS 13 Dark mode
        if #available(iOS 13.0, *) {
            window?.overrideUserInterfaceStyle = .light
        }
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        print("applicationDidEnterBackground")
        UIApplication.shared.setMinimumBackgroundFetchInterval( 60 )
        let controller = application.topMostViewController()
        if(controller is WstViewController){
            let vc = controller.self as! WstViewController
            vc.setBackgroundMode(background: true)
        }else if (controller is WstEarbudSettingViewController){
            let vc = controller.self as! WstEarbudSettingViewController
            vc.setBackgroundMode(background: true)
        }else if (controller is WstEqModeTableViewController){
            let vc = controller.self as! WstEqModeTableViewController
            vc.setBackgroundMode(background: true)
        }else if (controller is WstFindMyEarbudsViewController){
            let vc = controller.self as! WstFindMyEarbudsViewController
            vc.setBackgroundMode(background: true)
        }else if (controller is WstTouchpadSettingViewController){
            let vc = controller.self as! WstTouchpadSettingViewController
            vc.setBackgroundMode(background: true)
        }else if (controller is WstButtonActionTableViewController){
            let vc = controller.self as! WstButtonActionTableViewController
            vc.setBackgroundMode(background: true)
        }
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        print("applicationDidBecomeActive")
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        let controller = application.topMostViewController()
        if(controller is WstViewController){
            let vc = controller.self as! WstViewController
            vc.setBackgroundMode(background: false)
        }else if (controller is WstEarbudSettingViewController){
            let vc = controller.self as! WstEarbudSettingViewController
            vc.setBackgroundMode(background: false)
        }else if (controller is WstEqModeTableViewController){
            let vc = controller.self as! WstEqModeTableViewController
            vc.setBackgroundMode(background: false)
        }else if (controller is WstFindMyEarbudsViewController){
            let vc = controller.self as! WstFindMyEarbudsViewController
            vc.setBackgroundMode(background: false)
        }else if (controller is WstTouchpadSettingViewController){
            let vc = controller.self as! WstTouchpadSettingViewController
            vc.setBackgroundMode(background: false)
        }else if (controller is WstButtonActionTableViewController){
            let vc = controller.self as! WstButtonActionTableViewController
            vc.setBackgroundMode(background: false)
        }
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        print("applicationWillTerminate")
        let controller = application.topMostViewController()
        if(controller is WstViewController){
            let vc = controller.self as! WstViewController
            vc.terminateBle()
        }else if (controller is WstEarbudSettingViewController){
            let vc = controller.self as! WstEarbudSettingViewController
            vc.terminateBle()
        }else if (controller is WstEqModeTableViewController){
            let vc = controller.self as! WstEqModeTableViewController
            vc.terminateBle()
        }else if (controller is WstFindMyEarbudsViewController){
            let vc = controller.self as! WstFindMyEarbudsViewController
            vc.terminateBle()
        }else if (controller is WstTouchpadSettingViewController){
            let vc = controller.self as! WstTouchpadSettingViewController
            vc.terminateBle()
        }else if (controller is WstButtonActionTableViewController){
            let vc = controller.self as! WstButtonActionTableViewController
            vc.terminateBle()
        }
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
//    func application(_ application: UIApplication, performFetchWithCompletionHandler completionHandler: (UIBackgroundFetchResult) -> Void) {
//        var fetchResult: UIBackgroundFetchResult!
//
//
//        if doingYourStuffActuallyCreatesNetworkTraffic() {
//            fetchResult = UIBackgroundFetchResult.newData
//        } else if thereWasAnError() {
//            fetchResult = UIBackgroundFetchResult.failed
//        } else {
//            fetchResult = UIBackgroundFetchResult.noData
//        }
//        completionHandler( fetchResult )
//
//        return
//    }
}

extension UIViewController {
    func topMostViewController() -> UIViewController {
        if self.presentedViewController == nil {
            return self
        }
        if let navigation = self.presentedViewController as? UINavigationController {
            return navigation.visibleViewController!.topMostViewController()
        }
        if let tab = self.presentedViewController as? UITabBarController {
            if let selectedTab = tab.selectedViewController {
                return selectedTab.topMostViewController()
            }
            return tab.topMostViewController()
        }
        return self.presentedViewController!.topMostViewController()
    }
}

extension UIApplication {
    func topMostViewController() -> UIViewController? {
        return self.keyWindow?.rootViewController?.topMostViewController()
    }
}
