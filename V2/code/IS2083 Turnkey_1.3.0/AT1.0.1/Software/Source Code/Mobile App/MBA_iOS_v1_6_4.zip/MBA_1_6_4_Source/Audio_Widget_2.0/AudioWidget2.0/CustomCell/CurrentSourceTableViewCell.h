//
//  CurrentSourceTableViewCell.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 22/03/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CurrentSourceTableViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *AudioSourceLabel;
@property (retain, nonatomic) IBOutlet UIButton *AudioSourceToggleBtn;
@property (retain, nonatomic) IBOutlet UILabel *CellTitleLabel;

@end
