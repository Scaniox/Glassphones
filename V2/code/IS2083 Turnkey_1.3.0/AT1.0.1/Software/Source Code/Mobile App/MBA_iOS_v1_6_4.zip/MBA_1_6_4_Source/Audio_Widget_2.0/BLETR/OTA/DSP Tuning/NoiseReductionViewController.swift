//
//  NoiseReductionViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/6.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class NoiseReductionViewController: UIViewController, DSPTuningDelegate{
    @IBOutlet var SPK_NR: DropDown!
    @IBOutlet var MIC_NR: DropDown!
    @IBOutlet var TuneDSP: UIButton!
    @IBOutlet var DSPState: UILabel!
    @IBOutlet var FENR_checkbox: VKCheckbox!
    @IBOutlet var NENR_checkbox: VKCheckbox!
    
    @IBOutlet var NoiseFactor: DropDown!
    @IBOutlet var CoefLow: DropDown!
    
    var DSPManager: TuneDSPManager?
    
    var Hidden: Bool?
    
    var SPK_List: Bool!
    var MIC_List: Bool!
    var NoiseFactor_List: Bool!
    var CoefHigh_List: Bool!
    var CoefLow_List: Bool!
    var SampleDelay_List: Bool!
    
    @IBOutlet var CoefHigh: DropDown!
    @IBOutlet var SampleDelay: DropDown!
    
    @IBOutlet var FENR_Label: UILabel!
    @IBOutlet var NENR_Label: UILabel!
    @IBOutlet var NoiseFactor_Label: UILabel!
    @IBOutlet var CoefLow_Label: UILabel!
    @IBOutlet var CoefHigh_Label: UILabel!
    @IBOutlet var SampleDelay_Label: UILabel!
    
    var SPK_NoiseReduction_Data: [UInt8] = [UInt8]()
    var MIC_NoiseReduction_Data: [UInt8] = [UInt8]()
    
    var SPK_Prev_Data: [UInt8] = [UInt8]()
    var MIC_Prev_Data: [UInt8] = [UInt8]()
    
    var SampleDelay_data: UInt8?
    var SampleDelay_prev_data: UInt8?
    
    //var DSPTuningSPK: Bool = false
    //var DSPTuningMIC: Bool = false
    var Modified_Parameters: UInt8?
    
    let NR_table = ["6dB Noise Suppression", "9dB Noise Suppression", "12dB Noise Suppression", "15dB Noise Suppression -Default", "18dB Noise Suppression", "21dB Noise Suppression", "24dB Noise Suppression", "27dB Noise Suppression", "30dB Noise Suppression"]
    
    let NR_table1 = ["6dB Noise Suppression", "9dB", "12dB", "15dB -Default", "18dB", "21dB", "24dB", "27dB", "30dB"]
    
    let NoiseFactor_table = ["0x00", "0x01", "0x02"]
    let NoiseFactor_ids = [1, 2, 3]
    
    let Coef_high_low_table = ["0x00", "0x01", "0x02", "0x03"]
    let Coef_ids = [1, 2, 3, 4]
    
    let SampleDelay_table = ["0x00", "0x01", "0x02", "0x03", "0x04"]
    let SampleDelay_ids = [1, 2, 3, 4, 5]
    
    let NR_Low_ids = [64, 45, 32, 22, 16, 11, 8, 6, 4]
    let NR_High_ids = [90, 64, 45, 32, 22, 16, 11, 8, 6]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        TuneDSP.layer.cornerRadius = 15.0
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.VoiceNR_Delegate = self
        
        SPK_List = false
        MIC_List = false
        NoiseFactor_List = false
        CoefLow_List = false
        CoefHigh_List = false
        SampleDelay_List = false
        
        Modified_Parameters = 0x00
        
        SPK_NR.isSearchEnable = false
        MIC_NR.isSearchEnable = false
        
        NoiseFactor.isSearchEnable = false
        CoefLow.isSearchEnable = false
        CoefHigh.isSearchEnable = false
        SampleDelay.isSearchEnable = false
        
        //SPK_NR.optionArray = NR_table
        //MIC_NR.optionArray = NR_table
        SPK_NR.optionArray = NR_table1
        MIC_NR.optionArray = NR_table1
        
        SPK_NR.optionIds = NR_Low_ids
        MIC_NR.optionIds = NR_Low_ids
        
        NoiseFactor.optionArray = NoiseFactor_table
        NoiseFactor.optionIds = NoiseFactor_ids
        
        CoefHigh.optionArray = Coef_high_low_table
        CoefHigh.optionIds = Coef_ids
        
        CoefLow.optionArray = Coef_high_low_table
        CoefLow.optionIds = Coef_ids
        
        CoefHigh.listHeight = 90
        
        SampleDelay.optionArray = SampleDelay_table
        SampleDelay.optionIds = SampleDelay_ids
        
        SampleDelay.listHeight = 60
        
        FENR_checkbox.setOn(true)
        NENR_checkbox.setOn(false)
        
        SPK_NR.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.SPK_NR.text != self.NR_table1[self.SPK_NR.selectedIndex!]){
                print("Selected String = \(self.NR_table1[self.SPK_NR.selectedIndex!])")
                self.DSPTuningEnable()
                print("SPK NR data = \(String(format: "0x%02X",self.SPK_NoiseReduction_Data[0])),\(String(format: "0x%02X",self.SPK_NoiseReduction_Data[1]))")
                self.SPK_NoiseReduction_Data[0] = UInt8(self.NR_Low_ids[self.SPK_NR.selectedIndex!])
                self.SPK_NoiseReduction_Data[1] = UInt8(self.NR_High_ids[self.SPK_NR.selectedIndex!])
                print("New data = \(String(format: "0x%02X",self.SPK_NoiseReduction_Data[0])),\(String(format: "0x%02X",self.SPK_NoiseReduction_Data[1]))")
                //print("\(String(format: "%02X",self.SPK_NoiseReduction_Data[0]))")
                //self.DSPTuningSPK = true
                self.Modified_Parameters! |= 0x01
            }
        }
        
        MIC_NR.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.MIC_NR.text != self.NR_table1[self.MIC_NR.selectedIndex!]){
                print("Selected String = \(self.NR_table1[self.MIC_NR.selectedIndex!])")
                self.DSPTuningEnable()
                print("MIC NR data = \(String(format: "0x%02X",self.MIC_NoiseReduction_Data[0])),\(String(format: "0x%02X",self.MIC_NoiseReduction_Data[1]))")
                self.MIC_NoiseReduction_Data[0] = UInt8(self.NR_Low_ids[self.MIC_NR.selectedIndex!])
                self.MIC_NoiseReduction_Data[1] = UInt8(self.NR_High_ids[self.MIC_NR.selectedIndex!])
                print("New data = \(String(format: "0x%02X",self.MIC_NoiseReduction_Data[0])),\(String(format: "0x%02X",self.MIC_NoiseReduction_Data[1]))")
                //self.DSPTuningMIC = true
                self.Modified_Parameters! |= 0x02
            }
        }
        
        NoiseFactor.didSelect{(selectedText , index , id) in
            if(self.NoiseFactor.text != self.NoiseFactor_table[self.NoiseFactor.selectedIndex!]){
                if(self.FENR_checkbox.isOn()){
                    if(self.SPK_NoiseReduction_Data.count != 0){
                        self.SPK_NoiseReduction_Data[2] &= ~(0x30)
                        self.SPK_NoiseReduction_Data[2] |= UInt8(self.NoiseFactor.selectedIndex!) << 4
                        print("SPK_NoiseReduction_Data[2] = \(String(format: "0x%02X",self.SPK_NoiseReduction_Data[2]))")
                        self.DSPTuningEnable()
                        self.Modified_Parameters! |= 0x01
                    }
                }
                else if(self.NENR_checkbox.isOn()){
                    if(self.MIC_NoiseReduction_Data.count != 0){
                        self.MIC_NoiseReduction_Data[2] &= ~(0x30)
                        self.MIC_NoiseReduction_Data[2] |= UInt8(self.NoiseFactor.selectedIndex!) << 4
                        print("MIC_NoiseReduction_Data[2] = \(String(format: "0x%02X",self.MIC_NoiseReduction_Data[2]))")
                        self.DSPTuningEnable()
                        self.Modified_Parameters! |= 0x02
                    }
                }
            }
        }
        
        CoefLow.didSelect{(selectedText , index , id) in
            if(self.CoefLow.text != self.Coef_high_low_table[self.CoefLow.selectedIndex!]){
                if(self.FENR_checkbox.isOn()){
                    if(self.SPK_NoiseReduction_Data.count != 0){
                        self.SPK_NoiseReduction_Data[2] &= ~(0x0C)
                        self.SPK_NoiseReduction_Data[2] |= UInt8(self.CoefLow.selectedIndex!) << 2
                        print("SPK_NoiseReduction_Data[2] = \(String(format: "0x%02X",self.SPK_NoiseReduction_Data[2]))")
                        self.DSPTuningEnable()
                        self.Modified_Parameters! |= 0x01
                    }
                }
                else if(self.NENR_checkbox.isOn()){
                    if(self.MIC_NoiseReduction_Data.count != 0){
                        self.MIC_NoiseReduction_Data[2] &= ~(0x0C)
                        self.MIC_NoiseReduction_Data[2] |= UInt8(self.CoefLow.selectedIndex!) << 2
                        print("MIC_NoiseReduction_Data[2] = \(String(format: "0x%02X",self.MIC_NoiseReduction_Data[2]))")
                        self.DSPTuningEnable()
                        self.Modified_Parameters! |= 0x02
                    }
                }
            }
        }
        
        CoefHigh.didSelect{(selectedText , index , id) in
            if(self.CoefHigh.text != self.Coef_high_low_table[self.CoefHigh.selectedIndex!]){
                if(self.FENR_checkbox.isOn()){
                    if(self.SPK_NoiseReduction_Data.count != 0){
                        self.SPK_NoiseReduction_Data[2] &= ~(0x03)
                        self.SPK_NoiseReduction_Data[2] |= UInt8(self.CoefHigh.selectedIndex!)
                        print("SPK_NoiseReduction_Data[2] = \(String(format: "0x%02X",self.SPK_NoiseReduction_Data[2]))")
                        self.DSPTuningEnable()
                        self.Modified_Parameters! |= 0x01
                    }
                }
                else if(self.NENR_checkbox.isOn()){
                    if(self.MIC_NoiseReduction_Data.count != 0){
                        self.MIC_NoiseReduction_Data[2] &= ~(0x03)
                        self.MIC_NoiseReduction_Data[2] |= UInt8(self.CoefHigh.selectedIndex!)
                        print("MIC_NoiseReduction_Data[2] = \(String(format: "0x%02X",self.MIC_NoiseReduction_Data[2]))")
                        self.DSPTuningEnable()
                        self.Modified_Parameters! |= 0x02
                    }
                }
            }
        }
        
        SampleDelay.didSelect{(selectedText , index , id) in
            if(self.SampleDelay.text != self.SampleDelay_table[self.SampleDelay.selectedIndex!]){
                if(self.SampleDelay_data != nil){
                    self.SampleDelay_data = UInt8(self.SampleDelay.selectedIndex!)
                    print("SampleDelay_data = \(String(format: "0x%02X",self.SampleDelay_data!))")
                    self.DSPTuningEnable()
                    self.Modified_Parameters! |= 0x04
                }
            }
        }
        
        SPK_NR.listWillAppear {
            self.SPK_List = true
            
            if(self.MIC_List == true){
                self.MIC_NR.hideList()
            }
            
            if(self.NoiseFactor_List == true){
                self.NoiseFactor.hideList()
            }
            
            if(self.CoefLow_List == true){
                self.CoefLow.hideList()
            }
            
            if(self.CoefHigh_List == true){
                self.CoefHigh.hideList()
            }
            
            if(self.SampleDelay_List == true){
                self.SampleDelay.hideList()
            }
            
            self.MIC_NR.isHidden = true
            self.TuneDSP.isHidden = true
            
            //Hidden
            self.NENR_Label.isHidden = true
            self.NoiseFactor.isHidden = true
            self.CoefLow.isHidden = true
            self.CoefHigh.isHidden = true
            self.SampleDelay.isHidden = true
        }
        
        MIC_NR.listWillAppear {
            self.MIC_List = true
            
            if(self.NoiseFactor_List == true){
                self.NoiseFactor.hideList()
            }
            
            if(self.CoefLow_List == true){
                self.CoefLow.hideList()
            }
            
            if(self.CoefHigh_List == true){
                self.CoefHigh.hideList()
            }
            
            if(self.SampleDelay_List == true){
                self.SampleDelay.hideList()
            }
            
            //Hidden
            self.NENR_Label.isHidden = true
            self.NoiseFactor.isHidden = true
            self.CoefLow.isHidden = true
            self.CoefHigh.isHidden = true
            self.SampleDelay.isHidden = true
            
            self.TuneDSP.isHidden = true
        }
        
        SPK_NR.listDidDisappear {
            self.SPK_List = false
            
            self.MIC_NR.isHidden = false
            self.TuneDSP.isHidden = false

            self.NENR_Label.isHidden = self.Hidden!
            self.NoiseFactor.isHidden = self.Hidden!
            self.CoefLow.isHidden = self.Hidden!
            self.CoefHigh.isHidden = self.Hidden!
            self.SampleDelay.isHidden = self.Hidden!
        }
        
        MIC_NR.listDidDisappear {
            self.MIC_List = false
            
            if(self.SPK_List == false){
                //Hidden
                
                self.NENR_Label.isHidden = self.Hidden!
                self.NoiseFactor.isHidden = self.Hidden!
                self.CoefLow.isHidden = self.Hidden!
                self.CoefHigh.isHidden = self.Hidden!
                self.SampleDelay.isHidden = self.Hidden!
                
                self.TuneDSP.isHidden = false
            }
        }
        
        NoiseFactor.listWillAppear {
            self.NoiseFactor_List = true
            
            if(self.CoefLow_List == true){
                self.CoefLow.hideList()
            }
            
            if(self.CoefHigh_List == true){
                self.CoefHigh.hideList()
            }
            
            if(self.SampleDelay_List == true){
                self.SampleDelay.hideList()
            }
            
            self.SampleDelay_Label.isHidden = true
            self.CoefLow.isHidden = true
            self.CoefHigh.isHidden = true
            self.SampleDelay.isHidden = true
            self.TuneDSP.isHidden = true
        }
        
        NoiseFactor.listDidDisappear {
            self.NoiseFactor_List = false
            
            if(self.SPK_List == false && self.MIC_List == false){
                self.SampleDelay_Label.isHidden = false
                self.CoefLow.isHidden = false
                self.CoefHigh.isHidden = false
                self.SampleDelay.isHidden = false
                self.TuneDSP.isHidden = false
            }
        }
        
        CoefLow.listWillAppear {
            self.CoefLow_List = true
            
            if(self.CoefHigh_List == true){
                self.CoefHigh.hideList()
            }
            
            if(self.SampleDelay_List == true){
                self.SampleDelay.hideList()
            }
            
            self.SampleDelay_Label.isHidden = true
            self.CoefHigh.isHidden = true
            self.SampleDelay.isHidden = true
            self.TuneDSP.isHidden = true
        }
        
        CoefLow.listDidDisappear {
            self.CoefLow_List = false
            
            if(self.SPK_List == false && self.MIC_List == false && self.NoiseFactor_List == false){
                self.SampleDelay_Label.isHidden = false
                self.CoefHigh.isHidden = false
                self.SampleDelay.isHidden = false
                self.TuneDSP.isHidden = false
            }
        }
        
        CoefHigh.listWillAppear {
            self.CoefHigh_List = true
            
            if(self.SampleDelay_List == true){
                self.SampleDelay.hideList()
            }
            
            self.SampleDelay_Label.isHidden = true
            self.SampleDelay.isHidden = true
            self.TuneDSP.isHidden = true
        }
        
        CoefHigh.listDidDisappear {
            self.CoefHigh_List = false
            
            if(self.SPK_List == false && self.MIC_List == false && self.NoiseFactor_List == false && self.CoefLow_List == false){
                self.SampleDelay_Label.isHidden = false
                self.SampleDelay.isHidden = false
                self.TuneDSP.isHidden = false
            }
        }
        
        SampleDelay.listWillAppear {
            self.SampleDelay_List = true
            
            self.TuneDSP.isHidden = true
        }
        
        SampleDelay.listDidDisappear {
            self.SampleDelay_List = false
            
            if(self.SPK_List == false && self.MIC_List == false && self.NoiseFactor_List == false && self.CoefLow_List == false && self.CoefHigh_List == false){
                self.TuneDSP.isHidden = false
            }
        }
        
        FENR_checkbox.checkboxValueChangedBlock = {
            isOn in
            print("FENR_checkbox is \(isOn ? "ON" : "OFF")")
            
            if(isOn){
                if(self.NoiseFactor_List == true){
                    self.NoiseFactor.hideList()
                }
                
                if(self.CoefLow_List == true){
                    self.CoefLow.hideList()
                }
                
                if(self.CoefHigh_List == true){
                    self.CoefHigh.hideList()
                }
                
                self.NENR_checkbox.setOn(false)
                
                if(self.SPK_NoiseReduction_Data.count != 0){
                    self.NoiseFactor.selectedIndex = Int((self.SPK_NoiseReduction_Data[2] & 0x30) >> 4)
                    self.NoiseFactor.text = self.NoiseFactor_table[self.NoiseFactor.selectedIndex!]
                    self.CoefLow.selectedIndex = Int((self.SPK_NoiseReduction_Data[2] & 0x0C) >> 2)
                    self.CoefLow.text = self.Coef_high_low_table[self.CoefLow.selectedIndex!]
                    self.CoefHigh.selectedIndex = Int((self.SPK_NoiseReduction_Data[2] & 0x03))
                    self.CoefHigh.text = self.Coef_high_low_table[self.CoefHigh.selectedIndex!]
                }
            }
        }
        
        NENR_checkbox.checkboxValueChangedBlock = {
            isOn in
            print("NENR_checkbox is \(isOn ? "ON" : "OFF")")
            
            if(isOn){
                if(self.NoiseFactor_List == true){
                    self.NoiseFactor.hideList()
                }
                
                if(self.CoefLow_List == true){
                    self.CoefLow.hideList()
                }
                
                if(self.CoefHigh_List == true){
                    self.CoefHigh.hideList()
                }
                
                self.FENR_checkbox.setOn(false)
                
                if(self.MIC_NoiseReduction_Data.count != 0){
                    self.NoiseFactor.selectedIndex = Int((self.MIC_NoiseReduction_Data[2] & 0x30) >> 4)
                    self.NoiseFactor.text = self.NoiseFactor_table[self.NoiseFactor.selectedIndex!]
                    self.CoefLow.selectedIndex = Int((self.MIC_NoiseReduction_Data[2] & 0x0C) >> 2)
                    self.CoefLow.text = self.Coef_high_low_table[self.CoefLow.selectedIndex!]
                    self.CoefHigh.selectedIndex = Int((self.MIC_NoiseReduction_Data[2] & 0x03))
                    self.CoefHigh.text = self.Coef_high_low_table[self.CoefHigh.selectedIndex!]
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[NoiseReductionViewController] viewWillAppear")
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            //DSPState.text = DSPManager?.DSP_DUT_State
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "Noise Reduction")
        
        if(SPK_NR.text == "" || SPK_NoiseReduction_Data.count == 0){
            DSPTuningDisable()
            DSPManager?.Get_Voice_DSP_Setting_NR()
        }
        
        /*
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport){
            SPK_NR.isUserInteractionEnabled = false
            MIC_NR.isUserInteractionEnabled = false
            DSPTuningDisable()
        }*/
        
        if(DSPState.text == "DSP Status: "){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
        
        if(DSPManager?.RefreshGUIData(UIView_index: 4) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 4)
            Modified_Parameters = 0x00
            DSPTuningDisable()
            DSPManager?.Get_Voice_DSP_Setting_NR()
        }
        
        if(Hidden == nil){
            DSPTuningState(state: "Noise Reduction")
        }
        
        /*
        //Simulator
        SPK_NR.selectedIndex = 3
        SPK_NR.text = NR_table1[SPK_NR.selectedIndex!]
        MIC_NR.selectedIndex = 3
        MIC_NR.text = NR_table1[MIC_NR.selectedIndex!]
         */
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[NR]viewWillDisappear")
        
        QueueModifiedParameters(DSPTuning: false)
        
        /*
        if(TuneDSP.isEnabled == true){
            if(DSPTuningSPK == true ){
                if(SPK_NoiseReduction_Data.count != 0){
                    let tmp1 = NSData(bytes: &SPK_NoiseReduction_Data, length: SPK_NoiseReduction_Data.count)
                    print("tmp1 = \(tmp1)")
                    let tmp2 = NSData(bytes: &SPK_Prev_Data, length: SPK_Prev_Data.count)
                    print("tmp2 = \(tmp2)")
                    if(tmp1.isEqual(to: tmp2 as Data) == false){
                        DSPManager?.DSPQueueData(module:0x0D, cfg:0x06, len:UInt8(SPK_NoiseReduction_Data.count), data:SPK_NoiseReduction_Data)
                        SPK_Prev_Data.removeAll()
                        SPK_Prev_Data = SPK_NoiseReduction_Data
                    }
                }
            }
            
            if(DSPTuningMIC == true){
                if(MIC_NoiseReduction_Data.count != 0){
                    let tmp1 = NSData(bytes: &MIC_NoiseReduction_Data, length: MIC_NoiseReduction_Data.count)
                    print("tmp1 = \(tmp1)")
                    let tmp2 = NSData(bytes: &MIC_Prev_Data, length: MIC_Prev_Data.count)
                    print("tmp2 = \(tmp2)")
                    if(tmp1.isEqual(to: tmp2 as Data) == false){
                        DSPManager?.DSPQueueData(module:0x0D, cfg:0x07, len:UInt8(MIC_NoiseReduction_Data.count), data:MIC_NoiseReduction_Data)
                        MIC_Prev_Data.removeAll()
                        MIC_Prev_Data = SPK_NoiseReduction_Data
                    }
                }
            }
        }*/
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func ResetParameters(_ sender: Any) {
        print("ResetParameters")
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        /*
        if(DSPTuningSPK == true && DSPTuningMIC == false){
            if(SPK_NoiseReduction_Data.count != 0){
                print("DSPTuning:SPK")
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x06, len: UInt8(SPK_NoiseReduction_Data.count), data: SPK_NoiseReduction_Data)
            }
        }
        else if(DSPTuningSPK == false && DSPTuningMIC == true){
            if(MIC_NoiseReduction_Data.count != 0){
                print("DSPTuning:MIC")
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x07, len: UInt8(MIC_NoiseReduction_Data.count), data: MIC_NoiseReduction_Data)
            }
        }
        else if(DSPTuningSPK == true && DSPTuningMIC == true){
            if(SPK_NoiseReduction_Data.count != 0 && MIC_NoiseReduction_Data.count != 0){
                print("DSPTuning:SPK&MIC")
                DSPManager?.DSPTuning2(module: 0x0D, cfg1: 0x06, cfg2: 0x07, len1: UInt8(SPK_NoiseReduction_Data.count), len2: UInt8(MIC_NoiseReduction_Data.count), data1: SPK_NoiseReduction_Data, data2: MIC_NoiseReduction_Data)
            }
        }*/
        
        if(Modified_Parameters != nil && Modified_Parameters != 0x00) {
            print("Modified_Parameters = \(String(format: "0x%02X",self.Modified_Parameters!))")
            
            if(Modified_Parameters! == 0x01){
                print("DSPTuning:SPK")
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x06, len: UInt8(SPK_NoiseReduction_Data.count), data: SPK_NoiseReduction_Data)
            }
            else if(Modified_Parameters! == 0x02){
                print("DSPTuning:MIC")
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x07, len: UInt8(MIC_NoiseReduction_Data.count), data: MIC_NoiseReduction_Data)
            }
            else if(Modified_Parameters! == 0x04){
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x0C, len: 0x01, data: [SampleDelay_data!])
            }
            else{
                QueueModifiedParameters(DSPTuning: true)
                DSPManager?.DSPTuning3()
            }
        }
    }
    
    func QueueModifiedParameters(DSPTuning:Bool){
        if((Modified_Parameters! & 0x01) == 0x01){
            print("DSPTuning:SPK")
            DSPManager?.DSPQueueData(module:0x0D, cfg:0x06, len:UInt8(SPK_NoiseReduction_Data.count), data:SPK_NoiseReduction_Data)
            
            if(DSPTuning == false){
                SPK_Prev_Data.removeAll()
                SPK_Prev_Data = SPK_NoiseReduction_Data
            }
        }
        else if((Modified_Parameters! & 0x02) == 0x02){
            print("DSPTuning:MIC")
            DSPManager?.DSPQueueData(module:0x0D, cfg:0x07, len:UInt8(MIC_NoiseReduction_Data.count), data:MIC_NoiseReduction_Data)
            
            if(DSPTuning == false){
                MIC_Prev_Data.removeAll()
                MIC_Prev_Data = SPK_NoiseReduction_Data
            }
        }
        else if((Modified_Parameters! & 0x04) == 0x04){
            DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x0C, len: 1, data: [SampleDelay_data!])
            
            if(DSPTuning == false){
                SampleDelay_prev_data = nil
            }
        }
    }
    
    func NoiseReduction_Data_Init(){
        print("NoiseReduction_Data_Init")
        
        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
            print("**UIAlertController is presenting here!")
            self.dismiss(animated: true, completion: nil)
        }
        
        if(SPK_NoiseReduction_Data[0] > 45 && SPK_NoiseReduction_Data[0] <= 64){
            SPK_NR.selectedIndex = 0
        }
        else if(SPK_NoiseReduction_Data[0] > 32 && SPK_NoiseReduction_Data[0] <= 45){
            SPK_NR.selectedIndex = 1
        }
        else if(SPK_NoiseReduction_Data[0] > 22 && SPK_NoiseReduction_Data[0] <= 32){
            SPK_NR.selectedIndex = 2
        }
        else if(SPK_NoiseReduction_Data[0] > 16 && SPK_NoiseReduction_Data[0] <= 22){
            SPK_NR.selectedIndex = 3
        }
        else if(SPK_NoiseReduction_Data[0] > 11 && SPK_NoiseReduction_Data[0] <= 16){
            SPK_NR.selectedIndex = 4
        }
        else if(SPK_NoiseReduction_Data[0] > 8 && SPK_NoiseReduction_Data[0] <= 11){
            SPK_NR.selectedIndex = 5
        }
        else if(SPK_NoiseReduction_Data[0] > 6 && SPK_NoiseReduction_Data[0] <= 8){
            SPK_NR.selectedIndex = 6
        }
        else if(SPK_NoiseReduction_Data[0] > 4 && SPK_NoiseReduction_Data[0] <= 6){
            SPK_NR.selectedIndex = 7
        }
        else if(SPK_NoiseReduction_Data[0] <= 4){
            SPK_NR.selectedIndex = 8
        }
        SPK_NR.text = NR_table1[SPK_NR.selectedIndex!]
        
        if(MIC_NoiseReduction_Data[0] > 45 && MIC_NoiseReduction_Data[0] <= 64){
            MIC_NR.selectedIndex = 0
        }
        else if(MIC_NoiseReduction_Data[0] > 32 && MIC_NoiseReduction_Data[0] <= 45){
            MIC_NR.selectedIndex = 1
        }
        else if(MIC_NoiseReduction_Data[0] > 22 && MIC_NoiseReduction_Data[0] <= 32){
            MIC_NR.selectedIndex = 2
        }
        else if(MIC_NoiseReduction_Data[0] > 16 && MIC_NoiseReduction_Data[0] <= 22){
            MIC_NR.selectedIndex = 3
        }
        else if(MIC_NoiseReduction_Data[0] > 11 && MIC_NoiseReduction_Data[0] <= 16){
            MIC_NR.selectedIndex = 4
        }
        else if(MIC_NoiseReduction_Data[0] > 8 && MIC_NoiseReduction_Data[0] <= 11){
            MIC_NR.selectedIndex = 5
        }
        else if(MIC_NoiseReduction_Data[0] > 6 && MIC_NoiseReduction_Data[0] <= 8){
            MIC_NR.selectedIndex = 6
        }
        else if(MIC_NoiseReduction_Data[0] > 4 && MIC_NoiseReduction_Data[0] <= 6){
            MIC_NR.selectedIndex = 7
        }
        else if(MIC_NoiseReduction_Data[0] <= 4){
            MIC_NR.selectedIndex = 8
        }
        MIC_NR.text = NR_table1[MIC_NR.selectedIndex!]
        
        if(FENR_checkbox.isOn()){
            self.NoiseFactor.selectedIndex = Int((self.SPK_NoiseReduction_Data[2] & 0x30) >> 4)
            self.NoiseFactor.text = self.NoiseFactor_table[self.NoiseFactor.selectedIndex!]
            self.CoefLow.selectedIndex = Int((self.SPK_NoiseReduction_Data[2] & 0x0C) >> 2)
            self.CoefLow.text = self.Coef_high_low_table[self.CoefLow.selectedIndex!]
            self.CoefHigh.selectedIndex = Int((self.SPK_NoiseReduction_Data[2] & 0x03))
            self.CoefHigh.text = self.Coef_high_low_table[self.CoefHigh.selectedIndex!]
        }
        
        if(NENR_checkbox.isOn()){
            self.NoiseFactor.selectedIndex = Int((self.MIC_NoiseReduction_Data[2] & 0x30) >> 4)
            self.NoiseFactor.text = self.NoiseFactor_table[self.NoiseFactor.selectedIndex!]
            self.CoefLow.selectedIndex = Int((self.MIC_NoiseReduction_Data[2] & 0x0C) >> 2)
            self.CoefLow.text = self.Coef_high_low_table[self.CoefLow.selectedIndex!]
            self.CoefHigh.selectedIndex = Int((self.MIC_NoiseReduction_Data[2] & 0x03))
            self.CoefHigh.text = self.Coef_high_low_table[self.CoefHigh.selectedIndex!]
        }
        
        self.SampleDelay.selectedIndex = Int(SampleDelay_data!)
        self.SampleDelay.text = SampleDelay_table[self.SampleDelay.selectedIndex!]
        
        /*
        for index in 0..<NR_Low_ids.count {
            if(SPK_NoiseReduction_Data[0] == NR_Low_ids[index]){
                if(SPK_NoiseReduction_Data[1] == NR_High_ids[index]){
                    SPK_NR.selectedIndex = index
                    SPK_NR.text = NR_table1[SPK_NR.selectedIndex!]
                    break
                }
            }
        }
        
        for index in 0..<NR_Low_ids.count {
            if(MIC_NoiseReduction_Data[0] == NR_Low_ids[index]){
                if(MIC_NoiseReduction_Data[1] == NR_High_ids[index]){
                    MIC_NR.selectedIndex = index
                    MIC_NR.text = NR_table1[MIC_NR.selectedIndex!]
                    break
                }
            }
        }*/
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[NR] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
    }
    
    func RefreshModuleData() {
        print("[Voice NR] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 6){
                for index in 0..<3 {
                    SPK_NoiseReduction_Data.append(buffer[k+3+index])
                }
                print("SPK_NoiseReduction_Data (FENR)= \(SPK_NoiseReduction_Data)")
            }
            else if(buffer[k] == 13 && buffer[k+1] == 7){
                for index in 0..<3 {
                    MIC_NoiseReduction_Data.append(buffer[k+3+index])
                }
                print("MIC_NoiseReduction_Data (NENR)= \(MIC_NoiseReduction_Data)")
            }
            else if(buffer[k] == 0x03 && buffer[k+1] == 0x0D){
                print("AUD_MCU_CFG_KEY_NR_EQ_MODE = \(String(format: "0x%02X",buffer[k+3]))")
                if(buffer[k+3] == 0){
                    print("NR is OFF")
                    FENR_checkbox.isUserInteractionEnabled = false
                    NENR_checkbox.isUserInteractionEnabled = false
                    NoiseFactor.isUserInteractionEnabled = false
                    CoefLow.isUserInteractionEnabled = false
                    CoefHigh.isUserInteractionEnabled = false
                }
                else{
                    print("NR is ON")
                }
            }
            else if(buffer[k] == 13 && buffer[k+1] == 12){
                //Wind Noise sample delay
                SampleDelay_data = buffer[k+3]
                SampleDelay_prev_data = SampleDelay_data
                print("SampleDelay_data = \(SampleDelay_data)")
            }
            /*
            else if(buffer[k] == 13 && buffer[k+1] == 1){
                print("VOICE_DSP_CFG_KEY_CONFIG_WORD_byte2 = \(String(format: "0x%02X",buffer[k+4]))")
                if((buffer[k+4] & 0x20) == 0x20){
                    print("FENR is On")
                }
                else{
                    print("FENR is Off")
                }
                
                if((buffer[k+4] & 0x40) == 0x40){
                    print("NENR is On")
                }
                else{
                    print("NENR is Off")
                }
            }*/
            
            k += Int(3+len)
        }
        
        SPK_Prev_Data.removeAll()
        SPK_Prev_Data = SPK_NoiseReduction_Data
        
        MIC_Prev_Data.removeAll()
        MIC_Prev_Data = MIC_NoiseReduction_Data
        
        NoiseReduction_Data_Init()
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            //self.DSPTuningSPK = false
            //self.DSPTuningMIC = false
            self.Modified_Parameters = 0x00
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 4)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String){
        if(state == "Noise Reduction"){
            print("[Noise Reduction] Update GUI")
            
            if(SPK_List == true || MIC_List == true){
                return
            }
            
            if(Hidden == nil){
                Hidden = true
            }
            else{
                if(Hidden!){
                    Hidden = false
                }
                else{
                    Hidden = true
                }
            }
            print("Hidden = \(Hidden)")
            
            FENR_Label.isHidden = Hidden!
            NENR_Label.isHidden = Hidden!
            NoiseFactor_Label.isHidden = Hidden!
            CoefLow_Label.isHidden = Hidden!
            CoefHigh_Label.isHidden = Hidden!
            SampleDelay_Label.isHidden = Hidden!
            FENR_checkbox.isHidden = Hidden!
            NENR_checkbox.isHidden = Hidden!
            NoiseFactor.isHidden = Hidden!
            CoefLow.isHidden = Hidden!
            CoefHigh.isHidden = Hidden!
            SampleDelay.isHidden = Hidden!
            
            return
        }
        
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(SPK_List == true){
                SPK_List = false
                SPK_NR.hideList()
            }
            SPK_NR.isUserInteractionEnabled = false
            if(MIC_List == true){
                MIC_List = false
                MIC_NR.hideList()
            }
            MIC_NR.isUserInteractionEnabled = false
            
            if(self.NoiseFactor_List == true){
                self.NoiseFactor.hideList()
            }
            self.NoiseFactor.isUserInteractionEnabled = false
            
            if(self.CoefLow_List == true){
                self.CoefLow.hideList()
            }
            self.CoefLow.isUserInteractionEnabled = false
            
            if(self.CoefHigh_List == true){
                self.CoefHigh.hideList()
            }
            self.CoefHigh.isUserInteractionEnabled = false
            
            if(self.SampleDelay_List == true){
                self.SampleDelay.hideList()
            }
            self.SampleDelay.isUserInteractionEnabled = false
            
            FENR_checkbox.isUserInteractionEnabled = false
            NENR_checkbox.isUserInteractionEnabled = false
            
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            SPK_NR.isUserInteractionEnabled = true
            MIC_NR.isUserInteractionEnabled = true
            FENR_checkbox.isUserInteractionEnabled = true
            NENR_checkbox.isUserInteractionEnabled = true
            self.NoiseFactor.isUserInteractionEnabled = true
            self.CoefLow.isUserInteractionEnabled = true
            self.CoefHigh.isUserInteractionEnabled = true
            self.SampleDelay.isUserInteractionEnabled = true
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
