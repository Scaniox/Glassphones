//
//  SlaveVolumeControlTableViewCell.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 08/08/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "SlaveVolumeControlTableViewCell.h"

@implementation SlaveVolumeControlTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_volumeDownBtn release];
    [_volumeUpBtn release];
    [_slaveNameLabel release];
    [super dealloc];
}
@end
