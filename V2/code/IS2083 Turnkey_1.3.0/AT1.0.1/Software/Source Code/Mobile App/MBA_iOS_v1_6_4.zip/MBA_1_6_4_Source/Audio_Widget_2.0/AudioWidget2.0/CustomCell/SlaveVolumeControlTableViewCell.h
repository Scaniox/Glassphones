//
//  SlaveVolumeControlTableViewCell.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 08/08/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlaveVolumeControlTableViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIButton *volumeDownBtn;
@property (retain, nonatomic) IBOutlet UIButton *volumeUpBtn;
@property (retain, nonatomic) IBOutlet UILabel *slaveNameLabel;

@end
