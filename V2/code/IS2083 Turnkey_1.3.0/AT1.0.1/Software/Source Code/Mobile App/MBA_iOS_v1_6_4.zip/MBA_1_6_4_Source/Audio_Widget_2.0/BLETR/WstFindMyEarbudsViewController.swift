//
//  EstFindMyEarbudsViewController.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/8/20.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import CoreBluetooth

class WstFindMyEarbudsViewController: UIViewController, WST_FindEarbuds_Delegate{
    
    @IBOutlet var rightEarbudStatusImageView: UIImageView!
    @IBOutlet var leftEarbudStatusImageView: UIImageView!
    @IBOutlet var StartButton: UIButton!
    @IBOutlet var ControlView: UIView!
    @IBOutlet var StatusView: UIView!
    @IBAction func FindEarbudsButtonPressed(_ sender: Any) {
        if self.timer != nil {
            StartButton.setTitle("Start", for: .normal)
            self.timer?.invalidate()
            self.timer = nil
        }else{
            StartButton.setTitle("Stop", for: .normal)
            findEarbuds()
        }
    }
    
    let LEFT_SIDE = 0x00
    let RIGHT_SIDE = 0x01
    let WST_CONNECTED = 0x01
    let WST_DISCONNECTED = 0x00
    let STATE_IDLE = 0x00
    let STATE_CONNECTED = 0x01
    
    
    var m_wstPeripheral : WstPeripheral?
    var m_parentView: WstViewController?
    var timer: Timer? = nil
    var toneTypeIdx:UInt8 = 0
    var repeatTimes: Int = 0
    var m_primaryEarbudStatus_side: UInt8 = 0
    var m_primaryEarbudStatus_wstState: UInt8 = 0
    let leftEarbudImage = ["iconfinder_airpod_left_idle","iconfinder_airpod_left_connect"]
    let rightEarbudImage = ["iconfinder_airpod_right_idle","iconfinder_airpod_right_connect"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Find Earbuds"
        ControlView.layer.cornerRadius = 20
        ControlView.layer.borderWidth = 1
        
        StatusView.layer.cornerRadius = 20
        StatusView.layer.borderWidth = 1
        
        m_wstPeripheral?.wstFindEarbudsDelegate = self
        
        if m_primaryEarbudStatus_side ==  LEFT_SIDE{
            leftEarbudStatusImageView.image = UIImage(named: leftEarbudImage[STATE_CONNECTED])
            if m_primaryEarbudStatus_wstState == WST_CONNECTED{
                rightEarbudStatusImageView.image = UIImage(named: rightEarbudImage[STATE_CONNECTED])
            }else{
                rightEarbudStatusImageView.image = UIImage(named: rightEarbudImage[STATE_IDLE])
            }
        }else{ //RIGHT_SIDE
            rightEarbudStatusImageView.image = UIImage(named: rightEarbudImage[STATE_CONNECTED])
            if m_primaryEarbudStatus_wstState == WST_CONNECTED{
                leftEarbudStatusImageView.image = UIImage(named: leftEarbudImage[STATE_CONNECTED])
            }else{
                leftEarbudStatusImageView.image = UIImage(named: leftEarbudImage[STATE_IDLE])
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if(self.isMovingFromParent) {
            if self.timer != nil {
                self.timer?.invalidate()
                self.timer = nil
                
                m_wstPeripheral?.wstFindEarbudsDelegate = nil
            }
        }
    }
    
    func findEarbuds(){
        toneTypeIdx = TONE_TYPE.TONE_200HZ_100ms.rawValue
        repeatTimes = 0
        self.timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(self.firstTone), userInfo: nil, repeats: true)
    }
    
    @objc func firstTone(){
        if repeatTimes < 3{
            repeatTimes += 1
        }else{
            if toneTypeIdx < TONE_TYPE.TONE_2000Hz_100ms.rawValue{
                toneTypeIdx += 1
                repeatTimes = 0
            }
        }
        
        m_wstPeripheral?.command_FindingMyEarbud(tone: toneTypeIdx)
        Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.secondTone), userInfo: nil, repeats: false)
    }
    
    @objc func secondTone(){
        m_wstPeripheral?.command_FindingMyEarbud(tone: toneTypeIdx)
    }
    
    @objc func setBackgroundMode(background:Bool){
        m_parentView!.setBackgroundMode(background:background)
    }
    
    @objc func terminateBle(){
        m_parentView!.terminateBle()
    }
    
    // MARK: - WstPeripheral WstBleAdapterDelegate
    func didUpdateMessage( message: String?){
        if message != "Command Complete" {
            showToast(message: message!, font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
        }
        
    }
}
