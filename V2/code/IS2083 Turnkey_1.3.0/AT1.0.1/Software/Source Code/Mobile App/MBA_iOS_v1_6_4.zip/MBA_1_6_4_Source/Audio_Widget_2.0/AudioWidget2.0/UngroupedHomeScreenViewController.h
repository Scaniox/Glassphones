//
//  UngroupedHomeScreenViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 08/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPeripheral.h"
#import "AudioUartCommandHandler.h"
#import "FileOps.h"

@interface UngroupedHomeScreenViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,AudioUartCommandDelegate>{
    IBOutlet UITextView *textView;
    FileOps *logFiles;
    IBOutlet UITableView *ActionTableView;
    IBOutlet UITableView *groupInfoTableView;
    AudioUartCommandHandler *uartCommandHanlder;
}
@property(retain) MyPeripheral *connectedPeripheral;
@property(assign) unsigned char speakerRole;
@property(assign) unsigned char _csbState;
@property(assign) unsigned char dataCategory;
@property(assign) unsigned char DatabaseInfo;
@property(retain) NSMutableArray *groupInfo;
@end
