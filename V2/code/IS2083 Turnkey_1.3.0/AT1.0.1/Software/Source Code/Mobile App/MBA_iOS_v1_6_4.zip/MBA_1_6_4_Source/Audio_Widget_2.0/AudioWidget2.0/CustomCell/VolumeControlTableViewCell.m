//
//  VolumeControlTableViewCell.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 22/03/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "VolumeControlTableViewCell.h"

@implementation VolumeControlTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_volumeDownBtn release];
    [_volumeUpBtn release];
    [super dealloc];
}
@end
