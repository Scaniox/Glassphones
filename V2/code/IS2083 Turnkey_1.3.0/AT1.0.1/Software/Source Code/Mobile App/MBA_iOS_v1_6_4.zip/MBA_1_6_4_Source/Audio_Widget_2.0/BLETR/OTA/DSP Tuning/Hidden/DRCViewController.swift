//
//  DRCViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/8/13.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class DRCViewController: UIViewController, DSPTuningDelegate, UITextFieldDelegate {
    var DSPManager: TuneDSPManager?
    
    @IBOutlet var DSPState: UILabel!
    @IBOutlet var TuneDSP: UIButton!
    //DropDownMenu
    @IBOutlet var param_1: DropDown!        //Compressor Gain SPKOut
    @IBOutlet var param_2: DropDown!        //Compressor Gain MIC
    @IBOutlet var param_3: DropDown!        //Compressor Auto Lower Knee Thrd MIC
    //Textfield
    @IBOutlet var param_4: UITextField!     //Compressor Thrd Lower Knee
    @IBOutlet var param_5: UITextField!     //Compressor Thrd SPKOut
    @IBOutlet var param_6: UITextField!     //Compressor Thrd MIC
    @IBOutlet var param_7: UITextField!     //Compressor Slope SPKOut
    @IBOutlet var param_8: UITextField!     //Compressor Slope MIC
    
    let param_1_2_table = ["0x0", "0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8", "0x9", "0xA", "0xB", "0xC"]
    let param_1_2_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    
    let param_3_table = ["0x0", "0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8", "0x9", "0xA", "0xB", "0xC", "0xD", "0xE", "0xF"]
    let param_3_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    
    var param_1_List: Bool!
    var param_2_List: Bool!
    var param_3_List: Bool!
    
    var CONFIG_Data: [UInt8] = [UInt8]()
    var DRC_Data: [UInt8] = [UInt8]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[DRCViewController]viewDidLoad")
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.HiddenDRC_Delegate = self
        
        param_4.tag = 400
        param_5.tag = 500
        param_6.tag = 600
        param_7.tag = 700
        param_8.tag = 800
        
        param_4.delegate = self
        param_5.delegate = self
        param_6.delegate = self
        param_7.delegate = self
        param_8.delegate = self
        
        param_1.isSearchEnable = false
        param_2.isSearchEnable = false
        param_3.isSearchEnable = false
        
        param_1_List = false
        param_2_List = false
        param_3_List = false
        
        param_1.optionArray = param_1_2_table
        param_1.optionIds = param_1_2_ids
        
        param_2.optionArray = param_1_2_table
        param_2.optionIds = param_1_2_ids
        
        param_3.optionArray = param_3_table
        param_3.optionIds = param_3_ids
        
        param_1.didSelect{(selectedText , index , id) in
            if(self.param_1.text != self.param_1_2_table[self.param_1.selectedIndex!]){
                if(self.DRC_Data.count != 0){
                    self.DRC_Data[5] &= ~(0xf0)
                    self.DRC_Data[5] |= UInt8(self.param_1.selectedIndex!) << 4
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_2.didSelect{(selectedText , index , id) in
            if(self.param_2.text != self.param_1_2_table[self.param_2.selectedIndex!]){
                if(self.DRC_Data.count != 0){
                    self.DRC_Data[5] &= ~(0x0f)
                    self.DRC_Data[5] |= UInt8(self.param_2.selectedIndex!)
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_3.didSelect{(selectedText , index , id) in
            if(self.param_3.text != self.param_3_table[self.param_3.selectedIndex!]){
                if(self.DRC_Data.count != 0){
                    self.DRC_Data[6] = UInt8(self.param_3.selectedIndex!)
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_1.listWillAppear {
            self.param_1_List = true
            
            if(self.param_2_List == true){
                self.param_2.hideList()
            }
            
            if(self.param_3_List == true){
                self.param_3.hideList()
            }
            
            self.param_2.isHidden = true
            self.param_3.isHidden = true
            
            self.Hide_UserTextField(IsHidden: true)
        }
        
        param_1.listDidDisappear {
            self.param_1_List = false
            
            self.param_2.isHidden = false
            self.param_3.isHidden = false
            
            self.Hide_UserTextField(IsHidden: false)
        }
        
        param_2.listWillAppear {
            self.param_2_List = true
            
            if(self.param_3_List == true){
                self.param_3.hideList()
            }
            self.param_3.isHidden = true
            
            self.Hide_UserTextField(IsHidden: true)
        }
        
        param_2.listDidDisappear {
            self.param_2_List = false
            
            if(self.param_1_List == false){
                self.param_3.isHidden = false
                
                self.Hide_UserTextField(IsHidden: false)
            }
        }
        
        param_3.listWillAppear {
            self.param_3_List = true
            
            self.Hide_UserTextField(IsHidden: true)
        }
        
        param_3.listDidDisappear {
            self.param_3_List = false
            
            if(self.param_1_List == false && self.param_2_List == false){
                self.Hide_UserTextField(IsHidden: false)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "DRC")
        
        if(param_1.text == ""){
            DSPTuningDisable()
            DSPManager?.Get_Voice_DRC_Setting()
        }
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        DSPState.text = DSPManager?.DSP_DUT_State
        
        if(DSPManager?.RefreshGUIData(UIView_index: 0x09) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 0x09)
            DSPTuningDisable()
            DSPManager?.Get_Voice_DRC_Setting()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    
        if(TuneDSP.isEnabled == true){
            DSPManager?.DSPQueueData(module:0x0D, cfg:0x08, len:UInt8(DRC_Data.count), data:DRC_Data)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func DSPTuning(_ sender: Any) {
        if(DRC_Data.count != 0){
            print("DSPTuning")
            DSPManager?.DSPTuning(module: 0x0D, cfg: 0x08, len: UInt8(DRC_Data.count), data: DRC_Data)
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    func GUI_Data_Update(){
        if(DRC_Data.count != 0){
            print("GUI_Data_Update")
            param_1.selectedIndex = Int((DRC_Data[5] & 0xf0) >> 4)
            param_1.text = param_1_2_table[param_1.selectedIndex!]
            
            param_2.selectedIndex = Int(DRC_Data[5] & 0x0f)
            param_2.text = param_1_2_table[param_2.selectedIndex!]
            
            param_3.selectedIndex = Int(DRC_Data[6])
            param_3.text = param_3_table[param_3.selectedIndex!]
            
            param_4.text = String(DRC_Data[0])
            param_5.text = String(DRC_Data[1])
            param_6.text = String(DRC_Data[2])
            param_7.text = String(DRC_Data[3])
            param_8.text = String(DRC_Data[4])
        }
    }
    
    func Hide_UserTextField(IsHidden:Bool){
        self.param_4.isHidden = IsHidden
        self.param_5.isHidden = IsHidden
        self.param_6.isHidden = IsHidden
        self.param_7.isHidden = IsHidden
        self.param_8.isHidden = IsHidden
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if(DRC_Data.count != 0){
            print("textFieldShouldReturn")
            if(param_4.text != nil && textField.tag == 400){
                if let param_4_value = Int(param_4.text!){
                    if(param_4_value >= 0 && param_4_value <= 96){
                        DRC_Data[0] = UInt8(param_4_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_4.text = String(DRC_Data[0])
                    }
                }
                else{
                    param_4.text = String(DRC_Data[0])
                }
            }
            else if(param_5.text != nil && textField.tag == 500){
                if let param_5_value = Int(param_5.text!){
                    if(param_5_value >= 0 && param_5_value <= 96){
                        DRC_Data[1] = UInt8(param_5_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_5.text = String(DRC_Data[1])
                    }
                }
                else{
                    param_5.text = String(DRC_Data[1])
                }
            }
            else if(param_6.text != nil && textField.tag == 600){
                if let param_6_value = Int(param_6.text!){
                    if(param_6_value >= 0 && param_6_value <= 96){
                        DRC_Data[2] = UInt8(param_6_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_6.text = String(DRC_Data[2])
                    }
                }
                else{
                    param_6.text = String(DRC_Data[2])
                }
            }
            else if(param_7.text != nil && textField.tag == 700){
                if let param_7_value = Int(param_7.text!){
                    if(param_7_value >= 0 && param_7_value <= 255){
                        DRC_Data[3] = UInt8(param_7_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_7.text = String(DRC_Data[3])
                    }
                }
                else{
                    param_7.text = String(DRC_Data[3])
                }
            }
            else if(param_8.text != nil && textField.tag == 800){
                if let param_8_value = Int(param_8.text!){
                    if(param_8_value >= 0 && param_8_value <= 255){
                        DRC_Data[4] = UInt8(param_8_value)
                        DSPTuningEnable()
                    }
                    else{
                        param_8.text = String(DRC_Data[4])
                    }
                }
                else{
                    param_8.text = String(DRC_Data[4])
                }
            }
        }
        
        return true
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        print("[Hidden DRC] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 8){
                if(buffer[k+2] == 7){
                    DRC_Data.removeAll()
                    for index in 0..<7 {
                        DRC_Data.append(buffer[k+3+index])
                    }
                    print("DRC_Data = \(DRC_Data)")
                }
            }
            else if(buffer[k] == 13 && buffer[k+1] == 1){
                if(buffer[k+2] == 4){
                    CONFIG_Data.removeAll()
                    for index in 0..<4 {
                        CONFIG_Data.append(buffer[k+3+index])
                    }
                    print("CONFIG_Data = \(CONFIG_Data)")
                }
            }
            
            k += Int(3+len)
        }
        
        GUI_Data_Update()
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 0x09)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func BLE_ConnectionStatus(status: Bool) {
        print("[DRC] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func DSPTuningState(state: String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(param_1_List == true){
                param_1.hideList()
            }
            param_1.isUserInteractionEnabled = false
            if(param_2_List == true){
                param_2.hideList()
            }
            param_2.isUserInteractionEnabled = false
            if(param_3_List == true){
                param_3.hideList()
            }
            param_3.isUserInteractionEnabled = false
            
            param_4.isEnabled = false
            param_5.isEnabled = false
            param_6.isEnabled = false
            param_7.isEnabled = false
            param_8.isEnabled = false
            
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            param_1.isUserInteractionEnabled = true
            param_2.isUserInteractionEnabled = true
            param_3.isUserInteractionEnabled = true
            param_4.isEnabled = true
            param_5.isEnabled = true
            param_6.isEnabled = true
            param_7.isEnabled = true
            param_8.isEnabled = true
        }
    }
    
    func ExportDSPTuningResult() {
    }
}
