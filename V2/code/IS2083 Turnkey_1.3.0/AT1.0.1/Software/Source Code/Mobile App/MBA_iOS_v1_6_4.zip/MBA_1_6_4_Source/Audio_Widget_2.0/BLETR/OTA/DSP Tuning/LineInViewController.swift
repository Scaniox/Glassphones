//
//  LineInViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/5/31.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class LineInViewController: UIViewController, DSPTuningDelegate, UITextFieldDelegate {
    @IBOutlet var LineIn_Threshold: DropDown!
    @IBOutlet var LineIn_ADCGain: DropDown!
    @IBOutlet var TuneDSP: UIButton!
    @IBOutlet var DSPState: UILabel!
    @IBOutlet var LineIn_SMT: UITextField!  //LineIn Silence MV Thrd
    @IBOutlet var LineIn_EDT: UITextField!  //LineIn Encoder Delay Time
    @IBOutlet var Audio_EQ_Mode: UITextField!
    @IBOutlet var LineIn_SMT_Label: UILabel!
    @IBOutlet var LineIn_EDT_Label: UILabel!
    @IBOutlet var LineIn_Rx_EQ_Label: UILabel!
    
    @IBOutlet var Custom_EQ3_Btn: UIButton!
    var LineIn_Threshold_List: Bool!
    var LineIn_ADCGain_List: Bool!
    
    var DSPManager: TuneDSPManager?
    var LineIn_Data: [UInt8] = [UInt8]()
    var LineIn_Prev_Data: [UInt8] = [UInt8]()
    
    var Hidden: Bool?
    
    let eq_mode_table = ["OFF", "SOFT", "BASS", "TREBLE", "CLASSICAL", "ROCK", "JAZZ", "POP", "DANCE", "RNB", "USER"]
    
    let Threshold_table = ["0x00: -6dBOv", "0x02:-12dBOv", "0x04:-18dBOv", "0x06:-24dBOv", "0x08:-30dBOv", "0x0A:-36dBOv", "0x0C:-42dBOv", "0x0E:-48dBOv", "0x10:-54dBOv", "0x12:-60dBOv", "0x14:-66dBOv", "0x16:-72dBOv", "0x18:-78dBOv", "0x1A:-84dBOv", "0x1C:-92dBOv", "0x1E:-96dBOv", "LineIn Silence Detection Off"]
    
    //let ids_1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]
    let Threshold_table_ids = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 31]
    
    let ADC_Gain_table = ["-6dB, 0x00", "-3dB, 0x03", "0dB, 0x06", "3dB, 0x09", "6dB, 0x0C", "9dB, 0x0F", "12dB, 0x12", "15dB, 0x15", "18dB, 0x23", "21dB, 0x26", "24dB, 0x29", "27dB, 0x2C", "30dB, 0x2F", "33dB, 0x32", "36dB, 0x35", "39dB, 0x38", "42dB, 0x3B", "45dB, 0x3E"]
    
    let ADC_Gain_table_ids = [0, 3, 6, 9, 12, 15, 18, 21, 35, 38, 41, 44, 47, 50, 53, 56, 59, 62]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[LineInViewController]viewDidLoad")
        
        TuneDSP.layer.cornerRadius = 15.0
        
        LineIn_SMT.delegate = self
        LineIn_EDT.delegate = self
        
        LineIn_SMT.tag = 100
        LineIn_EDT.tag = 101
        
        DSPManager = TuneDSPManager.sharedInstance()
        DSPManager?.AudioLineIn_Delegate = self
        
        self.LineIn_Threshold_List = false
        self.LineIn_ADCGain_List = false
        
        self.LineIn_Threshold.isSearchEnable = false
        self.LineIn_ADCGain.isSearchEnable = false
        
        LineIn_Threshold.optionArray = Threshold_table
        LineIn_Threshold.optionIds = Threshold_table_ids
        
        LineIn_Threshold.didSelect{(selectedText , index , id) in
            print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.LineIn_Threshold.text != self.Threshold_table[self.LineIn_Threshold.selectedIndex!]){
                print("\(self.Threshold_table[self.LineIn_Threshold.selectedIndex!])")
                self.DSPTuningEnable()
                print("LineIn_Data[0] = \(self.LineIn_Data[0])")
                self.LineIn_Data[0] = UInt8(self.Threshold_table_ids[self.LineIn_Threshold.selectedIndex!])
                print("Update value = \(self.LineIn_Data[0])")
            }
        }
        
        LineIn_Threshold.arrowSize = 10
        
        LineIn_Threshold.text = ""
        
        LineIn_ADCGain.optionArray = ADC_Gain_table
        LineIn_ADCGain.optionIds = ADC_Gain_table_ids
        
        LineIn_ADCGain.didSelect{(selectedText , index , id) in
            print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.LineIn_ADCGain.text != self.ADC_Gain_table[self.LineIn_ADCGain.selectedIndex!]){
                print("\(self.ADC_Gain_table[self.LineIn_ADCGain.selectedIndex!])")
                self.DSPTuningEnable()
                print("LineIn_Data[1] = \(self.LineIn_Data[1])")
                self.LineIn_Data[1] = UInt8(self.ADC_Gain_table_ids[self.LineIn_ADCGain.selectedIndex!])
                print("Update value = \(self.LineIn_Data[1])")
            }
        }
        
        LineIn_ADCGain.arrowSize = 10
        
        LineIn_ADCGain.text = ""
        
        LineIn_Threshold.listWillAppear {
            print("LineIn_Threshold.listWillAppear")
            self.LineIn_Threshold_List = true
            
            if(self.LineIn_ADCGain_List){
                self.LineIn_ADCGain.hideList()
            }
            
            self.LineIn_ADCGain.isHidden = true
            self.TuneDSP.isHidden = true
            
            self.LineIn_SMT.isHidden = true
            self.LineIn_EDT.isHidden = true
            self.Audio_EQ_Mode.isHidden = true
            self.LineIn_SMT_Label.isHidden = true
            self.LineIn_EDT_Label.isHidden = true
            self.LineIn_Rx_EQ_Label.isHidden = true
            self.Custom_EQ3_Btn.isHidden = true
        }
        
        LineIn_ADCGain.listWillAppear {
            print("LineIn_ADCGain.listWillAppear")
            self.LineIn_ADCGain_List = true
            
            if(self.LineIn_Threshold_List){
                self.LineIn_Threshold.hideList()
            }
            
            self.TuneDSP.isHidden = true
            
            self.LineIn_SMT.isHidden = true
            self.LineIn_EDT.isHidden = true
            self.Audio_EQ_Mode.isHidden = true
            self.LineIn_SMT_Label.isHidden = true
            self.LineIn_EDT_Label.isHidden = true
            self.LineIn_Rx_EQ_Label.isHidden = true
            self.Custom_EQ3_Btn.isHidden = true
        }
        
        LineIn_Threshold.listDidDisappear {
            print("LineIn_Threshold.list DidDisappear")
            self.LineIn_Threshold_List = false
            
            if(self.LineIn_ADCGain.isHidden == true){
                self.LineIn_ADCGain.isHidden = false
            }
            
            if(self.TuneDSP.isHidden == true){
                self.TuneDSP.isHidden = false
            }
            
            self.LineIn_SMT.isHidden = self.Hidden!
            self.LineIn_EDT.isHidden = self.Hidden!
            self.Audio_EQ_Mode.isHidden = self.Hidden!
            self.LineIn_SMT_Label.isHidden = self.Hidden!
            self.LineIn_EDT_Label.isHidden = self.Hidden!
            self.LineIn_Rx_EQ_Label.isHidden = self.Hidden!
            self.Custom_EQ3_Btn.isHidden = self.Hidden!
        }
        
        LineIn_ADCGain.listDidDisappear{
            print("LineIn_ADCGain.list DidDisappear")
            self.LineIn_ADCGain_List = false
            
            if(self.TuneDSP.isHidden == true && self.LineIn_Threshold_List == false){
                self.TuneDSP.isHidden = false
                
                self.LineIn_SMT.isHidden = self.Hidden!
                self.LineIn_EDT.isHidden = self.Hidden!
                self.Audio_EQ_Mode.isHidden = self.Hidden!
                self.LineIn_SMT_Label.isHidden = self.Hidden!
                self.LineIn_EDT_Label.isHidden = self.Hidden!
                self.LineIn_Rx_EQ_Label.isHidden = self.Hidden!
                self.Custom_EQ3_Btn.isHidden = self.Hidden!
            }
        }
        
        DSPTuningDisable()
        
        //Debug for simulator
        ///*
        DSPManager?.DSP_Init()
        let device_capability = DSPManager?.Get_Device_Capability()
        print("device_capability = \(device_capability!)")
        
        if(DSPManager?.Audio_Config == nil){
            LoadDSPConfigData()
        }//*/
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        DSPManager?.Restore_DSP_State()
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPState.text = DSPManager?.DSP_DUT_State
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "LineIn")
        
        print("LineIn_Data = \(LineIn_Data)")
        
        if(LineIn_Threshold.text == "" && DSPManager?.Audio_Config != nil){
            print("Get LineIn config data")
            DSPTuningDisable()
            self.DSPManager?.Get_Audio_DSP_Setting_LineIn()
        }
        
        /*
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport){
            LineIn_Threshold.isUserInteractionEnabled = false
            LineIn_ADCGain.isUserInteractionEnabled = false
            DSPTuningDisable()
            print("dynamicToolMode is incorrect")
        }*/
        
        if(DSPManager?.RefreshGUIData(UIView_index: 0) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 0)
            DSPTuningDisable()
            self.DSPManager?.Get_Audio_DSP_Setting_LineIn()
        }
        
        if((DSPManager?.EQMode != nil) && (DSPManager?.EQ_Data.count == 0x54)){
            DSPTuningEnable()
        }
        else{
            DSPTuningDisable()
        }
        
        if(Hidden == nil){
            DSPTuningState(state: "LineIn")
        }
    
        /*
        //Simulator
        LineIn_Threshold.selectedIndex = 0
        LineIn_Threshold.text = Threshold_table[LineIn_Threshold.selectedIndex!]
        LineIn_ADCGain.selectedIndex = 0
        LineIn_ADCGain.text = ADC_Gain_table[LineIn_ADCGain.selectedIndex!]
        */
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[LineIn]viewWillDisappear")
        
        if(TuneDSP.isEnabled == true){
            if(LineIn_Data.count != 0){
                let tmp1 = NSData(bytes: &LineIn_Data, length: LineIn_Data.count)
                print("tmp1 = \(tmp1)")
                let tmp2 = NSData(bytes: &LineIn_Prev_Data, length: LineIn_Prev_Data.count)
                print("tmp2 = \(tmp2)")
                if(tmp1.isEqual(to: tmp2 as Data) == false){
                    DSPManager?.DSPQueueData(module:0x0C, cfg:0x01, len:0x04, data:LineIn_Data)
                    LineIn_Prev_Data.removeAll()
                    LineIn_Prev_Data = LineIn_Data
                }
            }
            
            if((DSPManager?.EQMode != nil) && (DSPManager?.EQMode == 0x06) && (DSPManager?.EQ_Data.count == 0x54)){
                DSPManager?.DSPQueueData(module: 0x0C, cfg: 0x05, len: 0x54, data: DSPManager!.EQ_Data)//AUD_DSP_CFG_KEY_H_CUSTOM_RX_EQ
                DSPManager?.EQMode = nil
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "LineInEQ_Segue") {
            print("prepareForSegue:AudioEQ")
            let vc = segue.destination as? EqCoeffViewController
            if(vc != nil){
                vc?.EQMode = 0x06
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func ResetParameters(_ sender: Any) {
        if(LineIn_Prev_Data.count != 0 && TuneDSP.isEnabled == true){
            DSPTuningDisable()
            print("ResetParameters")
            ResetGUIData()
        }
    }
    
    @IBAction func LineIn_Custom_EQ3(_ sender: Any) {
        print("LineIn_Custom_EQ3")
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        if(LineIn_Data.count != 0){
            print("DSP Tuning,LineIn_Data = \(LineIn_Data)")
            var change1: Bool = false
            var change2: Bool = false
            
            let tmp1 = NSData(bytes: &LineIn_Data, length: LineIn_Data.count)
            print("tmp1 = \(tmp1)")
            let tmp2 = NSData(bytes: &LineIn_Prev_Data, length: LineIn_Prev_Data.count)
            print("tmp2 = \(tmp2)")
            if(tmp1.isEqual(to: tmp2 as Data) == false){
                change1 = true
            }
            
            if((DSPManager?.EQMode != nil) && (DSPManager?.EQMode == 0x06) && (DSPManager?.EQ_Data.count == 0x54)){
                change2 = true
            }
            
            if(change1 == true && change2 == false){
                DSPManager?.DSPTuning(module: 0x0C, cfg: 0x01, len: UInt8(LineIn_Data.count), data: LineIn_Data)
            }
            else if(change1 == false && change2 == true){
                DSPManager?.DSPTuning(module: 0x0C, cfg: 0x05, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
            else if(change1 == true && change2 == true){
                DSPManager?.DSPTuning2(module: 0x0C, cfg1: 0x01, cfg2: 0x05, len1: UInt8(LineIn_Data.count), len2: 0x54, data1: LineIn_Data, data2: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
        }
    }
    
    func ResetGUIData(){
        LineIn_Data.removeAll()
        LineIn_Data = LineIn_Prev_Data
        
        print("LineIn_Data = \(LineIn_Data)")
        
        for index in 0..<Threshold_table_ids.count {
            if(LineIn_Data[0] == Threshold_table_ids[index]) {
                LineIn_Threshold.selectedIndex = index
                LineIn_Threshold.text = Threshold_table[index]
                break
            }
        }
        
        for index in 0..<ADC_Gain_table_ids.count {
            if(LineIn_Data[1] == ADC_Gain_table_ids[index]) {
                LineIn_ADCGain.selectedIndex = index
                LineIn_ADCGain.text = ADC_Gain_table[index]
                break
            }
        }
    }
    
    func LineIn_Config_Init(dat:Data){
        print("LineIn_Config_Init")
        
        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
            print("**UIAlertController is presenting here!")
            self.dismiss(animated: true, completion: nil)
        }
        
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        for index in 0..<(dat as NSData).length {
            LineIn_Data.append(buffer[index])
        }
        LineIn_Prev_Data = LineIn_Data
        
        print("LineIn_Data = \(LineIn_Data)")
        print("LineIn_Prev_Data = \(LineIn_Prev_Data)")
        
        for index in 0..<Threshold_table_ids.count {
            if(buffer[0] == Threshold_table_ids[index]) {
                LineIn_Threshold.selectedIndex = index
                LineIn_Threshold.text = Threshold_table[index]
                break
            }
        }
        
        for index in 0..<ADC_Gain_table_ids.count {
            if(buffer[1] == ADC_Gain_table_ids[index]) {
                LineIn_ADCGain.selectedIndex = index
                LineIn_ADCGain.text = ADC_Gain_table[index]
                break
            }
        }
        
        //Hidden function
        LineIn_SMT.text = String(buffer[2])
        LineIn_EDT.text = String(buffer[3])
        
        if(Audio_EQ_Mode.text == ""){
            if let EQMode = DSPManager?.GetAudioLineInEQMode(){
                Audio_EQ_Mode.text = eq_mode_table[Int(EQMode)]
                
                print("Set EQ mode = \(Audio_EQ_Mode.text!)")
            }
            else{
                Audio_EQ_Mode.text = "OFF"
            }
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    func LoadDSPConfigData() {
        let alertController = UIAlertController(
            title: nil,
            message: "Load DSP Configuration\n\n\n",
            preferredStyle: .alert)
        
        let activityIndicator : UIActivityIndicatorView = UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.whiteLarge)
        
        activityIndicator.color = UIColor.black
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        alertController.view.addSubview(activityIndicator)
        
        let centerHorizontally = NSLayoutConstraint(item: activityIndicator,
                                                    attribute: .centerX,
                                                    relatedBy: .equal,
                                                    toItem: activityIndicator.superview,
                                                    attribute: .centerX,
                                                    multiplier: 1.0,
                                                    constant: 0.0)
        
        let centerVertically = NSLayoutConstraint(item: activityIndicator,
                                                  attribute: .centerY,
                                                  relatedBy: .equal,
                                                  toItem: activityIndicator.superview,
                                                  attribute: .centerY,
                                                  multiplier: 1.0,
                                                  constant: 0.0)
        
        NSLayoutConstraint.activate([centerHorizontally, centerVertically])
        
        activityIndicator.startAnimating()
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if(LineIn_Data.count != 0){
            print("textFieldShouldReturn")
            if(LineIn_SMT.text != nil && textField.tag == 100){
                if let textfield_1_value = Int(LineIn_SMT.text!){
                    if(textfield_1_value >= 0 && textfield_1_value < 256){
                        LineIn_Data[2] = UInt8(textfield_1_value)
                        print("LineIn_Data[2] = \(LineIn_Data[2])")
                    }
                    else{
                        LineIn_SMT.text = String(LineIn_Data[2])
                    }
                }
                else{
                    LineIn_SMT.text = String(LineIn_Data[2])
                }
            }
            else if(LineIn_EDT.text != nil && textField.tag == 101){
                if let textfield_2_value = Int(LineIn_EDT.text!){
                    if(textfield_2_value >= 0 && textfield_2_value < 241){
                        LineIn_Data[3] = UInt8(textfield_2_value)
                        print("LineIn_Data[3] = \(LineIn_Data[3])")
                    }
                    else{
                        LineIn_EDT.text = String(LineIn_Data[3])
                    }
                }
                else{
                    LineIn_EDT.text = String(LineIn_Data[3])
                }
            }
            
            let tmp1 = NSData(bytes: &LineIn_Data, length: LineIn_Data.count)
            print("tmp1 = \(tmp1)")
            let tmp2 = NSData(bytes: &LineIn_Prev_Data, length: LineIn_Prev_Data.count)
            print("tmp2 = \(tmp2)")
            if(tmp1.isEqual(to: tmp2 as Data) == false){
                DSPTuningEnable()
            }
        }
        return true
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[LineIn] BLE_ConnectionStatus = \(status)")
        
        if(status == false){
           self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
        print("BLE_ServiceReady")
        
        if(DSPManager?.Audio_Config == nil){
            DSPManager?.Read_Module_Audio_MCU()
        }
        else{
            self.DSPManager?.Get_Audio_DSP_Setting_LineIn()
        }
    }
    
    func RefreshModuleData() {
        print("[Audio LineIn] RefreshModuleData")
    }
    
    func RefreshParametersData(dat:Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 12 && buffer[k+1] == 1){
                LineIn_Config_Init(dat: param_dat)
                break
            }
            
            k += Int(3+len)
        }
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            if(result != 0x01){
                self.ResetGUIData()
            }
            self.DSPManager?.ClearRefreshFlag(UIView_index: 0)
            self.LineIn_Prev_Data.removeAll()
            self.LineIn_Prev_Data = self.LineIn_Data
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String) {
        if(state == "LineIn"){
            print("[LineIn] Update GUI")
            
            if(LineIn_Threshold_List == true || LineIn_ADCGain_List == true){
                return
            }
            
            if(Hidden == nil){
                //Hidden = false
                Hidden = true
            }
            else{
                if(Hidden!){
                    Hidden = false
                }
                else{
                    Hidden = true
                }
            }
            
            //Hidden Audio Function:LineIn,EQ
            
            LineIn_SMT.isHidden = Hidden!
            LineIn_EDT.isHidden = Hidden!
            Audio_EQ_Mode.isHidden = Hidden!
            LineIn_SMT_Label.isHidden = Hidden!
            LineIn_EDT_Label.isHidden = Hidden!
            LineIn_Rx_EQ_Label.isHidden = Hidden!
            Custom_EQ3_Btn.isHidden = Hidden!
            
            return
        }
        
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            if(LineIn_Threshold_List == true){
                LineIn_Threshold.hideList()
                LineIn_Threshold_List = false
            }
            LineIn_Threshold.isUserInteractionEnabled = false
            if(LineIn_ADCGain_List == true){
                LineIn_ADCGain.hideList()
                LineIn_ADCGain_List = false
            }
            LineIn_ADCGain.isUserInteractionEnabled = false
            LineIn_EDT.isEnabled = false
            LineIn_SMT.isEnabled = false
            Custom_EQ3_Btn.isEnabled = false
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            LineIn_Threshold.isUserInteractionEnabled = true
            LineIn_ADCGain.isUserInteractionEnabled = true
            LineIn_EDT.isEnabled = true
            LineIn_SMT.isEnabled = true
            Custom_EQ3_Btn.isEnabled = true
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
