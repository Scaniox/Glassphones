//
//  EqualizerManualSettingViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 14/03/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "EqualizerManualSettingViewController.h"
#include "EQ_Calculate.h"

#define SET_AUDIO_EQ_PARAMETER 0x13

@interface EqualizerManualSettingViewController (){
    NSArray *gainArr;
    NSArray *freqArr;
    NSArray *qArr;
}

@end

@implementation EqualizerManualSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    tapGr.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGr];
    [tapGr release];
    
    freqTextField1.delegate = self;
    freqTextField2.delegate = self;
    freqTextField3.delegate = self;
    freqTextField4.delegate = self;
    freqTextField5.delegate = self;
    freqTextField1.keyboardType = UIKeyboardTypeNumberPad;
    freqTextField2.keyboardType = UIKeyboardTypeNumberPad;
    freqTextField3.keyboardType = UIKeyboardTypeNumberPad;
    freqTextField4.keyboardType = UIKeyboardTypeNumberPad;
    freqTextField5.keyboardType = UIKeyboardTypeNumberPad;
    qField1.delegate = self;
    qField2.delegate = self;
    qField3.delegate = self;
    qField4.delegate = self;
    qField5.delegate = self;
    qField1.keyboardType = UIKeyboardTypeNumberPad;
    qField2.keyboardType = UIKeyboardTypeNumberPad;
    qField3.keyboardType = UIKeyboardTypeNumberPad;
    qField4.keyboardType = UIKeyboardTypeNumberPad;
    qField5.keyboardType = UIKeyboardTypeNumberPad;
    
    
    
    gainArr = [[NSArray alloc] initWithObjects:gainSlider1,gainSlider2,gainSlider3,gainSlider4,gainSlider5, nil];
    freqArr = [[NSArray alloc] initWithObjects:freqTextField1,freqTextField2,freqTextField3,freqTextField4,freqTextField5, nil];
    qArr = [[NSArray alloc] initWithObjects:qField1,qField2,qField3,qField4,qField5, nil];
    
    
    UIBarButtonItem *SendButton = [[UIBarButtonItem alloc] init];
    SendButton.title = @"Set";
    SendButton.target = self;
    [SendButton setAction:@selector(sendEqSettings)];
    //logButton.enabled = FALSE;
    self.navigationItem.rightBarButtonItem = SendButton;
    
    //self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)dealloc {
    [freqTextField1 release];
    [freqTextField2 release];
    [freqTextField3 release];
    [freqTextField4 release];
    [freqTextField5 release];
    [qField1 release];
    [qField2 release];
    [qField3 release];
    [qField4 release];
    [qField5 release];
    [gainSlider1 release];
    [gainSlider2 release];
    [gainSlider3 release];
    [gainSlider4 release];
    [gainSlider5 release];
    [super dealloc];
}
- (IBAction)gain1ValueChanged:(id)sender {
    gainSlider1.value = round(gainSlider1.value);
}

- (IBAction)gain5ValueChanged:(id)sender {
    gainSlider5.value = round(gainSlider5.value);
}

- (IBAction)gain2ValueChanged:(id)sender {
    gainSlider2.value = round(gainSlider2.value);
}

- (IBAction)gain3ValueChanged:(id)sender {
    gainSlider3.value = round(gainSlider3.value);
}

- (IBAction)gain4ValueChanged:(id)sender {
    gainSlider4.value = round(gainSlider4.value);
}

-(void)sendEqSettings{
    double gain[5],freq[5],q[5];
    for (int i=0; i<5; i++) {
    
        UISlider *gain_ = [gainArr objectAtIndex:i];
        UITextField *freq_ = [freqArr objectAtIndex:i];
        UITextField *q_ = [qArr objectAtIndex:i];
        gain[i] = gain_.value;
        freq[i] = [freq_.text doubleValue];
        q[i] = [q_.text doubleValue];
    }
    int *eqSetting = getEqualizerParameters(gain,freq,q);
    Byte dataBytes[84];
    for (int i=0; i<84; i++) {
        dataBytes[i] = eqSetting[i];
    }
    NSData *data = [NSData dataWithBytes:dataBytes length:84];
    [_connectedPeripheral sendDspRuntimeProgram:SET_AUDIO_EQ_PARAMETER data:data];
}

-(void)viewTapped:(UITapGestureRecognizer*)tapGr{
    [self.view endEditing:NO];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

@end
