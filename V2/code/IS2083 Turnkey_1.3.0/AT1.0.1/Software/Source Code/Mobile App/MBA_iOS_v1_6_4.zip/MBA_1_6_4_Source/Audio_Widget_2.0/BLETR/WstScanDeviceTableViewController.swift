//
//  WstScanDeviceTableViewController.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/7/25.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import CoreBluetooth

class WstScanDeviceTableViewController: UITableViewController,WST_Scan_Delegate {
    var m_wstPeripheral : WstPeripheral?
    var m_parentView: WstViewController?
    var peripheralsArray: NSMutableArray = []
    var advArray: NSMutableArray = []
    var rssiArray: NSMutableArray = []
    let RssiLevelArray = ["signal0.png","signal1.png","signal2.png","signal3.png","signal4.png","signal5.png"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Add New Device"
        
        //print("[DeviceTableViewController]viewDidLoad")
        //bleAdapter = BLEAdapter.sharedInstance()
        
        //bleAdapter?.bleAdapterDelegate = self
        
        let ScanButton = UIBarButtonItem(title: "Scan", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.ScanbuttonTapped(_:)))
        
        self.navigationItem.rightBarButtonItem = ScanButton
        m_wstPeripheral?.wstScanDelegate = self
        m_wstPeripheral?.disconnectPeripheral()
        
        
        Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.StartScan), userInfo: nil, repeats: false)
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if(self.isMovingFromParent) {
            self.StopScan()
            m_wstPeripheral?.wstScanDelegate = nil
        }
    }
    
    @objc func StartScan() {
        print("StartScan")
        peripheralsArray.removeAllObjects()
        advArray.removeAllObjects()
        rssiArray.removeAllObjects()
        self.tableView.reloadData()
        var result:Int = 0
        result = (m_wstPeripheral?.StartScan())!
        if result != 0 {
            m_wstPeripheral?.deleteInstance()
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    
    @objc func StopScan() {
        print("StopDevice")
        m_wstPeripheral?.StopScan()
    }
    
    @objc func ScanbuttonTapped(_ sender:UIBarButtonItem!) {
        StartScan()
    }
    
    @objc func terminateBle(){
        m_parentView!.terminateBle()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //return 5
        return peripheralsArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WST_SCAN_RESULT_CELL", for: indexPath) as! WST_ScanResultCell
        
        // Configure the cell...
        
        //cell.textLabel?.text = "Row \(indexPath.row)"
        var groupID:String = "Group ID: "
        
        let rssi_Value = rssiArray.object(at: indexPath.row) as! NSNumber
        let p:CBPeripheral = peripheralsArray.object(at: indexPath.row) as! CBPeripheral
        let advdata = advArray.object(at: indexPath.row) as! [String : Any]
        if let Service_data_dic = advdata["kCBAdvDataServiceData"] as? [NSObject:AnyObject] {
            if let Service_data = Service_data_dic[CBUUID(string:"FEDA")] as? NSData {
                var dataByte = [UInt8] (Service_data as Data)
                let wst_beacon = WST_BEACON_FORMAT(UnsafeMutablePointer<UInt8>(&dataByte))
                groupID += wst_beacon.groupID_Str
                cell.setGroupID(ID: groupID)
            }
        }else{
            cell.setGroupID(ID: groupID)
        }
        if(p.name != nil) {
            let name = advdata["kCBAdvDataLocalName"]
            if(name != nil) {
                cell.setDeviceName(name: name as! String)
                //cell.textLabel!.text = name as? String
            }
            else {
                //cell.textLabel!.text = p.name
                cell.setDeviceName(name: p.name!)
                
            }
        } else {
            cell.setDeviceName(name: "Unknown")
        }
        
        var rssiLevelIdx = 0;
        
        if (rssi_Value.intValue < -110) {
            rssiLevelIdx = 0;
        }else if (rssi_Value.intValue <= -100){
            rssiLevelIdx = 1;
        }else if (rssi_Value.intValue <= -85){
            rssiLevelIdx = 2;
        }else if (rssi_Value.intValue <= -70){
            rssiLevelIdx = 3;
        }else if (rssi_Value.intValue <= -60){
            rssiLevelIdx = 4;
        }else{
            rssiLevelIdx = 5;
        }
        cell.setRssiImage(imageName: RssiLevelArray[rssiLevelIdx])
        cell.backgroundColor = .groupTableViewBackground
        
        return cell
    }
    
    // MARK: - Table view delegate
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print("Select device:\(indexPath.row)")
        //NSLog("WstScanDeviceTableViewController - didSelectRowAt")
        
        //let cell = tableView.cellForRow(at: indexPath)
        //let labelContent = cell?.textLabel?.text
        //print("BT Name = \(labelContent!)")
        //BT_Name = labelContent!
        peripheralsArray = NSMutableArray(array: (m_wstPeripheral?.peripheralsArray)!)
        advArray = NSMutableArray(array: (m_wstPeripheral?.advArray)!)
        let advdata = advArray.object(at: indexPath.row) as! [String : Any]
        if let connectable = advdata["kCBAdvDataIsConnectable"] as? NSNumber{
            let isConnectable = connectable.intValue == 1
            if isConnectable{
                m_wstPeripheral?.connecPeripheral(peripheralsArray[indexPath.row] as! CBPeripheral)
            }else{
                showToast(message: "The device is not connectable", font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
                self.tableView.deselectRow(at: indexPath, animated: true)
            }
        }
        //m_wstPeripheral?.connecPeripheral(peripheralsArray[indexPath.row] as! CBPeripheral)
    }
    
    // MARK: - WstPeripheral WstBleAdapterDelegate
    func didDiscoverPeripheral(Peripheral peripheral: CBPeripheral, AdvertisementData advertisementData: [String : Any], Rssi RSSI: NSNumber) {
        print("WstScanDeviceTableViewController didDiscoverPeripheral")
        peripheralsArray = NSMutableArray(array: (m_wstPeripheral?.peripheralsArray)!)
        advArray = NSMutableArray(array: (m_wstPeripheral?.advArray)!)
        rssiArray = NSMutableArray(array: (m_wstPeripheral?.rssiArray)!)
        self.tableView.reloadData()
    }
    
    /*func didConnected(){
        NSLog("WstScanDeviceTableViewController - didConnected")
        
        m_parentView?.updateConnectionState(connected: true)
    }*/
    
    func didDisconnected(){
        m_parentView?.updateConnectionState(connected: false)
    }
    
    func didUpdateMessage( message: String?){
        showToast(message: message!, font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
    }
}
