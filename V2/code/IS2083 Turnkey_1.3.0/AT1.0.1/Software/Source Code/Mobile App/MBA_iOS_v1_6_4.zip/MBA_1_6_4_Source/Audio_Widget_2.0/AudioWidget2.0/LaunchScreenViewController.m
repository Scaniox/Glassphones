//
//  LaunchScreenViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 25/01/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "LaunchScreenViewController.h"

@interface LaunchScreenViewController ()

@end

@implementation LaunchScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSDictionary* infoDict = [[NSBundle mainBundle] infoDictionary];
    NSString* version = [infoDict objectForKey:@"CFBundleShortVersionString"];
    //NSString* build = [infoDict objectForKey:@"CFBundleVersion"];
    //[_versionLabel setText:[NSString stringWithFormat:@"v%@ build%@ ",version,build]];
    [_versionLabel setText:[NSString stringWithFormat:@"v%@",version]];
    
    [self performSelector:NSSelectorFromString(@"showNavController") withObject:nil afterDelay:2.5];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)showNavController{
    [self performSegueWithIdentifier:@"SHOW_MAIN_PAGE" sender:self];

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)dealloc {
    [_versionLabel release];
    [super dealloc];
}
@end
