//
//  EQTableViewCell.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/3.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit

class EQTableViewCell: UITableViewCell {

    @IBOutlet var EQ_Mode_Label: UILabel!
    @IBOutlet var Setting: VKCheckbox!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.Setting.line             = .thin
        self.Setting.bgColorSelected  = UIColor(red: 46/255, green: 119/255, blue: 217/255, alpha: 1)
        self.Setting.bgColor          = .gray
        self.Setting.color            = .white
        self.Setting.borderColor      = .white
        self.Setting.borderWidth      = 2
        self.Setting.cornerRadius     = self.Setting.bounds.size.height / 2
    }
    
    func setTitle(_ title: String?)
    {
        self.EQ_Mode_Label.text = title
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
