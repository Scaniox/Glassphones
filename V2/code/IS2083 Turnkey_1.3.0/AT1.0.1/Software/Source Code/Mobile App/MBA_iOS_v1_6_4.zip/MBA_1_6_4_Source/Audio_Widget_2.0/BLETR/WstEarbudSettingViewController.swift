//
//  WstEarbudSettingViewController.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/8/8.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import CoreBluetooth
extension UIViewController{
    //隐藏键盘
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
}


class WstEarbudSettingViewController: UIViewController, WST_EarbudsSetting_Delegate , UITextFieldDelegate{

    @IBOutlet var deviceNameLabel: UILabel!
    @IBOutlet var deviceNameTextField: UITextField!
    
    var m_wstPeripheral : WstPeripheral?
    var m_parentView: WstViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        self.title = "Earbud Setting"
        
        m_wstPeripheral?.wstEarbudSettingDelegate = self
        deviceNameTextField.delegate = self
        
        m_wstPeripheral?.command_ReadLocalName()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if(self.isMovingFromParent) {
            m_wstPeripheral?.wstEarbudSettingDelegate = nil
        }
    }
    
    @objc func setBackgroundMode(background:Bool){
        m_parentView!.setBackgroundMode(background:background)
    }
    
    @objc func terminateBle(){
        m_parentView!.terminateBle()
    }
    
    //MARK: - UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        let nameString = textField.text
        m_wstPeripheral?.command_WriteLocalName(name:nameString!)
        return true
    }
    
    /*func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let maxLength = 8
        let currentString: NSString = textField.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }*/
    
    // MARK: - WstPeripheral WstBleAdapterDelegate
    func reportLocalName(name:String){
        deviceNameLabel.text = name
    }
    
    func didUpdateMessage( message: String?){
        showToast(message: message!, font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
        if message == "Command Complete" {
            m_wstPeripheral?.command_ReadLocalName()
        }
    }
}
