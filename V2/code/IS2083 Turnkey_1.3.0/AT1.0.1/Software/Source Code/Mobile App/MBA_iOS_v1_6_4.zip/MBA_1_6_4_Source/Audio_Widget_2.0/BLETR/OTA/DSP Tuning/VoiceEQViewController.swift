//
//  VoiceEQViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/10.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class VoiceEQViewController: UIViewController, DSPTuningDelegate{
    var DSPManager: TuneDSPManager?
    
    var CVSD_TX_EQ_Mode: UInt8 = 0x0f
    var CVSD_RX_EQ_Mode: UInt8 = 0x0f
    var MSBC_TX_EQ_Mode: UInt8 = 0x0f
    var MSBC_RX_EQ_Mode: UInt8 = 0x0f

    @IBOutlet var SPK_EQ: DropDown!
    @IBOutlet var MIC_EQ: DropDown!
    @IBOutlet var TuneDSP: UIButton!
    @IBOutlet var SPK_Custom_EQ: UIButton!  //mSBC
    @IBOutlet var MIC_Custom_EQ: UIButton!  //mSBC
    @IBOutlet var Custom_EQ_SPK: UIButton!
    @IBOutlet var Custom_EQ_MIC: UIButton!
    @IBOutlet var DSPState: UILabel!
    
    let EQ_table = ["EQ Off", "EQ On-Customized EQ Coeff", "AECFreqShaping", "Custom 2"]
    let EQ_ids = [1,2,3,4]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        TuneDSP.layer.cornerRadius = 15.0
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.VoiceEQ_Delegate = self
        
        SPK_EQ.isSearchEnable = false
        MIC_EQ.isSearchEnable = false
        
        //SPK_EQ.isEnabled = false
        //MIC_EQ.isEnabled = false
        SPK_EQ.optionArray = EQ_table
        SPK_EQ.optionIds = EQ_ids
        
        MIC_EQ.optionArray = EQ_table
        MIC_EQ.optionIds = EQ_ids
        
        SPK_EQ.isUserInteractionEnabled = false
        MIC_EQ.isUserInteractionEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[VoiceEQViewController] viewWillAppear")
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            //DSPState.text = DSPManager?.DSP_DUT_State
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "EQ")
        
        if(DSPManager?.BLE_Connection != nil && DSPManager?.BLE_Connection == false){
            self.navigationController?.popViewController(animated: true)
        }
        
        if(SPK_EQ.text == ""){
            if let (EQMode1, EQMode2, EQMode3, EQMode4) = DSPManager?.GetVoiceEQMode(){
                CVSD_TX_EQ_Mode = EQMode2!
                CVSD_RX_EQ_Mode = EQMode1!
                MSBC_TX_EQ_Mode = EQMode4!
                MSBC_RX_EQ_Mode = EQMode3!
                
                print("[VoiceEQMode]GUIUpdate,\(CVSD_TX_EQ_Mode),\(CVSD_RX_EQ_Mode),\(MSBC_TX_EQ_Mode),\(MSBC_RX_EQ_Mode)")
                if(Int(CVSD_TX_EQ_Mode) < EQ_table.count){
                    SPK_EQ.selectedIndex = Int(CVSD_TX_EQ_Mode)
                    SPK_EQ.text = EQ_table[SPK_EQ.selectedIndex!]
                }
                else{
                    //SPK_EQ.selectedIndex = 0
                    SPK_EQ.text = ""
                }
                
                if(Int(CVSD_RX_EQ_Mode) < EQ_table.count){
                    MIC_EQ.selectedIndex = Int(CVSD_RX_EQ_Mode)
                    MIC_EQ.text = EQ_table[MIC_EQ.selectedIndex!]
                }
                else{
                    //MIC_EQ.selectedIndex = 0
                    MIC_EQ.text = ""
                }
                
                if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
                    if(CVSD_TX_EQ_Mode == 0){
                        Custom_EQ_SPK.isEnabled = false
                    }
                    else{
                        Custom_EQ_SPK.isEnabled = true
                    }
                
                    if(CVSD_RX_EQ_Mode == 0){
                        Custom_EQ_MIC.isEnabled = false
                    }
                    else{
                        Custom_EQ_MIC.isEnabled = true
                    }
                
                    if(MSBC_TX_EQ_Mode == 0){
                        SPK_Custom_EQ.isEnabled = false
                    }
                    else{
                        SPK_Custom_EQ.isEnabled = true
                    }
                
                    if(MSBC_RX_EQ_Mode == 0){
                        MIC_Custom_EQ.isEnabled = false
                    }
                    else{
                        MIC_Custom_EQ.isEnabled = true
                    }
                }
            }
        }
        
        /*
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport){
            SPK_Custom_EQ.isEnabled = false
            MIC_Custom_EQ.isEnabled = false
            Custom_EQ_SPK.isEnabled = false
            Custom_EQ_MIC.isEnabled = false
            DSPTuningDisable()
        }*/
        
        if(DSPState.text == "DSP Status: "){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
        
        if((DSPManager?.EQMode != nil) && (DSPManager?.EQ_Data.count == 0x54)){
            DSPTuningEnable()
        }
        else{
            DSPTuningDisable()
        }
        
        /*
        //Simulator
        SPK_EQ.text = "EQ Off"
        MIC_EQ.text = "EQ Off"
        */
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[Voice EQ]viewWillDisappear")
        
        if((DSPManager?.EQMode != nil) && (DSPManager?.EQ_Data.count == 0x54)){
            if(DSPManager?.EQMode! == 0x02){
                //SPK EQ
                DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x0F, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x03){
                //MIC EQ
                DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x11, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x04){
                //SPK_mSBC EQ
                DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x10, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x05){
                //MIC_mSBC EQ
                DSPManager?.DSPQueueData(module: 0x0D, cfg: 0x12, len: 0x54, data: DSPManager!.EQ_Data)
                DSPManager?.EQMode = nil
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //print("prepareForSegue")
        if(segue.identifier == "SPK_EQ_Segue") {
            print("prepareForSegue: SPK EQ")
            let vc = segue.destination as? EqCoeffViewController
            if(vc != nil){
                vc?.EQMode = 0x02
            }
        }
        else if(segue.identifier == "MIC_EQ_Segue") {
            print("prepareForSegue: MIC EQ")
            let vc = segue.destination as? EqCoeffViewController
            if(vc != nil){
                vc?.EQMode = 0x03
            }
        }
        else if(segue.identifier == "SPK_mSBC_EQ_Segue") {
            print("prepareForSegue: SPK mSBC EQ")
            let vc = segue.destination as? EqCoeffViewController
            if(vc != nil){
                vc?.EQMode = 0x04
            }
        }
        else if(segue.identifier == "MIC_mSBC_EQ_Segue") {
            print("prepareForSegue: MIC mSBC EQ")
            let vc = segue.destination as? EqCoeffViewController
            if(vc != nil){
                vc?.EQMode = 0x05
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func ResetParameters(_ sender: Any) {
        
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        if((DSPManager?.EQMode != nil) && (DSPManager?.EQ_Data.count == 0x54)){
            print("[Voice EQ]DSP Tuning...")
            if(DSPManager?.EQMode! == 0x02){
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x0F, len: 0x54, data: DSPManager!.EQ_Data)
                //DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x03){
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x11, len: 0x54, data: DSPManager!.EQ_Data)
                //DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x04){
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x10, len: 0x54, data: DSPManager!.EQ_Data)
                //DSPManager?.EQMode = nil
            }
            else if(DSPManager?.EQMode! == 0x05){
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x12, len: 0x54, data: DSPManager!.EQ_Data)
                //DSPManager?.EQMode = nil
            }
            DSPManager?.EQMode = nil
            DSPManager?.EQ_Data.removeAll()
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[Voice EQ] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
    }
    
    func RefreshModuleData() {
        print("[Voice EQ] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            SPK_Custom_EQ.isEnabled = false
            MIC_Custom_EQ.isEnabled = false
            Custom_EQ_SPK.isEnabled = false
            Custom_EQ_MIC.isEnabled = false
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            if(CVSD_TX_EQ_Mode == 0){
                Custom_EQ_SPK.isEnabled = false
            }
            else{
                Custom_EQ_SPK.isEnabled = true
            }
            
            if(CVSD_RX_EQ_Mode == 0){
                Custom_EQ_MIC.isEnabled = false
            }
            else{
                Custom_EQ_MIC.isEnabled = true
            }
            
            if(MSBC_TX_EQ_Mode == 0){
                SPK_Custom_EQ.isEnabled = false
            }
            else{
                SPK_Custom_EQ.isEnabled = true
            }
            
            if(MSBC_RX_EQ_Mode == 0){
                MIC_Custom_EQ.isEnabled = false
            }
            else{
                MIC_Custom_EQ.isEnabled = true
            }
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
