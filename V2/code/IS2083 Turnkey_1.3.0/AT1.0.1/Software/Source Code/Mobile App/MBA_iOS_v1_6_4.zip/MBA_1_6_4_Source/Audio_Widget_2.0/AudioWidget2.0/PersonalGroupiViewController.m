//
//  PersonalGroupiViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 25/05/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "PersonalGroupiViewController.h"
#import "UIView+Toast.h"
#import "FileOps.h"
#import "HomeScreenViewController.h"
#define GROUP_MODE_STEREO 0
#define GROUP_MODE_CONCERT 1
enum{
    MMI_ACTION_POWER_ON_BUTTON_PRESS = 0x51,
    MMI_ACTION_POWER_ON_BUTTON_RELEASE,
};

enum{
    STEP_MASTER_CONNECTION = 0x00,
    STEP_MASTER_READ_POWER_STATE,
    STEP_MASTER_POWER_ON_BUTTON_PRESS,
    STEP_MASTER_POWER_ON_BUTTON_RELEASE,
    STEP_MASTER_READ_BD_ADDRESS,
    STEP_MASTER_SET_GROUP_MODE,
    STEP_MASTER_SET_GROUP_MASTER,
    STEP_MASTER_DISCONNECT,
    STEP_SLAVE_CONNECTION,
    STEP_SLAVE_READ_POWER_STATE,
    STEP_SLAVE_POWER_ON_BUTTON_PRESS,
    STEP_SLAVE_POWER_ON_BUTTON_RELEASE,
    STEP_SLAVE_PERSONAL_GROUP_CONTROL,
    STEP_SLAVE_SET_GROUP_MODE,
    STEP_SLAVE_SET_GROUP_SLAVE,
    STEP_SLAVE_DISCONNECT,
    STEP_PERSONAL_GROUP_FINISH,
    STEP_PERSONAL_GROUP_FAIL,
};
enum{
    eENTER_NSPK_MODE = 0xF4,
    eENTER_BORADCAST_MODE = 0xF5,
    eCANCEL_NSPK_CREATION = 0xE3,
    eTERMINATE_CANCEL_NSPK_CONNECTION = 0xE5,
    eTRIGGER_NSPK_MASTER = 0xE0,
    eTRIGGER_NSPK_SLAVE = 0xE1,
};

@interface PersonalGroupiViewController (){
    //NSMutableArray *masterFlag;
    //NSMutableArray *slaveFlag;
    
    int stepIndex;
    int slaveIndex;
    NSMutableArray *selectedMasterList;
    NSMutableArray *selectedSlaveList;
    NSData* masterAddress;
    FileOps *logFiles;
    NSTimer *personalGroupingProcessTimer;
    
    unsigned char connectionState;
    unsigned char CSB_State;
}
@end

@implementation PersonalGroupiViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [_cbController setDelegate:self];
    [_pmgr setDelegate:self];
    
    masterListTableView.backgroundColor = [UIColor clearColor];
    masterListTableView.delegate = self;
    masterListTableView.dataSource = self;
    
    slaveListTableView.backgroundColor = [UIColor clearColor];
    slaveListTableView.delegate = self;
    slaveListTableView.dataSource = self;
    
    masterListTableView.layer.borderWidth = 1.0;
    masterListTableView.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    
    slaveListTableView.layer.borderWidth = 1.0;
    slaveListTableView.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    
    createGroupButton.layer.cornerRadius = 10.0;
    if (_personalGroupMode == GROUP_MODE_STEREO) {
        self.title = @"Stereo Mode";
    }else{
        self.title = @"Concert Mode";
    }
    
    groupName.delegate = self;
    
    if (_newPersonalGroup) {
        _groupNameStr = @"";
    }
    
    groupName.text = _groupNameStr;
    
    groupName.enabled = _newPersonalGroup;
    
    uartCommandHanlder = [[AudioUartCommandHandler alloc] init];
    uartCommandHanlder.uartCommandDelegate = self;
    
    selectedMasterList = [[NSMutableArray alloc] init];
    selectedSlaveList = [[NSMutableArray alloc] init];
    
    personalGroupingProcessTimer = nil;
    
    /*UIBarButtonItem *logButton = [[UIBarButtonItem alloc] init];
     logButton.title = @"Log";
     logButton.target = self;
     [logButton setAction:@selector(showLog)];
     self.navigationItem.rightBarButtonItem = logButton;*/
    
    /***Create File*/
    logFiles = [[FileOps alloc] init];
    [logFiles createFileWithContent:[[NSString stringWithFormat:@""] mutableCopy]];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (void)dealloc {
    [groupName release];
    [masterListTableView release];
    [slaveListTableView release];
    [createGroupButton release];
    [_allMasterList removeAllObjects];
    [_allSlaveList removeAllObjects];
    uartCommandHanlder.uartCommandDelegate = nil;
    [self.navigationController.view hideToastActivity];
    [super dealloc];
}

- (IBAction)createGroupButtonPressed:(id)sender {
    [selectedMasterList removeAllObjects];
    [selectedSlaveList removeAllObjects];
    
    connectionState = 0;
    CSB_State = 0;
    
    for (int i=0; i<[_allMasterList count]; i++) {
        BOOL masterFlag = [[_masterFlag objectAtIndex:i] boolValue];
        if (masterFlag) {
            [selectedMasterList addObject:[_allMasterList objectAtIndex:i]];
        }
    }
    
    for (int i=0; i<[_allSlaveList count]; i++) {
        BOOL slaveFlag = [[_slaveFlag objectAtIndex:i] boolValue];
        if (slaveFlag) {
            [selectedSlaveList addObject:[_allSlaveList objectAtIndex:i]];
        }
    }
    
    if ([groupName.text length] == 0) {
        [self.navigationController.view makeToast:@"Please Input Group name"
                                         duration:100.0
                                         position:CSToastPositionCenter
                                            title:@"Warning"
                                            image:[UIImage imageNamed:@"warning.png"]
                                            style:nil
                                       completion:nil];
        return;
    }
    
    if ([selectedMasterList count] == 0) {
        [self.navigationController.view makeToast:@"Please Select the Master Speaker"
                                         duration:100.0
                                         position:CSToastPositionCenter
                                            title:@"Warning"
                                            image:[UIImage imageNamed:@"warning.png"]
                                            style:nil
                                       completion:nil];
        return;
        
    }
    
    if ([selectedSlaveList count] == 0) {
        [self.navigationController.view makeToast:@"Please Select the Slave Speaker"
                                         duration:100.0
                                         position:CSToastPositionCenter
                                            title:@"Warning"
                                            image:[UIImage imageNamed:@"warning.png"]
                                            style:nil
                                       completion:nil];
        return;
        
    }
    
    stepIndex = STEP_MASTER_CONNECTION;
    slaveIndex = 0;
    
    [self.navigationController.view makeToastActivity:CSToastPositionCenter];
    [self personalGroupingProcess:stepIndex];
}

- (void)checkPersonalGroupingProcessTimeout:(NSTimeInterval)timeout {
    if (!personalGroupingProcessTimer) {
        personalGroupingProcessTimer = [NSTimer scheduledTimerWithTimeInterval:timeout target:self selector:@selector(personalGroupingProcessTimeout) userInfo:nil repeats:NO];
    }
}

-(void)personalGroupingProcessTimeout{
    NSString *title = @"Error:";//[NSString stringWithFormat:@"Bluetooth state alert"];
    NSString *error = @"Personal Group Process Timeout";//[errorArray objectAtIndex:status];
    NSString *stepindex = [NSString stringWithFormat:@", %d",stepIndex];
    //NSMutableString *errStr = [[NSMutableString alloc] initWithString:error];
    NSMutableString *errStr = [[NSMutableString alloc] initWithString:[error stringByAppendingString:stepindex]];
    [errStr appendFormat:@"\n\n"];
    [uartCommandHanlder.uartCommandDelegate AudioUartCommandHandler:uartCommandHanlder.connectedPeripheral didUpdateMessage:[errStr mutableCopy] title:title error:TRUE];
}

-(void) personalGroupingProcess:(unsigned char)index{
    if ([personalGroupingProcessTimer isValid]) {
        [personalGroupingProcessTimer invalidate];
    }
    personalGroupingProcessTimer = nil;
    if ((index != STEP_PERSONAL_GROUP_FINISH) && (index != STEP_PERSONAL_GROUP_FAIL)) {
        [self checkPersonalGroupingProcessTimeout:10.0];
        NSLog(@"Check timeout!");
    }
    switch (index) {
        case STEP_MASTER_CONNECTION:{
            NSLog(@"STEP_MASTER_CONNECTION");
            MyPeripheral* peripheral = [selectedMasterList objectAtIndex:0];
            [_cbController connectDevice:peripheral];
        }
            break;
            
        case STEP_MASTER_READ_POWER_STATE:
        case STEP_SLAVE_READ_POWER_STATE:{
            NSLog(@"STEP_READ_POWER_STATE");
            [uartCommandHanlder.connectedPeripheral sendReadLinkStatus];
        }
            break;
            
        case STEP_MASTER_POWER_ON_BUTTON_PRESS:
        case STEP_SLAVE_POWER_ON_BUTTON_PRESS:{
            NSLog(@"STEP_POWER_ON_BUTTON_PRESS");
            [uartCommandHanlder.connectedPeripheral sendMmiAction:MMI_ACTION_POWER_ON_BUTTON_PRESS];
        }
            break;
            
        case STEP_MASTER_POWER_ON_BUTTON_RELEASE:
        case STEP_SLAVE_POWER_ON_BUTTON_RELEASE:{
            NSLog(@"STEP_POWER_ON_BUTTON_RELEASE");
            [uartCommandHanlder.connectedPeripheral sendMmiAction:MMI_ACTION_POWER_ON_BUTTON_RELEASE];
        }
            break;
            
        case STEP_MASTER_READ_BD_ADDRESS:{
            NSLog(@"STEP_MASTER_READ_BD_ADDRESS");
            [uartCommandHanlder.connectedPeripheral sendReadLocalBDAddress];
        }
            break;
            
        case STEP_MASTER_SET_GROUP_MODE:
        case STEP_SLAVE_SET_GROUP_MODE:{
            NSLog(@"STEP_SET_GROUP_MODE");
            if(_personalGroupMode == GROUP_MODE_STEREO){
                [uartCommandHanlder.connectedPeripheral sendMmiAction:eENTER_NSPK_MODE];
            }else{
                [uartCommandHanlder.connectedPeripheral sendMmiAction:eENTER_BORADCAST_MODE];
            }
            
        }
            break;
            
        case STEP_MASTER_SET_GROUP_MASTER:{
            NSLog(@"STEP_MASTER_SET_GROUP_MASTER");
            [uartCommandHanlder.connectedPeripheral sendMmiAction:eTRIGGER_NSPK_MASTER];
        }
            break;
            
        case STEP_SLAVE_DISCONNECT:{
            //NSLog(@"STEP_SLAVE_DISCONNECT");
            NSLog(@"STEP_SLAVE_DISCONNECT,Delay 3 seconds");
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC));
            //dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC));
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                //Check connection!!!
                NSLog(@"Peripheral state = %d",uartCommandHanlder.connectedPeripheral.connectStatus);
                NSLog(@"STEP_SLAVE_DISCONNECT.Done");
                if(uartCommandHanlder.connectedPeripheral.connectStatus == 2){
                    [_cbController disconnectDevice:uartCommandHanlder.connectedPeripheral];
                }
            });
        }
            break;
            
        case STEP_MASTER_DISCONNECT:{
            NSLog(@"STEP_MASTER_DISCONNECT");
            [_cbController disconnectDevice:uartCommandHanlder.connectedPeripheral];
        }
            break;
            
        case STEP_SLAVE_CONNECTION:{
            NSLog(@"STEP_SLAVE_CONNECTION");
            MyPeripheral* peripheral = [selectedSlaveList objectAtIndex:slaveIndex];
            [_cbController connectDevice:peripheral];
        }
            break;
            
        case STEP_SLAVE_PERSONAL_GROUP_CONTROL:{
            NSLog(@"STEP_SLAVE_PERSONAL_GROUP_CONTROL");
            [uartCommandHanlder.connectedPeripheral sendPersonalGroupControl:0x01 btAddress:[masterAddress mutableCopy]];
        }
            break;
            
        case STEP_SLAVE_SET_GROUP_SLAVE:{
            NSLog(@"STEP_SLAVE_SET_GROUP_SLAVE");
            [uartCommandHanlder.connectedPeripheral sendMmiAction:eTRIGGER_NSPK_SLAVE];
        }
            break;
            
        case STEP_PERSONAL_GROUP_FINISH:
            NSLog(@"STEP_PERSONAL_GROUP_FINISH");
            [self.navigationController.view hideToastActivity];
            [self.navigationController.view makeToast:@"Personal Group Success!"
                                             duration:1.5
                                             position:CSToastPositionBottom];
            
            /**Store Group Information*/
            
            NSString* name = [groupName.text mutableCopy];
            NSNumber* mode = [NSNumber numberWithInt:_personalGroupMode];
            NSMutableArray* masterArray = [NSMutableArray arrayWithCapacity:[selectedMasterList count]];
            NSMutableArray* slaveArray = [NSMutableArray arrayWithCapacity:[selectedSlaveList count]];
            for (MyPeripheral* peripheral in selectedMasterList){
                [masterArray addObject:peripheral.uuidString];
            }
            for (MyPeripheral* peripheral in selectedSlaveList){
                [slaveArray addObject:peripheral.uuidString];
            }
            NSMutableDictionary *groupRecord;// = [[NSMutableDictionary alloc] init];
            NSDictionary *record = [[NSUserDefaults standardUserDefaults] objectForKey:@"GROUP_RECORD"];
            if (record == nil) {
                groupRecord = [[NSMutableDictionary alloc] init];
            }else{
                groupRecord = [record mutableCopy];
            }
            NSLog(@"groupRecord = %@",groupRecord);
            
            NSDictionary* groupDataDictionary = [NSDictionary dictionaryWithObjectsAndKeys:name,@"GROUP_NAME",mode,@"GROUP_MODE",masterArray,@"MASTER_LIST",slaveArray,@"SLAVE_LIST", nil];
            
            [groupRecord setObject:groupDataDictionary forKey:name];
            NSLog(@"record = %@",groupRecord);
            
            NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
            [def setObject:groupRecord forKey:@"GROUP_RECORD"];
            [def synchronize];
            [self.navigationController popToRootViewControllerAnimated:YES];
            
            break;
            
        case STEP_PERSONAL_GROUP_FAIL:
            NSLog(@"STEP_PERSONAL_GROUP_FAIL");
            if (uartCommandHanlder.connectedPeripheral) {
                [_cbController disconnectDevice:uartCommandHanlder.connectedPeripheral];
            }
            [self.navigationController.view hideToastActivity];
            [self.navigationController.view makeToast:@"Personal Group Fail!"
                                             duration:100.0
                                             position:CSToastPositionCenter
                                                title:@"Error:"
                                                image:[UIImage imageNamed:@"error.png"]
                                                style:nil
                                           completion:nil];
            [self.navigationController popToRootViewControllerAnimated:YES];
            break;
            
        default:
            break;
    }
}

-(void)showLog{
    NSLog(@"showLog");
    [self displayContent];
}

-(void) displayContent{
    
    NSString *content = [logFiles readFromFile];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"LOG" message:content preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *dafaultAction = [UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){}];
    [alert addAction:dafaultAction];
    UIView *subView1 = alert.view.subviews[0];
    UIView *subView2 = subView1.subviews[0];
    UIView *subView3 = subView2.subviews[0];
    UIView *subView4 = subView3.subviews[0];
    UIView *subView5 = subView4.subviews[0];
    UILabel *contentView = subView5.subviews[1];
    contentView.textAlignment = NSTextAlignmentLeft;
    [self presentViewController:alert animated:YES completion:nil];
    //[ASFunction alert:content];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == masterListTableView) {
        return [_allMasterList count];
        
    }else{
        return [_allSlaveList count];
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSString *title = nil;
    if (tableView == masterListTableView) {
        title = @"Select Master";
    }else{
        title = @"Select Slaves";
    }
    return title;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == masterListTableView) {
        MyPeripheral *peripheral = [_allMasterList objectAtIndex:indexPath.row];
        UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        cell.textLabel.text = peripheral.advName;
        if (cell.textLabel.text == nil)
            cell.textLabel.text = @"Unknow";
        cell.backgroundColor = [UIColor clearColor];
        BOOL masterFlag = [[_masterFlag objectAtIndex:indexPath.row] boolValue];
        if (masterFlag) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }else{
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        
        return cell;
        
    }else{
        
        UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        MyPeripheral *peripheral = [_allSlaveList objectAtIndex:indexPath.row];
        cell.textLabel.text = peripheral.advName;
        if (cell.textLabel.text == nil)
            cell.textLabel.text = @"Unknow";
        cell.backgroundColor = [UIColor clearColor];
        BOOL slaveFlag = [[_slaveFlag objectAtIndex:indexPath.row] boolValue];
        if (slaveFlag) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }else{
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        return cell;
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 20;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == masterListTableView) {
        for (int i=0; i<[_allMasterList count]; i++) {
            if (i == indexPath.row) {
                [_masterFlag replaceObjectAtIndex:i withObject:@(TRUE)];
                if ([[_slaveFlag objectAtIndex:i] boolValue]) {
                    [_slaveFlag replaceObjectAtIndex:i withObject:@(FALSE)];
                }
            }else{
                [_masterFlag replaceObjectAtIndex:i withObject:@(FALSE)];
            }
        }
        
    }else{
        if ([[_masterFlag objectAtIndex:indexPath.row] boolValue]){
            [_slaveFlag replaceObjectAtIndex:indexPath.row withObject:@(FALSE)];
        }else{
            if (_personalGroupMode == 0x00) {
                for (int i=0; i<[_allSlaveList count]; i++) {
                    if (i == indexPath.row) {
                        [_slaveFlag replaceObjectAtIndex:i withObject:@(TRUE)];
                    }else{
                        [_slaveFlag replaceObjectAtIndex:i withObject:@(FALSE)];
                    }
                }
            }else{
                BOOL flag = [[_slaveFlag objectAtIndex:indexPath.row] boolValue];
                [_slaveFlag replaceObjectAtIndex:indexPath.row withObject:@(!flag)];
            }
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [masterListTableView reloadData];
    [slaveListTableView reloadData];
}


#pragma mark - CBController delegate
- (void)CBController:(CBController *)cbController didUpdateDiscoveredPeripherals:(NSDictionary *)peripherals{
}

- (void)CBController:(CBController *)cbController didDisconnectedPeripheral:(MyPeripheral *)myPeripheral {
    NSLog(@"updateMyPeripheralForDisconnect");//, %@", myPeripheral.advName);
    
    uartCommandHanlder.connectedPeripheral = nil;
    
    if (stepIndex == STEP_MASTER_DISCONNECT) {
        stepIndex = STEP_SLAVE_CONNECTION;
        
    }else if (stepIndex == STEP_SLAVE_DISCONNECT){
        slaveIndex++;
        connectionState = 0;
        CSB_State = 0;
        if (slaveIndex == [selectedSlaveList count]) {
            stepIndex = STEP_PERSONAL_GROUP_FINISH;
        }else{
            stepIndex = STEP_SLAVE_CONNECTION;
        }
        
    }else if (stepIndex == STEP_PERSONAL_GROUP_FAIL){
        return;
    }
    [self personalGroupingProcess:stepIndex];
}

- (void)CBController:(CBController *)cbController didConnectedPeripheral:(MyPeripheral *)myPeripheral {
    NSLog(@"[PersonalGroupViewController] updateMyPeripheralForNewConnected");
    if (stepIndex == STEP_MASTER_CONNECTION) {
        stepIndex = STEP_MASTER_READ_POWER_STATE;
        
    }else if (stepIndex == STEP_SLAVE_CONNECTION){
        stepIndex = STEP_SLAVE_READ_POWER_STATE;
    }
    [uartCommandHanlder setPeripheral:myPeripheral];
    [self personalGroupingProcess:stepIndex];
    
}

#pragma mark - Audio Uart Command Delegate
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateMessage:(NSString* )message title:(NSString* )title error:(BOOL) error{
    [logFiles WriteToFile:[message mutableCopy]];
    NSString* image;
    if (error) {
        image = @"error.png";//[NSString stringWithString:@"error.png"];
    }else{
        image = @"warning.png";
    }
    [self.navigationController.view makeToast:message
                                     duration:100.0
                                     position:CSToastPositionCenter
                                        title:title
                                        image:[UIImage imageNamed:image]
                                        style:nil
                                   completion:nil];
    
    stepIndex = STEP_PERSONAL_GROUP_FAIL;
    
    connectionState = 0;
    CSB_State = 0;
    
    [self personalGroupingProcess:stepIndex];
}
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateLogForCommand:(NSString *)log{
    [logFiles WriteToFile:[log mutableCopy]];
}

- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdatePowerState:(BOOL )state{
    if (state) {
        if ((stepIndex == STEP_MASTER_READ_POWER_STATE) || (stepIndex == STEP_MASTER_POWER_ON_BUTTON_RELEASE)) {
            stepIndex = STEP_MASTER_READ_BD_ADDRESS;
        }else if((stepIndex == STEP_SLAVE_READ_POWER_STATE) || (stepIndex == STEP_SLAVE_POWER_ON_BUTTON_RELEASE)){
            stepIndex =  STEP_SLAVE_PERSONAL_GROUP_CONTROL;
        }else{
            return;
        }
        
    }else{
        if (stepIndex == STEP_MASTER_READ_POWER_STATE) {
            stepIndex = STEP_MASTER_POWER_ON_BUTTON_PRESS;
        }else if(stepIndex == STEP_SLAVE_READ_POWER_STATE){
            stepIndex = STEP_SLAVE_POWER_ON_BUTTON_PRESS;
        }else{
            return;
        }
    }
    [self personalGroupingProcess:stepIndex];
}

- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateAddress:(NSData* )addr{
    if (stepIndex == STEP_MASTER_READ_BD_ADDRESS) {
        masterAddress = [addr mutableCopy];
        stepIndex = STEP_MASTER_SET_GROUP_MODE;
        [self personalGroupingProcess:stepIndex];
    }
}

- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateCommandAck:(unsigned char)commandID{
    if (stepIndex == STEP_MASTER_SET_GROUP_MODE) {
        stepIndex = STEP_MASTER_SET_GROUP_MASTER;
        
    }else if (stepIndex == STEP_MASTER_SET_GROUP_MASTER){
        stepIndex = STEP_MASTER_DISCONNECT;
        
    }else if (stepIndex == STEP_MASTER_POWER_ON_BUTTON_PRESS){
        stepIndex = STEP_MASTER_POWER_ON_BUTTON_RELEASE;
        
    }else if (stepIndex == STEP_MASTER_POWER_ON_BUTTON_RELEASE){
        return;
        
    }else if (stepIndex == STEP_SLAVE_POWER_ON_BUTTON_PRESS){
        stepIndex = STEP_SLAVE_POWER_ON_BUTTON_RELEASE;
        
    }else if (stepIndex == STEP_SLAVE_POWER_ON_BUTTON_RELEASE){
        return;
        
    }else if (stepIndex == STEP_SLAVE_PERSONAL_GROUP_CONTROL){
        stepIndex = STEP_SLAVE_SET_GROUP_MODE;
        
    }else if (stepIndex == STEP_SLAVE_SET_GROUP_MODE){
        stepIndex = STEP_SLAVE_SET_GROUP_SLAVE;
        
    }else if (stepIndex == STEP_SLAVE_SET_GROUP_SLAVE){
        stepIndex = STEP_SLAVE_DISCONNECT;
        //return;
    }else{
        return;
    }
    
    //[self personalGroupingProcess:stepIndex];
    
    if(stepIndex == STEP_SLAVE_DISCONNECT){
        //if(CSB_State == 3){
        //    [self personalGroupingProcess:stepIndex];
        //}
        NSLog(@"stepIndex = STEP_SLAVE_DISCONNECT, CSB_State = %d",CSB_State);
    }
    else{
        [self personalGroupingProcess:stepIndex];
    }
    
}

- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateGroupConnectionState:(unsigned char)state CSB_State:(unsigned char)csbState{
    NSLog(@"[PersonalGroupViewController] ConnectionState = %d, CSB_State= %d",state,csbState);
    
    //connectionState = state;
    //CSB_State = csbState;
    
    if(connectionState != 6 && CSB_State != 3)
    {
        connectionState = state;
        CSB_State = csbState;
        
        if(stepIndex == STEP_SLAVE_DISCONNECT){
            if(CSB_State == 3){
                NSLog(@"Create CSB Link,Successful");
                [self personalGroupingProcess:stepIndex];
            }
        }
    }
}

#pragma mark - CBPeripheral delegate
- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    NSLog(@"state updated");
    HomeScreenViewController *view = (HomeScreenViewController*)self.rootViewController;
    view.BtState = peripheral.state;
    if (peripheral.state != CBPeripheralManagerStatePoweredOn) {
        
        NSString *title = @"Bluetooth state alert";//[NSString stringWithFormat:@"Bluetooth state alert"];
        NSString *error = @"Bluetooth Power Off";//[errorArray objectAtIndex:status];
        NSMutableString *errStr = [[NSMutableString alloc] initWithString:error];
        [errStr appendFormat:@"\n\n"];
        [uartCommandHanlder.uartCommandDelegate AudioUartCommandHandler:uartCommandHanlder.connectedPeripheral didUpdateMessage:[errStr mutableCopy] title:title error:TRUE];
    }
}

@end
