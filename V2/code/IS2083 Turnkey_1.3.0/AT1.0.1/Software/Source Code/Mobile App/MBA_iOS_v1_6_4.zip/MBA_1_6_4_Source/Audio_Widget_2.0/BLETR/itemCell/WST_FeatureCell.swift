//
//  WST_FeatureCell.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/7/19.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit

class WST_FeatureCell: UITableViewCell {
    
    @IBOutlet var featureImageView: UIImageView!
    @IBOutlet var featureNameLabel: UILabel!
    @IBOutlet var featureOptionNameLabel: UILabel!
    
    func setFeatureImage(imageName: String) {
        let myImage: UIImage = UIImage(named: imageName)!
        self.featureImageView.image = myImage
    }
    
    func setFeatureNameEnable(enable: Bool) {
        self.featureNameLabel.isEnabled = enable
    }
    
    func setFeatureName(name: String) {
        self.featureNameLabel.text = name
    }
    
    func setFeatureOptionName(name: String) {
        self.featureOptionNameLabel.text = name
    }
}
