//
//  OTASecurity.h
//  TestOTA
//
//  Created by TestPC on 12/04/2018.
//  Copyright © 2018 TestPC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OTASecurity : NSObject
+ (NSData *)CBCWithOperation:(BOOL)operation ivString:(NSString *)ivString andKey:(NSString *)keyString andInput1:(NSString *)PlaintextString andInput2:(NSData *)Plaintext2;
@end
