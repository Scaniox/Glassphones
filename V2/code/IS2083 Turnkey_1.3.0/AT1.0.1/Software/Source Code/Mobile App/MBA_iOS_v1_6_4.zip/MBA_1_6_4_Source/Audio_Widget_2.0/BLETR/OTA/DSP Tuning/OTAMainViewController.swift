//
//  OTAMainViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/7/10.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit

class OTAMainViewController: UIViewController, DSPTuningDelegate, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var myTable: UITableView!
    @IBOutlet var DynamicTuning: UIButton!
    @IBOutlet var SaveFile: UIButton!
    var DSPManager: TuneDSPManager?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //Debug for simulator
        DSPManager = TuneDSPManager.sharedInstance()
        DSPManager?.DSP_Init()
        
        myTable.delegate = self
        myTable.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[OTAMainViewController] viewWillAppear")
        
        DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "DSP_MAIN")
        
        print("BLE state = \(DSPManager?.BLE_Connection)")
        
        if(DSPManager?.BLE_Connection != nil && DSPManager?.BLE_Connection == false){
            print("BLE abnormal disconnect!")
            DSPManager?.DSP_Disconnect_Reset()
            //DSPManager?.redirectLogToFile(filename: "", open: false)
            self.navigationController?.popViewController(animated: true)
        }
        
        if(DSPManager?.Audio_Config == nil){
            DynamicTuning.isEnabled = false
            SaveFile.isEnabled = false
        }
        else{
            if(DSPManager?.TuneDSPParametersComplete == true){
                DynamicTuning.isEnabled = true
                SaveFile.isEnabled = true
            }
        }
        
        DSPManager?.DSP_ClearQueueData()
        
        self.myTable.reloadData()
        
        DSPManager?.Keep_DSP_State()
        
        //Debug
        //DynamicTuning.isEnabled = true
        //SaveFile.isEnabled = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[OTAMainViewController]viewWillDisappear")
        
        if(self.isMovingFromParent) {
            DSPManager?.DSP_Disconnect_Device()
            DSPManager?.DSP_Disconnect_Reset()
            //DSPManager?.redirectLogToFile(filename: "", open: false)
        }
    }
    
    @IBAction func DynamicTuningCommands(_ sender: Any) {
        print("DynamicTuningCommands")
        
        let CommandsString: [String] = ["Factory Reset", "Reset DSP", "Reset DUT", "Save to Flash", "Reset Parameters"]
        
        let alertController = UIAlertController(
            title: "DynamicTuningCommands",
            message: "",
            preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(
            title: "Cancel",
            style: .cancel,
            handler: nil)
        
        alertController.addAction(cancelAction)
        
        for index in 0..<CommandsString.count {
            let action = UIAlertAction(title: CommandsString[index] , style: .default, handler:{
                (action: UIAlertAction!) -> Void in
                print("DSP Command = \(index),\(CommandsString[index])")
                if(index == 0){
                    self.DSPManager?.DSPTuningCommand(dat: Data(bytes: [0x07]))
                }
                else if(index == 1){
                    self.DSPManager?.DSPTuningCommand(dat: Data(bytes: [0x05]))
                }
                else if(index == 2){
                    self.DSPManager?.DSPTuningCommand(dat: Data(bytes: [0x06]))
                }
                else if(index == 3){
                    self.DSPManager?.DSPTuningCommand(dat: Data(bytes: [0x08]))
                }
                else if(index == 4){
                    self.DSPManager?.DSPTuningCommand(dat: Data(bytes: [0x04]))
                }
            }
            )
            
            alertController.addAction(action)
        }
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func SaveDSPTuningResult(_ sender: Any) {
        print("SaveDSPTuningResult")
        
        DSPManager?.Read_Module_DSP_ALL()
        
        /*
        let write_data = Data(bytes:[0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,          0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F, 0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F, 0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x8D, 0x8E, 0x8F, 0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0x9B, 0x9C, 0x9D, 0x9E, 0x9F, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF, 0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7, 0xB8, 0xB9, 0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF, 0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xD0, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF, 0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED, 0xEE, 0xEF, 0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF])
        
        //checksum = 0x06
        let hex_data1 = Data(bytes:[0x10,0x00,0x00,0x00,0x00,0x80,0x04,0x00,0x00,0x03,0x28,0x82,0x04,0x00,0x20,0x00,0x00,0x83,0x12,0x00])
        
        //checksum = 0xAA
        let hex_data2 = Data(bytes:[0x10,0x06,0x50,0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF])
        
        //checksum = 0xD1
        let hex_data3 = Data(bytes:[0x10,0x02,0xA0,0x00,0x11,0x91,0x12,0x00,0x00,0x00,0x05,0x3E,0x00,0x00,0x20,0x00,0x02,0x00,0x14,0x50])
        
        //80
        let hex_data4 = Data(bytes:[0x10,0x01,0x10,0x00,0x00,0x90,0x08,0x00,0x00,0x20,0x00,0x01,0x00,0x03,0x00,0x91,0x12,0x00,0x00,0x00])
        
        HEX_Checksum_Calculation(data: hex_data1 as NSData)
        HEX_Checksum_Calculation(data: hex_data2 as NSData)
        HEX_Checksum_Calculation(data: hex_data3 as NSData)
        HEX_Checksum_Calculation(data: hex_data4 as NSData)
         
         let write_data_string = write_data.hexEncodedString(options: .upperCase)
         print("write_data_string = \(write_data_string), len = \(write_data_string.count)")
        */
    }
    
    func CreateDSPFile(){
        var record = ":10"  //Start code and byte count
        var len = 0
        var tmp: [UInt8] = [UInt8]()
        var tmp_data: Data = Data()
        //var Hex_String = ":02000004FB00FF\r\n"
        var Hex_String = ":02000004FD00FD\r\n"
        
        while(len < (DSPManager?.Module_Config_data?.count)!){
            //while(len < write_data.count){
            tmp.append(0x10)
            let addr = String(format: "%04X",len)
            record += addr  //Address
            let address_H = len >> 8
            let address_L = len & 0xff
            print("address = \(address_H),\(address_L)")
            record += "00"  //Record Type
            tmp.append(UInt8(address_H))
            tmp.append(UInt8(address_L))
            tmp.append(0x00)
            tmp_data.append(Data(bytes:tmp))
            
            let data = (DSPManager?.Module_Config_data as! NSData).subdata(with: NSMakeRange(len, 16))
            //let data = (write_data as NSData).subdata(with: NSMakeRange(len, 16))
            record += data.hexEncodedString(options: .upperCase)
            tmp_data.append(data)
            print("tmp_data = \(tmp_data as NSData)")
            
            record += HEX_Checksum_Calculation(data: tmp_data as NSData)
            record += "\r\n"
            print("HEX record = \(record)")
            Hex_String += record
            
            len += 16
            record = ":10"
            tmp.removeAll()
            tmp_data.removeAll()
        }
        Hex_String += ":00000001FF\r\n"
        
        print("Hex_String = \(Hex_String)")
        
        let file = "DSPTuningResult.HEX" //this is the file. we will write to and read from it
        
        print("Search file!")
        var filepath:String = ""
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
            let txtFiles = fileURLs.filter{ $0.pathExtension == "HEX" }
            
            print("HEX Files URLs = \(txtFiles)")
            
            let txtFileNames = txtFiles.map{ $0.deletingPathExtension().lastPathComponent }
            print("file name list = ", txtFileNames)
            
            if(txtFileNames.count != 0){
                for i in 0..<txtFileNames.count {
                    if("DSPTuningResult" == txtFileNames[i]) {
                        filepath = txtFiles[i].path
                        print("HEX file is Found! = \(filepath)")
                        if(try? fileManager.removeItem(atPath: filepath)) != nil {
                            print("Delete file : success ")
                        }
                        else {
                            print("Delete file : fail")
                        }
                        break
                    }
                }
            }
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
            return
        }
        
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            let fileURL = dir.appendingPathComponent(file)
            
            /*
            do{
                try FileManager.default.removeItem(at: fileURL)
                sleep(1)
                print("Delete file!")
            }
            catch{
                print("Can't delete the file")  //If file is not exist
                //return
            }*/
            
            /*
             if(try? fileManager.removeItem(atPath: filepath)) != nil {
             print("Delete file : success ")
             }
             else {
             print("Delete file : fail")
             }
             */
            
            //writing
            do {
                try Hex_String.write(to: fileURL, atomically: false, encoding: .utf8)
                
                //try write_data.write(to: fileURL)
            }
            catch {/* error handling here */
                print("Write data error")
                return
            }
            
            //reading
            //do {
            //    let text2 = try String(contentsOf: fileURL, encoding: .utf8)
            //}
            //catch {/* error handling here */}
            
            let alertController = UIAlertController(
                title: "DSPTuningResult.HEX is saved!",
                message: "",
                preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
                print("okAction")
            }
            
            alertController.addAction(okAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func HEX_Checksum_Calculation(data:NSData) -> String{
        print("HEX_Checksum_Calculation")
        
        var checksum: UInt8 = 0
        
        var buf = [UInt8](repeating:0, count:data.length)
        data.getBytes(&buf, length: data.length)
        
        var tmp = 0
        for index in 0..<data.length{
            tmp += Int(buf[index])
        }
        print("Sum = \(tmp)")
        
        if(tmp < 256){
            checksum = UInt8(255-tmp)
            checksum += 1
            print("checksum = \(String(format: "0x%02X",checksum))")
        }
        else{
            if(tmp == 256){
                checksum = 0
            }
            else{
                let Sum_LSB = UInt8(tmp & 0xff)
                print("SumSum_LSB = \(Sum_LSB)")
                checksum = UInt8(255-Sum_LSB)
                checksum += 1
                print("*checksum = \(String(format: "0x%02X",checksum))")
            }
        }
    
        //return checksum
        return String(format: "%02X",checksum)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Dynamic OTA DSP Tuning"
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 4
        //return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        // Configure the cell...
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if(indexPath.row == 0){
            cell.textLabel?.text = "Audio Function"
            cell.imageView?.image = UIImage(named: "audio.png")
        }
        else if(indexPath.row == 1){
            cell.textLabel?.text = "Voice Function"
            cell.imageView?.image = UIImage(named: "DSP voice.png")
        }
        else if(indexPath.row == 2){
            if(DSPManager?.Audio_Config == nil){
                cell.textLabel?.textColor = UIColor.gray
                cell.textLabel?.text = "Dynamic Tuning Commands"
            }
            else{
                cell.textLabel?.textColor = UIColor.black
                cell.textLabel?.text = "Dynamic Tuning Commands"
            }
            cell.imageView?.image = UIImage(named: "command.png")
        }
        else{
            if(DSPManager?.Audio_Config == nil){
                cell.textLabel?.textColor = UIColor.gray
                cell.textLabel?.text = "Export DSP Tuning Data"
            }
            else{
                
                cell.textLabel?.textColor = UIColor.black
                cell.textLabel?.text = "Export DSP Tuning Data"
            }
            //cell.imageView?.image = UIImage(named: "export_icon.png")
            cell.imageView?.image = UIImage(named: "export_hex.png")
        }
        /*
        if(indexPath.row == 0){
            cell.textLabel?.text = "Hidden Function"
            cell.imageView?.image = UIImage(named: "others icon.png")
        }
        else if(indexPath.row == 1){
            cell.textLabel?.text = "Audio Function"
            cell.imageView?.image = UIImage(named: "audio.png")
        }
        else if(indexPath.row == 2){
            cell.textLabel?.text = "Voice Function"
            cell.imageView?.image = UIImage(named: "DSP voice.png")
        }
        else if(indexPath.row == 3){
            if(DSPManager?.Audio_Config == nil){
                cell.textLabel?.textColor = UIColor.gray
                cell.textLabel?.text = "Dynamic Tuning Commands"
            }
            else{
                cell.textLabel?.textColor = UIColor.black
                cell.textLabel?.text = "Dynamic Tuning Commands"
            }
            cell.imageView?.image = UIImage(named: "command.png")
        }
        else{
            if(DSPManager?.Audio_Config == nil){
                cell.textLabel?.textColor = UIColor.gray
                cell.textLabel?.text = "Export DSP Tuning Data"
            }
            else{
                //if(DSPManager?.TuneDSPParametersComplete == true){
                //    cell.textLabel?.textColor = UIColor.black
                //}
                //else{
                //    cell.textLabel?.textColor = UIColor.gray
                //}
                cell.textLabel?.textColor = UIColor.black
                cell.textLabel?.text = "Export DSP Tuning Data"
            }
            cell.imageView?.image = UIImage(named: "export_icon.png")
        }*/
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Select device:\(indexPath.row)")
        
        if(indexPath.row == 0){
            if(DSPManager?.dynamicToolMode == 0 || DSPManager?.dynamicToolMode == 1){
                self.performSegue(withIdentifier: "DSP_Audio_Segue", sender: self)
            }
        }
        else if(indexPath.row == 1){
            if(DSPManager?.dynamicToolMode == 0 || DSPManager?.dynamicToolMode == 2){
                self.performSegue(withIdentifier: "DSP_Voice_Segue", sender: self)
            }
        }
        else if(indexPath.row == 2){
            if(DSPManager?.Audio_Config != nil){
                DynamicTuning.sendActions(for: UIControl.Event.touchUpInside)
            }
        }
        else{
            if(DSPManager?.Audio_Config != nil){
                //if(DSPManager?.TuneDSPParametersComplete == true){
                SaveFile.sendActions(for: UIControl.Event.touchUpInside)
                //}
            }
        }
        /*
        if(indexPath.row == 0){
            self.performSegue(withIdentifier: "DSP_Hidden_Segue", sender: self)
        }
        else if(indexPath.row == 1){
            self.performSegue(withIdentifier: "DSP_Audio_Segue", sender: self)
        }
        else if(indexPath.row == 2){
            self.performSegue(withIdentifier: "DSP_Voice_Segue", sender: self)
        }
        else if(indexPath.row == 3){
            if(DSPManager?.Audio_Config != nil){
                DynamicTuning.sendActions(for: UIControlEvents.touchUpInside)
            }
        }
        else{
            if(DSPManager?.Audio_Config != nil){
                //if(DSPManager?.TuneDSPParametersComplete == true){
                    SaveFile.sendActions(for: UIControlEvents.touchUpInside)
                //}
            }
        }*/
    }

    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        if(status == false){
            print("[OTAMainViewController] BLE disconnect!")
            DSPManager?.BLE_Connection = nil
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
    }
    
    func RefreshModuleData() {
    }
    
    func RefreshParametersData(dat: Data) {
    }
    
    func DSPTuningComplete(result: UInt8) {
        if(result != 0x01){
            var str:String = ""
            
            str = "Failed " + String(result)
            
            let alertController = UIAlertController(
                title: "DynamicTuningCommand",
                message: str,
                preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
                print("okAction")
            }
            
            alertController.addAction(okAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func DSPTuningState(state:String) {
    }
    
    func ExportDSPTuningResult(){
        print("ExportDSPTuningResult")
        
        CreateDSPFile()
    }
}
