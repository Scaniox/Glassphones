//
//  WstPeripheral.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/8/4.
//  Copyright © 2019 ISSC. All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth

let RECORD_GROUP_ID_KEY = "RECORD_GROUP_ID"
let RECORD_BUNDLE_ID_KEY = "RECORD_BUNDLE_ID"

@objc protocol WST_Delegate: AnyObject {
    func didUpdateMessage( message: String?)
    func didDiscoverPeripheral(Peripheral: CBPeripheral, AdvertisementData: [String : Any], Rssi RSSI: NSNumber)
    func didConnected()
    func didDisconnected()
    func reportEarbudPosition(position:UInt8)
    func reportPrimaryEarbudBatteryLevel(status:UInt8 , level:UInt8)
    func reportSecondaryEarbudBatteryLevel(level:UInt8)
//    func reportEqMode(mode:UInt8)
    func reportBtmStatus(status:UInt8 , linkInfo:UInt8)
    func reportCallStatus(status:UInt8)
    func reportWstStatus(status:UInt8)
    func reportLinkStatus(linkStatus:UInt8 , playStatus:UInt8)
//    func reportLocalName(name:String)
    func reportPlayStatus(status:UInt8)
//    func reportButtonSetting(role:UInt8, btnOperation:UInt8, btnSetting:Array<Any>)
}

@objc protocol WST_Scan_Delegate: AnyObject {
    func didUpdateMessage( message: String?)
    func didDiscoverPeripheral(Peripheral: CBPeripheral, AdvertisementData: [String : Any], Rssi RSSI: NSNumber)
    func didDisconnected()
}

@objc protocol WST_EQSetting_Delegate: AnyObject {
    func didUpdateMessage( message: String?)
    func reportEqMode(mode:UInt8)
}

@objc protocol WST_EarbudsSetting_Delegate: AnyObject {
    func didUpdateMessage( message: String?)
    func reportLocalName(name:String)
}

@objc protocol WST_FindEarbuds_Delegate: AnyObject {
    func didUpdateMessage( message: String?)
}

@objc protocol WST_TouchpadSetting_Delegate: AnyObject {
    func didUpdateMessage( message: String?)
    func reportButtonSetting(role:UInt8, btnOperation:UInt8, btnSetting:Array<Any>)
}

struct AUDIO_COMMAND_HEADER {
    var start_byte: UInt8 = 0
    var length_high: UInt8 = 0
    var length_low: UInt8 = 0
    var commandID: UInt8 = 0
    init(){}
    init(data: Data){
        //self.start_byte = data[0...3].withUnsafeBytes{$0.load(as: UInt8.self)}
        self.start_byte = data[0]
        self.length_high = data[1]
        self.length_low = data[2]
        self.commandID = data[3]
    }
}

struct AUDIO_UART_EVENT_FORMAT {
    var eventHeader: AUDIO_COMMAND_HEADER = AUDIO_COMMAND_HEADER()
    var commandParameters = [UInt8](repeating: 0, count: 260)
    init(){}

    static func archive(format:AUDIO_UART_EVENT_FORMAT) -> Data {
        var fw = format
        let len:UInt16 = (UInt16(((fw.eventHeader.length_high<<8) | (fw.eventHeader.length_low))+2))
        var value = [UInt8](repeating: 0, count: Int(len+2))
        value[0] = fw.eventHeader.start_byte
        value[1] = fw.eventHeader.length_high
        value[2] = fw.eventHeader.length_low
        value[3] = fw.eventHeader.commandID
        memcpy(&value[4], &fw.commandParameters, Int(len+1))
        
        let data = Data(bytes: UnsafePointer<UInt8>(&value), count: value.count)
        return data
    }
    
    static func unarchive(data:[UInt8]) -> AUDIO_UART_EVENT_FORMAT? {
        var w = AUDIO_UART_EVENT_FORMAT()
        w.eventHeader.start_byte = data[0]
        w.eventHeader.length_high = data[1]
        w.eventHeader.length_low = data[2]
        w.eventHeader.commandID = data[3]
        for i in 0..<data.count-4{
            w.commandParameters[i] = data[i+4]
        }
        return w
    }
}

struct BUNDLE_FORMAT {
    var opcode: UInt8 = 0
    var length: UInt8 = 0
    var commandParameters = [UInt8](repeating: 0, count: 6)
    init(){}
    
    static func archive(format:BUNDLE_FORMAT) -> Data {
        var fw = format
        var value = [UInt8](repeating: 0, count: Int(fw.length+2))
        value[0] = fw.opcode
        value[1] = fw.length
        if fw.length > 0 {
            memcpy(&value[2], &fw.commandParameters, Int(fw.length))
        }
        
        let data = Data(bytes: UnsafePointer<UInt8>(&value), count: value.count)
        return data
    }
    
    static func unarchive(data:[UInt8]) -> BUNDLE_FORMAT? {
        var w = BUNDLE_FORMAT()
        w.opcode = data[0]
        w.length = data[1]
        for i in 0..<data.count-2{
            w.commandParameters[i] = data[i+2]
        }
        return w
    }
}

extension Array {
    subscript(i: UInt) -> Int {
        get {
            return self[Int(i)] as! Int
        } set(from) {
            self[Int(i)] = from as! Element
        }
    }
}

let COMMAND_HEADER_SIZE = MemoryLayout<AUDIO_COMMAND_HEADER>.size

let eventStatusDictionary: [UInt8: String] = [0x00:"Command Complete", 0x01:"Command Disallow", 0x02:"Unknown Command", 0x03:"BTM is Busy", 0x05:"BTM Memory is full",0x07:"Position is not configured"]


struct BUTTON_SETTING{
    var callState:UInt8
    var action:UInt8
}

enum AUDIO_EVENT_ID : UInt8 {
    case ACK = 0x00
    case REPORT_BTM_STATUS = 0x01
    case REPORT_CALL_STATUS = 0x02
    case REPORT_BATTERY_STATUS = 0x0c
    //case BTM_CHARGING_STATUS = 0x0d
    case REPORT_EQ_MODE = 0x10
    //case READ_LINKED_DEVICE_INFORMATION_REPLY = 0x17
    //case READ_BTM_VERSION_REPLY = 0x18
    case AVC_VENDOR_DEPENDENT_RESPONSE = 0x1A
    //case BTM_UTILITY_REQ = 0x1B
    case REPORT_LINK_STATUS = 0x1E
    //case READ_LOCAL_BD_ADDRESS_REPLY = 0x20
    //case READ_LOCAL_DEVICE_NAME_REPLY = 0x21
    //case REPORT_SPP_DATA = 0x22
    //case REPORT_INPUT_SIGNAL_LEVEL = 0x27
    case REPORT_LOCAL_DEVICE_NAME = 0x21
    case REPORT_WST_LINK_STATUS = 0x33
    //case REPORT_IC_VERSION_INFO = 0x38
    //case REPORT_NSPK_EXCHANGE_LINK_INFO = 0x3d
    //case FEATURE_LIST_REPORT = 0x40
    case REPORT_PRIMARY_BOX_STATE_AND_ROLE_INFORMATION = 0x54
    case REPORT_EARBUD_POSITION = 0x57
    case REPORT_SECOND_DEVICE_STATUS = 0x58
    case REPORT_BUTTON_SETTING = 0x5C
}

enum AUDIO_COMMAND_ID : UInt8 {
    case WRITE_LOCAL_NAME = 0x35
    case READ_LINK_STATUS = 0x0D //REPORT_WST_LINK_STATUS
    case READ_LOCAL_NAME = 0x10 //REPORT_LOCAL_DEVICE_NAME
    case RESPONSE_ACK = 0x14
    case READ_BATTERY_STATUS = 0x25 //REPORT_BATTERY_STATUS
    case FINDING_EARBUD = 0x13
    case SET_EQ_MODE = 0x1C //REPORT_EQ_MODE
    case READ_WST_LINK_STATUS = 0x2B
    case READ_EARBUD_STATUS = 0x40 //0x01 - REPORT_PRIMARY_BOX_STATE_AND_ROLE_INFORMATION / 0x03 -REPORT_EARBUD_POSITION / 0x04 - REPORT_SECOND_DEVICE_STATUS
    case SET_BUTTON_SETTING = 0x46
    case READ_BUTTON_SETTING = 0x48
}

enum TONE_TYPE : UInt8 {
    case NA = 0x00
    case TONE_200HZ_100ms = 0x01
    case TONE_500HZ_100ms = 0x02
    case TONE_1000Hz_100ms = 0x03
    case TONE_1500Hz_100ms = 0x04
    case TONE_2000Hz_100ms = 0x05
    case TONE_200HZ_500ms = 0x06
    case TONE_500HZ_500ms = 0x07
    case TONE_1000Hz_500ms = 0x08
    case TONE_1500Hz_500ms = 0x09
    case TONE_2000Hz_500ms = 0x0A
}

enum BUNDLE_ID : UInt8 {
    case CONNECT_REQ = 0x01
    case CONNECT_RES = 0x02
    case CHALLENGE_REQ = 0x03
    case CHALLENGE_RES = 0x04
    case NEW_BUNDLE_REQ = 0x05
    case NEW_BUNDLE_RES = 0x06
}

enum BTM_STATE : UInt8{
    case POWEROFF = 0x00
    case PAIRING = 0x01
    case POWERON = 0x02
    case PAIRING_COMPLETE = 0x03
    case PAIRING_INCOMPLETE = 0x04
    case HS_CONNECTED = 0x05
    case A2DP_CONNECTED = 0x06
    case HS_DISCONNECTED = 0x07
    case A2DP_DISCONNECTED = 0x08
    case SCO_CONNECTED = 0x09
    case SCO_DISCONNECTED = 0x0A
    case AVRCP_CONNECTED = 0x0B
    case AVRCP_DISCONNECTED = 0x0C
    case SPP_CONNECTED = 0x0D
    case SPP_DISCONNECTED = 0x0E
    case STANDBY = 0x0F
    case iAP_CONNECTED = 0x10
    case ACL_DISCONNECTED = 0x11
    case MAP_LINK_CONNECTED = 0x12
    case MAP_OPERATION_FORBIDDEN = 0x13
    case MAP_LINK_DISCONNECTED = 0x14
    case ACL_CONNECTED = 0x15
    case SPP_DISCONNECTED_NO_OTHER_PROFILE = 0x16
    case ACL_LINK_BACK = 0x17
}

let START_BYTE = 0xaa
let POWER_OFF_STATE = 0x00
let POWER_ON_STATE = 0x02

let MCU_REPORT_A2DP_STATUS = 0x04

class ACKTimer2: NSObject {
    var timer: Timer?
    var commandID: UInt8 = 0
    init(commandID cmdID: UInt8, timer: Timer?) {
        super.init()
        self.timer = timer
        commandID = cmdID
    }
}

class WstPeripheral: WST_BLEAdapterDelegate {
    
    private var events: NSMutableData?
    private var waitingACK: NSMutableArray = []
    private var errorArray: NSArray
    var peripheralsArray: NSMutableArray = []
    var advArray: NSMutableArray = []
    var rssiArray: NSMutableArray = []
    
    var bleAdapter: BLEAdapter?
    var wstDelegate: WST_Delegate?
    var wstScanDelegate: WST_Scan_Delegate?
    var wstEqDelegate: WST_EQSetting_Delegate?
    var wstEarbudSettingDelegate: WST_EarbudsSetting_Delegate?
    var wstFindEarbudsDelegate: WST_FindEarbuds_Delegate?
    var wstTouchpadSettingDelegate: WST_TouchpadSetting_Delegate?
    
    var waitACK:Bool = false
    var queuedData: NSMutableArray = []
    
    var m_Sres = [UInt8](repeating: 0, count: 6)
    var m_ChaReq = [UInt8](repeating: 0, count: 6)
    var m_Rand = [UInt8](repeating: 0, count: 6)
    var m_GroupID = [UInt8](repeating: 0, count: 6)
    var m_BundleID = [UInt8](repeating: 0, count: 6)
    var m_Bundled:Bool = false
    var m_groupID_Str: String = ""
    
    
    private static var mInstance:WstPeripheral?
    class func sharedInstance() -> WstPeripheral {
        if(mInstance == nil) {
            mInstance = WstPeripheral()
        }
        return mInstance!
    }
    
    func deleteInstance(){
        bleAdapter?.deleteInstance()
    }
    
    private init() {
        errorArray = ["Command Complete", "Command Disallow", "Unknown Command", "Parameters Error", "BTN is Busy", "BTM Memory is Full"]
        events = NSMutableData()
        bleAdapter = BLEAdapter.sharedInstance()
        bleAdapter?.WstBleAdapterDelegate = self
    }
    
    deinit {
        bleAdapter?.disconnectPeripheral()
        bleAdapter?.deleteInstance()
    }
    
    func connecPeripheral(_ peripheral: CBPeripheral) {
        NSLog("WstPeripheral - connecPeripheral")
        peripheralsArray = NSMutableArray(array: (bleAdapter?.wstPeripherals)!)
        advArray = NSMutableArray(array: (bleAdapter?.wstAdvertisementDataArray)!)
        for i in 0 ..< self.peripheralsArray.count {
            let p:CBPeripheral = self.peripheralsArray.object(at: i) as! CBPeripheral
            if p == peripheral{
                let adv = self.advArray.object(at: i) as! [String : Any]
                if let Service_data_dic = adv["kCBAdvDataServiceData"] as? [NSObject:AnyObject] {
                    if let Service_data = Service_data_dic[CBUUID(string:"FEDA")] as? NSData {
                        var dataByte = [UInt8] (Service_data as Data)
                        let wst_beacon = WST_BEACON_FORMAT(UnsafeMutablePointer<UInt8>(&dataByte))
                        m_GroupID = wst_beacon.groupID
                        m_groupID_Str = wst_beacon.groupID_Str
                        let recordGroup = UserDefaults.standard
                        if let recordGroupID = recordGroup.string(forKey: RECORD_GROUP_ID_KEY){
                            if m_groupID_Str == recordGroupID {
                                if let recordBundleID = recordGroup.data(forKey: RECORD_BUNDLE_ID_KEY){
                                    m_Bundled = true
                                    m_BundleID = [UInt8](recordBundleID)
                                }else{ //no bundle ID record
                                    m_Bundled = false
                                }
                            }else{ //record group ID not match
                                m_Bundled = false
                            }
                        }else{ // no group ID record
                            m_Bundled = false
                        }
                    }
                }
                break
            }
        }
        bleAdapter?.connecPeripheral(peripheral)
    }
    
    func disconnectPeripheral(){
        bleAdapter?.disconnectPeripheral()
    }
    
    func isConnected() -> Bool{
        if bleAdapter?.activePeripheral != nil {
            return true
        }
        return false
    }
    
    func readByte(bytes: [UInt8], offset: Int) -> UInt8 {
        return bytes[offset]
    }

    func calculateChecksum(_ data: UnsafeMutablePointer<UInt8> , length: Int16) -> UInt8{
        var checksum:UInt16 = 0x00
        var idx = 0
        while (idx < length) {
            checksum += UInt16(data[idx])
            idx += 1
        }
        checksum = checksum & 0xFF
        let value = 0x100 - checksum
        let result:UInt8 = UInt8(value & 0xFF)
        return result
     }
    
    func parserEvents(){
        var dataBytes = [UInt8](events! as Data)
        var range = NSRange(location: 0, length: 1)
        while ((dataBytes[0] != START_BYTE) && (((events?.count) != nil))) {
            events?.replaceBytes(in: range, withBytes: nil, length: 0)
            dataBytes = [UInt8](events! as Data)
        }
        if (events!.count) < COMMAND_HEADER_SIZE {
            return
        }
        
        var headerBuf = [UInt8](events! as Data)
//        let headerBuf = UnsafeMutableRawPointer.allocate(byteCount: 10, alignment: 1)
//        events!.getBytes(headerBuf, length: COMMAND_HEADER_SIZE)
//        print(COMMAND_HEADER_SIZE)
//        print(headerBuf)
        let header = AUDIO_COMMAND_HEADER(data: Data(bytes: UnsafeMutablePointer<UInt8>(&headerBuf), count: headerBuf.count))
        //let header = headerBuf as? AUDIO_COMMAND_HEADER
        let payloadLen: Int16 = Int16((header.length_high << 8) | header.length_low)
        let eventLen = payloadLen + Int16(COMMAND_HEADER_SIZE)
        //check if event is complete
        
        //+ start byte AA and checksum
        if (events!.count) < payloadLen + 2 {
            return
        }
        
//        let buf = [UInt8](repeating: 0, count: 260)
//        events.getBytes(&buf, length: Int(eventLen))
//        var buf = [UInt8](events! as Data)
        //** Write Log To File
//        var logStr = "-> "
//        for i in 0..<eventLen {
//            logStr += String(format: "%02X ", buf[i])
//        }
//        logStr += "\n"
//        if (uartCommandDelegate != nil) && ((uartCommandDelegate as? NSObject)?.responds(to: #selector(NSObject.audioUartCommandHandler(_:didUpdateLogForCommand:)))) ?? false {
//            uartCommandDelegate.audioUartCommandHandler(connectedPeripheral, didUpdateLogForCommand: logStr)
//        }
        //var int = dataBytes
        //var eventData: Data = Data(bytes: &int, count: MemoryLayout<Int>.size)
        
        
        let event = AUDIO_UART_EVENT_FORMAT.unarchive(data: dataBytes)
        let checksum: UInt8 = calculateChecksum(UnsafeMutablePointer<UInt8>(&dataBytes[1]), length: eventLen - 2)
//        let checksum: UInt8 = event.calculateChecksum()
        range = NSRange(location: 0, length: Int(eventLen))
        events!.replaceBytes(in: range, withBytes: nil, length: 0)
        //if checksum != readByte(bytes: event!.commandParameters, offset: Int(payloadLen - 1)){
        if checksum != event!.commandParameters[Int(payloadLen - 1)]{//readByte(bytes: event!.commandParameters, offset: Int(payloadLen - 1)){
            print("CheckSum Error!")
            let errStr = "Error - CheckSum Error!"
            if(self.wstFindEarbudsDelegate != nil) {
                self.wstFindEarbudsDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstScanDelegate != nil) {
                self.wstScanDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstEarbudSettingDelegate != nil) {
                self.wstEarbudSettingDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstEqDelegate != nil) {
                self.wstEqDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstTouchpadSettingDelegate != nil) {
                self.wstTouchpadSettingDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstDelegate != nil) {
                self.wstDelegate?.didUpdateMessage( message: errStr)
            }
        }
        
        if header.commandID != AUDIO_EVENT_ID.ACK.rawValue {
            self.command_SendEventAck(eventID: header.commandID)
        }
        
        switch header.commandID {
        case AUDIO_EVENT_ID.ACK.rawValue:
            print("ACK")
            let cmdID = event!.commandParameters[0]
            let status = event!.commandParameters[1]
            let result = removeCheckResponseTimer(forCommand: cmdID)
            if result{}
//
            if status == 0x00{
                checkQueuedData()
                
                let str = "Command Complete"
                if cmdID == AUDIO_COMMAND_ID.FINDING_EARBUD.rawValue{
                    if(self.wstFindEarbudsDelegate != nil) {
                        self.wstFindEarbudsDelegate?.didUpdateMessage( message: str)
                    }
                }else if cmdID == AUDIO_COMMAND_ID.WRITE_LOCAL_NAME.rawValue{
                    if(self.wstEarbudSettingDelegate != nil) {
                        self.wstEarbudSettingDelegate?.didUpdateMessage( message: str)
                    }
                }else if cmdID == AUDIO_COMMAND_ID.SET_EQ_MODE.rawValue{
                    if(self.wstEqDelegate != nil) {
                        self.wstEqDelegate?.didUpdateMessage( message: str)
                    }
                }else if cmdID == AUDIO_COMMAND_ID.SET_BUTTON_SETTING.rawValue{
                    if(self.wstTouchpadSettingDelegate != nil) {
                        self.wstTouchpadSettingDelegate?.didUpdateMessage( message: str)
                    }
                }
            }else{ //FW not response command complete with ACK
                queuedData.removeAllObjects()
                var errStr:String = ""
                if let err = eventStatusDictionary[status]{
                    errStr = String(format: "Command 0x%02X Error: %@",cmdID ,err)
                }else{
                    errStr = String(format: "Command 0x%02X Error:",cmdID)
                }
                
                if(self.wstFindEarbudsDelegate != nil) {
                    self.wstFindEarbudsDelegate?.didUpdateMessage( message: errStr)
                }else if(self.wstScanDelegate != nil) {
                    self.wstScanDelegate?.didUpdateMessage( message: errStr)
                }else if(self.wstEarbudSettingDelegate != nil) {
                    self.wstEarbudSettingDelegate?.didUpdateMessage( message: errStr)
                }else if(self.wstEqDelegate != nil) {
                    self.wstEqDelegate?.didUpdateMessage( message: errStr)
                }else if(self.wstTouchpadSettingDelegate != nil) {
                    self.wstTouchpadSettingDelegate?.didUpdateMessage( message: errStr)
                }else if(self.wstDelegate != nil) {
                    self.wstDelegate?.didUpdateMessage( message: errStr)
                }
            }
            
        case AUDIO_EVENT_ID.REPORT_BTM_STATUS.rawValue:
            print("REPORT_BTM_STATUS")
            let btmStatus = event!.commandParameters[0]
            let info = event!.commandParameters[1]
            if(self.wstDelegate != nil) {
                self.wstDelegate?.reportBtmStatus(status: btmStatus, linkInfo: info)
            }
        case AUDIO_EVENT_ID.REPORT_CALL_STATUS.rawValue:
            print("REPORT_CALL_STATUS")
            let callStatus = event!.commandParameters[1]
            //let info = event!.commandParameters[1]
            if(self.wstDelegate != nil) {
                self.wstDelegate?.reportCallStatus(status: callStatus)
        }
        case AUDIO_EVENT_ID.REPORT_BATTERY_STATUS.rawValue:
            print("REPORT_BATTERY_STATUS")
            let batteryStatus = event!.commandParameters[0]
            let batteryLevel = event!.commandParameters[1]
            if(self.wstDelegate != nil) {
                self.wstDelegate?.reportPrimaryEarbudBatteryLevel(status:batteryStatus, level:batteryLevel)
            }
        case AUDIO_EVENT_ID.REPORT_EQ_MODE.rawValue:
            print("REPORT_EQ_MODE")
            let mode = event!.commandParameters[0]
            if(self.wstEqDelegate != nil) {
                self.wstEqDelegate?.reportEqMode(mode: mode)
            }
        case AUDIO_EVENT_ID.AVC_VENDOR_DEPENDENT_RESPONSE.rawValue:
            if event!.commandParameters[7] == 0x31 {
                if event!.commandParameters[11] == 0x01 {
                    let playStatus = event!.commandParameters[12]
                    if(self.wstDelegate != nil) {
                        self.wstDelegate?.reportPlayStatus(status: playStatus)
                    }
                }
            }
            
        /*case AUDIO_EVENT_ID.BTM_UTILITY_REQ.rawValue:
            print("REPORT_A2DP_STATUS")
            if  event!.commandParameters[0] == MCU_REPORT_A2DP_STATUS{
                let playStatus = event!.commandParameters[1]
                if(self.wstDelegate != nil) {
                    self.wstDelegate?.reportPlayStatus(status: playStatus)
                }
            }*/
            
        case AUDIO_EVENT_ID.REPORT_LINK_STATUS.rawValue:
            print("REPORT_LINK_STATUS")
            let linkStatus = event!.commandParameters[0]
            
            var playStatus:UInt8 = 0
            var DatabaseIndex:UInt8 = 0
            var linkA2DP:Bool = false
            var streaming:UInt8 = 0
            
            if((event!.commandParameters[1] != 0) && (event!.commandParameters[2] == 0)){
                DatabaseIndex = 0x00
            }
            else if((event!.commandParameters[1] == 0) && (event!.commandParameters[2] != 0)){
                DatabaseIndex = 0x01
            }
            else{
                DatabaseIndex = 0x00
            }
            
            if(DatabaseIndex == 0){
                if ((event!.commandParameters[1]&0x03) == 0x03) {//Database0_Connect_Status
                    linkA2DP = true
                }
                streaming = event!.commandParameters[5]//Database0_Stream_Status
                playStatus = event!.commandParameters[3]//Database0_Play_Status
            }
            else{
                if ((event!.commandParameters[2]&0x03) == 0x03) {//Database1_Connect_Status
                    linkA2DP = true
                }
                streaming = event!.commandParameters[6]//Database1_Stream_Status
                playStatus = event!.commandParameters[4]//Database1_Play_Status
            }
            if(self.wstDelegate != nil) {
                self.wstDelegate?.reportLinkStatus(linkStatus: linkStatus, playStatus: playStatus)
            }
            
            if linkA2DP{}
            if streaming == 0{}
            
        
            
        case AUDIO_EVENT_ID.REPORT_LOCAL_DEVICE_NAME.rawValue:
            print("REPORT_LOCAL_DEVICE_NAME")
            
            let len = event!.commandParameters[0]
            let nameBytes = event!.commandParameters[1...Int(len)]
            let nameString = String(decoding: nameBytes, as: UTF8.self)
            if(self.wstEarbudSettingDelegate != nil) {
                self.wstEarbudSettingDelegate?.reportLocalName(name: nameString)
            }
            
        case AUDIO_EVENT_ID.REPORT_WST_LINK_STATUS.rawValue:
            print("REPORT_WST_LINK_STATUS")
            let status = event!.commandParameters[0]
            if(self.wstDelegate != nil) {
                self.wstDelegate?.reportWstStatus(status: status)
            }
        case AUDIO_EVENT_ID.REPORT_PRIMARY_BOX_STATE_AND_ROLE_INFORMATION.rawValue:
            print("REPORT_PRIMARY_BOX_STATE_AND_ROLE_INFORMATION")
            
        case AUDIO_EVENT_ID.REPORT_EARBUD_POSITION.rawValue:
            print("REPORT_EARBUD_POSITION")
            let earbudPosition = event!.commandParameters[0]
            if(self.wstDelegate != nil) {
                self.wstDelegate?.reportEarbudPosition(position:earbudPosition)
            }
        case AUDIO_EVENT_ID.REPORT_SECOND_DEVICE_STATUS.rawValue:
            print("REPORT_SECOND_DEVICE_STATUS")
            let batteryLevel = event!.commandParameters[0]
            if(self.wstDelegate != nil) {
                self.wstDelegate?.reportSecondaryEarbudBatteryLevel(level: batteryLevel)
            }
        case AUDIO_EVENT_ID.REPORT_BUTTON_SETTING.rawValue:
            print("REPORT_SECOND_DEVICE_STATUS")
            
            let destination = event!.commandParameters[0]
            let btnOperation = event!.commandParameters[1]
            let len = payloadLen - 3
            var btnSettingArray:[BUTTON_SETTING] = []
            for i in 0..<Int(len/2){
                btnSettingArray.append(BUTTON_SETTING(callState: event!.commandParameters[i*2 + 2], action: event!.commandParameters[i*2 + 3]))
            }
            
            if(self.wstTouchpadSettingDelegate != nil) {
                self.wstTouchpadSettingDelegate?.reportButtonSetting(role: destination, btnOperation: btnOperation, btnSetting: btnSettingArray)
            }
        default:
            let format = String(format:"0x%02X",header.commandID)
            print("parserEvents : Event ID = \(format)")
            break
        }
    }
    
    @objc func StartScan() -> Int {
        print("StartScan")
        peripheralsArray.removeAllObjects()
        advArray.removeAllObjects()
        rssiArray.removeAllObjects()
        var result:Int = 0
        result = (bleAdapter?.findAllBLEPeripherals(0))!
        return result
    }
    
    @objc func StopScan() {
        print("StopDevice")
        bleAdapter?.stopScan()
    }

    func sendData(data:Data){
        //print("sendData")
        if (waitACK) {
            //print("sendData - Wait Ack")
            queuedData.add(data)
            return
        }

        bleAdapter?.BLE_WriteValue((bleAdapter?.TransparentRxChar)!,data:data,writeType: CBCharacteristicWriteType.withResponse)
        
        let cmdID = data[3]
        if ((cmdID != 0x14) && (cmdID != 0x16)){//BTAS-484
            waitACK = true
        }
        self.checkAck(ID: cmdID)
    }
    
    func checkAck(ID :UInt8){
        if ((ID != 0x14) && (ID != 0x16)){//BTAS-484
            self.checkResponse(ID, timeout: 3.0)
        }
    }
    
    func removeCheckResponseTimer(forCommand cmdID: UInt8) -> Bool {
        var obj: ACKTimer2? = nil
        waitACK = false
        for i in 0..<waitingACK.count {
            obj = waitingACK[i] as? ACKTimer2
            if obj?.commandID == cmdID {
                obj?.timer!.invalidate()
                waitingACK.removeObject(at: i)
                return true
            }
        }
        return false
    }
    
    @objc func ackTimeoutOfCommand(sender: Timer) {
        let cmdID = sender.userInfo! as! UInt8//sender.userInfo!["CMD_ID"] as! UInt8
        let result = removeCheckResponseTimer(forCommand: cmdID)
        if result{
            let errStr = String(format: "Command 0x%02X ACK Timeout", cmdID)
            if(self.wstFindEarbudsDelegate != nil) {
                self.wstFindEarbudsDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstScanDelegate != nil) {
                self.wstScanDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstEarbudSettingDelegate != nil) {
                self.wstEarbudSettingDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstEqDelegate != nil) {
                self.wstEqDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstTouchpadSettingDelegate != nil) {
                self.wstTouchpadSettingDelegate?.didUpdateMessage( message: errStr)
            }else if(self.wstDelegate != nil) {
                self.wstDelegate?.didUpdateMessage( message: errStr)
            }
        }
    }
    
    func checkResponse(_ cmdID: UInt8, timeout: TimeInterval) {
        let selector = #selector(ackTimeoutOfCommand(sender:))
        let timer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: selector, userInfo: cmdID, repeats: false)
        let obj = ACKTimer2(commandID: cmdID, timer: timer)
        waitingACK.add(obj)
    }
    
    func checkQueuedData() {
        //print("checkQueuedData")
        if (queuedData.count>0) {
            //print("checkQueuedData in")
            let data = queuedData[0] as! Data
            queuedData.removeObject(at: 0)
            self.sendData(data: data)
        }
        //print("checkQueuedData End")
    }

// MARK: - Commands
    func command_SendEventAck(eventID:UInt8){
        print("command_SendEventAck")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x02
        command.eventHeader.commandID = AUDIO_COMMAND_ID.RESPONSE_ACK.rawValue
        command.commandParameters[index] = eventID
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt8 = 0
        for i in 1...len{
            chkSum += buf[Int(i)]
        }
        command.commandParameters[index] = ~chkSum+1
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        //[self sendData:commandData]
        bleAdapter?.BLE_WriteValue((bleAdapter?.TransparentRxChar)!,data:commandData,writeType: CBCharacteristicWriteType.withResponse)
        /*** Call the Dalegate for Write Data to File Here*/
//        if ((transDataDelegate) && ([(NSObject *)transDataDelegate respondsToSelector:@selector(MyPeripheral:didUpdateLogForCommand:)])) {
//        [transDataDelegate MyPeripheral:self didUpdateLogForCommand:commandData]
//        }
    }
    
    @objc func command_ReadLinkStatus(){
        print("command_ReadLinkStatus")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x02
        command.eventHeader.commandID = AUDIO_COMMAND_ID.READ_LINK_STATUS.rawValue
        command.commandParameters[index] = 0x00
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_ReadWstLinkStatus(){
        print("command_ReadWstLinkStatus")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x02
        command.eventHeader.commandID = AUDIO_COMMAND_ID.READ_WST_LINK_STATUS.rawValue
        command.commandParameters[index] = 0x00
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_ReadPrimaryBatteryLevel(){
        print("command_ReadPrimaryBatteryLevel")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x02
        command.eventHeader.commandID = AUDIO_COMMAND_ID.READ_BATTERY_STATUS.rawValue
        command.commandParameters[index] = 0x00
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_ReadEarbudPosition(){
        print("command_ReadEarbudStatus")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x02
        command.eventHeader.commandID = AUDIO_COMMAND_ID.READ_EARBUD_STATUS.rawValue
        command.commandParameters[index] = 0x03
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        self.sendData(data: commandData)
    }
    
    @objc func command_ReadSecondaryEarbudStatus(){
        print("command_ReadSecondaryEarbudStatus")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x02
        command.eventHeader.commandID = AUDIO_COMMAND_ID.READ_EARBUD_STATUS.rawValue
        command.commandParameters[index] = 0x04
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        self.sendData(data: commandData)
    }
    
    @objc func command_ReadLocalName(){
        print("command_ReadLocalName")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x02
        command.eventHeader.commandID = AUDIO_COMMAND_ID.READ_LOCAL_NAME.rawValue
        command.commandParameters[index] = 0x00
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_FindingMyEarbud(tone: UInt8){
        print("command_FindingMyEarbud")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x03
        command.eventHeader.commandID = AUDIO_COMMAND_ID.FINDING_EARBUD.rawValue
        command.commandParameters[index] = 0x02
        index += 1
        command.commandParameters[index] = tone
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_SetEqMode(mode: UInt8){
        print("command_SetEqMode")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x02
        command.eventHeader.commandID = AUDIO_COMMAND_ID.SET_EQ_MODE.rawValue
        command.commandParameters[index] = mode
        index += 1
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_WriteLocalName(name:String){
        print("command_WriteLocalName")
        var index = 0
        let data:[UInt8] = [UInt8](name.utf8)
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = UInt8(data.count+4)
        command.eventHeader.commandID = AUDIO_COMMAND_ID.WRITE_LOCAL_NAME.rawValue
        command.commandParameters[0] = 0x00
        command.commandParameters[1] = 0x00
        command.commandParameters[2] = UInt8(data.count)
        index+=3
        for i in 0..<data.count{
            command.commandParameters[index] = data[i]
            index+=1
        }
        
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_SetButtonSetting(role:UInt8, btnOperation:UInt8, btnSetting:Array<Any>){
        print("command_SetButtonSetting")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x03 + UInt8(btnSetting.count * 2)
        command.eventHeader.commandID = AUDIO_COMMAND_ID.SET_BUTTON_SETTING.rawValue
        command.commandParameters[index] = role
        index += 1
        command.commandParameters[index] = btnOperation
        index += 1
        for i in 0..<btnSetting.count{
            let setting = btnSetting[i] as! BUTTON_SETTING
            command.commandParameters[index] = setting.callState
            index += 1
            command.commandParameters[index] = setting.action
            index += 1
        }
        
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_ReadButtonSetting(role:UInt8, btnOperation:UInt8, callState:[UInt8]){
        print("command_ReadButtonSetting")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x03 + UInt8(callState.count)
        command.eventHeader.commandID = AUDIO_COMMAND_ID.READ_BUTTON_SETTING.rawValue
        command.commandParameters[index] = role
        index += 1
        command.commandParameters[index] = btnOperation
        index += 1
        for i in 0..<callState.count{
            command.commandParameters[index] = callState[i]
            index += 1
        }
        
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }
    
    @objc func command_Test(){
        print("command_Test")
        var index = 0
        var command = AUDIO_UART_EVENT_FORMAT()
        command.eventHeader.start_byte = 0xAA
        command.eventHeader.length_high = 0x00
        command.eventHeader.length_low = 0x0B
        command.eventHeader.commandID = 0x40
        command.commandParameters[0] = 0x00
        command.commandParameters[1] = 0x11
        command.commandParameters[2] = 0x22
        command.commandParameters[3] = 0x33
        command.commandParameters[4] = 0x44
        command.commandParameters[5] = 0x55
        command.commandParameters[6] = 0x66
        command.commandParameters[7] = 0x77
        command.commandParameters[8] = 0x88
        command.commandParameters[9] = 0x99
        index += 10
        let len:UInt16 = (UInt16(((command.eventHeader.length_high<<8) | (command.eventHeader.length_low))+2))
        var buf = [UInt8](repeating: 0, count: 260)
        memcpy(&buf[0], &command.eventHeader.start_byte, 4)
        memcpy(&buf[4], &command.commandParameters,  Int(len-2))
        
        var chkSum:UInt16 = 0
        for i in 1...len{
            chkSum += UInt16(buf[Int(i)])
        }
        buf[index+4] = UInt8((~chkSum+1)&0xFF)
        //command.commandParameters[index] = UInt8((~chkSum+1)&0xFF)
        //let commandData = AUDIO_UART_EVENT_FORMAT.archive(format:command)
        //let commandData = [NSData]
        let commandData = Data(bytes: &buf, count: Int(len+2))
        sendData(data: commandData)
    }

    
// MARK: - APP Bundle Commands
    func Bundle_ConnectReq(){
        print("Bundle_ConnectReq")
        var command = BUNDLE_FORMAT()
        command.opcode = BUNDLE_ID.CONNECT_REQ.rawValue
        command.length = 0x00
        let commandData = BUNDLE_FORMAT.archive(format:command)
        bleAdapter?.BLE_WriteValue((bleAdapter?.TransparentControlPointChar)!,data:commandData,writeType: CBCharacteristicWriteType.withResponse)
    }
    
    func Bundle_BundleReq(Rand: [UInt8]){
        print("Bundle_BundleReq")
        var command = BUNDLE_FORMAT()
        command.opcode = BUNDLE_ID.NEW_BUNDLE_REQ.rawValue
        command.length = 0x06
        for i in 0..<Int(command.length){
            command.commandParameters[i] = Rand[i]
        }
        let commandData = BUNDLE_FORMAT.archive(format:command)
        bleAdapter?.BLE_WriteValue((bleAdapter?.TransparentControlPointChar)!,data:commandData,writeType: CBCharacteristicWriteType.withResponse)
    }
    
    func Bundle_ChallengeRes(ChaRes: [UInt8]){
        print("Bundle_ChallengeRes")
        var command = BUNDLE_FORMAT()
        command.opcode = BUNDLE_ID.CHALLENGE_RES.rawValue
        command.length = 0x06
        for i in 0..<Int(command.length){
            command.commandParameters[i] = ChaRes[i]
        }
        let commandData = BUNDLE_FORMAT.archive(format:command)
        bleAdapter?.BLE_WriteValue((bleAdapter?.TransparentControlPointChar)!,data:commandData,writeType: CBCharacteristicWriteType.withResponse)
    }
    
// MARK: - BLEAdapter WstBleAdapterDelegate
    func didDiscoverPeripheral(Peripheral peripheral: CBPeripheral, AdvertisementData advertisementData: [String : Any], Rssi RSSI: NSNumber) {
        print(" WstPeripheral - didDiscoverPeripheral")
        peripheralsArray = NSMutableArray(array: (bleAdapter?.wstPeripherals)!)
        advArray = NSMutableArray(array: (bleAdapter?.wstAdvertisementDataArray)!)
        rssiArray = NSMutableArray(array: (bleAdapter?.wstPeripheralsRssiArray)!)
        if(self.wstScanDelegate != nil) {
            self.wstScanDelegate?.didDiscoverPeripheral(Peripheral: peripheral, AdvertisementData: advertisementData, Rssi: RSSI)
        }else if(self.wstDelegate != nil) {
            self.wstDelegate?.didDiscoverPeripheral(Peripheral: peripheral, AdvertisementData: advertisementData, Rssi: RSSI)
        }
    }

    func didConnected(){
        print(" WstPeripheral - didConnected")
        Bundle_ConnectReq()
    }

    func didDisconnected(){
        print(" WstPeripheral - didDisconnected")
        if(self.wstScanDelegate != nil) {
            self.wstScanDelegate?.didDisconnected()
        }else if(self.wstDelegate != nil) {
            self.wstDelegate?.didDisconnected()
        }
    }
    
    func didReceiveAudioEvent(data: Data){
        print(" WstPeripheral - didReceiveAudioEvent")
        if (data.count > 0){
            let datas = data
            events?.append(datas)
            print(events!)
            
            let state = UIApplication.shared.applicationState
            if state == .background || state == .inactive{
                DispatchQueue.global(qos: .background).async {
                    //background code
                    DispatchQueue.main.async {
                        self.parserEvents()
                    }
                }
            }else if state == .active{
                self.parserEvents()
            }
        }
    }
    
    func didReceiveControlPointEvent(data: Data){
        print(" WstPeripheral - didReceiveControlPointEvent")
        if (data.count > 0){
            let dataBytes = [UInt8](data)
            let event = BUNDLE_FORMAT.unarchive(data: dataBytes)
            switch event!.opcode{
            case BUNDLE_ID.CONNECT_RES.rawValue:
                print("Bundle res = \(event!.commandParameters[0])")
                let result = event!.commandParameters[0]
                if(self.wstDelegate != nil && result == 0x01) {
                    let defaults = UserDefaults.standard
                    defaults.set(m_groupID_Str, forKey: RECORD_GROUP_ID_KEY)
                    defaults.set(m_BundleID, forKey: RECORD_BUNDLE_ID_KEY)
                    
                    self.wstDelegate?.didConnected()
                }else{
                    let errStr = "Error - Bundle Failed!"
                    if(self.wstScanDelegate != nil) {
                        self.wstScanDelegate?.didUpdateMessage( message: errStr)
                    }else if(self.wstDelegate != nil) {
                        self.wstDelegate?.didUpdateMessage( message: errStr)
                    }
                    bleAdapter?.disconnectPeripheral()
                }
            case BUNDLE_ID.CHALLENGE_REQ.rawValue:
                print("Challenge Req")
                memcpy(&m_ChaReq, event!.commandParameters, 6)
                //m_ChaVal = event!.commandParameters[0..<6]
                if m_Bundled == true{
                    var ChaRes = [UInt8](repeating: 0, count: 6)
                    for i in 0..<6{
                        ChaRes[i] = m_ChaReq[i] ^ m_BundleID[i] ^ m_GroupID[i]
                    }
                    Bundle_ChallengeRes(ChaRes: ChaRes)
                    
                }else{
                    memcpy(&m_ChaReq, event!.commandParameters, 6)
                    for i in 0..<6{
                        m_Rand[i] = UInt8.random(in: 0...255)
                    }
                    Bundle_BundleReq(Rand: m_Rand)
                }
            case BUNDLE_ID.NEW_BUNDLE_RES.rawValue:
                memcpy(&m_Sres, event!.commandParameters, 6)
                var ChaRes = [UInt8](repeating: 0, count: 6)
                
                for i in 0..<6{
                    m_BundleID[i] = m_Sres[i] ^ m_Rand[i] ^ m_GroupID[i]
                }
                
                for i in 0..<6{
                    ChaRes[i] = m_ChaReq[i] ^ m_BundleID[i] ^ m_GroupID[i]
                }
                Bundle_ChallengeRes(ChaRes: ChaRes)
                print("Bundle Res")
            default:
                print("Receive Bundle opcode = \(event!.opcode)")
            }
        }
    }
}
