//
//  ViewController.swift
//  TestOTA
//
//  Created by TestPC on 26/10/2017.
//  Copyright © 2017 TestPC. All rights reserved.
//

import UIKit
import ExternalAccessory

//protocol OTAProtocol {
//    func BLEDataOut(_ DataOut:Data)
//}

class ViewController: UIViewController, BLEAdapterDelegate, UITextFieldDelegate{
    
    var bleAdapter : BLEAdapter?
    
    var isConnected : Bool!
    
    @IBOutlet weak var m_RunButtom: UIButton!
    
    var OTACommad : NSMutableData?
    var UpdateFWType : UInt8!
    var ConnectionInit : Bool!
    var OTABufferSize : UInt16 = 0
    var imageSize : UInt = 0            //MCU
    var anotherSize : UInt = 0          //Voice Prompt & DSP
    var uidataSize : UInt = 0
    var hexdata : NSData?               //MCU
    var dspdata : NSData?               //DSP
    var uidata : NSData?                //User Config data
    var Command_data : NSData?
    var bankInfo : NSData?
    var imageCRC : UInt16 = 0
    var mcu_checksum : UInt16 = 0
    var dsp_checksum : UInt16 = 0
    var ui_checksum : UInt16 = 0
    var comparedCRC : NSMutableData?    //CRC array
    var OTARunning : Bool! = false
    var EncryptionData : NSMutableData!
    
    var OTA_Key_Field : UITextField?
    var OTA_IV_Field  : UITextField?
    
    var OTA_AES_Key : String! = ""
    var OTA_AES_IV : String! = ""
    
    var activityIndicator : UIActivityIndicatorView = UIActivityIndicatorView()
    
    @IBOutlet weak var OTAProgress : UIProgressView!
    
    var ISSC_Device = false
    
    enum OTA_Encrypted : Int {
        case NoDefine = 0,Enable,Disable
    }
    
    enum HEX_STAGE {
        case IDLE,
        //INIT,
        INIT_MCU,
        INIT_VP_DSP,
        INIT_UI,
        GET_BUFFER_SIZE,
        VERSION_REQ,
        WRITE_REQ,
        WRITE_PAYLOAD,
        WRITE_SEGMENT_CHECK,
        ERASE_REQ,
        DUMP_REQ,
        DUMP_COMPLETE,
        RESET_REQ,
        UPDATE_FINISH,
        VERIFY_COMMON_BANK_REQ,
        WRITE_BANK_INFO
    }
    
    let Image_Type_MCU: UInt8 = 0x01
    let Image_Type_DSP: UInt8 = 0x02
    let Image_Type_UI: UInt8 = 0x03
    let Image_Type_Voice_prompt: UInt8 = 0x04
    let Image_Type_Vendor_data: UInt8 = 0x05
    let Image_Type_VoicePrompt_DSP: UInt8 = 0x06
    
    var hexStage = HEX_STAGE.IDLE
    var UpdateMTU : UInt = 16
    var UpdateOffset : UInt = 0
    var SelectedHexFile : String = ""
    var SelectedImageType : UInt8 = 0
    var AnotherHexFile : String = ""
    var UIHexFile : String = ""
    #if Debug
    var ImageTypeList: [String] = ["MCU", "DSP" , "UI_data"]
    #else
    var ImageTypeList: [String] = ["MCU", "VP_DSP"]
    #endif
    var OTA_State: UInt8 = 0x00
    var MCU_Version : String = ""
    var DSP_Version : String = ""
    //var Updated_DSP_Version : String = ""
    //var Updated_MCU_Version : String = ""
    var Updated_DSP_Version : String?
    var Updated_MCU_Version : String?
    //var otadefault : Int = 0
    var otadefault : Int = OTA_Encrypted.NoDefine.rawValue
    var OTA_Time : String = ""
    
    @IBOutlet weak var m_OTASetting: UIButton!
    
    @IBOutlet var mcu_label: UILabel!
    @IBOutlet var dsp_label: UILabel!
    @IBOutlet var state_label: UILabel!
    @IBOutlet var info: UILabel!
    @IBOutlet var myview: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //mcu_label.layer.borderColor = UIColor.red.cgColor
        //mcu_label.layer.borderWidth = 1.0
        mcu_label.attributedText = NSAttributedString(string: "MCU Version :", attributes:
            [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
        
        dsp_label.attributedText = NSAttributedString(string: "DSP&VP Version : ", attributes:
            [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
        
        state_label.attributedText = NSAttributedString(string: "OTA State :", attributes:
            [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
        
        myview.layer.borderWidth = 2.0
        myview.layer.borderColor = UIColor.red.cgColor
        
        isConnected = false
        
        #if Debug
            print("Debug mode is ON.")
        #else
            let OptionButton = UIBarButtonItem(title: "Security", style: UIBarButtonItemStyle.plain, target: self, action: #selector(ViewController.OptionbuttonTapped(_:)))
        
            self.navigationItem.rightBarButtonItem = OptionButton
        #endif
        
        print("[ViewController] viewDidLoad")
        bleAdapter = BLEAdapter.sharedInstance()
        
        bleAdapter?.bleAdapterDelegate = self
        
        self.title = bleAdapter?.Peripheral_Name
        
        //if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_6_1)
        if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_9_0){
            print("iOS version is too old, OTA doesn't support this version")
            UpdateMTU = 20
        }
        else {
            print("iOS version = \(UIDevice.current.systemVersion)")
        }
        
        OTAProgress.progress = 0
        OTAProgress.progressTintColor = UIColor.blue
        OTAProgress.trackTintColor = UIColor.white
        OTAProgress.transform = CGAffineTransform(scaleX: 1, y: 4)
        
        let AppDefaults = UserDefaults.standard
        otadefault = AppDefaults.integer(forKey: "SecuringOTA")
        //if(otadefault == 0) {
        if(otadefault == OTA_Encrypted.NoDefine.rawValue) {
            //AppDefaults.set(1, forKey: "SecuringOTA")
            AppDefaults.set(OTA_Encrypted.Enable.rawValue, forKey: "SecuringOTA")
        }
        
        if let AES_key = AppDefaults.object(forKey: "SecuringOTA.key"){
            let key = AES_key as! String
            //print("AES key = " + key)
            OTA_AES_Key = key
            print("AES key = " + OTA_AES_Key)
            if let AES_iv = AppDefaults.object(forKey: "SecuringOTA.iv"){
                let iv = AES_iv as! String
                OTA_AES_IV = iv
                print("AES iv = " + OTA_AES_IV)
            }
        }
        else{
            print("Can't find the AES_key")
            OTA_AES_Key = "22222222222222222222222222222222"
            OTA_AES_IV = "00000000000000000000000000000000"
            AppDefaults.set(OTA_AES_Key, forKey: "SecuringOTA.key")
            AppDefaults.set(OTA_AES_IV, forKey: "SecuringOTA.iv")
        }
        
        //self.info.text = "OTA_file:" + "MCU_STACK_DEBUG_1234.HEX" + ",VP_DSP_APPLICATION_5678.HEX"
        self.info.text = ""
        
        if(UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.pad){
            print("This is iPad")
        }
        
        m_RunButtom.layer.cornerRadius = 15.0
        m_OTASetting.layer.cornerRadius = 15.0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        bleAdapter?.bleAdapterDelegate = self
        
        print("[ViewController] viewWillAppear")
        
        ConnectionInit = false
        
        isConnected = true
        
        SelectedHexFile = ""
        AnotherHexFile = ""
        
        OTA_Time = ""
        
        //m_OTAStatus.text = "Connect"
        //state_label.attributedText = NSAttributedString(string: "OTA State : Connect", attributes:[NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
        state_label.attributedText = NSAttributedString(string: "OTA State : Connected", attributes:
            [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
        
        otadefault = UserDefaults.standard.integer(forKey: "SecuringOTA")
        
        Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(ViewController.OTA_GetVersionAfterConnection), userInfo: nil, repeats: false)
        
        print("AES key = " + OTA_AES_Key)
        print("AES iv = " + OTA_AES_IV)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        
        print("viewWillDisappear")
        
        if(self.isMovingFromParent) {
            print("Detecting 'BACK' button event!!")
            
            if(isConnected) {
                bleAdapter!.disconnectPeripheral()
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func OTASettings(_ sender: Any) {
        //OTASelectImageType()
        OTASelectFile()
    }
    
    @IBAction func RunOTA(_ sender: Any) {
        
        print("Run button")
        //Debug
        //let mydata = Data(bytes:[0x04,0x01,0x02,0x0b])//Read Parameters:MODULE_BT_CFG_KEY_DEVICE_NAME
        //let mydata = Data(bytes:[0x05,0x03])//Read Module:MODULE_AUDIO_MCU
        //bleAdapter?.SendTestData(mydata)
        
        ///*
        var str = ""
        
        if(!(isConnected)) {
            OTA_ReConnect()
            self.m_OTASetting.isEnabled = true
            return;
        }
        
        if #available(iOS 11.0, *) {
            // use iOS 11-only feature
            print("Check iOS version : 11.0+")
        } else {
            OTA_AlertMessage(title: "OTA not supported", Message: "Please upgrade to iOS 11.0 and later ")
            return
        }
        
        //Debug
        //ISSC_Device = true
        
        if(OTARunning) {
            return
        }
        
        if(!ISSC_Device){
            if(isConnected) {
                bleAdapter!.disconnectPeripheral()
            }
            OTA_AlertMessage(title: "This device doesn't support OTA update", Message: "")
            return
        }
        
        if((SelectedHexFile == "") && (AnotherHexFile == "") && (UIHexFile == "")) {
            print("Can't find OTA files")
            OTA_AlertMessage(title: "Select file before update", Message: "")
            return
        }
        else {
            if(SelectedHexFile != "")  {
                //str = str + "MCU: " + SelectedHexFile + "\n"
                str = str + SelectedHexFile + "\n"
            }
            
            if(AnotherHexFile != "")  {
                #if Debug
                str = str + "DSP: " + AnotherHexFile + "\n"
                #else
                str = str + "VP_DSP: " + AnotherHexFile + "\n"
                #endif
            }
            
            #if Debug
            if(UIHexFile != "") {
                str = str + "UI: " + UIHexFile + "\n"
            }
            #endif
        }
        
        let alertController = UIAlertController(
            title: "OTA update files:",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                if(self.ISSC_Device) {
                    print("ISSC_OTA_DEVICE = True")
                    
                    if(self.m_OTASetting.title(for: UIControl.State.normal) == "Setting"){
                        self.OTA_ReadFile()
                    }
                    else {
                        print("Please wait..")
                    }
                }
        })
        
        let cancelAction = UIAlertAction(
            title: "Cancel",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                self.SelectedHexFile = ""
                self.AnotherHexFile = ""
                print("Reset OTA file")
                self.info.text = ""
                self.m_OTASetting.isEnabled = true
                self.info.text = ""
        })
        
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
        //*/
    }
    
    @IBAction func ScanButton(_ sender: Any) {
        
    }
    
    func OptionbuttonTapped(_ sender:UIBarButtonItem!) {
        print("AES key settings")
        
        //bleAdapter?.prepareForDisconnect()
        
        //let iv : String = "00000000000000000000000000000000"
        //let key : String = "22222222222222222222222222222222"
        
        let str : String = "Key_IV (16 bytes)"
        
        otadefault = UserDefaults.standard.integer(forKey: "SecuringOTA")
        
        if(otadefault == OTA_Encrypted.Enable.rawValue) {
            //str = "Enable"
        }
        else if(otadefault == OTA_Encrypted.Disable.rawValue) {
            //str = "Disable"
        }
        
        //let alertController = UIAlertController(title: "Securing OTA Update", message: str, preferredStyle: UIAlertControllerStyle.alert)
        let alertController = UIAlertController(title: "AES settings", message: "Key_IV", preferredStyle: UIAlertController.Style.alert)
        // Background color.
        let backView = alertController.view.subviews.last?.subviews.last
        backView?.layer.cornerRadius = 10.0
        backView?.backgroundColor = UIColor.yellow
        
        // Change Title With Color and Font:
        
        var messageMutableString = NSMutableAttributedString()
        messageMutableString = NSMutableAttributedString(string: str, attributes: [NSAttributedString.Key.font:UIFont(name: "Georgia", size: 20.0)!])
        
        //messageMutableString = NSMutableAttributedString(string: message as String, attributes: [NSFontAttributeName:UIFont(name: "Georgia", size: 18.0)!])
        //messageMutableString.addAttribute(NSForegroundColorAttributeName, value: UIColor.green, range: NSRange(location:0,length:message.characters.count))
        //messageMutableString.addAttribute(NSForegroundColorAttributeName, value: UIColor.green, range: NSRange(location:0,length:message.count))
        
        //messageMutableString.addAttribute(NSForegroundColorAttributeName, value: ((otadefault == 1) ? UIColor.green : UIColor.red), range: NSRange(location:0,length:str.count))
        //messageMutableString.addAttribute(NSForegroundColorAttributeName, value: ((otadefault == OTA_Encrypted.Enable.rawValue) ? UIColor.green : UIColor.red), range: NSRange(location:0,length:str.count))
        messageMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red, range: NSRange(location:0,length:str.count))
        alertController.setValue(messageMutableString, forKey: "attributedMessage")
        
        alertController.addTextField(configurationHandler: { (textField : UITextField!) -> Void in
            
            //textField.placeholder = "key = 22222222222222222222222222222222"
            textField.placeholder = "key = " + self.OTA_AES_Key
            
            self.OTA_Key_Field = textField
            self.OTA_Key_Field?.delegate = self
        })
        
        alertController.addTextField(configurationHandler: { (textField : UITextField!) -> Void in
            
            //textField.placeholder = "IV = 00000000000000000000000000000000"
            textField.placeholder = "IV = " + self.OTA_AES_IV
            
            self.OTA_IV_Field = textField
            self.OTA_IV_Field?.delegate = self
        })
        
        // Action.
        //let action1 = UIAlertAction(title: "Enable", style: UIAlertActionStyle.default, handler: nil)
        //let action2 = UIAlertAction(title: "Disable", style: UIAlertActionStyle.default, handler: nil)
        
        /*
        let action1 = UIAlertAction(
            title: "Enable",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                //if(self.otadefault != 1){
                if(self.otadefault != OTA_Encrypted.Enable.rawValue){
                    //self.otadefault = 1
                    self.otadefault = OTA_Encrypted.Enable.rawValue
                    //UserDefaults.standard.set(1, forKey: "SecuringOTA")
                    UserDefaults.standard.set(OTA_Encrypted.Enable.rawValue, forKey: "SecuringOTA")
                    print("SecuringOTA = Enable")
                }
            }
        )
        
        let action2 = UIAlertAction(
            title: "Disable",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                //if(self.otadefault != 2){
                if(self.otadefault != OTA_Encrypted.Disable.rawValue){
                    //self.otadefault = 2
                    self.otadefault = OTA_Encrypted.Disable.rawValue
                    //UserDefaults.standard.set(2, forKey: "SecuringOTA")
                    UserDefaults.standard.set(OTA_Encrypted.Disable.rawValue, forKey: "SecuringOTA")
                    print("SecuringOTA = Disable")
                }
            }
        )*/
        
        /*
        //if(otadefault == 1) {
        if(otadefault == OTA_Encrypted.Enable.rawValue) {
            alertController.addAction(action2)
        }
        else {
            alertController.addAction(action1)
        }*/
        
        let action3 = UIAlertAction(
            title: "Ok",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                print("Update AES parameters")
                //print(self.OTA_Key_Field?.text)
                //print(self.OTA_IV_Field?.text)
                
                var changed : Bool = false
                
                let disallowedCharacterSet = NSCharacterSet(charactersIn: "0123456789abcdefABCDEF").inverted
                
                if let key = self.OTA_Key_Field?.text{
                    print("key len  = \(key.count)")
                    if(key.count == 32){
                        if(key.rangeOfCharacter(from: disallowedCharacterSet) != nil){
                            print("Invalid data XXX")
                        }
                        else{
                            if(key != self.OTA_AES_Key){
                                self.OTA_AES_Key = key
                                print("AES key = " + self.OTA_AES_Key)
                                changed = true
                            }
                        }
                    }
                    else{
                        print("key length != 32")
                    }
                }
                else{
                    print("key is invalid")
                    
                }
                if let iv = self.OTA_IV_Field?.text{
                    print("iv len  = \(iv.count)")
                    if(iv.count == 32){
                        if(iv.rangeOfCharacter(from: disallowedCharacterSet) != nil){
                            print("Invalid data XXX")
                        }
                        else{
                            if(iv != self.OTA_AES_IV){
                                self.OTA_AES_IV = iv
                                print("AES iv = " + self.OTA_AES_IV)
                                changed = true
                            }
                        }
                    }
                    else{
                        print("iv length != 32")
                        
                    }
                }
                else{
                    print("iv is invalid")
                }
                
                //let testdata = OTASecurity.cbc(withOperation: true, ivString: self.OTA_AES_IV, andKey: self.OTA_AES_Key, andInput1: nil, andInput2: nil)
                if(changed){
                    DispatchQueue.main.asyncAfter(deadline: .now()+2, execute: {
                        print("Delay 2 seconds")
                        self.OTA_Encrypted_Information()
                    })
                }
            }
        )
        
        alertController.addAction(action3)
        
        let action4 = UIAlertAction(
            title: "Cancel",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                    DispatchQueue.main.asyncAfter(deadline: .now()+2, execute: {
                        print("Delay 2 seconds")
                        self.OTA_Encrypted_Information()
                    })
            })
        
        alertController.addAction(action4)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    @objc func ScanbuttonTapped(_ sender:UIBarButtonItem!) {
        let button:UIBarButtonItem = sender as UIBarButtonItem
        
        print("ScanButton:\(button.tag)")
        
        performSegue(withIdentifier: "ScanDevice", sender: button.tag)
    }
    
    @IBAction func TestButton(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let tag = sender
        print("Prepare Segue = \(tag as! Int)")
        let controller = segue.destination as! DeviceTableViewController
        controller.ScanOption = tag as! Int
    }
    
    func OTASelectImageFile(type : String , files : [String]) {
        
        var alertController = UIAlertController()
        
        if(otadefault == 1) {
            alertController = UIAlertController(
                title: (type + " Image"),
                //message: "Select an encrypted image",
                message: "Choose a file",
                preferredStyle: .alert)
        }
        else {
            alertController = UIAlertController(
                title: (type + " Image"),
                //message: "Select a image",
                message: "Choose a file",
                preferredStyle: .alert)
        }
            
        let cancelAction = UIAlertAction(
            title: "Cancel",
            style: .cancel,
            handler: {
                (action: UIAlertAction!) -> Void in
                if(self.m_OTASetting.title(for: UIControl.State.normal) != "Setting") {
                    self.m_OTASetting.setTitle("Setting", for: UIControl.State.normal)
                }
            }
        )
        
        alertController.addAction(cancelAction)
        
        for index in 0..<files.count {
            let action = UIAlertAction(title: files[index] , style: .default, handler:{
                (action: UIAlertAction!) -> Void in
                
                //print("file is \(files[index])")
                self.m_OTASetting.setTitle("Setting", for: UIControl.State.normal)
                
                if(type == "MCU") {
                    self.SelectedHexFile = files[index]
                    print("MCU_HexFile is \(files[index])")
                    
                    if(self.otadefault == OTA_Encrypted.Enable.rawValue) {
                        let result = OTA_File.CheckHexFormat(name: self.SelectedHexFile)
                        if(result) {
                            #if Debug
                                print("MCU_HexFile is \(self.SelectedHexFile)")
                            #else
                                let newfile = OTA_File.EncryptNewFile(name: self.SelectedHexFile)
                                self.SelectedHexFile = newfile
                                print("[OTA_Encryption] MCU_HexFile is \(self.SelectedHexFile)")
                            #endif
                        }
                        else{
                            print("[OTA_Encryption] MCU file is encrypted.")
                        }
                    }
                    
                    if(self.info.text == ""){
                        //self.info.text = self.SelectedHexFile
                        self.info.text = "OTA file: " + self.SelectedHexFile
                    }
                    else {
                        self.info.text = self.info.text! + "," + self.SelectedHexFile
                    }
                    
                    self.m_OTASetting.isEnabled = false
                }
                else if((type == "VP_DSP") || (type == "DSP")) {
                    self.AnotherHexFile = files[index]
                    //print("VP_DSP_HexFile is \(files[index])")
                    //if(self.otadefault == OTA_Encrypted.Enable.rawValue) {
                        let result = OTA_File.CheckHexFormat(name: self.AnotherHexFile)
                        if(result) {
                            #if Debug
                                print("DSP_HexFile is \(self.AnotherHexFile)")
                            #else
                                print("VP_DSP_HexFile is \(files[index])")
                                let newfile = OTA_File.EncryptNewFile(name: self.AnotherHexFile)
                                self.AnotherHexFile = newfile
                                print("[OTA_Encryption] VP_DSP_HexFile is \(self.AnotherHexFile)")
                            #endif
                        }
                        else {
                            print("[OTA_Encryption] VP_DSP file is encrypted.")
                            //OTA_File.Load_OTA_DSP(name: self.AnotherHexFile)    //Debug
                        }
                    //}
                    
                    if(self.info.text == ""){
                        //self.info.text = self.AnotherHexFile
                        self.info.text = "OTA file: " + self.AnotherHexFile
                    }
                    else {
                        self.info.text = self.info.text! + "," + self.AnotherHexFile
                    }
                    
                    self.m_OTASetting.isEnabled = false
                }
                else if(type == "UI_data") {
                    self.UIHexFile = files[index]
                    print("UI_HexFile is \(self.UIHexFile)")
                    
                    if(self.info.text == ""){
                        self.info.text = "OTA file: " + self.UIHexFile
                    }
                    else {
                        self.info.text = self.info.text! + "," + self.UIHexFile
                    }
                    
                    self.m_OTASetting.isEnabled = false
                }
            }
            )
            alertController.addAction(action)
        }
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    /*
    func OTAInputVendorData() {
        print("InputVendorData")
        
        let alertController = UIAlertController(title: "Vendor Data", message: "Enter data", preferredStyle: UIAlertControllerStyle.alert)
        
        alertController.addTextField(configurationHandler: {
            (textfiled:UITextField!) -> Void in textfiled.placeholder = "Flash Address"
        })
        
        alertController.addTextField(configurationHandler: {
            (textfiled:UITextField!) -> Void in textfiled.placeholder = "Flash data"
        })
        
        let okAction = UIAlertAction(
            title: "Ok",
            style: .default,
            handler: {
                alert -> Void in
                let address = alertController.textFields![0] as UITextField
                //print("Address = \(address.text)")
                let tmp = Int(address.text!)
                self.VendorDataAddress = UInt(tmp!)
                print("Address = \(self.VendorDataAddress)")
                let data = alertController.textFields![1] as UITextField
                print("data = \(data.text)")
        }
        )
        
        let cancelAction = UIAlertAction(
            title: "Cancel",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                if(self.m_OTASetting.title(for: UIControlState.normal) != "Setting") {
                    self.m_OTASetting.setTitle("Setting", for: UIControlState.normal)
                }
        }
        )
        
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }*/
    
    func OTAFileNotFound() {
        let alertController = UIAlertController(
            title: "OTA file is not found!",
            message: "",
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .default,
            handler: nil)
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func OTASelectImageType() {
        print("OTASelectImageType")
        
        if(m_OTASetting.title(for: UIControl.State.normal) == "MCU") {
            print("Imagetype = MCU")
            
            let mcufiles = OTASearchFile(str: "MCU")
            
            print("\(mcufiles)")
            
            if(mcufiles.count != 0) {
                OTASelectImageFile(type: "MCU" , files: mcufiles)
                print("SelectedHexFile = \(SelectedHexFile)")
            }
            else {
                self.m_OTASetting.setTitle("Setting", for: UIControl.State.normal)
                
                OTAFileNotFound()
            }
        }
        else if(m_OTASetting.title(for: UIControl.State.normal) == "DSP") {
            print("Imagetype = DSP")
            
            let files = OTASearchFile(str: "DSP")
            
            print("\(files)")
            
            if(files.count != 0) {
                OTASelectImageFile(type: "DSP" , files: files)
                print("AnotherHexFile = \(AnotherHexFile)")
            }
            else {
                self.m_OTASetting.setTitle("Setting", for: UIControl.State.normal)
                
                OTAFileNotFound()
            }
        }
        else if(m_OTASetting.title(for: UIControl.State.normal) == "VP_DSP") {
            print("Imagetype = VP_DSP")
            
            let files = OTASearchFile(str: "VP_DSP")
            
            print("\(files)")
            
            if(files.count != 0) {
                OTASelectImageFile(type: "VP_DSP" , files: files)
                print("AnotherHexFile = \(AnotherHexFile)")
            }
            else {
                self.m_OTASetting.setTitle("Setting", for: UIControl.State.normal)
                
                OTAFileNotFound()
            }
        }
        else if(m_OTASetting.title(for: UIControl.State.normal) == "UI_data") {
            print("Imagetype = UI_data")
            
            let files = OTASearchFile(str: "UI_data")
            
            print("\(files)")
            
            if(files.count != 0) {
                OTASelectImageFile(type: "UI_data" , files: files)
                print("UIHexFile = \(UIHexFile)")
            }
            else {
                self.m_OTASetting.setTitle("Setting", for: UIControl.State.normal)
                
                OTAFileNotFound()
            }
        }
        else if(m_OTASetting.title(for: UIControl.State.normal) == "Vendor Data") {
            //OTAInputVendorData()
        }
        else {
            let alertController = UIAlertController(
                title: "OTA Image",
                message: "Select image type",
                preferredStyle: .alert)
        
            let cancelAction = UIAlertAction(
                title: "Cancel",
                style: .cancel,
                handler: nil)
        
            alertController.addAction(cancelAction)
        
            for index in 0..<ImageTypeList.count {
                let action = UIAlertAction(title: ImageTypeList[index] , style: .default, handler:{
                    (action: UIAlertAction!) -> Void in
                    if(self.ImageTypeList[index] == "MCU") {
                        self.SelectedImageType = self.Image_Type_MCU
                        self.m_OTASetting.setTitle("MCU", for: UIControl.State.normal)
                        
                        sleep(1)
                        self.m_OTASetting.sendActions(for: UIControl.Event.touchUpInside)
                    }
                    else if(self.ImageTypeList[index] == "DSP") {
                        self.SelectedImageType = self.Image_Type_DSP
                        self.m_OTASetting.setTitle(self.ImageTypeList[index], for: UIControl.State.normal)
                        
                        sleep(1)
                        self.m_OTASetting.sendActions(for: UIControl.Event.touchUpInside)
                    }
                    else if(self.ImageTypeList[index] == "UI_data") {
                        self.SelectedImageType = self.Image_Type_UI
                        self.m_OTASetting.setTitle(self.ImageTypeList[index], for: UIControl.State.normal)
                        
                        sleep(1)
                        self.m_OTASetting.sendActions(for: UIControl.Event.touchUpInside)
                    }
                    else if(self.ImageTypeList[index] == "VP_DSP") {
                        self.SelectedImageType = self.Image_Type_VoicePrompt_DSP
                        self.m_OTASetting.setTitle("VP_DSP", for: UIControl.State.normal)
                        
                        sleep(1)
                        self.m_OTASetting.sendActions(for: UIControl.Event.touchUpInside)
                    }
                    else if(self.ImageTypeList[index] == "Vendor Data") {
                        self.SelectedImageType = self.Image_Type_Vendor_data
                        self.m_OTASetting.setTitle("Vendor Data", for: UIControl.State.normal)
                        
                        sleep(1)
                        self.m_OTASetting.sendActions(for: UIControl.Event.touchUpInside)
                    }
                    
                    
                    //print("\(self.SelectedImageType)")
                    print("Selected item is \(self.ImageTypeList[index]),\(self.SelectedImageType)")
                    
                }
                )
                alertController.addAction(action)
            }
        
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func OTASearchFile(str:String) ->[String] {
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
            let FileNames = fileURLs.map{ $0.deletingPathExtension().lastPathComponent }
            //let FileNames = fileURLs.map{ $0.lastPathComponent }
            //print("file list:", FileNames)
            
            let files = FileNames.filter{ $0.hasPrefix(str) == true}
            //print("\(files)")
            
            return files
            
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
            return []
        }
    }
    
    func OTASelectFile() {
        print("OTASelectFile")
        
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) as NSArray
        let documentsDir = paths.firstObject as! String
        print("Path to the Documents directory\n\(documentsDir)")
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            // process files
            
            print("fileURLs = \(fileURLs)")
            
            let hexFiles = fileURLs.filter{ $0.pathExtension == "HEX" }
            print("txtFiles = \(hexFiles)")
            
            let newhexFiles = hexFiles.filter{ $0.lastPathComponent != "DSPTuningResult.HEX" }
            print("newhexFiles = \(newhexFiles)")
            
            //if(txtFiles.count == 1) {
            //    let filepath:String = txtFiles[0].path
            //    print("filepath = \(filepath)")
            //}
            
            //let txtFileNames = hexFiles.map{ $0.deletingPathExtension().lastPathComponent}
            let txtFileNames = newhexFiles.map{ $0.deletingPathExtension().lastPathComponent}
            
            print("txt list:", txtFileNames)
            
            let alertController = UIAlertController(
                title: "OTA image files",
                message: "Choose a file to update",
                preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(
                title: "Cancel",
                style: .cancel,
                handler: nil)
            
            alertController.addAction(cancelAction)
            
            //for index in 0..<hexFiles.count {
            for index in 0..<txtFileNames.count {
                let action = UIAlertAction(title: txtFileNames[index] , style: .default, handler:{
                    (action: UIAlertAction!) -> Void in
                    self.SelectedHexFile = txtFileNames[index]
                    //self.SelectedHexFile += ".HEX"
                    //print("SelectedHexFile = \(self.SelectedHexFile)")
                    
                    //self.OTAFileTest()
                    
                    let result = OTA_File.CheckHexFormat(name: self.SelectedHexFile)
                    if(result){
                        print("Check HexFormat = true")
                        //self.SelectedHexFile += ".HEX"
                        print("SelectedHexFile = \(self.SelectedHexFile)")
                    
                        if(self.info.text == ""){
                            self.info.text = "OTA file: " + self.SelectedHexFile
                        }
                        else {
                            self.info.text = self.info.text! + "," + self.SelectedHexFile
                        }
                    
                        self.m_OTASetting.isEnabled = false
                    }
                }
                )
                alertController.addAction(action)
            }
        
            self.present(alertController, animated: true, completion: nil)
            
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
        }
    }
    
    func OTAFileTest() {
        print("OTAFileTest")
    }
    
    func GetTime() -> String {
        // get the current date and time
        let currentDateTime = Date()
        
        // initialize the date formatter and set the style
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        formatter.dateStyle = .none
        
        // get the date time String from the date object
        let CurrentTime = formatter.string(from: currentDateTime)
        print("\(CurrentTime)")
        
        return CurrentTime
    }
    
    // MARK: - BLEAdapterDelegate
    func BLEDataIn(_ dataIn: Data) {
        print("[BLEDataIn] : \(dataIn as NSData)")
    
        OTA_Event(dat: dataIn)
    }
    
    func OnConnected(_ connectionStatus: Bool) {
        if(connectionStatus) {
            isConnected = true
            print("Device is Connected..")
            
            //m_OTAStatus.text = "Connect"
            state_label.textColor = UIColor.black
            //state_label.attributedText = NSAttributedString(string: "OTA State : Connect", attributes:[NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
            state_label.attributedText = NSAttributedString(string: "OTA State : Connected", attributes:
                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
            
            //print("***** Get Version...")
            //OTA_GetInformation()
        }
        else {
            isConnected = false
            print("XXX Device is Disconnected")
            
           // m_OTAStatus.text = "Disconnect"
            state_label.textColor = UIColor.red
            //state_label.attributedText = NSAttributedString(string: "OTA State : Disconnect", attributes:[NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
            state_label.attributedText = NSAttributedString(string: "OTA State : Disconnected", attributes:
                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
            
            if(OTA_Time != ""){
                if((OTA_Time.range(of:"OTA_Start") == nil) && (OTA_Time.range(of:"OTA_Stop") == nil))
                {
                    if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                        print("_UIAlertController is presenting here!")
                        self.dismiss(animated: true, completion: nil)
                        sleep(1)
                    }
                }
            }
            else {
                if(ISSC_Device) {
                    if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                        print("*UIAlertController is presenting here!")
                        self.dismiss(animated: true, completion: nil)
                        sleep(1)
                    }
                }
            }
           
            let Runstate = OTARunning
            let state = OTA_State
            OTA_Setup()
            info.text = ""
            
            if(Runstate!) {
                OTA_AlertMessage(title: "OTA Update:Fail", Message: "Abnormally terminated," + String(state))
            }
        }
    }
    
    func UpdateMTU(_ mtu:Int) {
        UpdateMTU = UInt(mtu)
        
        print("Update MTU = \(UpdateMTU)")
        
    }
    
    func ISSC_Peripheral_Device(_ device_found: Bool) {
        let device = device_found
        if(device) {
            print("ISSC Device = true")
            ISSC_Device = true
        }
        else {
            ISSC_Device = false
            print("ISSC Device = false")
        }
    }
    
    func DSPTuningResponse(_ dataIn: Data) {
    }
    
    func DSPTuningResponse_Read(_ dataIn:Data) {
    }
    
    func DSPTuningCommandComplete(_ dataIn:Data) {
    }
    
    func DSPTuningLogs(_ state:Data) {
    }
    
    // MARK: - BM83 OTA DFU
    let AIR_PATCH_COMMAND_OPCODE_RESPONSE: UInt8 = 0x01
    let AIR_PATCH_COMMAND_OPCODE_START: UInt8 = 0x02
    let AIR_PATCH_COMMAND_OPCODE_INFO_REQ: UInt8 = 0x03
    let AIR_PATCH_COMMAND_OPCODE_INIT: UInt8 = 0x04
    let AIR_PATCH_COMMAND_OPCODE_UPDATE: UInt8 = 0x05
    let AIR_PATCH_COMMAND_OPCODE_VALIDATE: UInt8 = 0x06
    let AIR_PATCH_COMMAND_OPCODE_END: UInt8 = 0x07
    let AIR_PATCH_COMMAND_OPCODE_RESET: UInt8 = 0x08
    
    let AIR_PATCH_COMMAND_RESULT_SUCCESS: UInt8 = 0x01
    let AIR_PATCH_COMMAND_RESULT_INVALID_STATE: UInt8 = 0x02
    let AIR_PATCH_COMMAND_RESULT_NOT_SUPPORTED: UInt8 = 0x03
    let AIR_PATCH_COMMAND_RESULT_FAILED: UInt8 = 0x04
    
    let OTA_EVENT_ERROR: UInt8 = 0x00
    
    func OTA_SendCommand() {
        bleAdapter?.BLEDataOut_WriteResponse(OTACommad! as Data)
        
        print("OTA_SendCommand")
        
        OTA_SendData()
    }
    
    func OTA_SendData() {
        var command:UInt8 = 0
        
        switch(OTA_State) {
            case AIR_PATCH_COMMAND_OPCODE_START:
                OTACommad = NSMutableData()
                //8051 MCU
                command = UInt8((imageSize&0xff000000) >> 24)
                OTACommad?.append(&command, length: 1)
                command = UInt8((imageSize&0xff0000) >> 16)
                OTACommad?.append(&command, length: 1)
                command = UInt8((imageSize&0x0000ff00) >> 8)
                OTACommad?.append(&command, length: 1)
                command = UInt8(imageSize & 0x00ff)
                OTACommad?.append(&command, length: 1)
                //VP&DSP
                command = UInt8((anotherSize&0xff000000) >> 24)
                OTACommad?.append(&command, length: 1)
                command = UInt8((anotherSize&0xff0000) >> 16)
                OTACommad?.append(&command, length: 1)
                command = UInt8((anotherSize&0x0000ff00) >> 8)
                OTACommad?.append(&command, length: 1)
                command = UInt8(anotherSize & 0x00ff)
                OTACommad?.append(&command, length: 1)
                
                ///*
                //UI Config
                var len : UInt = 0
                if(ui_checksum != 0){
                    len = UInt(uidata!.length)
                }
                command = UInt8((len&0xff000000) >> 24)
                OTACommad?.append(&command, length: 1)
                command = UInt8((len&0xff0000) >> 16)
                OTACommad?.append(&command, length: 1)
                command = UInt8((len&0x0000ff00) >> 8)
                OTACommad?.append(&command, length: 1)
                command = UInt8(len & 0x00ff)
                OTACommad?.append(&command, length: 1)
                //*/
                
                command = 0 //TBD
                OTACommad?.append(&command, length: 1)
                
                print("OTA command = \(OTACommad!)")
                print("Image Size & Version Info")
                break;
            case AIR_PATCH_COMMAND_OPCODE_INIT:
                //Image Info
                OTACommad = NSMutableData()
                command = UInt8((imageCRC&0xff00) >> 8)
                OTACommad?.append(&command, length: 1)
                command = UInt8(imageCRC & 0x00ff)
                OTACommad?.append(&command, length: 1)
                print("OTA command = \(OTACommad!)")
                print("Image Info,CRC = \(imageCRC)")
                if(hexStage == HEX_STAGE.INIT_VP_DSP) {
                    //let (header_data , _) = OTA_File.LoadOTAHexHeader(name: AnotherHexFile)
                    var len : UInt16 = 0
                    //Length of DSP flash header
                    len = UInt16(bankInfo!.length)
                    command = UInt8((len&0xff00) >> 8)
                    OTACommad?.append(&command, length: 1)
                    command = UInt8(len & 0x00ff)
                    OTACommad?.append(&command, length: 1)
                    //Information block of DSP write to Flash header
                    OTACommad?.append(bankInfo!.bytes, length: Int(len))
                    print("Length,Flash header")
                }
                break;
            case AIR_PATCH_COMMAND_OPCODE_UPDATE:
                //Fragement of image
                OTA_WriteImage()
                break;
            default:
                break;
        }
        
        if((OTA_State == AIR_PATCH_COMMAND_OPCODE_START)) {
            print("OTA_SendData: Image Size")
            
            bleAdapter?.BLEDataOut_WriteNoResponse(OTACommad! as Data)
        }
        else if((OTA_State == AIR_PATCH_COMMAND_OPCODE_INIT)) {
            print("OTA_SendData: Image Info")
            
            if(OTACommad!.length >= UpdateMTU) {
                UpdateOffset = 0
                
                print("OTACommand length > MTU")
                
                //uidata = OTACommad
                Command_data = OTACommad
                
                print("*******************************")
                print("Commmand_data = \(Command_data!)")
                
                OTA_WriteCommand()
            }
            else {
                bleAdapter?.BLEDataOut_WriteNoResponse(OTACommad! as Data)
            }
        }
    }
    
    func OTA_Image_CRC(type:String) {
        
        if(type == "MCU") {
            var buffer = [UInt8](repeating: 0, count: Int(imageSize))
            hexdata!.getBytes(&buffer, length: Int(imageSize))
            
            for index in 0..<imageSize {
                OTA_CRC.crc_calc_update(value:buffer[Int(index)] )
            }
        }
        else{
            var buffer = [UInt8](repeating: 0, count: Int(anotherSize))
            dspdata!.getBytes(&buffer, length: Int(anotherSize))
            
            for index in 0..<anotherSize {
                OTA_CRC.crc_calc_update(value:buffer[Int(index)] )
            }
        }
        
        imageCRC = OTA_CRC.crc_calc_finished()
        
        print("OTA_Image_CRC = \(imageCRC)")
        
    }
    
    func OTA_Setup() {
        print("OTASetup")
        
        OTARunning = false
        OTACommad = nil
        OTAProgress.progress = 0
        OTA_State = 0x00
        //OTARunning = false
        UpdateFWType = 0x00
        hexStage = HEX_STAGE.IDLE
        //OTA_Time = ""
        
        self.m_OTASetting.isEnabled = true
        //Updated_MCU_Version = nil
        //Updated_DSP_Version = nil
        
        if(isConnected) {
            //m_OTAStatus.text = "Connect"
            state_label.textColor = UIColor.black
            //state_label.attributedText = NSAttributedString(string: "OTA State : Connect", attributes:[NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
            state_label.attributedText = NSAttributedString(string: "OTA State : Connected", attributes:
                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
        }
        else {
            //m_OTAStatus.text = "Disconnect"
            state_label.textColor = UIColor.red
            //state_label.attributedText = NSAttributedString(string: "OTA State : Disconnect", attributes:[NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
            state_label.attributedText = NSAttributedString(string: "OTA State : Disconnected", attributes:
                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
        }
        
        if(Updated_MCU_Version != nil)  {
            mcu_label.attributedText = NSAttributedString(string: "MCU Version :" + Updated_MCU_Version!, attributes:
                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
            
            Updated_MCU_Version = nil
        }
        
        if(Updated_DSP_Version != nil)  {
            dsp_label.attributedText = NSAttributedString(string: "DSP&VP Version : " + Updated_DSP_Version!, attributes:
                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
            
            Updated_DSP_Version = nil
        }
    }
    
    func OTA_ReadFile() {
        
        if(!OTARunning ) {
            OTARunning = true
        }
        else {
            return;
        }
        
        let ota_queue = DispatchQueue(label: "com.microchip.otadfu.enc")
        
        //print("AnotherHexFile = \(self.AnotherHexFile)")
            
        OTA_AlertWaiting(str:"Initialization")
        print("Initialization...")
            
        ota_queue.async {
            if(self.AnotherHexFile != ""){
                print("AnotherHexFile = \(self.AnotherHexFile)")
                
                //(self.bankInfo , self.dspdata , self.Updated_DSP_Version) = OTA_File.Load_OTA_DSP(name: self.AnotherHexFile)
                (self.bankInfo , self.dspdata , self.Updated_DSP_Version , self.imageCRC) = OTA_File.Load_OTA_DSP(name: self.AnotherHexFile)
                
                print("Parsing DSP Hex....Done")
                
                print("\(self.dspdata!)")
            }
                
            if(self.SelectedHexFile != ""){
                print("SelectedHexFile = \(self.SelectedHexFile)")
                
                //(self.hexdata , self.Updated_MCU_Version) = OTA_File.Load_OTA_MCU(name: self.SelectedHexFile)
                
                //(self.hexdata, self.Updated_MCU_Version, self.imageCRC, dsp_checksum, ui_checksum) = OTA_File.Load_OTA_MCU(name: self.SelectedHexFile)
                (self.hexdata, self.Updated_MCU_Version, self.mcu_checksum, self.dsp_checksum, self.ui_checksum) = OTA_File.Load_OTA_MCU(name: self.SelectedHexFile)
                
                self.imageCRC = self.mcu_checksum
                
                print("Parsing MCU Hex....Done")
                
                if((self.dsp_checksum == 0) && (self.ui_checksum == 0)){
                    print("OTA image = MCU")
                }
                else{
                    print("OTA image = Full image")
                    
                    if(self.ui_checksum != 0){
                        (self.uidata, self.ui_checksum) = OTA_File.Load_OTA_UI(name: self.SelectedHexFile)
                        
                        print("Parsing UI Hex....Done")
                        print("UI data len = \(self.uidata?.length)")
                    }
                    
                    if(self.dsp_checksum != 0){
                        (self.bankInfo , self.dspdata , self.Updated_DSP_Version , self.dsp_checksum) = OTA_File.Load_OTA_DSP(name: self.SelectedHexFile)
                        
                        print("Parsing DSP Hex....Done")
                        
                        if(self.Updated_DSP_Version == nil) {
                            DispatchQueue.main.async {
                                self.dismiss(animated: true, completion: nil)
                                self.m_OTASetting.isEnabled = true
                                self.OTA_AlertMessage(title: "DSP data error", Message: "Can't read OTA file")
                            }
                            return
                        }
                        
                        print("DSP data len = \(self.dspdata?.length)")
                        
                    }
                }
            }
            
            if(self.UIHexFile != ""){
                print("UIHexFile = \(self.UIHexFile)")
                
                //OTA_File.Load_OTA_DSP(name: self.UIHexFile)
                OTA_File.Load_OTA_UI(name: self.UIHexFile)
                
                print("Parsing UI Hex....Done")
            }
                
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
                
                self.OTA_START()
            }
        }
    }
    
    func OTA_START() {
        
        if(!(isConnected)) {
            return;
        }
        
        if(AnotherHexFile != "")
        {
            print("AnotherHexFile = \(self.AnotherHexFile)")
            
            if((bankInfo == nil) || (dspdata == nil) || (Updated_DSP_Version == nil)) {
                self.m_OTASetting.isEnabled = true
                self.AnotherHexFile = ""
                OTA_AlertMessage(title: "DSP Hex", Message: "Can't read OTA file")
                return
            }
        }
        
        if(SelectedHexFile != "") {
            print("SelectedHexFile = \(self.SelectedHexFile)")
            //print("\(hexdata)")
            //print("\(Updated_MCU_Version)")
            
            if((hexdata == nil) || (Updated_MCU_Version == nil)) {
                self.m_OTASetting.isEnabled = true
                OTA_AlertMessage(title: "MCU Hex", Message: "Can't read OTA file")
                return
            }
        }
        
        //var message:String = "Current version : \n" + "Update version : \n"
        var message : String = ""
        if(SelectedHexFile != ""){
            if((dsp_checksum == 0) && (ui_checksum == 0)){
                message += "Current version : " + MCU_Version + "\n\n"
                message += "Update version : " + Updated_MCU_Version! + "\n"
            }
            else{
                message += "[MCU]Current version : " + MCU_Version + "\n\n"
                message += "[MCU]Update version : " + Updated_MCU_Version! + "\n\n"
            
                message += "[DSP]Current version : " + DSP_Version + "\n\n"
                message += "[DSP]Update version : " + Updated_DSP_Version! + "\n"
            }
        }
        else if(AnotherHexFile != ""){
            message += "Current version : " + DSP_Version + "\n\n"
            message += "Update version : " + Updated_DSP_Version! + "\n"
        }
        
        let alertController = UIAlertController(
            //title: "Current version : ",
            title: nil,
            message: message,
            preferredStyle: .alert)
        
        let backView = alertController.view.subviews.last?.subviews.last
        backView?.layer.cornerRadius = 10.0
        backView?.backgroundColor = UIColor.yellow
        
        var messageMutableString = NSMutableAttributedString()
        messageMutableString = NSMutableAttributedString(string: message, attributes: [NSAttributedString.Key.font:UIFont(name: "Georgia", size: 20.0)!])
        messageMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: (UIColor.red), range: NSRange(location:0,length:message.count))
        alertController.setValue(messageMutableString, forKey: "attributedMessage")
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                if(self.AnotherHexFile != ""){
                    #if Debug
                    print("Load DSP hexfile = \(self.AnotherHexFile)")
                    #else
                    print("Load VP_DSP hexfile = \(self.AnotherHexFile)")
                    #endif
                    print("Header length = \(self.bankInfo!.length)")
                    print("data length = \(self.dspdata!.length)")
                    print("Update version = " + self.Updated_DSP_Version!)
                
                    self.anotherSize = UInt(self.dspdata!.length)
                    print("imageSize = \(self.anotherSize)")
                    print("checksum = \(self.imageCRC)")
                
                    //self.OTA_Image_CRC(type:"VP_DSP")
                
                    self.hexStage = HEX_STAGE.INIT_VP_DSP
                    self.UpdateFWType = self.Image_Type_VoicePrompt_DSP
                
                    #if Debug
                        self.EncryptionData = NSMutableData(data: self.dspdata! as Data)
                    #else
                        self.OTA_Encryption(size: Int(self.anotherSize), hexdata: self.dspdata! )
                    #endif
                }
                if(self.SelectedHexFile != ""){
                    print("Load MCU hexfile = \(self.SelectedHexFile)")
                    print("Update version = " + self.Updated_MCU_Version!)
                    
                    self.imageSize = UInt(self.hexdata!.length)
                    print("imageSize = \(self.imageSize)")
                    print("checksum = \(self.imageCRC)")
                    
                    if(self.dsp_checksum != 0){
                        self.anotherSize = UInt(self.dspdata!.length)
                    }
                    
                    //self.OTA_Image_CRC(type:"MCU")
                    
                    self.hexStage = HEX_STAGE.INIT_MCU
                    self.UpdateFWType = self.Image_Type_MCU
                    
                    #if Debug
                        self.EncryptionData = NSMutableData(data: self.hexdata! as Data)
                    #else
                        self.OTA_Encryption(size: Int(self.imageSize), hexdata: self.hexdata! )
                    #endif
                    
                    print("EncryptionData = \(self.EncryptionData.subdata(with: NSMakeRange(0, 16)) as NSData)")
                }
                
                self.OTA_StartOTA()
        })
        
        let cancelAction = UIAlertAction(
            title: "Cancel",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                print("Cancel")
                if(self.AnotherHexFile != ""){
                    self.AnotherHexFile = ""
                    self.Updated_DSP_Version = nil
                }
                if(self.SelectedHexFile != ""){
                    self.SelectedHexFile = ""
                    self.Updated_MCU_Version = nil
                }
                self.m_OTASetting.isEnabled = true
                self.info.text = ""
                self.OTARunning = false
        })
        
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    func OTA_StartOTA() {
        if(!(isConnected)) {
            return;
        }
        
        bleAdapter?.GetMTUSize()
        
        print("Get MTU Size")
        
        OTA_State = AIR_PATCH_COMMAND_OPCODE_START
        var command = AIR_PATCH_COMMAND_OPCODE_START
        
        if(OTACommad == nil) {
            OTACommad = NSMutableData()
        }
        
        OTACommad?.append(&command, length: 1)
        
        print("OTA command = \(OTACommad!)")
        print("OTA_START : " + GetTime())
        
        OTA_Time = ""
        OTA_Time = OTA_Time + "OTA_Start : " + GetTime()
        
        OTA_SendCommand()
    }
    
    @objc func OTA_GetVersionAfterConnection() {
        
        //Debug
        //print("Connect Service")
        //var command = 0x02  //Connect Service
        //OTACommad = NSMutableData()
        //OTACommad?.append(&command, length: 1)
        //bleAdapter?.SendTestCommmand(OTACommad! as Data)
        
        print("OTA_GetVersionAfterConnection")
        
        bleAdapter?.GetISSCDevice()
        
        ///*
        if(ISSC_Device) {
            
            print("***** Get Version...")
            
            OTA_GetInformation()
            
            OTACommad = nil
            
            let canSendData = bleAdapter?.canSendData
            print("canSendData = \(canSendData!)")
        }//*/
    }
    
    func OTA_GetInformation() {
        OTA_State = AIR_PATCH_COMMAND_OPCODE_INFO_REQ
        var command = AIR_PATCH_COMMAND_OPCODE_INFO_REQ
        
        OTACommad = NSMutableData()
        
        OTACommad?.append(&command, length: 1)
        
        print("OTA command = \(OTACommad!)")
        print("OTA_GetInformation")
        
        OTA_SendCommand()
    }
    
    func OTA_Initialization() {
        OTA_State = AIR_PATCH_COMMAND_OPCODE_INIT
        var command = AIR_PATCH_COMMAND_OPCODE_INIT
        
        OTACommad = NSMutableData()
        OTACommad?.append(&command, length: 1)
        
        if(hexStage == HEX_STAGE.INIT_MCU) {
            command = Image_Type_MCU
        }
        else if(hexStage == HEX_STAGE.INIT_VP_DSP) {
            command = Image_Type_DSP
            //command = Image_Type_VoicePrompt_DSP
        }
        else if(hexStage == HEX_STAGE.INIT_UI){
            command = Image_Type_UI
        }
        else {
            print("xxxOTA_Initialization")
            return
        }
        
        OTACommad?.append(&command, length: 1)
        
        print("OTA command = \(OTACommad!)")
        print("OTA_Initialization")
        
        OTA_SendCommand()
    }
    
    func OTA_Update() {
        var totalSize : UInt = 0
        
        if(UpdateFWType == Image_Type_MCU) {
            totalSize = imageSize
        }
        else if(UpdateFWType == Image_Type_DSP){
            totalSize = anotherSize
        }
        else if(UpdateFWType == Image_Type_UI){
            totalSize = UInt(uidata!.length)
        }
        
        //if(UpdateOffset != imageSize){
        if(UpdateOffset != totalSize){
            OTA_State = AIR_PATCH_COMMAND_OPCODE_UPDATE
            var command = AIR_PATCH_COMMAND_OPCODE_UPDATE
        
            OTACommad = NSMutableData()
            OTACommad?.append(&command, length: 1)
        
            print("OTA command = \(OTACommad!)")
            print("OTA_Update")
        
            hexStage = HEX_STAGE.WRITE_PAYLOAD
            //UpdateOffset = 0
        
            OTA_SendCommand()
        }
    }
    
    func OTA_Validate() {
        OTA_State = AIR_PATCH_COMMAND_OPCODE_VALIDATE
        var command = AIR_PATCH_COMMAND_OPCODE_VALIDATE
        
        OTACommad = NSMutableData()
        OTACommad?.append(&command, length: 1)
        
        print("OTA command = \(OTACommad!)")
        print("OTA_Validate")
        
        OTA_SendCommand()
        
        if(self.UpdateFWType == self.Image_Type_UI){
            return
        }
        
        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
            print("Dismiss the Alert view")
            self.dismiss(animated: true, completion: nil)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                self.OTA_AlertWaiting(str:"Validation")
            }
        }
        else{
            OTA_AlertWaiting(str:"Validation")
        }
    }
    
    func OTA_End() {
        OTA_State = AIR_PATCH_COMMAND_OPCODE_END
        var command = AIR_PATCH_COMMAND_OPCODE_END
        
        OTACommad = NSMutableData()
        OTACommad?.append(&command, length: 1)
        
        print("OTA command = \(OTACommad!)")
        print("OTA_End")
        
        OTA_SendCommand()
    }
    
    func OTA_Reset() {
        OTA_State = AIR_PATCH_COMMAND_OPCODE_RESET
        var command = AIR_PATCH_COMMAND_OPCODE_RESET
        
        OTACommad = NSMutableData()
        OTACommad?.append(&command, length: 1)
        
        print("OTA command = \(OTACommad!)")
        print("OTA_Reset : " + GetTime())
        
        OTA_SendCommand()
        
        if(SelectedHexFile != ""){
            SelectedHexFile = ""
        }
        
        if(AnotherHexFile != ""){
            AnotherHexFile = ""
        }
        
        OTA_Setup()
        info.text = ""
        
        OTA_Time = OTA_Time + "\nOTA_Stop : " + GetTime()
        
        /*
        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
            self.dismiss(animated: true, completion: nil)
            print("****UIAlertController is presenting here!")
            
            sleep(1)
            
            OTA_AlertMessage(title: "OTA Update: PASS", Message: OTA_Time)
        }
        else{
            OTA_AlertMessage(title: "OTA Update: PASS", Message: OTA_Time)
        }*/
        
        OTA_AlertMessage(title: "OTA Update: PASS", Message: OTA_Time)
    }
    
    func OTA_ReConnect() {
        let alertController = UIAlertController(
            title: "BLE disconnect",
            message: "Reconnect",
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .default,
            handler: {
                (action: UIAlertAction!) -> Void in
                print("Reconnect a new device")
                self.navigationController?.popViewController(animated: true)
            })
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion:nil)
    }
    
    func OTA_Encrypted_Information() {
        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
            return
        }
        
        print("OTA_Encrypted_Information")
        print("key = " + OTA_AES_Key)
        print("iv = " + OTA_AES_IV)
        
        var str : String = ""
        let alertController = UIAlertController(title: "Encryption", message: "Key_IV", preferredStyle: UIAlertController.Style.alert)
        // Background color.
        let backView = alertController.view.subviews.last?.subviews.last
        backView?.layer.cornerRadius = 10.0
        backView?.backgroundColor = UIColor.yellow
        
        // Change Title With Color and Font:
        
        str = "key = " + OTA_AES_Key + "\n" + "iv = " + OTA_AES_IV
        
        var messageMutableString = NSMutableAttributedString()
        messageMutableString = NSMutableAttributedString(string: str, attributes: [NSAttributedString.Key.font:UIFont(name: "Georgia", size: 10.0)!])
        
        messageMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red, range: NSRange(location:0,length:str.count))
        alertController.setValue(messageMutableString, forKey: "attributedMessage")
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .default,
            handler: nil)
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func OTA_AlertWaiting(str:String) {
        var title:String = ""
        
        if(str == "") {
            title = "Please wait...\n\n\n"
        }
        else {
            title = str + " ,Please wait...\n\n\n"
        }
        
        let alertController = UIAlertController(
            title: nil,
            message: title,
            preferredStyle: .alert)
        
        let activityIndicator : UIActivityIndicatorView = UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.whiteLarge)
        
        activityIndicator.color = UIColor.black
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        alertController.view.addSubview(activityIndicator)
        
        let centerHorizontally = NSLayoutConstraint(item: activityIndicator,
                                                    attribute: .centerX,
                                                    relatedBy: .equal,
                                                    toItem: activityIndicator.superview,
                                                    attribute: .centerX,
                                                    multiplier: 1.0,
                                                    constant: 0.0)
        
        let centerVertically = NSLayoutConstraint(item: activityIndicator,
                                                  attribute: .centerY,
                                                  relatedBy: .equal,
                                                  toItem: activityIndicator.superview,
                                                  attribute: .centerY,
                                                  multiplier: 1.0,
                                                  constant: 0.0)
        
        NSLayoutConstraint.activate([centerHorizontally, centerVertically])
        
        activityIndicator.startAnimating()
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func OTA_AlertMessage(title:String , Message:String) {
        let alertController = UIAlertController(
            title: title,
            message: Message,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .default,
            handler: nil)
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func OTA_WriteCommand() {
        var totalSize : UInt = 0
        
        //totalSize = UInt(uidata!.length)
        totalSize = UInt(Command_data!.length)
        print("totalSize = \(totalSize)")
        
        while(UpdateOffset < totalSize) {
            var len : UInt = 0
            var tr_len : UInt = 0
            
            print("UpdateOffset = \(UpdateOffset)")
            
            let segment_len = (totalSize - UpdateOffset) > UInt(OTABufferSize) ? UInt(OTABufferSize) : (totalSize - UpdateOffset)
            
            print("segment_len = \(segment_len)")
            
            while(len < segment_len){
                
                if(segment_len == UInt(OTABufferSize)) {
                    tr_len = (UInt(OTABufferSize) - len) > UpdateMTU ? UpdateMTU : (UInt(OTABufferSize) - len)
                }
                else {
                    tr_len = (totalSize - (UpdateOffset+len)) > UpdateMTU ? UpdateMTU : (totalSize - (UpdateOffset+len))
                }
                
                print("tr_len = \(tr_len)")
                
                //let dat = uidata!.subdata(with: NSMakeRange(Int(len)+Int(UpdateOffset), Int(tr_len)))
                let dat = Command_data!.subdata(with: NSMakeRange(Int(len)+Int(UpdateOffset), Int(tr_len)))
                
                bleAdapter?.BLEDataOut_WriteNoResponse(dat)
                
                len += tr_len
            }
            
            print("Segment data transfer complete")
            
            UpdateOffset += segment_len
            
            sleep(1)
        }
        
        print("OTA_WriteCommand")
    }
    
    func OTA_WriteTestData() {
        if((hexStage == HEX_STAGE.WRITE_PAYLOAD)) {
            var len : UInt = 0
            var tr_len : UInt = 0
            
            let segment_len = OTABufferSize
            
            print("segment_len = \(segment_len)")
            
            while(len < segment_len){
                
                if(segment_len == UInt(OTABufferSize)) {
                    tr_len = (UInt(OTABufferSize) - len) > UpdateMTU ? UpdateMTU : (UInt(OTABufferSize) - len)
                }
                
                print("tr_len = \(tr_len)")
                
                let dat = EncryptionData.subdata(with: NSMakeRange(Int(len), Int(tr_len)))
                bleAdapter?.BLEDataOut_WriteNoResponse(dat)
                
                len += tr_len
            }
            
            hexStage = HEX_STAGE.WRITE_SEGMENT_CHECK
            
            print("OTA_WriteTestData: \(segment_len)")
        }
    }
    
    func OTA_WriteImage() {
        let canSendData = bleAdapter?.canSendData
        if(canSendData == false){
            if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                self.dismiss(animated: true, completion: nil)
                print("****UIAlertController is presenting here!")
            }
            
            print("OTA Fail! Peripheral not ready")
            
            OTA_Setup()
            
            OTA_AlertMessage(title: "OTA Update", Message: "Fail")
            
            return
        }
        
        var totalSize : UInt = 0
        
        if(UpdateFWType == Image_Type_MCU) {
            totalSize = imageSize
        }
        else if(UpdateFWType == Image_Type_DSP){
            totalSize = anotherSize
        }
        else if(UpdateFWType == Image_Type_UI){
            totalSize = UInt(uidata!.length)
        }
        
        if((hexStage == HEX_STAGE.WRITE_PAYLOAD) && (UpdateOffset < totalSize)) {
            var len : UInt = 0
            var tr_len : UInt = 0
            
            print("UpdateOffset = \(UpdateOffset)")
            //let segment_len = (imageSize - UpdateOffset) > 2048 ? 2048 : (imageSize - UpdateOffset)
            
            let segment_len = (totalSize - UpdateOffset) > UInt(OTABufferSize) ? UInt(OTABufferSize) : (totalSize - UpdateOffset)
            
            print("segment_len = \(segment_len)")
            
            while(len < segment_len){
                
                //tr_len = (2048 - len) > UpdateMTU ? UpdateMTU : (2048 - len)
                if(segment_len == UInt(OTABufferSize)) {
                    tr_len = (UInt(OTABufferSize) - len) > UpdateMTU ? UpdateMTU : (UInt(OTABufferSize) - len)
                }
                else {
                    tr_len = (totalSize - (UpdateOffset+len)) > UpdateMTU ? UpdateMTU : (totalSize - (UpdateOffset+len))
                }
                
                print("tr_len = \(tr_len)")
                
                //let dat = hexdata!.subdata(with: NSMakeRange(Int(len)+Int(UpdateOffset), Int(tr_len)))
                let dat = EncryptionData.subdata(with: NSMakeRange(Int(len)+Int(UpdateOffset), Int(tr_len)))
                bleAdapter?.BLEDataOut_WriteNoResponse(dat)
                
                len += tr_len
                
                OTAProgress.progress = Float(UpdateOffset) / Float(totalSize)
            }
            
            UpdateOffset += segment_len
            
            hexStage = HEX_STAGE.WRITE_SEGMENT_CHECK
            
            print("OTA_WriteImage: \(segment_len)")
            
            var str:String! = "OTA State : Update..."
            
            if(UpdateFWType == Image_Type_MCU) {
                str = "OTA State : MCU Update..."
            }
            else if(UpdateFWType == Image_Type_DSP){
                str = "OTA State : DSP Update..."
            }
            else{
                str = "OTA State : UI Update..."
            }
            
            var ota_percentage : Int = 0
            ota_percentage = Int((Float(UpdateOffset) / Float(totalSize)) * 100)
            //state_label.attributedText = NSAttributedString(string: ("OTA State : Update..." + String(ota_percentage) + "%"), attributes:[NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
            state_label.attributedText = NSAttributedString(string: (str + String(ota_percentage) + "%"), attributes:[NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
            
            print("Update ota percentage " + String(ota_percentage) + "%")
            
        }
    }
    
    func OTA_Encryption(size:Int , hexdata:NSData) {
        EncryptionData = NSMutableData()
        
        if(otadefault == 1) {
            print("OTA_Image_Encryption: True")
        
            //let iv : String = "00000000000000000000000000000000"
            
            //let key : String = "22222222222222222222222222222222"
            print("key = " + OTA_AES_Key)
            print("iv = " + OTA_AES_IV)
            
            //let testdata = OTASecurity.cbc(withOperation: true, ivString: iv, andKey: key, andInput1: nil, andInput2: hexdata as Data)
            let testdata = OTASecurity.cbc(withOperation: true, ivString: OTA_AES_IV, andKey: OTA_AES_Key, andInput1: nil, andInput2: hexdata as Data)
            EncryptionData = NSMutableData(data:testdata!)
            
            //print("EncryptionData = \(EncryptionData)")
            print("Length of EncryptionData = \(EncryptionData.length)")
            print("End of OTA_Encryption...................")
        }
        else {
            print("OTA_Image_Encryption: False")
            EncryptionData = NSMutableData(data: hexdata as Data)
        }
    }
    
    func OTA_Event(dat:Data) {
        let bytes : NSData = dat as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var CheckError = true
        
        if(bytes.length < 3) {
            if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                print("**UIAlertController is presenting here!")
                self.dismiss(animated: true, completion: nil)
            }
            print("OTA_Event:invalid command and data")
            OTA_Setup()
            //OTA_AlertMessage(result: false)
            OTA_AlertMessage(title: "OTA Update", Message: "Fail")
            return;
        }
        
        switch(OTA_State) {
            case AIR_PATCH_COMMAND_OPCODE_START:
                if((buf[0] == AIR_PATCH_COMMAND_OPCODE_RESPONSE) && (buf[1] == AIR_PATCH_COMMAND_OPCODE_START)) {
                    if(buf[2] == AIR_PATCH_COMMAND_RESULT_SUCCESS) {
                        CheckError = false
                        
                        print("Operation success..")
                        
                        OTA_GetInformation()
                    }
                }
                break;
            case AIR_PATCH_COMMAND_OPCODE_INFO_REQ:
                if((buf[0] == AIR_PATCH_COMMAND_OPCODE_RESPONSE) && (buf[1] == AIR_PATCH_COMMAND_OPCODE_INFO_REQ)) {
                    if(buf[2] == AIR_PATCH_COMMAND_RESULT_SUCCESS) {
                        //Read firmware Version and OTA buffer size
                        CheckError = false
                        
                        print("FW information = \(bytes.subdata(with: NSMakeRange(2, bytes.length-3)))")
                        //let subdata = Data(bytes : buf , count : bytes.length)
                        
                        var tmpArray = [UInt8]()
                        tmpArray.append(buf[4])
                        tmpArray.append(buf[3])
                        let dd = NSData(bytes:tmpArray,length:2)
                        dd.getBytes(&OTABufferSize, length: 2)
                        print("OTABufferSize = \(OTABufferSize)")

                        if(bytes.length >= 13) {
                            //Main version(1) + sub version(1) + control version(2) = 4 bytes
                            
                            let mcuver = bytes.subdata(with: NSMakeRange(5, 4))
                            //let mcuver = bytes.subdata(with: NSMakeRange(5, 2))
                            let controlVersion = bytes.subdata(with: NSMakeRange(7, 2))
                            MCU_Version = mcuver.hexEncodedString()
                            print("MCU Version = " + MCU_Version)
                            print("Control Version = " + controlVersion.hexEncodedString())
                            //m_MCUVersion.text = MCU_Version
                            mcu_label.attributedText = NSAttributedString(string: "MCU Version : " + MCU_Version, attributes:
                                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
                        
                            let dspver = bytes.subdata(with: NSMakeRange(9, 4))
                            DSP_Version = dspver.hexEncodedString()
                            print("DSP Version = " + DSP_Version)
                            //m_DSPVersion.text = DSP_Version
                            dsp_label.attributedText = NSAttributedString(string: "DSP&VP Version : " + DSP_Version, attributes:
                                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
                        }
                        
                        //Compare current version and updated version
                        
                        if(OTARunning){
                            OTA_Initialization()
                        }
                        else {
                            OTA_State = 0;
                        }
                    }
                }
                break;
            case AIR_PATCH_COMMAND_OPCODE_INIT:
                if((buf[0] == AIR_PATCH_COMMAND_OPCODE_RESPONSE) && (buf[1] == AIR_PATCH_COMMAND_OPCODE_INIT)) {
                    if(buf[2] == AIR_PATCH_COMMAND_RESULT_SUCCESS) {
                        CheckError = false
                        
                        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                            self.dismiss(animated: true, completion: nil)
                        }
                        
                        UpdateOffset = 0
                        
                        OTA_Update()
                    }
                }
                break;
            case AIR_PATCH_COMMAND_OPCODE_UPDATE:
                if((buf[0] == AIR_PATCH_COMMAND_OPCODE_RESPONSE) && (buf[1] == AIR_PATCH_COMMAND_OPCODE_UPDATE)) {
                    if(buf[2] == AIR_PATCH_COMMAND_RESULT_SUCCESS) {
                        
                        CheckError = false
                        
                        var updateSize : UInt = 0
                        
                        if(UpdateFWType == Image_Type_MCU) {
                            updateSize = imageSize
                        }
                        else if(UpdateFWType == Image_Type_DSP){
                            updateSize = anotherSize
                        }
                        else{
                            updateSize = UInt(uidata!.length)
                        }
                        //else if()
    
                        if(updateSize == UpdateOffset) {
                            //print("OTA update is finished")
                            
                            if(UpdateFWType == Image_Type_MCU) {
                                
                            }
                            else {
                                
                            }
                            
                            OTAProgress.progress = 1.0
                            
                            state_label.attributedText = NSAttributedString(string: "OTA State : Update...100%", attributes:
                                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
                            
                            UpdateOffset = 0
                            
                            OTA_Validate()
                            
                            state_label.attributedText = NSAttributedString(string: "OTA State : Validation", attributes:
                                [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
                        }
                        else {
                            OTA_Update()
                            
                            //state_label.attributedText = NSAttributedString(string: "OTA State : Update", attributes:[NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
                        }
                    }
                }
                break;
            case AIR_PATCH_COMMAND_OPCODE_VALIDATE:
                //if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                //    print("Dismiss the Alert view")
                //    self.dismiss(animated: true, completion: nil)
                //}
                
                if((buf[0] == AIR_PATCH_COMMAND_OPCODE_RESPONSE) && (buf[1] == AIR_PATCH_COMMAND_OPCODE_VALIDATE)) {
                    if(buf[2] == AIR_PATCH_COMMAND_RESULT_SUCCESS) {
                        CheckError = false
                        
                        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                            print("Dismiss the Alert view")
                            self.dismiss(animated: true, completion: nil)
                        }
                        
                        if((SelectedHexFile != "") && (AnotherHexFile != "")) {
                            if(UpdateFWType == Image_Type_MCU) {
                                //print("Change hexStage = VP_DSP ")
                            
                                //hexStage = HEX_STAGE.INIT_VP_DSP
                                //UpdateFWType = Image_Type_VoicePrompt_DSP
                            
                                //OTA_Encryption(size: Int(anotherSize), hexdata: dspdata! )
                            
                                //OTA_Image_CRC(type:"VP_DSP")
                                
                                //OTAProgress.progress = 1.0
                            
                                //OTA_Initialization()
                            }
                            else {
                                hexStage = HEX_STAGE.IDLE
                                UpdateFWType = 0
                                OTA_State = 0
                                OTA_End()
                            }
                        }
                        else {
                            if((dsp_checksum == 0) && (ui_checksum == 0))
                            {
                                hexStage = HEX_STAGE.IDLE
                                UpdateFWType = 0
                                OTA_State = 0
                                OTA_End()
                            }
                            else{
                                /*
                                if(ui_checksum != 0){
                                    print("Initial UI Update..")
                                    
                                    //sleep(1)
                                    
                                    OTA_AlertMessage(title: "UI update", Message: "Continue...")
                                    
                                    hexStage = HEX_STAGE.INIT_UI
                                    
                                    imageCRC = ui_checksum
                                    
                                    ui_checksum = 0
                                    
                                    self.UpdateFWType = self.Image_Type_UI
                                    
                                    OTAProgress.progress = 0
                                    
                                    self.EncryptionData = NSMutableData(data: self.uidata! as Data)
                                    
                                    print("EncryptionData = \(self.EncryptionData.subdata(with: NSMakeRange(0, 16)) as NSData)")
                                    
                                    OTA_Initialization()
                                }
                                else if(dsp_checksum != 0){
                                    print("Initial DSP Update..")
                                    
                                    OTA_AlertMessage(title: "DSP update", Message: "Continue...")
                                    
                                    hexStage = HEX_STAGE.INIT_VP_DSP
                                    
                                    imageCRC = dsp_checksum
                                    
                                    dsp_checksum = 0
                                    
                                    self.UpdateFWType = self.Image_Type_DSP
                                    
                                    OTAProgress.progress = 0
                                    
                                    self.EncryptionData = NSMutableData(data: self.dspdata! as Data)
                                    
                                    print("EncryptionData1 = \(self.EncryptionData.subdata(with: NSMakeRange(0, 16)) as NSData)")
                                    print("EncryptionData2 = \(self.EncryptionData.subdata(with: NSMakeRange(0x40000, 16)) as NSData)")
                                    print("EncryptionData3 = \(self.EncryptionData.subdata(with: NSMakeRange((dspdata!.length-16), 16)) as NSData)")
                                    
                                    OTA_Initialization()
                                }*/
                                ///*
                                if(dsp_checksum != 0){
                                    print("Initial DSP Update..")
                                    
                                    OTA_AlertMessage(title: "DSP update", Message: "Continue...")
                                    
                                    hexStage = HEX_STAGE.INIT_VP_DSP
                                    
                                    imageCRC = dsp_checksum
                                    
                                    dsp_checksum = 0
                                    
                                    self.UpdateFWType = self.Image_Type_DSP
                                    
                                    OTAProgress.progress = 0
                                    
                                    self.EncryptionData = NSMutableData(data: self.dspdata! as Data)
                                    
                                    //print("Data1 = \(self.EncryptionData.subdata(with: NSMakeRange(0, 16)) as NSData)")
                                    //if(self.EncryptionData.length > 0x40000){
                                    //    print("Data2 = \(self.EncryptionData.subdata(with: NSMakeRange(0x40000, 16)) as NSData)")
                                    //}
                                    //print("Data3 = \(self.EncryptionData.subdata(with: NSMakeRange((dspdata!.length-16), 16)) as NSData)")
                                    
                                    OTA_Initialization()
                                }
                                else if(ui_checksum != 0){
                                    print("Initial UI Update..")
                                    
                                    OTA_AlertMessage(title: "UI update", Message: "Continue...")
                                    
                                    hexStage = HEX_STAGE.INIT_UI
                                    
                                    imageCRC = ui_checksum
                                    
                                    ui_checksum = 0
                                    
                                    self.UpdateFWType = self.Image_Type_UI
                                    
                                    OTAProgress.progress = 0
                                    
                                    self.EncryptionData = NSMutableData(data: self.uidata! as Data)
                                    
                                    print("EncryptionData = \(self.EncryptionData.subdata(with: NSMakeRange(0, 16)) as NSData)")
                                    
                                    
                                    OTA_Initialization()
                                }//*/
                            }
                        }
                    }
                }
                break;
            case AIR_PATCH_COMMAND_OPCODE_END:
                if((buf[0] == AIR_PATCH_COMMAND_OPCODE_RESPONSE) && (buf[1] == AIR_PATCH_COMMAND_OPCODE_END)) {
                    if(buf[2] == AIR_PATCH_COMMAND_RESULT_SUCCESS) {
                        CheckError = false
                        
                        OTA_Reset()
                    }
                }
                break;
            case AIR_PATCH_COMMAND_OPCODE_RESET:
                print("OTA Reset..")
                break;
            case OTA_EVENT_ERROR:
                print("OTA_EVENT_ERROR")
                
                CheckError = true;
                break;
            default:
                print("OTA unknown command!")
                break;
        }
        
        if(CheckError){
            if(!OTARunning){
                OTA_State = 0;
                return;
            }
            
            if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                self.dismiss(animated: true, completion: nil)
                print("****UIAlertController is presenting here!")
            }
            
            print("OTA Fail!,result = \(buf[2])")
            
            let errorMsg = Data(bytes : buf , count : bytes.length)
            print("OTA Fail, \(errorMsg.hexEncodedString())")
            
            OTA_Setup()
            
            OTA_AlertMessage(title: "OTA Update", Message: "Fail")
        }
    }
    
}

