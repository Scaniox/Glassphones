//
//  DeviceInfo.m
//  BLETR
//
//  Created by d500_MacMini on 13/6/19.
//  Copyright (c) 2013年 ISSC. All rights reserved.
//

#import "DeviceInfo.h"

@implementation DeviceInfo

@synthesize myPeripheral;
//@synthesize uartCommandTableViewController;

- (id)init {
    self = [super init];
    if (self) {
        //mainViewController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
        //uartCommandTableViewController = [[UartCommandTableViewController alloc] initWithNibName:@"UartCommandTableViewController" bundle:nil];
        //gsdViewController = [GSDRootViewController shareInstanceWithTagString:@"GSDRootViewController" direction:GSDTabBarDirectionHorizontalLeftMain];
        //gsdViewController = [GSDRootViewController alloc];
//GSDRootViewController *gsdViewController;
    }
    return self;
}

- (void)dealloc {
    //[uartCommandTableViewController release];
    [myPeripheral release];
    [super dealloc];
}

@end
