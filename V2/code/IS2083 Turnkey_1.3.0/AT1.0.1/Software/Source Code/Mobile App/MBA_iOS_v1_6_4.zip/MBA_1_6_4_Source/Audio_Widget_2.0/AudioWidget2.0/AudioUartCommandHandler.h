//
//  AudioUartCommandHandler.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 21/05/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyPeripheral.h"
//#import "CBController.h"

@protocol AudioUartCommandDelegate;
@interface AudioUartCommandHandler : NSObject<MyPeripheralDelegate>{
    //MyPeripheral *controlPeripheral;
}
@property(assign) id<AudioUartCommandDelegate> uartCommandDelegate;
@property(retain) MyPeripheral    *connectedPeripheral;

-(void) setPeripheral:(MyPeripheral *)connectedPeripheral;
@end


@protocol AudioUartCommandDelegate
@optional
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateMessage:(NSString* )message title:(NSString* )title error:(BOOL) error;
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateLogForCommand:(NSString *)log;
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdatePowerState:(BOOL )state;
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateFeature_StereoMode:(BOOL)stereoMode Feature_ConcertMode:(BOOL)concertMode Feature_EmbeddedMode:(BOOL)embeddedMode;
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateAddress:(NSData* )addr;
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateCommandAck:(unsigned char)commandID;
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateDatabaseInfo:(unsigned char)database;
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateGroupConnectionState:(unsigned char)state CSB_State:(unsigned char)csbState;
@end

