//
//  EqModeSettingViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 23/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "EqModeSettingViewController.h"
#import "EqualizerManualSettingViewController.h"
#import "ISUtility.h"
#import "UIView+Toast.h"

@interface EqModeSettingViewController (){
    NSArray *eqModeArray;
    int _count;
    int _cmdIdx;
}
@end

@implementation EqModeSettingViewController
@synthesize selectedEqMode;
@synthesize DatabaseInfo;

- (void)viewDidLoad {
    [super viewDidLoad];
    myTableView.backgroundColor = [UIColor clearColor];

    myTableView.dataSource = self;
    myTableView.delegate = self;
    eqModeArray = [[NSArray alloc] initWithObjects:@"OFF",@"Soft Mode",@"Bass Mode",@"Treble Mode",@"Classical Mode",@"Rock Mode",@"Jazz Mode",@"POP Mode",@"Dance Mode",@"R&B Mode",@"Custom Mode", nil];
    
    manualSettingButton.layer.cornerRadius = 10.0;
    // Do any additional setup after loading the view.
    /*UIBarButtonItem *testButton = [[UIBarButtonItem alloc] init];
    testButton.title = @"Test";
    testButton.target = self;
    [testButton setAction:@selector(autoTest)];
    self.navigationItem.rightBarButtonItem = testButton;*/
    
    _connectedPeripheral.EQSettingDelegate = self;
    
    self.title = @"Equalizer Setting";
    
    NSLog(@"Send MMI action : report current EQ mode");
    [_connectedPeripheral sendMmiAction:0x3f databaseIndex:DatabaseInfo];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)manualSettingBtnPressed:(id)sender {
    [self performSegueWithIdentifier:@"FORCE_TO_EQUALIZER_MANUAL_SETTING" sender:self];
}

-(void)autoTest{
    _count = 0;
    _cmdIdx = 0;
    [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(testPattern) userInfo:nil repeats:YES];
}

-(void)testPattern{
    [_connectedPeripheral sendEqModeSetting:_cmdIdx];
    NSString *str = [NSString stringWithFormat:@"Count = %d, Command = 0x%02X",_count,_cmdIdx];
    [self.navigationController.view makeToast:str
                                     duration:1.5
                                     position:CSToastPositionBottom];
    if(_cmdIdx == 0x0A){
        _cmdIdx = 0;
        _count++;
    }else{
        _cmdIdx++;
    }
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if([[segue identifier] isEqualToString:@"FORCE_TO_EQUALIZER_MANUAL_SETTING"]){
        EqualizerManualSettingViewController *view = segue.destinationViewController;
        view.connectedPeripheral = _connectedPeripheral;
    }
}


- (void)dealloc {
    [self.navigationController.view hideToastActivity];
    [myTableView release];
    [manualSettingButton release];
    _connectedPeripheral.EQSettingDelegate = nil;
    [super dealloc];
}

#pragma mark - Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    NSString *title = nil;
    title = @"EQ Mode:";
    return title;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [eqModeArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[eqModeArray objectAtIndex:indexPath.row]];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:[eqModeArray objectAtIndex:indexPath.row]] autorelease];
        [cell.textLabel setText:[eqModeArray objectAtIndex:indexPath.row]];
    }
    [ISUtility uncheckCell:cell];
    if ([indexPath isEqual:selectedEqMode])
        [ISUtility checkCell:cell];
    else
        [ISUtility uncheckCell:cell];
    cell.backgroundColor = [UIColor clearColor];
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    for (int row = 0; row < [myTableView numberOfRowsInSection:0]; row++) {
        NSIndexPath *indexPath1 = [NSIndexPath indexPathForRow:row inSection:0];
        [ISUtility uncheckCell:[tableView cellForRowAtIndexPath:indexPath1]];
    }
    [ISUtility uncheckCell:[tableView cellForRowAtIndexPath:selectedEqMode]];
    [self setSelectedEqMode:indexPath];
    [ISUtility checkCell:[tableView cellForRowAtIndexPath:selectedEqMode]];
    [_connectedPeripheral sendEqModeSetting:indexPath.row];
    
    [tableView setUserInteractionEnabled:NO];
    [self.navigationController.view makeToastActivity:CSToastPositionCenter];
    double delayInSeconds = 1.5;

    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    //dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(250 * NSEC_PER_MSEC));//Audio DSP Test
    
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [tableView setUserInteractionEnabled:YES];
        [self.navigationController.view hideToastActivity];
    });
    
    [myTableView reloadData];
    return;
}

#pragma mark - EQ setting delegate
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateEQMode:(unsigned char)EQModes {
    NSLog(@"EQ mode = %d",EQModes);
    
    selectedEqMode = [NSIndexPath indexPathForRow:(NSInteger)EQModes inSection:0];
    
    [myTableView reloadData];
}

@end
