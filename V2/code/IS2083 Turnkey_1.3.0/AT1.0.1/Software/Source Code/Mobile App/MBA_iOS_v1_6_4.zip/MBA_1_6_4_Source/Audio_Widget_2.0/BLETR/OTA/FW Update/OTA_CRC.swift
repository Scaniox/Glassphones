//
//  OTA_CRC.swift
//  TestOTA
//
//  Created by TestPC on 29/03/2018.
//  Copyright © 2018 TestPC. All rights reserved.
//

import Foundation

class OTA_CRC : NSObject {
    static var CRC_Value : UInt16 = 0xffff
    
    static let crc_table : [UInt16] = [0x0000, 0x1081, 0x2102, 0x3183, 0x4204, 0x5285, 0x6306, 0x7387, 0x8408, 0x9489, 0xa50a, 0xb58b, 0xc60c, 0xd68d, 0xe70e, 0xf78f]
    
    class func crc_calc_update(value:UInt8) {
        
        let i = (UInt8(CRC_Value&0x00ff) ^ value) & 0x0f
        CRC_Value = (CRC_Value >> 4) ^ crc_table[Int(i)]
        
        let j = (UInt8(CRC_Value&0x00ff) ^ (value >> 4)) & 0x0f
        CRC_Value = (CRC_Value >> 4) ^ crc_table[Int(j)]
    }
    
    class func crc_calc_finished() -> UInt16 {
        var crc : UInt16 = 0
        
        CRC_Value = ((CRC_Value & 0xFF00) >> 8) | ((CRC_Value & 0x00FF) << 8)
        CRC_Value = ((CRC_Value & 0xF0F0) >> 4) | ((CRC_Value & 0x0F0F) << 4)
        CRC_Value = ((CRC_Value & 0xCCCC) >> 2) | ((CRC_Value & 0x3333) << 2)
        CRC_Value = ((CRC_Value & 0xAAAA) >> 1) | ((CRC_Value & 0x5555) << 1)
        
        crc = CRC_Value
        CRC_Value = 0xffff
        
        return crc
    }
}
