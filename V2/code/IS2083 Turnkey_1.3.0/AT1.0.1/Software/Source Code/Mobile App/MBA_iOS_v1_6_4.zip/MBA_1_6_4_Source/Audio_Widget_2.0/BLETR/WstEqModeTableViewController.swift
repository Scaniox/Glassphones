//
//  WstEqModeTableViewController.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/8/8.
//  Copyright © 2019 ISSC. All rights reserved.
//

import Foundation
import UIKit
import CoreBluetooth

class WstEqModeTableViewController: UITableViewController,WST_EQSetting_Delegate {
    var m_wstPeripheral : WstPeripheral?
    var m_parentView: WstViewController?
    let eqModeArray = ["OFF","Soft Mode","Bass Mode","Treble Mode","Classical Mode","Rock Mode","Jazz Mode","POP Mode","Dance Mode","R&B Mode"];
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "EQ Mode Setting"
        
        m_wstPeripheral?.wstEqDelegate = self
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if(self.isMovingFromParent) {
            m_wstPeripheral?.wstEqDelegate = nil
        }
    }
    
    @objc func setBackgroundMode(background:Bool){
        m_parentView!.setBackgroundMode(background:background)
    }
    
    @objc func terminateBle(){
        m_parentView!.terminateBle()
    }
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //return 5
        return eqModeArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()//tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! WST_ScanResultCell
        cell.textLabel?.text = eqModeArray[indexPath.row]
        cell.backgroundColor = .groupTableViewBackground
        return cell
    }
    
    // MARK: - Table view delegate
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        m_wstPeripheral?.command_SetEqMode(mode: UInt8(indexPath.row))
    }
    
    // MARK: - WstPeripheral WST_EqDelegate
    func reportEqMode(mode:UInt8){
        m_parentView?.updateEqMode(mode: mode)
        let array = navigationController?.viewControllers
        if let object = array?[1] {
            navigationController?.popToViewController(object, animated: true)
        }
    }
    
    func didUpdateMessage( message: String?){
        showToast(message: message!, font: UIFont.systemFont(ofSize: UIFont.systemFontSize))
    }
}
