//
//  UngroupedHomeScreenViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 08/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "UngroupedHomeScreenViewController.h"
#import "UIView+Toast.h"
#import "ISUtility.h"
#import "SpeakerSettingTableViewController.h"
#import "PlaybackControlViewController.h"
#import "GroupSettingViewController.h"
#import "CommandWindowViewController.h"

enum{
    MMI_ACTION_POWER_ON_BUTTON_PRESS = 0x51,
    MMI_ACTION_POWER_ON_BUTTON_RELEASE,
    MMI_ACTION_POWER_OFF_BUTTON_PRESS,
    MMI_ACTION_POWER_OFF_BUTTON_RELEASE,
};

enum{
    DATA_CATEGORY0 = 0x00,
    DATA_CATEGORY1,
    DATA_CATEGORY2,
};

enum{
    OPTION_AUDIO_SETTING = 0x00,
    OPTION_SPEAKER_SETTING,
    OPTION_GROUP_SETTING,
    OPTION_COMMAND_PROMPT_CATEGORY2 = 0x02,
    OPTION_COMMAND_PROMPT = 0x03,
};

@interface UngroupedHomeScreenViewController (){
    NSMutableDictionary *MultiSpkRoleDict;
    BOOL PowerOn;
    BOOL Feature_StereoMode;
    BOOL Feature_ConcertMode;
    BOOL Feature_EmbeddedMode;
}
@end

@implementation UngroupedHomeScreenViewController
@synthesize _csbState;
@synthesize DatabaseInfo;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"[UngroupedHomeScreenViewController] viewDidLoad");
    // Do any additional setup after loading the view.
    UIBarButtonItem *logButton = [[UIBarButtonItem alloc] init];
    logButton.title = @"Log";
    logButton.target = self;
    [logButton setAction:@selector(showLog)];
    self.navigationItem.rightBarButtonItem = logButton;
    
    textView.layer.borderWidth = 1;
    textView.backgroundColor = [UIColor clearColor];
    
    ActionTableView.backgroundColor = [UIColor clearColor];
    ActionTableView.delegate = self;
    ActionTableView.dataSource = self;
    
    groupInfoTableView.backgroundColor = [UIColor clearColor];
    groupInfoTableView.delegate = self;
    groupInfoTableView.dataSource = self;
    
    uartCommandHanlder = [[AudioUartCommandHandler alloc] init];
    uartCommandHanlder.uartCommandDelegate = self;
    [uartCommandHanlder setPeripheral:_connectedPeripheral];
    
    NSString *str = [NSString stringWithFormat:@"\n\nGroup Info: Ungrouped\nRSSI Value: -81 dBm\nBattery Level: 45%%"];
    textView.text = str;
    
    MultiSpkRoleDict = [@{@0x00:@"Ungrouped",
                          @0x01:@"Stereo Master",
                          @0x04:@"Stereo Slave",
                          @0x05:@"Concert Master",
                          @0x06:@"Concert Slave",
                          @0x07:@"Concert Master"}mutableCopy];
    
    /***Create File*/
    logFiles = [[FileOps alloc] init];
    [logFiles createFileWithContent:[[NSString stringWithFormat:@""] mutableCopy]];
    
    PowerOn = FALSE;
    
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    //self.title =
    if (_dataCategory == DATA_CATEGORY0) {
        Feature_StereoMode = TRUE;
        Feature_ConcertMode = FALSE;
        Feature_EmbeddedMode = TRUE;
        [_connectedPeripheral sendReadFeatureList];
        
    }else if (_dataCategory == DATA_CATEGORY1){
        CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
        id serviceData = [uartCommandHanlder.connectedPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
        id Data = [serviceData objectForKey:uuid];
        unsigned char *dataByte;
        dataByte = malloc([Data length]);
        [Data getBytes:dataByte length:[Data length]];
        struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
        
        Feature_StereoMode = FALSE;
        Feature_ConcertMode = FALSE;
        Feature_EmbeddedMode = FALSE;
        
        if ((discoveredSpecialData->extendData.category1_par.supportFeature & 0x01) == 0x01)
            Feature_StereoMode = TRUE;
        if ((discoveredSpecialData->extendData.category1_par.supportFeature & 0x02) == 0x02)
            Feature_ConcertMode = TRUE;
        if ((discoveredSpecialData->extendData.category1_par.supportFeature & 0x04) == 0x04)
            Feature_EmbeddedMode = TRUE;
        
    }else{
        Feature_StereoMode = FALSE;
        Feature_ConcertMode = FALSE;
        Feature_EmbeddedMode = TRUE;
    }
    double delayInSeconds = 0.3;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [_connectedPeripheral sendReadLinkStatus];
    });
    
    DatabaseInfo = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)showLog{
    NSLog(@"showLog");
    [self displayContent];
}

-(void) displayContent{
    
    NSString *content = [logFiles readFromFile];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"LOG" message:content preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *dafaultAction = [UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){}];
    [alert addAction:dafaultAction];
    UIView *subView1 = alert.view.subviews[0];
    UIView *subView2 = subView1.subviews[0];
    UIView *subView3 = subView2.subviews[0];
    UIView *subView4 = subView3.subviews[0];
    UIView *subView5 = subView4.subviews[0];
    UILabel *contentView = subView5.subviews[1];
    contentView.textAlignment = NSTextAlignmentLeft;
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)updateSwitch:(id)sender{
    UISwitch *switcher = (UISwitch *)sender;
    double delayInSeconds = 0.3;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    
    if (switcher.on) {
        [switcher setOn:YES animated:YES];
        
        //[_connectedPeripheral sendMmiAction:MMI_ACTION_POWER_ON_BUTTON_PRESS];
        [_connectedPeripheral sendMmiAction:MMI_ACTION_POWER_ON_BUTTON_PRESS databaseIndex:DatabaseInfo];
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            //[_connectedPeripheral sendMmiAction:MMI_ACTION_POWER_ON_BUTTON_RELEASE];
            [_connectedPeripheral sendMmiAction:MMI_ACTION_POWER_ON_BUTTON_RELEASE databaseIndex:DatabaseInfo];
        });
    }else{
        [switcher setOn:NO animated:YES];
        [_connectedPeripheral sendMmiAction:MMI_ACTION_POWER_OFF_BUTTON_PRESS];
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            //[_connectedPeripheral sendMmiAction:MMI_ACTION_POWER_OFF_BUTTON_RELEASE];
            [_connectedPeripheral sendMmiAction:MMI_ACTION_POWER_OFF_BUTTON_RELEASE databaseIndex:DatabaseInfo];
        });
    }
}

- (void)dealloc {
    [textView release];
    [ActionTableView release];
    [groupInfoTableView release];
    _connectedPeripheral.transDataDelegate = nil;
    uartCommandHanlder.uartCommandDelegate = nil;
    [super dealloc];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if([[segue identifier] isEqualToString:@"FORCE_TO_AUDIO_SETTING_PALYBACK_CONTROL"]){
        PlaybackControlViewController *view = segue.destinationViewController;
        view.connectedPeripheral = _connectedPeripheral;
        view.Feature_EmbeddedMode = Feature_EmbeddedMode;
        view.Feature_StereoMode = Feature_StereoMode;
        view.Feature_ConcertMode = Feature_ConcertMode;
        view.DatabaseInfo = DatabaseInfo;
        view.groupInfo = [[NSMutableArray alloc]init];
        
        for (MyPeripheral* tmpPeripheral in _groupInfo) {
            if (tmpPeripheral != _connectedPeripheral) {
                CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
                id serviceData = [tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
                id Data = [serviceData objectForKey:uuid];
                unsigned char *dataByte;
                dataByte = malloc([Data length]);
                [Data getBytes:dataByte length:[Data length]];
                struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
                if (discoveredSpecialData->batteryLevel_And_Data_Category.category == 0x01) {
                    [view.groupInfo addObject:tmpPeripheral];
                }
            }
        }
        //view.groupInfoBtAddress = _groupInfoBtAddress;
    }else if([[segue identifier] isEqualToString:@"FORCE_TO_GROUP_SETTING"]){
        GroupSettingViewController *view = segue.destinationViewController;
        view.connectedPeripheral = _connectedPeripheral;
        view.speakerRole = _speakerRole;
        view.Feature_ConcertMode = Feature_ConcertMode;
        view._csbState = _csbState;
        view.Feature_StereoMode = Feature_StereoMode;
    }else if([[segue identifier] isEqualToString:@"FORCE_TO_SPEAKER_SETTING"]){
        SpeakerSettingTableViewController *view = segue.destinationViewController;
        view.connectedPeripheral = _connectedPeripheral;
    }else if([[segue identifier] isEqualToString:@"FORCE_TO_COMMAND_WINDOW"]){
        CommandWindowViewController *view = segue.destinationViewController;
        view.connectedPeripheral = _connectedPeripheral;
    }
}

#pragma mark - Audio Uart Command Delegate
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateMessage:(NSString* )message title:(NSString* )title error:(BOOL) error{
    [logFiles WriteToFile:[message mutableCopy]];
    NSString* image;
    
    if (error) {
        image = @"error.png";
    }else{
        image = @"warning.png";
    }
    [self.navigationController.view makeToast:message
                                     duration:100.0
                                     position:CSToastPositionCenter
                                        title:title
                                        image:[UIImage imageNamed:image]
                                        style:nil
                                   completion:nil];
}

- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateLogForCommand:(NSString *)log{
    [logFiles WriteToFile:[log mutableCopy]];
}

- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdatePowerState:(BOOL )state{
    PowerOn = state;
    [ActionTableView reloadData];
    [groupInfoTableView reloadData];
}
- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateFeature_StereoMode:(BOOL)stereoMode Feature_ConcertMode:(BOOL)concertMode Feature_EmbeddedMode:(BOOL)embeddedMode{
    Feature_StereoMode = stereoMode;
    Feature_ConcertMode = concertMode;
    Feature_EmbeddedMode = embeddedMode;
}

- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateGroupConnectionState:(unsigned char)state CSB_State:(unsigned char)csbState{
    _speakerRole = state;
    _csbState = csbState;
}

- (void)AudioUartCommandHandler:(MyPeripheral *)peripheral didUpdateDatabaseInfo:(unsigned char)database{
    //NSLog(@"didUpdateDatabaseInfo");
    DatabaseInfo = database;
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == groupInfoTableView) {
        return 2;
    }else
        return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == groupInfoTableView) {
        switch (section) {
            case 0:
                return 1;
                
            default:
                return [_groupInfo count];
        }
        
    }else{
        if (_dataCategory != DATA_CATEGORY2) {
            return 4;
        }else{
            return 3;
        }
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == groupInfoTableView) {
        if (indexPath.section == 0) {
            UITableViewCell *cell;
            UISwitch *mySwitch = [[UISwitch alloc]initWithFrame:CGRectZero];
            
            [mySwitch setOn:PowerOn animated:NO];
            [mySwitch addTarget:self action:@selector(updateSwitch:) forControlEvents:UIControlEventAllTouchEvents];
            
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"SwitchCell"];
            cell.textLabel.text = @"Power";
            cell.backgroundColor = [UIColor clearColor];
            [cell addSubview:mySwitch];
            cell.accessoryView = mySwitch;
            return cell;
            
        }else{
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"MyIdentifier"];
            }
            
            cell.backgroundColor = [UIColor clearColor];
            MyPeripheral *tmpPeripheral = [_groupInfo objectAtIndex:indexPath.row];
            CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
            id serviceData = [tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
            id Data = [serviceData objectForKey:uuid];
            unsigned char *dataByte;
            dataByte = malloc([Data length]);
            [Data getBytes:dataByte length:[Data length]];
            struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
            
            NSString *GAP_Name = tmpPeripheral.deviceName;
            NSString *LocalName = tmpPeripheral.deviceName;
            
            if(!([LocalName isEqualToString:GAP_Name])) {
                cell.textLabel.text = tmpPeripheral.deviceName;
            }
            else {
                cell.textLabel.text = tmpPeripheral.advName;
            }
            
            cell.detailTextLabel.text = MultiSpkRoleDict[@([[NSNumber numberWithInt:discoveredSpecialData->multiSpeakerRole]intValue])];
            return cell;
        }
    }else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
        }
        
        cell.backgroundColor = [UIColor clearColor];
        switch (indexPath.row) {
            case OPTION_AUDIO_SETTING:{
                cell.textLabel.text =@"Audio";
                cell.imageView.image = [UIImage imageNamed:@"audio.png"];
            }
                break;
            case OPTION_SPEAKER_SETTING:{
                if(_speakerRole == 0x00)
                    cell.textLabel.text =@"Speaker Setting";
                else
                    cell.textLabel.text =@"Master Setting";
                
                cell.imageView.image = [UIImage imageNamed:@"speaker_settings.png"];
            }
                break;
            default:{
                if (_dataCategory == DATA_CATEGORY2) {
                    cell.textLabel.text =@"Command Window";
                    cell.imageView.image = [UIImage imageNamed:@"command.png"];
                }else{
                    if (indexPath.row == OPTION_GROUP_SETTING) {
                        cell.textLabel.text =@"Group Settings";
                        cell.imageView.image = [UIImage imageNamed:@"group_settings.png"];
                    }else{
                        cell.textLabel.text =@"Command Window";
                        cell.imageView.image = [UIImage imageNamed:@"command.png"];
                    }
                }
                break;
            }
        }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.userInteractionEnabled = PowerOn;
        cell.textLabel.enabled = PowerOn;
        return cell;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    NSString *title = nil;
    if ((tableView == groupInfoTableView) && (section == 1)) {
        title = @"Group Details";
    }
    return title;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == groupInfoTableView) {
        return 44;
    }else{
        return 47;
    }
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == groupInfoTableView) {
        return;
    }else{
        switch (indexPath.row) {
            case OPTION_AUDIO_SETTING:
                [self performSegueWithIdentifier:@"FORCE_TO_AUDIO_SETTING_PALYBACK_CONTROL" sender:self];
                break;
            case OPTION_SPEAKER_SETTING:
                [self performSegueWithIdentifier:@"FORCE_TO_SPEAKER_SETTING" sender:self];
                break;
            default:
                if (_dataCategory == DATA_CATEGORY2 ) {
                    [self performSegueWithIdentifier:@"FORCE_TO_COMMAND_WINDOW" sender:self];
                    break;
                }else{
                    if (indexPath.row == OPTION_GROUP_SETTING) {
                        [self performSegueWithIdentifier:@"FORCE_TO_GROUP_SETTING" sender:self];
                        break;
                    }else{
                        [self performSegueWithIdentifier:@"FORCE_TO_COMMAND_WINDOW" sender:self];
                        break;
                    }
                }
                break;
        }
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}
@end
