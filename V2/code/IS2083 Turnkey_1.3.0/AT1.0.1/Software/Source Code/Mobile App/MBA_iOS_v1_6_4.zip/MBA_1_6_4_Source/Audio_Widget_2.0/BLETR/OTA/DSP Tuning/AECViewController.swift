//
//  AECViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/11.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class AECViewController: UIViewController, DSPTuningDelegate{
    var DSPManager: TuneDSPManager?

    @IBOutlet var AES_OnOff_checkbox: VKCheckbox!
    @IBOutlet var AEC_OnOff_checkbox: VKCheckbox!
    @IBOutlet var mSBC_checkbox: VKCheckbox!
    @IBOutlet var Stepsize: DropDown!
    @IBOutlet var TapLength: DropDown!

    @IBOutlet var TuneDSP: UIButton!
  
    @IBOutlet var AEC_Threshold: DropDown!
    
    @IBOutlet var AES_Suppression: DropDown!
    
    @IBOutlet var DoubleTalk_Threshold: DropDown!
    
    @IBOutlet var DSPState: UILabel!
    
    @IBOutlet var AEC_Button: UIButton!
    
    var Stepsize_List: Bool!
    var TapLength_List: Bool!
    var AEC_Threshold_List: Bool!
    var AES_Suppression_List: Bool!
    var DoubleTalk_Threshold_List: Bool!

    //var AEC_Data: [UInt8] = [UInt8]()
    var AEC_Prev_Data: [UInt8] = [UInt8]()
    
    var VOICE_Config_Data: [UInt8] = [UInt8]()
    var VOICE_Config_Data_Byte2: UInt8 = 0
    
    var AEC_ON: Bool?
    
    var Hidden: Bool?
    
    let Stepsize_table = ["0x01: Fast AEC Convergence", "0x02", "0x03", "0x04", "0x05", "0x06: Slow AEC Convergence"]
    let Stepsize_ids = [1, 2, 3, 4, 5, 6]
    
    let TapLength_table = ["0x01: 8msec Echo Tail", "0x02: 16msec Echo Tail", "0x03: 24msec Echo Tail", "0x04: 32msec Echo Tail", "0x05: 40msec Echo Tail", "0x06: 48msec Echo Tail", "0x07: 56msec Echo Tail", "0x08: 64msec Echo Tail", "0x09: 72msec Echo Tail", "0x0A: 80msec Echo Tail"]
    let TapLength_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    let AEC_Threshold_table = ["0x7F:Worst Linearity", "0x3F:", "0x1F:", "0x0F:", "0x07:", "0x03:Best Linearity"]
    let AEC_Threshold_ids = [0x7F, 0x3F, 0x1F, 0x0F, 0x07, 0x03]
    
    let AEC_Threshold_SBC_table = ["0x7F:Worst Linearity-mSBC", "0x3F:-mSBC", "0x1F:-mSBC", "0x0F:-mSBC", "0x07:-mSBC", "0x03:Best Linearity-mSBC"]
    let AEC_Threshold_SBC_ids = [0x7F, 0x3F, 0x1F, 0x0F, 0x07, 0x03]
    
    let AES_Suppression_table = ["0x01:Less Echo Suppression", "0x02:", "0x03:", "0x04:", "0x05:", "0x06:", "0x07:", "0x08:Medium Echo Suppression", "0x09:", "0x0A:", "0x0B:", "0x0C:", "0x0D:", "0x0E:", "0x0F:Most Echo Suppression"]
    let AES_Suppression_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    
    let AES_Suppression_SBC_table = ["0x01:Less Echo Supp.-mSBC", "0x02:-mSBC", "0x03:-mSBC", "0x04:-mSBC", "0x05:-mSBC", "0x06:-mSBC", "0x07:-mSBC", "0x08:Medium Echo Supp.-mSBC", "0x09:-mSBC", "0x0A:-mSBC", "0x0B:-mSBC", "0x0C:-mSBC", "0x0D:-mSBC", "0x0E:-mSBC", "0x0F:Most Echo Supp.-mSBC"]
    let AES_Suppression_SBC_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    
    let DoubleTalk_Threshold_table = ["0x7F:Better Full-Duplex", "0x72:", "0x65:", "0x5A:Medium Full-Duplex", "0x50:", "0x47:", "0x40:", "0x39:", "0x32:", "0x2D:", "0x28:", "0x24:", "0x20:", "0x1C:Worse Full-Duplex"]
    let DoubleTalk_Threshold_ids = [0x7F, 0x72, 0x65, 0x5A, 0x50, 0x47, 0x40, 0x39, 0x32, 0x2D, 0x28, 0x24, 0x20, 0x1C]
    
    let DoubleTalk_Threshold_SBC_table = ["0x7F:Better Full-Duplex-mSBC", "0x72:-mSBC", "0x65:-mSBC", "0x5A:Medium Full-Duplex-mSBC", "0x50:-mSBC", "0x47:-mSBC", "0x40:-mSBC", "0x39:-mSBC", "0x32:-mSBC", "0x2D:-mSBC", "0x28:-mSBC", "0x24:-mSBC", "0x20:-mSBC", "0x1C:Worse Full-Duplex-mSBC"]
    let DoubleTalk_Threshold_SBC_ids = [0x7F, 0x72, 0x65, 0x5A, 0x50, 0x47, 0x40, 0x39, 0x32, 0x2D, 0x28, 0x24, 0x20, 0x1C]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        TuneDSP.layer.cornerRadius = 10.0
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.VoiceAEC_Delegate = self
        
        Stepsize.isSearchEnable = false
        TapLength.isSearchEnable = false
        
        AEC_Threshold.isSearchEnable = false
        
        AES_Suppression.isSearchEnable = false
        AES_Suppression.listHeight = 120
        
        DoubleTalk_Threshold.isSearchEnable = false
        DoubleTalk_Threshold.listHeight = 90
        
        Stepsize_List = false
        TapLength_List = false
        AEC_Threshold_List = false
        AES_Suppression_List = false
        DoubleTalk_Threshold_List = false
        
        Stepsize.optionArray = Stepsize_table
        Stepsize.optionIds = Stepsize_ids
        
        TapLength.optionArray = TapLength_table
        TapLength.optionIds = TapLength_ids
        
        AEC_Threshold.optionArray = AEC_Threshold_table
        AEC_Threshold.optionIds = AEC_Threshold_ids
        
        AES_Suppression.optionArray = AES_Suppression_table
        AES_Suppression.optionIds = AES_Suppression_ids
        
        DoubleTalk_Threshold.optionArray = DoubleTalk_Threshold_table
        DoubleTalk_Threshold.optionIds = DoubleTalk_Threshold_ids
        
        mSBC_checkbox.checkboxValueChangedBlock = {
            isOn in
            print("mSBC checkbox is \(isOn ? "ON" : "OFF")")
            
            if(self.AEC_Threshold_List == true){
                self.AEC_Threshold.hideList()
            }
            
            if(self.AES_Suppression_List == true){
                self.AES_Suppression.hideList()
            }
            
            if(self.DoubleTalk_Threshold_List == true){
                self.DoubleTalk_Threshold.hideList()
            }
            
            if(self.TuneDSP.isHidden){
                self.TuneDSP.isHidden = false
            }
            
            if(isOn){
                self.AEC_Threshold.optionArray = self.AEC_Threshold_SBC_table
                self.AEC_Threshold.optionIds = self.AEC_Threshold_SBC_ids
                
                self.AES_Suppression.optionArray = self.AES_Suppression_SBC_table
                self.AES_Suppression.optionIds = self.AES_Suppression_SBC_ids
                
                self.DoubleTalk_Threshold.optionArray = self.DoubleTalk_Threshold_SBC_table
                self.DoubleTalk_Threshold.optionIds = self.DoubleTalk_Threshold_SBC_ids
                
                //if(self.AEC_Data.count != 0){
                if(self.DSPManager?.AEC_AES_Data.count != 0){
                    var kk1 = 5
                    //while(self.AEC_Data[5] > self.AEC_Threshold_ids[kk1]){
                    while(self.DSPManager!.AEC_AES_Data[5] > self.AEC_Threshold_ids[kk1]){
                        kk1 -= 1
                    }
                    self.AEC_Threshold.selectedIndex = kk1
                    self.AEC_Threshold.text = self.AEC_Threshold_SBC_table[self.AEC_Threshold.selectedIndex!]
                    
                    for index in 0..<self.DoubleTalk_Threshold_SBC_ids.count {
                        //if(self.AEC_Data[6] == self.DoubleTalk_Threshold_SBC_ids[index]) {
                        if(self.DSPManager!.AEC_AES_Data[6] == self.DoubleTalk_Threshold_SBC_ids[index]) {
                            self.DoubleTalk_Threshold.selectedIndex = index
                            self.DoubleTalk_Threshold.text = self.DoubleTalk_Threshold_SBC_table[self.DoubleTalk_Threshold.selectedIndex!]
                            break
                        }
                    }
                    
                    //self.AES_Suppression.selectedIndex = Int((self.AEC_Data[1] & 0x0f))-1
                    self.AES_Suppression.selectedIndex = Int((self.DSPManager!.AEC_AES_Data[1] & 0x0f))-1
                    self.AES_Suppression.text = self.AES_Suppression_table[self.AES_Suppression.selectedIndex!]
                }
            }
            else{
                self.AEC_Threshold.optionArray = self.AEC_Threshold_table
                self.AEC_Threshold.optionIds = self.AEC_Threshold_ids
                
                self.AES_Suppression.optionArray = self.AES_Suppression_table
                self.AES_Suppression.optionIds = self.AES_Suppression_ids
                
                self.DoubleTalk_Threshold.optionArray = self.DoubleTalk_Threshold_table
                self.DoubleTalk_Threshold.optionIds = self.DoubleTalk_Threshold_ids
                
                if(self.DSPManager?.AEC_AES_Data.count != 0){
                    var kk = 5
                    while(self.DSPManager!.AEC_AES_Data[2] > self.AEC_Threshold_ids[kk]){
                        kk -= 1
                    }
                    print("[AEC_Data[2]] SelectIndex = \(kk)")
                    self.AEC_Threshold.selectedIndex = kk
                    self.AEC_Threshold.text = self.AEC_Threshold_table[self.AEC_Threshold.selectedIndex!]
                    
                    for index in 0..<self.DoubleTalk_Threshold_ids.count {
                        if(self.DSPManager!.AEC_AES_Data[3] == self.DoubleTalk_Threshold_ids[index]) {
                            self.DoubleTalk_Threshold.selectedIndex = index
                            self.DoubleTalk_Threshold.text = self.DoubleTalk_Threshold_table[self.DoubleTalk_Threshold.selectedIndex!]
                            break
                        }
                    }
                    
                    //self.AES_Suppression.selectedIndex = Int((self.AEC_Data[1] & 0xf0) >> 4)
                    self.AES_Suppression.selectedIndex = Int((self.DSPManager!.AEC_AES_Data[1] & 0xf0) >> 4)-1
                    self.AES_Suppression.text = self.AES_Suppression_table[self.AES_Suppression.selectedIndex!]
                }
            }
        }
        
        AEC_OnOff_checkbox.checkboxValueChangedBlock = {
            isOn in
            print("AEC_OnOff checkbox is \(isOn ? "ON" : "OFF")")
        }
        
        //DSP Tool v4.0
        AES_OnOff_checkbox.checkboxValueChangedBlock = {
            isOn in
            print("AES_OnOff checkbox is \(isOn ? "ON" : "OFF")")
            
            print("VOICE_Config_Data[1] = \(String(format: "0x%02X",self.VOICE_Config_Data[1]))")
            
            //Update VOICE_DSP_CFG_KEY_CONFIG_WORD,Byte2,bit 2
            if(isOn){
                self.VOICE_Config_Data[1] |= 0x04
            }
            else{
                self.VOICE_Config_Data[1] &= ~(0x04)
            }
            
            print("New value = \(String(format: "0x%02X",self.VOICE_Config_Data[1]))")
            
            //self.DSPTuningEnable()
        }
        
        Stepsize.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.Stepsize.text != self.Stepsize_table[self.Stepsize.selectedIndex!]){
                print("Selected String = \(self.Stepsize_table[self.Stepsize.selectedIndex!])")
                self.DSPTuningEnable()
                print("AEC_Data[4] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[4]))")
                self.DSPManager!.AEC_AES_Data[4] &= ~(0xf0)
                //self.AEC_Data[4] |= UInt8(self.Stepsize.selectedIndex!) << 4
                self.DSPManager!.AEC_AES_Data[4] |= (UInt8(self.Stepsize.selectedIndex!)+1) << 4
                print("New value = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[4]))")
            }
        }
        
        TapLength.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.TapLength.text != self.TapLength_table[self.TapLength.selectedIndex!]){
                print("Selected String = \(self.TapLength_table[self.TapLength.selectedIndex!])")
                self.DSPTuningEnable()
                print("AEC_Data[0] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[0]))")
                //self.AEC_Data[0] = UInt8(self.TapLength.selectedIndex!)
                self.DSPManager!.AEC_AES_Data[0] = UInt8(self.TapLength.selectedIndex!)+1
                print("New value = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[0]))")
            }
        }
        
        AEC_Threshold.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.mSBC_checkbox.isOn()){
                if(self.AEC_Threshold.text != self.AEC_Threshold_SBC_table[self.AEC_Threshold.selectedIndex!]){
                    print("Selected String = \(self.AEC_Threshold_SBC_table[self.AEC_Threshold.selectedIndex!])")
                    self.DSPTuningEnable()
                    //print("AEC_Data[11] = \(String(format: "0x%02X",self.AEC_Data[11]))")
                    print("AEC_Data[5] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[5]))")
                    //self.AEC_Data[11] = UInt8(self.AEC_Threshold_SBC_ids[self.AEC_Threshold.selectedIndex!])
                    self.DSPManager!.AEC_AES_Data[5] = UInt8(self.AEC_Threshold_SBC_ids[self.AEC_Threshold.selectedIndex!])
                    //print("New value = \(String(format: "0x%02X",self.AEC_Data[11]))")
                    print("New value = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[5]))")
                }
            }
            else{
                if(self.AEC_Threshold.text != self.AEC_Threshold_table[self.AEC_Threshold.selectedIndex!]){
                    print("Selected String = \(self.AEC_Threshold_table[self.AEC_Threshold.selectedIndex!])")
                    self.DSPTuningEnable()
                    print("AEC_Data[2] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[2]))")
                    self.DSPManager!.AEC_AES_Data[2] = UInt8(self.AEC_Threshold_ids[self.AEC_Threshold.selectedIndex!])
                    print("New value = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[2]))")
                }
            }
        }
        
        AES_Suppression.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.mSBC_checkbox.isOn()){
                if(self.AES_Suppression.text != self.AES_Suppression_SBC_table[self.AES_Suppression.selectedIndex!]){
                    print("Selected String = \(self.AES_Suppression_SBC_table[self.AES_Suppression.selectedIndex!])")
                    self.DSPTuningEnable()
                    print("AEC_Data[1] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[1]))")
                    self.DSPManager!.AEC_AES_Data[1] &= ~(0x0f)
                    //self.AEC_Data[1] |= UInt8(self.AES_Suppression.selectedIndex!)
                    self.DSPManager!.AEC_AES_Data[1] |= (UInt8(self.AES_Suppression.selectedIndex!)+1)
                    print("New value = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[1]))")
                }
            }
            else{
                if(self.AES_Suppression.text != self.AES_Suppression_table[self.AES_Suppression.selectedIndex!]){
                    print("Selected String = \(self.AES_Suppression_table[self.AES_Suppression.selectedIndex!])")
                    self.DSPTuningEnable()
                    print("AEC_Data[1] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[1]))")
                    self.DSPManager!.AEC_AES_Data[1] &= ~(0xf0)
                    //self.AEC_Data[1] |= UInt8(self.AES_Suppression.selectedIndex!) << 4
                    self.DSPManager!.AEC_AES_Data[1] |= (UInt8(self.AES_Suppression.selectedIndex!)+1) << 4
                    print("New value = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[1]))")
                }
            }
        }
        
        DoubleTalk_Threshold.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.mSBC_checkbox.isOn()){
                if(self.DoubleTalk_Threshold.text != self.DoubleTalk_Threshold_SBC_table[self.DoubleTalk_Threshold.selectedIndex!]){
                    print("Selected String = \(self.DoubleTalk_Threshold_SBC_table[self.DoubleTalk_Threshold.selectedIndex!])")
                    self.DSPTuningEnable()
                    print("AEC_Data[6] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[6]))")
                    self.DSPManager!.AEC_AES_Data[6] = UInt8(self.DoubleTalk_Threshold_SBC_ids[self.DoubleTalk_Threshold.selectedIndex!])
                    print("New value = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[6]))")
                }
            }
            else{
                if(self.DoubleTalk_Threshold.text != self.DoubleTalk_Threshold_table[self.DoubleTalk_Threshold.selectedIndex!]){
                    print("Selected String = \(self.DoubleTalk_Threshold_table[self.DoubleTalk_Threshold.selectedIndex!])")
                    self.DSPTuningEnable()
                    print("AEC_Data[3] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[3]))")
                    self.DSPManager!.AEC_AES_Data[3] = UInt8(self.DoubleTalk_Threshold_ids[self.DoubleTalk_Threshold.selectedIndex!])
                    print("New value = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[3]))")
                }
            }
        }
        
        Stepsize.listWillAppear {
            self.Stepsize_List = true
            
            if(self.TapLength_List == true){
                self.TapLength.hideList()
            }
            
            if(self.AEC_Threshold_List == true){
                self.AEC_Threshold.hideList()
            }
            
            if(self.AES_Suppression_List == true){
                self.AES_Suppression.hideList()
            }
            
            if(self.DoubleTalk_Threshold_List == true){
               self.DoubleTalk_Threshold.hideList()
            }
            
            self.TapLength.isHidden = true
            self.AEC_Threshold.isHidden = true
            self.AES_Suppression.isHidden = true
            self.DoubleTalk_Threshold.isHidden = true
            self.TuneDSP.isHidden = true
            self.AEC_Button.isHidden = true
        }
        
        Stepsize.listDidDisappear {
            self.Stepsize_List = false
            
            self.TapLength.isHidden = false
            self.AEC_Threshold.isHidden = false
            self.AES_Suppression.isHidden = false
            self.DoubleTalk_Threshold.isHidden = false
            
            self.TuneDSP.isHidden = false
            self.AEC_Button.isHidden = self.Hidden!
        }

        TapLength.listWillAppear {
            self.TapLength_List = true
            
            if(self.AEC_Threshold_List == true){
                self.AEC_Threshold.hideList()
            }
            
            if(self.AES_Suppression_List == true){
                self.AES_Suppression.hideList()
            }
            
            if(self.DoubleTalk_Threshold_List == true){
                self.DoubleTalk_Threshold.hideList()
            }
            
            self.AEC_Threshold.isHidden = true
            self.AES_Suppression.isHidden = true
            self.DoubleTalk_Threshold.isHidden = true
            self.TuneDSP.isHidden = true
            self.AEC_Button.isHidden = true
        }
        
        TapLength.listDidDisappear {
            self.TapLength_List = false
            
            if(self.Stepsize_List == false)
            {
                self.AEC_Threshold.isHidden = false
            
                self.AES_Suppression.isHidden = false
            
                self.DoubleTalk_Threshold.isHidden = false
            
                self.TuneDSP.isHidden = false
                
                self.AEC_Button.isHidden = self.Hidden!
            }
        }
        
        AEC_Threshold.listWillAppear {
            self.AEC_Threshold_List = true
            
            if(self.AES_Suppression_List == true){
                self.AES_Suppression.hideList()
            }
            
            if(self.DoubleTalk_Threshold_List == true){
                self.DoubleTalk_Threshold.hideList()
            }
            
            self.AES_Suppression.isHidden = true
            self.DoubleTalk_Threshold.isHidden = true
            self.TuneDSP.isHidden = true
            self.AEC_Button.isHidden = true
        }
        
        AEC_Threshold.listDidDisappear {
            self.AEC_Threshold_List = false
            
            if(self.Stepsize_List == false && self.TapLength_List == false)
            {
                self.AES_Suppression.isHidden = false
            
                self.DoubleTalk_Threshold.isHidden = false
            
                self.TuneDSP.isHidden = false
                
                self.AEC_Button.isHidden = self.Hidden!
            }
        }
        
        AES_Suppression.listWillAppear {
            self.AES_Suppression_List = true
            
            if(self.DoubleTalk_Threshold_List == true){
                self.DoubleTalk_Threshold.hideList()
            }
            
            self.DoubleTalk_Threshold.isHidden = true
            
            self.TuneDSP.isHidden = true
            self.AEC_Button.isHidden = true
        }
        
        AES_Suppression.listDidDisappear {
            self.AES_Suppression_List = false
            
            if(self.Stepsize_List == false && self.TapLength_List == false && self.AEC_Threshold_List == false)
            {
                self.DoubleTalk_Threshold.isHidden = false
            
                self.TuneDSP.isHidden = false
                
                self.AEC_Button.isHidden = self.Hidden!
            }
        }
        
        DoubleTalk_Threshold.listWillAppear {
            self.DoubleTalk_Threshold_List = true
            
            self.TuneDSP.isHidden = true
            self.AEC_Button.isHidden = true
        }
        
        DoubleTalk_Threshold.listDidDisappear {
            self.DoubleTalk_Threshold_List = false
            
            if(self.Stepsize_List == false && self.TapLength_List == false && self.AEC_Threshold_List == false && self.AES_Suppression_List == false)
            {
                self.TuneDSP.isHidden = false
                
                self.AEC_Button.isHidden = self.Hidden!
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[AECViewController] viewWillAppear")
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            //DSPState.text = DSPManager?.DSP_DUT_State
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "AEC/AES")
        
        //if(Stepsize.text == "" || AEC_Data.count == 0){
        if(Stepsize.text == "" ){
            DSPTuningDisable()
            DSPManager?.Get_Voice_DSP_Setting_AEC_AES()
        }
        
        /*
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport){
            Stepsize.isUserInteractionEnabled = false
            TapLength.isUserInteractionEnabled = false
            AEC_Threshold.isUserInteractionEnabled = false
            AES_Suppression.isUserInteractionEnabled = false
            DoubleTalk_Threshold.isUserInteractionEnabled = false
            DSPTuningDisable()
        }*/
        
        if(DSPState.text == "DSP Status: "){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
        
        if(DSPManager?.BLE_Connection != nil && DSPManager?.BLE_Connection == false){
            self.navigationController?.popViewController(animated: true)
            return
        }
        
        if(DSPManager?.RefreshGUIData(UIView_index: 7) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 7)
            DSPTuningDisable()
            DSPManager?.Get_Voice_DSP_Setting_AEC_AES()
        }
        
        if(Hidden == nil){
            DSPTuningState(state: "AEC/AES")
        }
        
        /*
        //Simulator
        Stepsize.selectedIndex = 0
        Stepsize.text = Stepsize_table[Stepsize.selectedIndex!]
        TapLength.selectedIndex = 0
        TapLength.text = TapLength_table[TapLength.selectedIndex!]
        AEC_Threshold.selectedIndex = 0
        AEC_Threshold.text = AEC_Threshold_table[AEC_Threshold.selectedIndex!]
        AES_Suppression.selectedIndex = 0
        AES_Suppression.text = AES_Suppression_table[AES_Suppression.selectedIndex!]
        DoubleTalk_Threshold.selectedIndex = 0
        DoubleTalk_Threshold.text = DoubleTalk_Threshold_table[DoubleTalk_Threshold.selectedIndex!]
        */
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[AEC]viewWillDisappear")
        
        if(TuneDSP.isEnabled == true){
            if(DSPManager?.AEC_AES_Data.count != 0){
                let tmp1 = NSData(bytes: &DSPManager!.AEC_AES_Data, length: DSPManager!.AEC_AES_Data.count)
                print("tmp1 = \(tmp1)")
                let tmp2 = NSData(bytes: &AEC_Prev_Data, length: AEC_Prev_Data.count)
                print("tmp2 = \(tmp2)")
                if(tmp1.isEqual(to: tmp2 as Data) == false){
                    DSPManager?.DSPQueueData(module:0x0D, cfg:0x05, len:UInt8(DSPManager!.AEC_AES_Data.count), data:DSPManager!.AEC_AES_Data)
                    AEC_Prev_Data.removeAll()
                    AEC_Prev_Data = DSPManager!.AEC_AES_Data
                }
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func ResetParameters(_ sender: Any) {
        print("ResetParameters")
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        if(DSPManager?.AEC_AES_Data.count != 0){
            print("DSPTuning:AEC")
            
            var change1: Bool = false
            var change2: Bool = false
            
            if(VOICE_Config_Data.count != 0){
                if(VOICE_Config_Data[1] != VOICE_Config_Data_Byte2){
                    //change1 = true
                }
            }
            
            let tmp1 = NSData(bytes: &DSPManager!.AEC_AES_Data, length: DSPManager!.AEC_AES_Data.count)
            print("tmp1 = \(tmp1)")
            let tmp2 = NSData(bytes: &AEC_Prev_Data, length: AEC_Prev_Data.count)
            print("tmp2 = \(tmp2)")
            if(tmp1.isEqual(to: tmp2 as Data) == false){
                change2 = true
            }
            
            if(change1 == true && change2 == false){
                //DSPManager?.DSPTuning(module: 0x0D, cfg: 0x01, len: UInt8(VOICE_Config_Data.count), data: VOICE_Config_Data)
            }
            else if(change1 == false && change2 == true){
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x05, len: UInt8(DSPManager!.AEC_AES_Data.count), data: DSPManager!.AEC_AES_Data)
            }
            else if(change1 == true && change2 == true){
                //DSPManager?.DSPTuning2(module: 0x0D, cfg1: 0x01, cfg2: 0x05, len1: UInt8(VOICE_Config_Data.count), len2: UInt8(DSPManager!.AEC_AES_Data.count), data1: VOICE_Config_Data, data2: DSPManager!.AEC_AES_Data)
            }
        }
    }
    
    func AEC_AES_Data_Init(){
        if(DSPManager?.AEC_AES_Data.count != 16){
            return
        }
        
        print("AEC_AES_Data_Init")
        
        if let AEC_Mode = DSPManager?.GetVoiceAECMode(){
            print("AEC OnOff = \(AEC_Mode)")
        
            if(AEC_Mode == 0x01){
                AEC_OnOff_checkbox.setOn(true)
                //AES_OnOff_checkbox.isUserInteractionEnabled = true
                
                AEC_ON = true
            }
            else{
                AEC_ON = false
                
                AEC_OnOff_checkbox.setOn(false)
                //AES_OnOff_checkbox.isUserInteractionEnabled = false
            }
        
            AEC_OnOff_checkbox.isUserInteractionEnabled = false
        }
        
        if(VOICE_Config_Data.count != 0){
            if((VOICE_Config_Data[1] & 0x04) == 0x04){  //VOICE_DSP_CFG_KEY_CONFIG_WORD, Byte 2 , bit 2
                print("Set AES On")
                AES_OnOff_checkbox.setOn(true)
            }
            else{
                print("Set AES Off")
                AES_OnOff_checkbox.setOn(false)
            }
        }
        
        //Stepsize.selectedIndex = Int((AEC_Data[4] & 0xf0) >> 4) //0x01~0x06
        Stepsize.selectedIndex = Int((self.DSPManager!.AEC_AES_Data[4] & 0xf0) >> 4) - 1 //0x01~0x06
        Stepsize.text = Stepsize_table[Stepsize.selectedIndex!]
        
        //TapLength.selectedIndex = Int(AEC_Data[0])
        TapLength.selectedIndex = Int(self.DSPManager!.AEC_AES_Data[0])-1
        TapLength.text = TapLength_table[TapLength.selectedIndex!]
        
        if(self.mSBC_checkbox.isOn()){
            var kk1 = 5
            while(self.DSPManager!.AEC_AES_Data[5] > AEC_Threshold_ids[kk1]){
                kk1 -= 1
            }
            print("AEC_Data[5]] kk1 = \(kk1)")
            AEC_Threshold.selectedIndex = kk1
            AEC_Threshold.text = AEC_Threshold_SBC_table[AEC_Threshold.selectedIndex!]
            
            for index in 0..<DoubleTalk_Threshold_SBC_ids.count {
                if(self.DSPManager!.AEC_AES_Data[6] == DoubleTalk_Threshold_SBC_ids[index]) {
                    DoubleTalk_Threshold.selectedIndex = index
                    DoubleTalk_Threshold.text = DoubleTalk_Threshold_SBC_table[DoubleTalk_Threshold.selectedIndex!]
                    break
                }
            }
            
            //AES_Suppression.selectedIndex = Int((AEC_Data[1] & 0x0f))
            AES_Suppression.selectedIndex = Int((self.DSPManager!.AEC_AES_Data[1] & 0x0f))-1
            AES_Suppression.text = AES_Suppression_table[AES_Suppression.selectedIndex!]
        }
        else{
            var kk = 5
            while(self.DSPManager!.AEC_AES_Data[2] > AEC_Threshold_ids[kk]){
                kk -= 1
            }
            print("[AEC_Data[2]] SelectIndex = \(kk)")
            AEC_Threshold.selectedIndex = kk
            AEC_Threshold.text = AEC_Threshold_table[AEC_Threshold.selectedIndex!]
            
            for index in 0..<DoubleTalk_Threshold_ids.count {
                if(self.DSPManager!.AEC_AES_Data[3] == DoubleTalk_Threshold_ids[index]) {
                    DoubleTalk_Threshold.selectedIndex = index
                    DoubleTalk_Threshold.text = DoubleTalk_Threshold_table[DoubleTalk_Threshold.selectedIndex!]
                    break
                }
            }
            
            //AES_Suppression.selectedIndex = Int((AEC_Data[1] & 0xf0) >> 4)
            AES_Suppression.selectedIndex = Int((self.DSPManager!.AEC_AES_Data[1] & 0xf0) >> 4)-1
            AES_Suppression.text = AES_Suppression_table[AES_Suppression.selectedIndex!]
        }
        
        if(!(AEC_OnOff_checkbox.isOn())){
            mSBC_checkbox.isUserInteractionEnabled = false
            Stepsize.isUserInteractionEnabled = false
            TapLength.isUserInteractionEnabled = false
            AEC_Threshold.isUserInteractionEnabled = false
            AES_Suppression.isUserInteractionEnabled = false
            DoubleTalk_Threshold.isUserInteractionEnabled = false
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[AEC] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        print("[Voice AEC] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 5){
                if(buffer[k+2] == 16){
                    DSPManager?.AEC_AES_Data.removeAll()
                    for index in 0..<16 {
                        DSPManager?.AEC_AES_Data.append(buffer[k+3+index])
                    }
                    print("AEC_AES_Data = \(DSPManager?.AEC_AES_Data)")
                    //AEC_AES_Data_Init()
                    //break
                }
            }
            else if(buffer[k] == 13 && buffer[k+1] == 1){
                print("VOICE_DSP_CFG_KEY_CONFIG_WORD_byte2 = \(String(format: "0x%02X",buffer[k+4]))")
                if((buffer[k+4] & 0x01) == 0x01){
                    print("AEC is On")
                }
                else{
                    print("AEC is Off")
                }
                
                if(buffer[k+2] == 4){
                    for index in 0..<4 {
                        VOICE_Config_Data.append(buffer[k+3+index])
                    }
                    print("VOICE_Config_Data = \(VOICE_Config_Data)")
                    VOICE_Config_Data_Byte2 = VOICE_Config_Data[1]
                }
            }
            
            k += Int(3+len)
        }
        
        if(DSPManager?.AEC_AES_Data.count != 0){
            AEC_Prev_Data.removeAll()
            AEC_Prev_Data = DSPManager!.AEC_AES_Data
        }
        AEC_AES_Data_Init()
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 7)
            if(self.VOICE_Config_Data.count != 0){
                self.VOICE_Config_Data_Byte2 = self.VOICE_Config_Data[1]
            }
            if(self.DSPManager?.AEC_AES_Data.count != 0){
                self.AEC_Prev_Data.removeAll()
                self.AEC_Prev_Data = self.DSPManager!.AEC_AES_Data
            }
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String) {
        if(state == "AEC/AES"){
            print("[AEC] Update GUI")
            
            if(Stepsize_List == true || TapLength_List == true || AEC_Threshold_List == true || AES_Suppression_List == true || DoubleTalk_Threshold_List == true){
                return
            }
            
            if(Hidden == nil){
                Hidden = true
            }
            else{
                if(Hidden!){
                    Hidden = false
                }
                else{
                    Hidden = true
                }
            }
            print("Hidden = \(Hidden)")
            
            AEC_Button.isHidden = Hidden!
            
            return
        }
        
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(Stepsize_List == true){
                Stepsize_List = false
                Stepsize.hideList()
            }
            Stepsize.isUserInteractionEnabled = false
            if(TapLength_List == true){
                TapLength_List = false
                TapLength.hideList()
            }
            TapLength.isUserInteractionEnabled = false
            if(AEC_Threshold_List == true){
                AEC_Threshold_List = false
                AEC_Threshold.hideList()
            }
            AEC_Threshold.isUserInteractionEnabled = false
            if(AES_Suppression_List == true){
                AES_Suppression_List = false
                AES_Suppression.hideList()
            }
            AES_Suppression.isUserInteractionEnabled = false
            if(DoubleTalk_Threshold_List == true){
                DoubleTalk_Threshold_List = false
                DoubleTalk_Threshold.hideList()
            }
            DoubleTalk_Threshold.isUserInteractionEnabled = false
            mSBC_checkbox.isUserInteractionEnabled = false
            AES_OnOff_checkbox.isUserInteractionEnabled = false
            AEC_Button.isEnabled = false
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            Stepsize.isUserInteractionEnabled = true
            TapLength.isUserInteractionEnabled = true
            AEC_Threshold.isUserInteractionEnabled = true
            AES_Suppression.isUserInteractionEnabled = true
            DoubleTalk_Threshold.isUserInteractionEnabled = true
            mSBC_checkbox.isUserInteractionEnabled = true
            AEC_Button.isEnabled = true
            AES_OnOff_checkbox.isUserInteractionEnabled = false //BTAS-1172
            /*
            if(AEC_ON != nil && AEC_ON == true){
                AES_OnOff_checkbox.isUserInteractionEnabled = true
            }
            else{
                AES_OnOff_checkbox.isUserInteractionEnabled = false
            }*/
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
