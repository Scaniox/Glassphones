//
//  MICGainViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/11.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class MICGainViewController: UIViewController, DSPTuningDelegate{
    var DSPManager: TuneDSPManager?
    
    @IBOutlet var Mic_Gain: DropDown!
    @IBOutlet var ComfortNoise: DropDown!
    
    @IBOutlet var TuneDSP: UIButton!
    @IBOutlet var DSPState: UILabel!
    
    var Hidden: Bool?
    
    //New GUI
    //Mic Codec
    @IBOutlet var MC_Gain: DropDown!
    @IBOutlet var MC_KR: DropDown!
    @IBOutlet var MC_RIT: DropDown!
    @IBOutlet var MC_WRT: DropDown!
    
    //Digital Gain
    @IBOutlet var DG_SPKOUT: DropDown!
    @IBOutlet var DG_Line: DropDown!
    @IBOutlet var DG_MIC1: DropDown!
    
    @IBOutlet var MC_Gain_Label: UILabel!
    @IBOutlet var MC_KR_Label: UILabel!
    @IBOutlet var MC_RIT_Label: UILabel!
    @IBOutlet var MC_WRT_Label: UILabel!
    @IBOutlet var DG_SPKOUT_Label: UILabel!
    @IBOutlet var DG_Line_Label: UILabel!
    @IBOutlet var DG_MIC1_Label: UILabel!
    
    var MIC_Data: [UInt8] = [UInt8]()
    var MIC_Prev_Data: [UInt8] = [UInt8]()
    var ComfortNoise_Data: [UInt8] = [UInt8]()
    var ComfortNoise_Prev_Data: [UInt8] = [UInt8]()
    
    var DSPTuningMicGain: Bool = false
    var DSPTuningComfortNoise: Bool = false
    
    var Mic_Gain_List: Bool!
    var ComfortNoise_List: Bool!
    var MC_Gain_List: Bool!
    var MC_KR_List: Bool!
    var MC_RIT_List: Bool!
    var MC_WRT_List: Bool!
    var DG_SPKOUT_List: Bool!
    var DG_Line_List: Bool!
    var DG_MIC1_List: Bool!
    
    let Mic_Gain_table = ["0x00: -19dB -Minimum", "0x03: -16dB", "0x05: -14dB", "0x07: -12dB", "0x09: -10dB", "0x0B: -8dB", "0x0D: -6dB", "0x0F: -4dB", "0x11: -2dB", "0x13: 0dB -Default", "0x15: 2dB", "0x17: 4dB", "0x19: 6dB", "0x1B: 8dB", "0x1D: 10dB", "0x1F: 12dB", "0x21: 14dB", "0x23: 16dB", "0x25: 18dB", "0x27: 20dB -Maximum"]
    let Mic_Gain_ids = [0x00, 0x03, 0x05, 0x07, 0x09, 0x0B, 0x0D, 0x0F, 0x11, 0x13, 0x15, 0x17, 0x19, 0x1B, 0x1D, 0x1F, 0x21, 0x23, 0x25, 0x27]
    let ComfortNoise_table = ["0x00: 0dB -Highest", "0x01: -6dB", "0x02: -12dB", "0x03: -18dB", "0x04: -24dB", "0x05: -30dB", "0x06: -36dB", "0x07: -42dB", "0x08: -48dB", "0x09: -54dB", "0x0A: -60dB", "0x0B: -66dB", "0x0C: -72dB", "0x0D: -78dB -Default", "0x0E: -84dB", "0x0F: -90dB -Lowest"]
    let ComfortNoise_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    
    let MC_Gain_table = ["0x0", "0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8", "0x9"]
    let MC_Gain_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    
    let MC_KR_table = ["0x0", "0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8", "0x9"]
    let MC_KR_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    
    let MC_RIT_table = ["0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8", "0x9", "0xA"]
    let MC_RIT_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    let MC_WRT_table = ["0x2", "0x3", "0x4", "0x5"]
    let MC_WRT_ids = [1, 2, 3, 4]
    
    let DG_table = ["0x00: -19dB -Minimum", "0x03: -16dB", "0x05: -14dB", "0x07: -12dB", "0x09: -10dB", "0x0B:  -8dB", "0x0D:  -6dB", "0x0F:  -4dB", "0x11:  -2dB", "0x13:  0dB -Default", "0x15:   2dB", "0x17:   4dB", "0x19:   6dB", "0x1B:   8dB", "0x1D:  10dB", "0x1F:  12dB", "0x21:  14dB", "0x23:  16dB", "0x25:  18dB", "0x27: 20dB -Maximum"]
    let DG_ids = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        TuneDSP.layer.cornerRadius = 10.0
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.VoiceMIC_Delegate = self
        
        Mic_Gain.isSearchEnable = false
        ComfortNoise.isSearchEnable = false
        MC_Gain.isSearchEnable = false
        MC_KR.isSearchEnable = false
        MC_RIT.isSearchEnable = false
        MC_WRT.isSearchEnable = false
        DG_SPKOUT.isSearchEnable = false
        DG_Line.isSearchEnable = false
        DG_MIC1.isSearchEnable = false
        
        DG_SPKOUT.listHeight = 80
        DG_Line.listHeight = 60
        DG_MIC1.listHeight = 50
        
        Mic_Gain_List = false
        ComfortNoise_List = false
        MC_Gain_List = false
        MC_KR_List = false
        MC_RIT_List = false
        MC_WRT_List = false
        DG_SPKOUT_List = false
        DG_Line_List = false
        DG_MIC1_List = false
        
        Mic_Gain.optionArray = Mic_Gain_table
        Mic_Gain.optionIds = Mic_Gain_ids
        
        ComfortNoise.optionArray = ComfortNoise_table
        ComfortNoise.optionIds = ComfortNoise_ids
        
        MC_Gain.optionArray = MC_Gain_table
        MC_Gain.optionIds = MC_Gain_ids
        
        MC_KR.optionArray = MC_KR_table
        MC_KR.optionIds = MC_KR_ids
        
        MC_RIT.optionArray = MC_RIT_table
        MC_RIT.optionIds = MC_RIT_ids
        
        MC_WRT.optionArray = MC_WRT_table
        MC_WRT.optionIds = MC_WRT_ids
        
        DG_SPKOUT.optionArray = DG_table
        DG_SPKOUT.optionIds = DG_ids
        
        DG_Line.optionArray = DG_table
        DG_Line.optionIds = DG_ids
        
        DG_MIC1.optionArray = DG_table
        DG_MIC1.optionIds = DG_ids
        
        Mic_Gain.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.Mic_Gain.text != self.Mic_Gain_table[self.Mic_Gain.selectedIndex!]){
                print("Selected String = \(self.Mic_Gain_table[self.Mic_Gain.selectedIndex!])")
                self.DSPTuningEnable()
                self.DSPTuningMicGain = true
                print("MIC data 0 = \(String(format: "0x%02X",self.MIC_Data[0]))")
                self.MIC_Data[0] = UInt8(self.Mic_Gain_ids[self.Mic_Gain.selectedIndex!])
                print("New value = \(String(format: "0x%02X",self.MIC_Data[0]))")
            }
        }
        
        ComfortNoise.didSelect{(selectedText , index , id) in
            //print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
            if(self.ComfortNoise.text != self.ComfortNoise_table[self.ComfortNoise.selectedIndex!]){
                print("Selected String = \(self.ComfortNoise_table[self.ComfortNoise.selectedIndex!])")
                self.DSPTuningEnable()
                self.DSPTuningComfortNoise = true
                print("ComfortNoise_data = \(String(format: "0x%02X",self.ComfortNoise_Data[0])),\(String(format: "0x%02X",self.ComfortNoise_Data[1]))")
                //self.ComfortNoise_Data[0] = UInt8(self.ComfortNoise_ids[self.ComfortNoise.selectedIndex!]) >> 8
                //self.ComfortNoise_Data[1] = UInt8(self.ComfortNoise_ids[self.ComfortNoise.selectedIndex!])
                let DSP_Byte = ((0x8000 >> (self.ComfortNoise.selectedIndex!))-1)
                self.ComfortNoise_Data[0] = UInt8(DSP_Byte >> 8)
                self.ComfortNoise_Data[1] = UInt8(DSP_Byte & 0xFF)
                print("New value = \(String(format: "0x%02X",self.ComfortNoise_Data[0])),\(String(format: "0x%02X",self.ComfortNoise_Data[1]))")
            }
        }
        
        MC_Gain.didSelect{(selectedText , index , id) in
            if(self.MC_Gain.text != self.MC_Gain_table[self.MC_Gain.selectedIndex!]){
                self.MIC_Data[1] &= ~(0xf0)
                self.MIC_Data[1] |= UInt8(self.MC_Gain.selectedIndex!) << 4
                print("[MC_Gain]New value = \(String(format: "0x%02X",self.MIC_Data[1]))")
            }
        }
        
        MC_KR.didSelect{(selectedText , index , id) in
            if(self.MC_KR.text != self.MC_KR_table[self.MC_KR.selectedIndex!]){
                self.MIC_Data[1] &= (0xf0)
                self.MIC_Data[1] |= UInt8(self.MC_KR.selectedIndex!)
                print("[MC_KR]New value[1] = \(String(format: "0x%02X",self.MIC_Data[1]))")
            }
        }
        
        MC_RIT.didSelect{(selectedText , index , id) in
            if(self.MC_RIT.text != self.MC_RIT_table[self.MC_RIT.selectedIndex!]){
                self.MIC_Data[2] &= ~(0xf0)
                self.MIC_Data[2] |= UInt8((self.MC_RIT.selectedIndex!)+1) << 4
                print("[MC_RIT]New value[2] = \(String(format: "0x%02X",self.MIC_Data[2]))")
            }
        }
        
        MC_WRT.didSelect{(selectedText , index , id) in
            if(self.MC_WRT.text != self.MC_WRT_table[self.MC_WRT.selectedIndex!]){
                self.MIC_Data[2] &= (0xf0)
                self.MIC_Data[2] |= UInt8((self.MC_WRT.selectedIndex!)+2)
                print("[MC_WRT]New value[2] = \(String(format: "0x%02X",self.MIC_Data[2]))")
            }
        }

        DG_SPKOUT.didSelect{(selectedText , index , id) in
            if(self.DG_SPKOUT.text != self.DG_table[self.DG_SPKOUT.selectedIndex!]){
                if(self.DG_SPKOUT.selectedIndex! == 0){
                    self.MIC_Data[3] = 0
                }
                else{
                    self.MIC_Data[3] = UInt8((self.DG_SPKOUT.selectedIndex! << 1) + 1)
                }
                print("[DG_SPKOUT]New value[3] = \(String(format: "0x%02X",self.MIC_Data[3]))")
            }
        }
        
        DG_Line.didSelect{(selectedText , index , id) in
            if(self.DG_Line.text != self.DG_table[self.DG_Line.selectedIndex!]){
                if(self.DG_Line.selectedIndex! == 0){
                    self.MIC_Data[4] = 0
                }
                else{
                    self.MIC_Data[4] = UInt8((self.DG_Line.selectedIndex! << 1) + 1)
                }
                print("[DG_Line]New value[4] = \(String(format: "0x%02X",self.MIC_Data[4]))")
            }
        }
        
        DG_MIC1.didSelect{(selectedText , index , id) in
            if(self.DG_MIC1.text != self.DG_table[self.DG_MIC1.selectedIndex!]){
                if(self.DG_MIC1.selectedIndex! == 0){
                    self.MIC_Data[5] = 0
                }
                else{
                    self.MIC_Data[5] = UInt8((self.DG_MIC1.selectedIndex! << 1) + 1)
                }
                print("[DG_MIC1]New value[5] = \(String(format: "0x%02X",self.MIC_Data[5]))")
            }
        }
        
        Mic_Gain.listWillAppear {
            print("Mic_Gain.listWillAppear")
            self.Mic_Gain_List = true
            
            self.GUI_HideTextfield(status: 8)
        }
        
        Mic_Gain.listDidDisappear {
            self.Mic_Gain_List = false
            
            self.GUI_ShowTextfield(status: 8)
        }
        
        ComfortNoise.listWillAppear {
            self.ComfortNoise_List = true
            
            self.GUI_HideTextfield(status: 7)
        }
        
        ComfortNoise.listDidDisappear {
            self.ComfortNoise_List = false

            self.GUI_ShowTextfield(status: 7)
        }
    
        MC_Gain.listWillAppear {
            self.MC_Gain_List = true
            
            self.GUI_HideTextfield(status: 6)
        }
        
        MC_Gain.listDidDisappear {
            self.MC_Gain_List = false
            
            self.GUI_ShowTextfield(status: 6)
        }
        
        MC_KR.listWillAppear {
            self.MC_KR_List = true
            
            self.GUI_HideTextfield(status: 5)
        }
        
        MC_KR.listDidDisappear {
            self.MC_KR_List = false
            
            self.GUI_ShowTextfield(status: 5)
        }
        
        MC_RIT.listWillAppear {
            self.MC_RIT_List = true
            
            self.GUI_HideTextfield(status: 4)
        }
        
        MC_RIT.listDidDisappear {
            self.MC_RIT_List = false
            
            self.GUI_ShowTextfield(status: 4)
        }
        
        MC_WRT.listWillAppear {
            self.MC_WRT_List = true
            
            self.GUI_HideTextfield(status: 3)
        }
        
        MC_WRT.listDidDisappear {
            self.MC_WRT_List = false
            
            self.GUI_ShowTextfield(status: 3)
        }
        
        DG_SPKOUT.listWillAppear {
            self.DG_SPKOUT_List = true
            
            self.GUI_HideTextfield(status: 2)
        }
        
        DG_SPKOUT.listDidDisappear {
            self.DG_SPKOUT_List = false
            
            self.GUI_ShowTextfield(status: 2)
        }
        
        DG_Line.listWillAppear {
            self.DG_Line_List = true
            
            self.GUI_HideTextfield(status: 1)
        }
        
        DG_Line.listDidDisappear {
            self.DG_Line_List = false
            
            self.GUI_ShowTextfield(status: 1)
        }
        
        DG_MIC1.listWillAppear {
            self.DG_MIC1_List = true
            
            self.GUI_HideTextfield(status: 0)
        }
        
        DG_MIC1.listDidDisappear {
            self.DG_MIC1_List = false
            
            self.GUI_ShowTextfield(status: 0)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[MICGainViewController] viewWillAppear")
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            //DSPState.text = DSPManager?.DSP_DUT_State
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "MIC Gain/ComfortNoise")
        
        if(Mic_Gain.text == ""){
            DSPTuningDisable()
            DSPManager?.Get_Voice_MIC_Gain()
        }
        
        /*
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport){
            Mic_Gain.isUserInteractionEnabled = false
            ComfortNoise.isUserInteractionEnabled = false
            DSPTuningDisable()
        }*/
        
        if(DSPState.text == "DSP Status: "){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
        
        if(DSPManager?.RefreshGUIData(UIView_index: 6) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 6)
            self.DSPTuningMicGain = false
            self.DSPTuningComfortNoise = false
            DSPTuningDisable()
            DSPManager?.Get_Voice_MIC_Gain()
        }
        
        if(Hidden == nil){
            DSPTuningState(state: "MIC Gain/ComfortNoise")
        }
     
        /*
        //Simulator
        Mic_Gain.selectedIndex = 6
        Mic_Gain.text = Mic_Gain_table[Mic_Gain.selectedIndex!]
        ComfortNoise.selectedIndex = 0
        ComfortNoise.text = ComfortNoise_table[ComfortNoise.selectedIndex!]
        */
    }
    
    func GUI_HideTextfield(status:Int){
        print("GUI_HideTextfield = \(status)")
        
        if(self.ComfortNoise_List == true && status >= 8){
            self.ComfortNoise.hideList()
        }
        
        if(self.MC_Gain_List == true && status >= 7){
            self.MC_Gain.hideList()
        }
        
        if(self.MC_KR_List == true && status >= 6){
            self.MC_KR.hideList()
        }
        
        if(self.MC_RIT_List == true && status >= 5){
            self.MC_RIT.hideList()
        }
        
        if(self.MC_WRT_List == true && status >= 4){
            self.MC_WRT.hideList()
        }
        
        if(self.DG_SPKOUT_List == true && status >= 3){
            self.DG_SPKOUT.hideList()
        }
        
        if(self.DG_Line_List == true && status >= 2){
            self.DG_Line.hideList()
        }
        
        if(self.DG_MIC1_List == true && status >= 1){
            self.DG_MIC1.hideList()
        }
        
        if(status >= 8){
            self.ComfortNoise.isHidden = true
        }
        
        if(status >= 7){
            self.MC_Gain.isHidden = true
        }
            
        if(status >= 6){
            self.MC_KR.isHidden = true
        }
        
        if(status >= 5){
            self.MC_RIT.isHidden = true
        }
        
        if(status >= 4){
            self.MC_WRT.isHidden = true
        }
        
        if(status >= 3){
            self.DG_SPKOUT.isHidden = true
        }
        
        if(status >= 2){
            self.DG_Line.isHidden = true
        }
        
        if(status >= 1){
            self.DG_MIC1.isHidden = true
        }
        
        self.TuneDSP.isHidden = true
    }
    
    func GUI_ShowTextfield(status:Int){
        print("GUI_ShowTextfield = \(status)")
        
        var display = false
        if(status >= 7){
            if(self.Mic_Gain_List == false){
                display = true
            }
        }
        else if(status >= 6){
            if(self.Mic_Gain_List == false && self.ComfortNoise_List == false){
                display = true
            }
        }
        else if(status >= 5){
            if(self.Mic_Gain_List == false && self.ComfortNoise_List == false && self.MC_Gain_List == false){
                display = true
            }
        }
        else if(status >= 4){
            if(self.Mic_Gain_List == false && self.ComfortNoise_List == false && self.MC_Gain_List == false && self.MC_KR_List == false){
                display = true
            }
        }
        else if(status >= 3){
            if(self.Mic_Gain_List == false && self.ComfortNoise_List == false && self.MC_Gain_List == false && self.MC_KR_List == false && MC_RIT_List == false){
                display = true
            }
        }
        else if(status >= 2){
            if(self.Mic_Gain_List == false && self.ComfortNoise_List == false && self.MC_Gain_List == false && self.MC_KR_List == false && MC_RIT_List == false && MC_WRT_List == false){
                display = true
            }
        }
        else if(status >= 1){
            if(self.Mic_Gain_List == false && self.ComfortNoise_List == false && self.MC_Gain_List == false && self.MC_KR_List == false && MC_RIT_List == false && MC_WRT_List == false && self.DG_SPKOUT_List == false){
                display = true
            }
        }
        else if(status == 0){
            if(self.Mic_Gain_List == false && self.ComfortNoise_List == false && self.MC_Gain_List == false && self.MC_KR_List == false && MC_RIT_List == false && MC_WRT_List == false && self.DG_SPKOUT_List == false && self.DG_Line_List == false){
                display = true
            }
        }
        
        print("display = \(display)")
        
        if(status >= 8){
            self.ComfortNoise.isHidden = false
        }
        if(status >= 7){
            if(display){
                //self.MC_Gain.isHidden = false
                self.MC_Gain.isHidden = self.Hidden!
            }
        }
        if(status >= 6){
            if(display){
                //self.MC_KR.isHidden = false
                self.MC_KR.isHidden = self.Hidden!
            }
        }
        if(status >= 5){
            if(display){
                //self.MC_RIT.isHidden = false
                self.MC_RIT.isHidden = self.Hidden!
            }
        }
        if(status >= 4){
            if(display){
                //self.MC_WRT.isHidden = false
                self.MC_WRT.isHidden = self.Hidden!
            }
        }
        if(status >= 3){
            if(display){
                //self.DG_SPKOUT.isHidden = false
                self.DG_SPKOUT.isHidden = self.Hidden!
            }
        }
        if(status >= 2){
            if(display){
                //self.DG_Line.isHidden = false
                self.DG_Line.isHidden = self.Hidden!
            }
        }
        if(status >= 1){
            if(display){
                //self.DG_MIC1.isHidden = false
                self.DG_MIC1.isHidden = self.Hidden!
            }
        }
        
        if(display){
            self.TuneDSP.isHidden = false
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[MIC Gain]viewWillDisappear")
        
        if(TuneDSP.isEnabled == true){
            if(DSPTuningMicGain == true){
                if(MIC_Data.count != 0){
                    let tmp1 = NSData(bytes: &MIC_Data, length: MIC_Data.count)
                    print("tmp1 = \(tmp1)")
                    let tmp2 = NSData(bytes: &MIC_Prev_Data, length: MIC_Prev_Data.count)
                    print("tmp2 = \(tmp2)")
                    if(tmp1.isEqual(to: tmp2 as Data) == false){
                        DSPManager?.DSPQueueData(module:0x0D, cfg:0x04, len:UInt8(MIC_Data.count), data:MIC_Data)
                        MIC_Prev_Data.removeAll()
                        MIC_Prev_Data = MIC_Data
                    }
                }
            }
            
            if(DSPTuningComfortNoise == true){
                if(ComfortNoise_Data.count != 0){
                    let tmp1 = NSData(bytes: &ComfortNoise_Data, length: ComfortNoise_Data.count)
                    print("tmp1 = \(tmp1)")
                    let tmp2 = NSData(bytes: &ComfortNoise_Prev_Data, length: ComfortNoise_Prev_Data.count)
                    print("tmp2 = \(tmp2)")
                    if(tmp1.isEqual(to: tmp2 as Data) == false){
                        DSPManager?.DSPQueueData(module:0x0D, cfg:0x03, len:UInt8(ComfortNoise_Data.count), data:ComfortNoise_Data)
                        ComfortNoise_Prev_Data.removeAll()
                        ComfortNoise_Prev_Data = ComfortNoise_Data
                    }
                }
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func ResetParameters(_ sender: Any) {
        print("ResetParameters")
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        if(DSPTuningMicGain == true && DSPTuningComfortNoise == false){
            if(MIC_Data.count != 0){
                print("DSPTuning: MIC Gain")
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x04, len: UInt8(MIC_Data.count), data: MIC_Data)
            }
        }
        else if(DSPTuningMicGain == false && DSPTuningComfortNoise == true){
            if(ComfortNoise_Data.count != 0){
                print("DSPTuning: Comfort Noise")
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x03, len: UInt8(ComfortNoise_Data.count), data: ComfortNoise_Data)
            }
        }
        else if(DSPTuningMicGain == true && DSPTuningComfortNoise == true){
            if(MIC_Data.count != 0 && ComfortNoise_Data.count != 0){
                print("DSPTuning: MicGain&ComfortNoise")
                DSPManager?.DSPTuning2(module: 0x0D, cfg1: 0x04, cfg2: 0x03, len1: UInt8(MIC_Data.count), len2: UInt8(ComfortNoise_Data.count), data1: MIC_Data, data2: ComfortNoise_Data)
            }
        }
    }
    
    func Voice_Data_Init(){
        print("Voice_Data_Init")
        
        if(MIC_Data.count != 0){
            for index in 0..<Mic_Gain_ids.count {
                if(MIC_Data[0] == Mic_Gain_ids[index]){
                    Mic_Gain.selectedIndex = index
                    Mic_Gain.text = Mic_Gain_table[Mic_Gain.selectedIndex!]
                }
            }
            
            //Hidden function
            MC_Gain.selectedIndex = Int((MIC_Data[1] & 0xf0) >> 4)
            MC_Gain.text = MC_Gain_table[MC_Gain.selectedIndex!]
            
            MC_KR.selectedIndex = Int(MIC_Data[1] & 0x0f)
            MC_KR.text = MC_KR_table[MC_KR.selectedIndex!]
            
            MC_RIT.selectedIndex = Int((MIC_Data[2] & 0xf0) >> 4)-1
            MC_RIT.text = MC_RIT_table[MC_RIT.selectedIndex!]
            
            MC_WRT.selectedIndex = Int((MIC_Data[2] & 0x0f))-2
            MC_WRT.text = MC_WRT_table[MC_WRT.selectedIndex!]
            
            if(MIC_Data[3] == 0){
                DG_SPKOUT.selectedIndex = 0
            }
            else{
                DG_SPKOUT.selectedIndex = Int((MIC_Data[3]-1) >> 1)
            }
            DG_SPKOUT.text = DG_table[DG_SPKOUT.selectedIndex!]
            
            if(MIC_Data[4] == 0){
                DG_Line.selectedIndex = 0
            }
            else{
                DG_Line.selectedIndex = Int((MIC_Data[4]-1) >> 1)
            }
            DG_Line.text = DG_table[DG_Line.selectedIndex!]
            
            if(MIC_Data[5] == 0){
                DG_MIC1.selectedIndex = 0
            }
            else{
                DG_MIC1.selectedIndex = Int((MIC_Data[5]-1) >> 1)
            }
            DG_MIC1.text = DG_table[DG_MIC1.selectedIndex!]
        }
        
        if(ComfortNoise_Data.count != 0){
            let noise : UInt = UInt((ComfortNoise_Data[0] << 8) + ComfortNoise_Data[1])
            print("ComfortNoise = \(noise)")
            var i: Int = 0
            var DSP_Byte: UInt = 1 << 15
            while((noise+1) < DSP_Byte){
                i += 1
                DSP_Byte = DSP_Byte >> 1
            }
            ComfortNoise.selectedIndex = i
            ComfortNoise.text = ComfortNoise_table[ComfortNoise.selectedIndex!]
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[MIC Gain] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        print("[Voice MIC] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 3){
                for index in 0..<3 {
                    ComfortNoise_Data.append(buffer[k+3+index])
                }
                print("ComfortNoise_Data = \(ComfortNoise_Data)")
                ComfortNoise_Prev_Data.removeAll()
                ComfortNoise_Prev_Data = ComfortNoise_Data
                
                let noise : UInt = UInt((ComfortNoise_Data[0] << 8) + ComfortNoise_Data[1])
                print("ComfortNoise = \(noise)")
                
            }
            else if(buffer[k] == 13 && buffer[k+1] == 4){
                for index in 0..<6 {
                    MIC_Data.append(buffer[k+3+index])
                }
                print("MIC_Data = \(MIC_Data)")
                MIC_Prev_Data.removeAll()
                MIC_Prev_Data = MIC_Data
            }
            
            k += Int(3+len)
        }
        
        Voice_Data_Init()
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPTuningMicGain = false
            self.DSPTuningComfortNoise = false
            self.DSPManager?.ClearRefreshFlag(UIView_index: 6)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String) {
        //print("MIC Gain:DSP State")
        if(state == "MIC Gain/ComfortNoise"){
            print("[MIC Gain/ComfortNoise] Update GUI")
            
            if(Mic_Gain_List == true || ComfortNoise_List == true){
                return
            }
            
            if(Hidden == nil){
                Hidden = true
            }
            else{
                if(Hidden!){
                    Hidden = false
                }
                else{
                    Hidden = true
                }
            }
            print("Hidden = \(Hidden)")
            
            MC_Gain.isHidden = Hidden!
            MC_KR.isHidden = Hidden!
            MC_RIT.isHidden = Hidden!
            MC_WRT.isHidden = Hidden!
            
            DG_SPKOUT.isHidden = Hidden!
            DG_Line.isHidden = Hidden!
            DG_MIC1.isHidden = Hidden!
            
            MC_Gain_Label.isHidden = Hidden!
            MC_KR_Label.isHidden = Hidden!
            MC_RIT_Label.isHidden = Hidden!
            MC_WRT_Label.isHidden = Hidden!
            DG_SPKOUT_Label.isHidden = Hidden!
            DG_Line_Label.isHidden = Hidden!
            DG_MIC1_Label.isHidden = Hidden!
        
            return
        }
        
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(Mic_Gain_List == true){
                Mic_Gain_List = false
                Mic_Gain.hideList()
            }
            Mic_Gain.isUserInteractionEnabled = false
            
            if(ComfortNoise_List == true){
                ComfortNoise_List = false
                ComfortNoise.hideList()
            }
            ComfortNoise.isUserInteractionEnabled = false
            
            if(self.MC_Gain_List == true){
                self.MC_Gain.hideList()
            }
            self.MC_Gain.isUserInteractionEnabled = false
            
            if(self.MC_KR_List == true){
                self.MC_KR.hideList()
            }
            self.MC_KR.isUserInteractionEnabled = false
            
            if(self.MC_RIT_List == true){
                self.MC_RIT.hideList()
            }
            self.MC_RIT.isUserInteractionEnabled = false
            
            if(self.MC_WRT_List == true){
                self.MC_WRT.hideList()
            }
            self.MC_WRT.isUserInteractionEnabled = false
            
            if(self.DG_SPKOUT_List == true){
                self.DG_SPKOUT.hideList()
            }
            self.DG_SPKOUT.isUserInteractionEnabled = false
            
            if(self.DG_Line_List == true){
                self.DG_Line.hideList()
            }
            self.DG_Line.isUserInteractionEnabled = false
            
            if(self.DG_MIC1_List == true){
                self.DG_MIC1.hideList()
            }
            self.DG_MIC1.isUserInteractionEnabled = false
            
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            Mic_Gain.isUserInteractionEnabled = true
            ComfortNoise.isUserInteractionEnabled = true
            self.MC_Gain.isUserInteractionEnabled = true
            self.MC_KR.isUserInteractionEnabled = true
            self.MC_RIT.isUserInteractionEnabled = true
            self.MC_WRT.isUserInteractionEnabled = true
            self.DG_SPKOUT.isUserInteractionEnabled = true
            self.DG_Line.isUserInteractionEnabled = true
            self.DG_MIC1.isUserInteractionEnabled = true
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
