//
//  PlaybackControlViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 22/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "PlaybackControlViewController.h"
#import "UIView+Toast.h"
#import "EqModeSettingViewController.h"
#import "AudioSettingMessageViewController.h"
#import "FileOps.h"
#import "SpeakerConnectionTableViewCell.h"
#import "VolumeControlTableViewCell.h"
#import "CurrentSourceTableViewCell.h"
#import "SlaveVolumeControlTableViewCell.h"
#import "ISUtility.h"


@interface PlaybackControlViewController (){
    BOOL A2DP_Connected;
    BOOL streamingNow;
    BOOL supportAudioSuorceToggleInEmbeddedMode;
    unsigned char playStatusValue;
    unsigned char btmStatusValue;
    NSString *remoteDeviceName;
    FileOps *logFiles;
    NSArray *PairingModeArr;
    BOOL PowerOn;
    unsigned char AuxInState;
    unsigned char actionSheetIdx;
    UITableViewController *individualSlaveVolumeControlTableViewController;
    CGRect myRect;
    //UIViewController *individualVolumeController;
}

@end

@implementation UIView (ParentTableViewCell)

-(UITableViewCell *)parentTableViewCell{
    UIView *aView = self.superview;
    while (aView != nil) {
        if ([aView isKindOfClass:[UITableViewCell class]]) {
            return (UITableViewCell *)aView;
        }
        aView = aView.superview;
    }
    return nil;
}
@end

@implementation PlaybackControlViewController

@synthesize DatabaseInfo;

#define PLAY_STATUS 0x01
#define PAIRING_STATE 0x01
#define POWER_OFF_STATE 0x00
#define POWER_ON_STATE 0x02
#define AUXIN_NOT_AVAILABLE 0x80
#define AUXIN_PLUGGED_AND_AUXING_PLAYING 0x81
#define AUXIN_PLUGGED_AND_A2DP_PLAYING 0x82

enum{
    MMI_ACTION_INCREASE_SPEAKER_GAIN = 0x30,
    MMI_ACTION_DECREASE_SPEAKER_GAIN = 0x31,
    MMI_ACTION_FASTER_ENTER_PAIRING = 0x5D,
    MMI_ACTION_EXIT_PAIRING = 0x6B,
    MMI_ACTION_NSPK_SOUND_SYNC = 0xF7,
};

enum{
    COMMAND_STOP_FORWARD_REWIND = 0x00,
    COMMAND_FORWARD,
    COMMAND_FORWARD_REPEAT,
    COMMAND_REWIND,
    COMMAND_REWIND_REPEAT,
    COMMAND_PLAY,
    COMMAND_PAUSE,
    COMMAND_PLAY_PAUSE_TOGGLE,
    COMMAND_STOP,
    COMMAND_NEXT,
    COMMAND_PREVIOUS,
};

enum{
    //INDEX_POWER_ON_OFF = 0x00,
    //INDEX_A2DP_NAME,
    INDEX_CURRENT_SOURCE = 0x00,
    INDEX_PAIRING_MODE,
    INDEX_SPEAKER_CONNECTION,
    INDEX_EQ_SETTING,
    INDEX_VOLUME_CONTROL,
    INDEX_INDIVIDUAL_SLAVE_VOLUME_CONTROL,
};

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"[PlaybackControlViewController] viewDidLoad");
    //self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    remoteDeviceName = [[NSString alloc]init];
    // Do any additional setup after loading the view.
    myTableView.delegate = self;
    myTableView.dataSource = self;
    
    myTableView.backgroundColor = [UIColor clearColor];
    
    _connectedPeripheral.fWVersionDelegate = self;
    _connectedPeripheral.playbackControlDelegate = self;
    //[_connectedPeripheral sendReadLinkStatus];
    
    PairingModeArr = [[NSArray alloc] initWithObjects:@"Enter Pairing",@"Exit Pairing", nil];
    
    self.title = @"Audio Control";
    
    /*if (_groupInfo.count < 4) {
        myRect = CGRectMake(15, 0, 272, 100);
    }else if (_groupInfo.count < 6){
        myRect = CGRectMake(15, 0, 272, 150);
    }else if (_groupInfo.count < 8){
        myRect = CGRectMake(15, 0, 272, 200);
    }else {
        myRect = CGRectMake(15, 0, 272, 250);
    }
    
    individualSlaveVolumeControlTableView  = [[UITableView alloc]initWithFrame:myRect];*/
    //individualSlaveVolumeControlTableView.delegate = self;
    //individualSlaveVolumeControlTableView.dataSource = self;
    //[individualSlaveVolumeControlTableView registerClass:[SlaveVolumeControlTableViewCell class] forCellReuseIdentifier:@"SLAVE_VOLUME_CONTROL_TABLEVIEW_CELL"];
    //[individualSlaveVolumeControlTableView registerClass:[VolumeControlTableViewCell class] forCellReuseIdentifier:@"VOLUME_CONTROL_TABLEVIEW_CELL"];


    
    /*UIBarButtonItem *logButton = [[UIBarButtonItem alloc] init];
     logButton.title = @"Log";
     logButton.target = self;
     [logButton setAction:@selector(displayContent)];
     self.navigationItem.rightBarButtonItem = logButton;*/
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshStatus) name:UIApplicationWillEnterForegroundNotification object:nil];
    
    audioSyncBtn.backgroundColor = [UIColor lightGrayColor];
    audioSyncBtn.layer.borderWidth = 2.0;
    audioSyncBtn.layer.cornerRadius = 10.0;
    
    supportAudioSuorceToggleInEmbeddedMode = FALSE;
    PowerOn = FALSE;
    AuxInState = AUXIN_NOT_AVAILABLE;
    A2DP_Connected = FALSE;
    [self updateControlState];
    audioSyncBtn.hidden = YES;
    if (_Feature_EmbeddedMode) {
        [_connectedPeripheral sendReadICVersionInformation];
    }
    
    if (_Feature_StereoMode || _Feature_ConcertMode) {
        [_connectedPeripheral sendReadnSPKStatus];
    }
    
    DatabaseInfo = 0x00;
}

- (void)viewDidAppear:(BOOL)animated {
    [self.navigationController.view hideToastActivity];
    [self refreshStatus];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)updatePlayPauseButton{
    if (playStatusValue == PLAY_STATUS) {
        UIImage *image = [UIImage imageNamed:@"pausebtn.png"];
        [playBtn setImage:image forState:UIControlStateNormal];
    }else{
        UIImage *image = [UIImage imageNamed:@"playbtn.png"];
        [playBtn setImage:image forState:UIControlStateNormal];
    }
}

-(void)updateControlState{
    bool on = FALSE;
    if ((AuxInState != AUXIN_PLUGGED_AND_AUXING_PLAYING) && A2DP_Connected && PowerOn) {
        on = TRUE;
    }
    playBtn.hidden = !on;
    nextBtn.hidden = !on;
    previousBtn.hidden = !on;
    stopBtn.hidden = !on;
}

- (void) refreshStatus{
    double delayInSeconds = 0.3;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    
    
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        //[_connectedPeripheral sendReadLinkedDeviceInformation:0x00];
        [_connectedPeripheral sendReadLinkedDeviceInformation:0x00 database:DatabaseInfo];
    });
    
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [_connectedPeripheral sendReadLinkStatus];
    });
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        if (!_Feature_EmbeddedMode) {
            [_connectedPeripheral sendReadAuxInStatus];
        }
        
    });
}

-(void) displayContent{
    
    logFiles = [[FileOps alloc] init];
    NSString *content = [logFiles readFromFile];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"LOG" message:content preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *dafaultAction = [UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){}];
    [alert addAction:dafaultAction];
    UIView *subView1 = alert.view.subviews[0];
    UIView *subView2 = subView1.subviews[0];
    UIView *subView3 = subView2.subviews[0];
    UIView *subView4 = subView3.subviews[0];
    UIView *subView5 = subView4.subviews[0];
    UILabel *contentView = subView5.subviews[1];
    contentView.textAlignment = NSTextAlignmentLeft;
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([[segue identifier] isEqualToString:@"FORCE_TO_EQ_MODE_SETTING"]){
        EqModeSettingViewController *view = segue.destinationViewController;
        view.connectedPeripheral = _connectedPeripheral;
        view.DatabaseInfo = DatabaseInfo;
    }
}


- (void)dealloc {
    [playBtn release];
    [nextBtn release];
    [previousBtn release];
    [myTableView release];
    _connectedPeripheral.playbackControlDelegate = nil;
    [audioSyncBtn release];
    [stopBtn release];
    [super dealloc];
}
- (IBAction)playBtnPressed:(id)sender {
    if (playStatusValue == PLAY_STATUS) {
        [_connectedPeripheral sendMusicControl:COMMAND_PAUSE];
    }else{
        [_connectedPeripheral sendMusicControl:COMMAND_PLAY];
    }
}

- (IBAction)nextBtnPressed:(id)sender {
    [_connectedPeripheral sendMusicControl:COMMAND_NEXT];
}

- (IBAction)previoceBtnPressed:(id)sender {
    [_connectedPeripheral sendMusicControl:COMMAND_PREVIOUS];
}

- (IBAction)audioSyncBtnPressed:(id)sender {
    //[_connectedPeripheral sendMmiAction:MMI_ACTION_NSPK_SOUND_SYNC];
    [_connectedPeripheral sendMmiAction:MMI_ACTION_NSPK_SOUND_SYNC databaseIndex:DatabaseInfo];
}

- (IBAction)stopBtnPressed:(id)sender {
    [_connectedPeripheral sendMusicControl:COMMAND_STOP];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == myTableView) {
        /**if ([_groupInfo count]>0) {
            return 6;
        }else{
            return 5;
        }*/
        return 5;
    }else{
        return [_groupInfo count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;// = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier" forIndexPath:indexPath];
    if (tableView == myTableView) {
        switch (indexPath.row) {
            case  INDEX_CURRENT_SOURCE:{
                CurrentSourceTableViewCell *cell = (CurrentSourceTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"AUDIO_SOURCE_TABLEVIEW_CELL"];
                if (AuxInState == AUXIN_PLUGGED_AND_AUXING_PLAYING) {
                    cell.AudioSourceLabel.text = @"Aux-In";
                }else{
                    cell.AudioSourceLabel.text = @"BT Audio";///audioSourceStr
                }
                [cell.AudioSourceToggleBtn addTarget:self action:@selector(actionToggleAudioSource:) forControlEvents:UIControlEventTouchUpInside];
                cell.backgroundColor = [UIColor clearColor];
                bool bEnable;// = (PowerOn & !_Feature_EmbeddedMode);
                if (_Feature_EmbeddedMode) {
                    bEnable = (PowerOn & supportAudioSuorceToggleInEmbeddedMode);
                }else{
                    bEnable = PowerOn;
                }
                cell.userInteractionEnabled = bEnable;
                cell.CellTitleLabel.enabled = bEnable;
                cell.AudioSourceToggleBtn.enabled = bEnable;
                return cell;
                
            }
                break;
            case INDEX_PAIRING_MODE:{
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"IndicatorCell"];
                cell.textLabel.text = @"Pairing Mode";
                if (btmStatusValue == PAIRING_STATE) {
                    cell.detailTextLabel.text = @"Pairing";
                }else{
                    cell.detailTextLabel.text = @"Off";
                }
                
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                cell.userInteractionEnabled = PowerOn;
                cell.textLabel.enabled = PowerOn;
                
            }
                break;
            case INDEX_SPEAKER_CONNECTION:{
                SpeakerConnectionTableViewCell *cell = (SpeakerConnectionTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"SPEAKER_CONNECTION_TABLEVIEW_CELL"];
                
                //cell.remoteDeviceName.text = remoteDeviceName;
                if (A2DP_Connected) {
                    cell.remoteDeviceName.text = remoteDeviceName;
                    cell.A2DP_Status.text = @"Connected";
                    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                }else{
                    cell.remoteDeviceName.text = @"not connected";
                    cell.A2DP_Status.text = @"Disconnected";
                    cell.accessoryType = UITableViewCellAccessoryNone;
                }
                cell.userInteractionEnabled = PowerOn;
                cell.remoteDeviceName.enabled = PowerOn;
                cell.CellTitleLabel.enabled = PowerOn;
                cell.backgroundColor = [UIColor clearColor];
                return cell;
            }
                break;
            case INDEX_EQ_SETTING:{
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"IndicatorCell"];
                cell.textLabel.text = @"Equalizer Setting";
                cell.detailTextLabel.text = @"Edit";
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                cell.userInteractionEnabled = PowerOn;
                cell.textLabel.enabled = PowerOn;
            }
                break;
            case INDEX_VOLUME_CONTROL:{
                VolumeControlTableViewCell *cell = (VolumeControlTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"VOLUME_CONTROL_TABLEVIEW_CELL"];
                [cell.volumeDownBtn addTarget:self action:@selector(actionVolumeDown:) forControlEvents:UIControlEventTouchUpInside];
                [cell.volumeUpBtn addTarget:self action:@selector(actionVolumeUp:) forControlEvents:UIControlEventTouchUpInside];
                cell.userInteractionEnabled = PowerOn;
                cell.volumeDownBtn.enabled = PowerOn;
                cell.volumeUpBtn.enabled = PowerOn;
                
                cell.backgroundColor = [UIColor clearColor];
                return cell;
            }
                break;
            case INDEX_INDIVIDUAL_SLAVE_VOLUME_CONTROL:{
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"IndicatorCell"];
                cell.textLabel.text = @"Group Volume Control";
                cell.detailTextLabel.text = @"";
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                cell.userInteractionEnabled = PowerOn;
                cell.textLabel.enabled = PowerOn;
            }

        }
    }else{
        SlaveVolumeControlTableViewCell *cell = (SlaveVolumeControlTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"SLAVE_VOLUME_CONTROL_TABLEVIEW_CELL"];
        MyPeripheral *tmpPeripheral = [_groupInfo objectAtIndex:indexPath.row];
        
        [cell.volumeDownBtn addTarget:self action:@selector(actionSlaveVolumeDown:) forControlEvents:UIControlEventTouchUpInside];
        [cell.volumeUpBtn addTarget:self action:@selector(actionSlaveVolumeUp:) forControlEvents:UIControlEventTouchUpInside];
        cell.volumeDownBtn.tag =indexPath.row;
        cell.volumeUpBtn.tag =indexPath.row;
        cell.userInteractionEnabled = PowerOn;
        cell.volumeDownBtn.enabled = PowerOn;
        cell.volumeUpBtn.enabled = PowerOn;
        cell.slaveNameLabel.text = tmpPeripheral.deviceName;
        NSLog(@"%@",tmpPeripheral.deviceName);
        //cell.backgroundColor = [UIColor clearColor];
        /*VolumeControlTableViewCell *cell = (VolumeControlTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"VOLUME_CONTROL_TABLEVIEW_CELL"];
        [cell.volumeDownBtn addTarget:self action:@selector(actionVolumeDown:) forControlEvents:UIControlEventTouchUpInside];
        [cell.volumeUpBtn addTarget:self action:@selector(actionVolumeUp:) forControlEvents:UIControlEventTouchUpInside];
        cell.userInteractionEnabled = PowerOn;
        cell.volumeDownBtn.enabled = PowerOn;
        cell.volumeUpBtn.enabled = PowerOn;
        
        cell.backgroundColor = [UIColor clearColor];*/
        return cell;
    }
        cell.backgroundColor = [UIColor clearColor];
        cell.textLabel.font = [UIFont fontWithName:@"System" size:17.0];
        return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    /*if (tableView == individualSlaveVolumeControlTableViewController.tableView) {
        return 50;
    }else{
        if ((indexPath.row == 0) || (indexPath.row == 2) || (indexPath.row == 4)) {
            return 50;
        }else
            return 50;
    }*/
    return 50;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    actionSheetIdx = indexPath.row;
    if (tableView == myTableView) {
        switch (indexPath.row) {
            case INDEX_PAIRING_MODE:{
                UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Set Speaker as:" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil];
                
                for(NSString *title in PairingModeArr){
                    [actionSheet addButtonWithTitle:title];
                }
                
                [actionSheet addButtonWithTitle:@"Cancel"];
                actionSheet.cancelButtonIndex = [PairingModeArr count];
                
                actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
                [actionSheet showInView:self.view];
            }
                break;
            case INDEX_SPEAKER_CONNECTION:{
                if (!A2DP_Connected) {
                    break;
                }
                UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Set Speaker:" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil];
                
                [actionSheet addButtonWithTitle:@"Disconnect"];
                [actionSheet addButtonWithTitle:@"Cancel"];
                actionSheet.cancelButtonIndex = 1;
                
                actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
                [actionSheet showInView:self.view];
            }
                break;
            case INDEX_EQ_SETTING:{
                [self performSegueWithIdentifier:@"FORCE_TO_EQ_MODE_SETTING" sender:self];
            }
                break;
            case INDEX_INDIVIDUAL_SLAVE_VOLUME_CONTROL:{
                UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                //individualSlaveVolumeControlTableView = [sb instantiateViewControllerWithIdentifier:@"IMDIVIDUAL_SLAVE_VOLUME_CONTROL_TABLE_VIEW_CONTROLLER"];
                individualSlaveVolumeControlTableViewController = [sb instantiateViewControllerWithIdentifier:@"IMDIVIDUAL_SLAVE_VOLUME_CONTROL_TABLE_VIEW_CONTROLLER"];
                individualSlaveVolumeControlTableViewController.tableView.delegate = self;
                individualSlaveVolumeControlTableViewController.tableView.dataSource = self;
                //[controller setPreferredContentSize:myRect.size];
                //individualSlaveVolumeControlTableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
                //[individualSlaveVolumeControlTableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
                //individualSlaveVolumeControlTableView.backgroundColor = [UIColor whiteColor];
                //[alertTableView setTag:kAlertTableViewTag];
                /*individualSlaveVolumeControlTableViewController.tableView
                 [controller.view addSubview:individualSlaveVolumeControlTableView];
                 [controller.view bringSubviewToFront:individualSlaveVolumeControlTableView];
                 [controller.view setUserInteractionEnabled:YES];
                 [individualSlaveVolumeControlTableView setUserInteractionEnabled:YES];
                 [individualSlaveVolumeControlTableView setAllowsSelection:YES];*/
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Individual Voulme Control" message:@"" preferredStyle:UIAlertControllerStyleActionSheet];
                [alertController setValue:individualSlaveVolumeControlTableViewController forKey:@"contentViewController"];
                UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
                    
                }];
                [alertController addAction:cancelAction];
                [self presentViewController:alertController animated:YES completion:nil];
                
            }
                break;
            default:
                break;
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Action button function
- (void)actionToggleAudioSource:(id)sender {
    [_connectedPeripheral sendToggleAudioSource];
}

- (void)actionVolumeUp:(id)sender {
    //[_connectedPeripheral sendMmiAction:MMI_ACTION_INCREASE_SPEAKER_GAIN];
    [_connectedPeripheral sendMmiAction:MMI_ACTION_INCREASE_SPEAKER_GAIN databaseIndex:DatabaseInfo];
}

- (void)actionVolumeDown:(id)sender {
    //[_connectedPeripheral sendMmiAction:MMI_ACTION_DECREASE_SPEAKER_GAIN];
    [_connectedPeripheral sendMmiAction:MMI_ACTION_DECREASE_SPEAKER_GAIN databaseIndex:DatabaseInfo];
}

- (void)actionSlaveVolumeUp:(id)sender {
    UIButton *button = (UIButton *)sender;
    MyPeripheral *tmpPeripheral = [_groupInfo objectAtIndex:button.tag];
    CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
    id serviceData = [tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
    id Data = [serviceData objectForKey:uuid];
    unsigned char *dataByte;
    dataByte = malloc([Data length]);
    [Data getBytes:dataByte length:[Data length]];
    struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
    NSData* addr = [NSData dataWithBytes:discoveredSpecialData->extendData.category1_par.btAddress length:6];
    NSData* reverseData = [ISUtility reverseData:addr];
    //sendIndividualVolumeControl
    [_connectedPeripheral sendIndividualVolumeControl:MMI_ACTION_INCREASE_SPEAKER_GAIN btAddress:reverseData];
}

- (void)actionSlaveVolumeDown:(id)sender {
    UIButton *button = (UIButton *)sender;
    MyPeripheral *tmpPeripheral = [_groupInfo objectAtIndex:button.tag];
    CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
    id serviceData = [tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
    id Data = [serviceData objectForKey:uuid];
    unsigned char *dataByte;
    dataByte = malloc([Data length]);
    [Data getBytes:dataByte length:[Data length]];
    struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
    NSData* addr = [NSData dataWithBytes:discoveredSpecialData->extendData.category1_par.btAddress length:6];
    NSData* reverseData = [ISUtility reverseData:addr];
    //sendIndividualVolumeControl
    [_connectedPeripheral sendIndividualVolumeControl:MMI_ACTION_DECREASE_SPEAKER_GAIN btAddress:reverseData];
}


#pragma mark - UIActionSheetDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"actionSheet button:%d",(int)buttonIndex);
    if(actionSheetIdx == INDEX_PAIRING_MODE){
        switch (buttonIndex) {
            case 0:
                //[_connectedPeripheral sendMmiAction:MMI_ACTION_FASTER_ENTER_PAIRING];
                [_connectedPeripheral sendMmiAction:MMI_ACTION_FASTER_ENTER_PAIRING databaseIndex:DatabaseInfo];
                break;
            case 1:
                //[_connectedPeripheral sendMmiAction:MMI_ACTION_EXIT_PAIRING];
                [_connectedPeripheral sendMmiAction:MMI_ACTION_EXIT_PAIRING databaseIndex:DatabaseInfo];
                break;
            default:
                break;
        }
    }else if(actionSheetIdx == INDEX_SPEAKER_CONNECTION){
        switch (buttonIndex) {
            case 0:
                [_connectedPeripheral sendDisconnectionFlag:0x07];
                break;
            default:
                break;
        }
    }
}

#pragma mark - MyPeripheral playbackControl delegate
- (void)MyPeripheral:(MyPeripheral *)peripheral didLinkA2DP:(BOOL)A2DP btmStatus:(unsigned char)btmStatus playStatus:(unsigned char)playStatus streaming:(BOOL)streaming database:(unsigned char)database{
    NSLog(@"didLinkA2DP..");
    
    A2DP_Connected = A2DP;
    streamingNow = streaming;
    playStatusValue = playStatus;
    btmStatusValue = btmStatus;
    
    if (btmStatus == POWER_OFF_STATE) {
        PowerOn = FALSE;
    }else{
        PowerOn = TRUE;
    }
    
    [self updatePlayPauseButton];
    [self updateControlState];
    [myTableView reloadData];
    
    if(database < 2) {
        if(DatabaseInfo != database){
            DatabaseInfo = database;
            double delayInSeconds = 0.3;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                [_connectedPeripheral sendReadLinkedDeviceInformation:0x00 database:DatabaseInfo];
            });
        }
    }
}

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateBtmStatus:(unsigned char)btmStatus{
    double delayInSeconds = 0.3;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    if ((btmStatus == AUXIN_NOT_AVAILABLE) || (btmStatus == AUXIN_PLUGGED_AND_AUXING_PLAYING) || (btmStatus == AUXIN_PLUGGED_AND_A2DP_PLAYING) ) {
        AuxInState = btmStatus;
    }
    else
        btmStatusValue = btmStatus;
    
    if (btmStatus == POWER_OFF_STATE) {
        PowerOn = FALSE;
    }else if(btmStatus == POWER_ON_STATE){
        PowerOn = TRUE;
    }
    [self updateControlState];
    [myTableView reloadData];
    
    if((btmStatus == 0x0B) || (btmStatus == 0x08)){
        //[_connectedPeripheral sendReadLinkedDeviceInformation:0x00];
        [_connectedPeripheral sendReadLinkedDeviceInformation:0x00 database:DatabaseInfo];
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [_connectedPeripheral sendReadLinkStatus]; ///Master
        });
    }
}

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdatePlayerStatus:(unsigned char)playStatus{
    playStatusValue = playStatus;
    [self updatePlayPauseButton];
    [myTableView reloadData];
}

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateRemoteDeviceName:(NSString *)name{
    if (name == nil) {
        remoteDeviceName = @"not connected";
    }else{
        remoteDeviceName = name;
    }
    
    [myTableView reloadData];
}

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateGroupConnectionState:(unsigned char)state CSB_State:(unsigned char)csbState{
    BOOL on = YES;
    if (state != 0x00) {
        on = NO;
    }
    audioSyncBtn.hidden = on;
}

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateIcVersionIn:(NSString *)bodyVersion romVersion:(unsigned char)romVersion romSubVersion:(unsigned char)romSubVersion segment:(unsigned char)segment eepromTableVersion:(unsigned char)eepromTableVersion eepromTableSubVersion:(unsigned char)eepromTableSubVersion dspVersion:(unsigned char)dspVersion{
    if ([bodyVersion isEqualToString:@"5506_DUAL_SPK"]) {
        supportAudioSuorceToggleInEmbeddedMode = TRUE;
        //fwVersion = [[NSString alloc] initWithFormat:@"v%02X.%02X",romVersion,romSubVersion];
        [myTableView reloadData];
    }
}

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateDatabase:(unsigned char)database{
    NSLog(@"didUpdateDatabase = %d,%d",DatabaseInfo,database);
    
    if(DatabaseInfo != database){
        DatabaseInfo = database;
        [self refreshStatus];
    }
}

@end
