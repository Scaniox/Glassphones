//
//  MyPeripheral.h
//  BLETR
//
//  Created by D500 user on 13/5/30.
//  Copyright (c) 2013年 ISSC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "ReliableBurstData.h"

#define AIR_PATCH_COMMAND_VENDOR_MP_ENABLE      0x03
#define AIR_PATCH_COMMAND_XMEMOTY_READ          0x08
#define AIR_PATCH_COMMAND_XMEMOTY_WRITE         0x09
#define AIR_PATCH_COMMAND_E2PROM_READ           0x0a
#define AIR_PATCH_COMMAND_E2PROM_WRITE          0x0b
#define AIR_PATCH_COMMAND_READ_HW_VERSION       0x12
#define AIR_PATCH_COMMAND_READ_FW_VERSION       0x16
#define AIR_PATCH_COMMAND_READ                  0x24

#define AIR_PATCH_SUCCESS   0x00
#define AIR_PATCH_INVALID_PARAMETERS      0x02

#define AIR_PATCH_ACTION_CHANGE_DEVICE_NAME     0X01
#define AIR_PATCH_ACTION_READ_ADVERTISE_DATA1   0X02
#define AIR_PATCH_ACTION_READ_ADVERTISE_DATA2   0X03
#define AIR_PATCH_ACTION_UPDATE_ADVERTISE_DATA  0X04
#define AIR_PATCH_ACTION_CHANGE_DEVICE_NAME_MEMORY     0X05
#define AIR_PATCH_ACTION_READ                   0X24

#define ADVERTISE_DATA_TYPE_COMPLETE_DEVICE_NAME 0X09
#define ADVERTISE_DATA_TYPE_SHORTEN_DEVICE_NAME  0X08

enum {
    MYPERIPHERAL_CONNECT_STATUS_IDLE = 0,
    MYPERIPHERAL_CONNECT_STATUS_CONNECTING,
    MYPERIPHERAL_CONNECT_STATUS_CONNECTED,
};

enum {
    UPDATE_PARAMETERS_STEP_PREPARE = 0,
    UPDATE_PARAMETERS_STEP_CHECK_RESULT,
};
typedef struct _AIR_PATCH_COMMAND_FORMAT
{
    unsigned char commandID;
    char parameters[19];
}__attribute__((packed)) AIR_PATCH_COMMAND_FORMAT;

typedef struct _AIR_PATCH_EVENT_FORMAT
{
    char    status;
    unsigned char commandID;
    char parameters[16];
}__attribute__((packed)) AIR_PATCH_EVENT_FORMAT;

typedef struct _GROUP_STATUS_FORMAT
{
    unsigned int btConnectable:1;
    unsigned int outputChannel:3;
    unsigned int roleOfGroup:1;
    unsigned int groupStatus:3;
}__attribute__((packed)) GROUP_STATUS_FORMAT;

typedef struct _DATA_CATEGORY_FORMAT
{
    unsigned int batteryLevel:4;
    unsigned int category:4;
}__attribute__((packed)) DATA_CATEGORY_FORMAT;

typedef struct _SPECIAL_DATA_FORMAT
{
    DATA_CATEGORY_FORMAT batteryLevel_And_Data_Category;
    unsigned char btmStatus;
    unsigned char multiSpeakerRole;
    unsigned char multiSpeakerState;
    union{
        struct{
            unsigned char unique_ID[4];
            unsigned char group_ID[4];
        }category0_par;
        
        struct{
            unsigned char btAddress[6];
            unsigned char group_ID[6];
            unsigned char supportFeature;
        }category1_par;
        
        unsigned char data[13];
    }extendData;
}__attribute__((packed)) SPECIAL_DATA_FORMAT;

/*typedef struct _SPECIAL_DATA_FORMAT_CATEGORY1
{
    DATA_CATEGORY_FORMAT batteryLevel_And_Data_Category;
    unsigned char btmStatus;
    unsigned char multiSpeakerRole;
    unsigned char multiSpeakerState;
    unsigned char unique_ID[6];
    unsigned char group_ID[6];
    unsigned char supportFeature;
}__attribute__((packed)) SPECIAL_DATA_FORMAT_CATEGORY1;*/

/*typedef struct _SPECIAL_DATA_FORMAT
{
    unsigned char model_ID;
    unsigned char model_Number;
    unsigned char color;
    unsigned char unique_ID[4];
    unsigned char capability_Flags[2];
    char txPower;
    GROUP_STATUS_FORMAT groupStatus;
    unsigned char group_ID[4];
    unsigned char numberOfPlayer;
}__attribute__((packed)) SPECIAL_DATA_FORMAT;*/

typedef struct _MANUFAUTURE_DATA_FORMAT
{
    unsigned char company_ID[2];
    unsigned char Product_ID[2];
    unsigned char version;
    unsigned char data[20];
}__attribute__((packed)) MANUFAUTURE_DATA_FORMAT;

typedef struct _WRITE_EEPROM_COMMAND_FORMAT
{
    unsigned char addr[2];
    unsigned char length;
    char    data[16];
}__attribute__((packed)) WRITE_EEPROM_COMMAND_FORMAT;

typedef struct _CONNECTION_PARAMETER_FORMAT
{
    unsigned char status;
    unsigned short minInterval;
    unsigned short maxInterval;
    unsigned short latency;
    unsigned short connectionTimeout;
}__attribute__((packed)) CONNECTION_PARAMETER_FORMAT;

typedef struct _AUDIO_UART_COMMAND_FORMAT
{
    unsigned char start;
    unsigned char length_H;
    unsigned char length_L;
    unsigned char commandID;
    unsigned char commandParameters[256];
}__attribute__((packed)) AUDIO_UART_COMMAND_FORMAT;

@protocol MyPeripheralDelegate;
@interface MyPeripheral : NSObject
{
@private
    char    advData[32];
    char    deviceName_[16];
    NSMutableArray *queuedTask;
    NSMutableArray *queuedData;
    short   deviceNameMemoryAddr;
}
@property(assign) id<MyPeripheralDelegate> transDataDelegate;
//@property(assign) id<MyPeripheralDelegate> proprietaryDelegate;
//@property(assign) id<MyPeripheralDelegate> deviceInfoDelegate;
//@property(assign) id<MyPeripheralDelegate> multipleAudioServiceDelegate;
@property(assign) id<MyPeripheralDelegate> DevelopeLogDelegate;
//@property(assign) id<MyPeripheralDelegate> LeDataDelegate;
//@property(assign) id<MyPeripheralDelegate> gpioDelegate;

@property(assign) id<MyPeripheralDelegate> fWVersionDelegate;
@property(assign) id<MyPeripheralDelegate> playbackControlDelegate;
@property(assign) id<MyPeripheralDelegate> EQSettingDelegate;
@property(assign) id<MyPeripheralDelegate> groupSettingDelegate;

@property (retain) CBPeripheral *peripheral;
@property(assign) uint8_t connectStatus;
@property (assign) BOOL canSendData;
//@property (assign) BOOL isReadAddress;
//@property (assign) BOOL isReadHardVersion;
@property (readonly) NSString *uuidString;
@property(readonly) NSString *advName;
@property (readonly) NSString *deviceName;
@property (readonly) NSData *manuData;
@property (readonly) NSArray *serviceUUIDs;
@property (readonly) NSDictionary *_serviceData;
@property (copy) NSDictionary *advertiseData;
@property (assign)signed int rssi_Value;
@property (assign)BOOL waitACK;

///DIS
/*@property(retain) CBCharacteristic *manufactureNameChar;
@property(retain) CBCharacteristic *modelNumberChar;
@property(retain) CBCharacteristic *serialNumberChar;
@property(retain) CBCharacteristic *hardwareRevisionChar;
@property(retain) CBCharacteristic *firmwareRevisionChar;
@property(retain) CBCharacteristic *softwareRevisionChar;
@property(retain) CBCharacteristic *systemIDChar;
@property(retain) CBCharacteristic *certDataListChar;
@property(retain) CBCharacteristic *specificChar1;
@property(retain) CBCharacteristic *specificChar2;
*/
///Proprietary
//@property(retain) CBCharacteristic *airPatchChar;
@property(retain) CBCharacteristic *transparentDataWriteChar;
@property(retain) CBCharacteristic *transparentDataReadChar;
@property(retain) CBCharacteristic *connectionParameterChar;
@property(assign) uint8_t   updateConnectionParameterStep;
@property(readonly) ReliableBurstData *transmit;

///Bluetooth Connection
/*@property(retain) CBCharacteristic *btConnectionChar;
@property(retain) CBCharacteristic *btModeChar;
*/
///Bluetooth Multiple Audio Service
/*@property(retain) CBCharacteristic *MasterCapabilityChar;
@property(retain) CBCharacteristic *GroupControlChar;
@property(retain) CBCharacteristic *GroupStateChar;
@property(retain) CBCharacteristic *RoleOfGroupChar;
@property(retain) CBCharacteristic *NumberOfPlayerChar;
*/
/*@property(assign) CONNECTION_PARAMETER_FORMAT connectionParameter;
@property(assign) CONNECTION_PARAMETER_FORMAT backupConnectionParameter;
*/

/*@property(assign) BOOL    vendorMPEnable;
@property(assign) short   airPatchAction;*/
@property(assign) BOOL    isNotifying;


- (CONNECTION_PARAMETER_FORMAT *)retrieveBackupConnectionParameter;
- (void)updateBackupConnectionParameter:(CONNECTION_PARAMETER_FORMAT *)parameter;
- (BOOL)compareBackupConnectionParameter:(CONNECTION_PARAMETER_FORMAT *)parameter;

- (void)checkConnectionParameterStatus;
- (void)sendVendorMPEnable;
- (void)updateAirPatchEvent: (NSData *)returnEvent;
- (void)writeE2promValue: (short)address length:(short)length data:(char *)data;
- (void)readE2promValue: (short)address length:(short)length;
- (void)writeMemoryValue: (short)address length:(short)length data:(char *)data;
- (void)readMemoryValue: (short)address length:(short)length;
- (CBCharacteristicWriteType)sendTransparentData:(NSData *)data type:(CBCharacteristicWriteType)type;
- (void)setServiceNotification:(BOOL)notify;

- (NSError *)setMaxConnectionInterval:(unsigned short)maxInterval connectionTimeout:(unsigned short)connectionTimeout connectionLatency:(unsigned short)connectionLatency;
- (void)checkIsAllowUpdateConnectionParameter;
- (void)changePeripheralName: (NSString *)name;
- (void)readBtAddress;

- (void)readManufactureName;
- (void)readModelNumber;
- (void)readSerialNumber;
- (void)readHardwareRevision;
- (void)readFirmwareRevision;
- (void)readSoftwareRevison;
- (void)readSystemID;
- (void)readCertificationData;
- (void)readSpecificUUID1;
- (void)readSpecificUUID2;

- (void)readMasterCapability;
- (void)readRoleOfgroup;
- (void)readNumberOfGroup;
- (void)readGroupState;

- (void)changeDeviceName: (NSData *)deviceName;
- (void)sendMmiAction:(unsigned char)parameter;
- (void)sendMmiAction:(unsigned char)parameter databaseIndex:(unsigned char)databaseIndex;
- (void)sendMusicControl:(unsigned char)parameter;
- (void)sendEventFilter:(NSData *)eventFilters;
- (void)sendGpioControl:(NSData *)parameters;
- (void)sendDisconnectionFlag:(unsigned char)parameter;
- (void)sendReadBTMVersion:(unsigned char)type;
- (void)sendReadAuxInStatus;
- (void)sendToggleAudioSource;
- (void)sendReadBTMBatteryChargerStatus:(unsigned char)type;
- (void)sendEqModeSetting:(unsigned char)parameter;
- (void)sendSetOverallGain:(unsigned char)mask type:(unsigned char)type gain1:(NSData*)gain1 gain2:(NSData*)gain2 gain3:(NSData*)gain3;
- (void)sendDspNRControl:(unsigned char)parameter;
- (void)sendEventAck:(unsigned char)eventID;
- (void)sendReadLinkStatus;
- (void)sendReadLocalBDAddress;
- (void)sendReadLocalDeviceName;
//- (void)sendReadLinkedDeviceInformation:(unsigned char)type;
- (void)sendReadLinkedDeviceInformation:(unsigned char)type database:(unsigned char)database;
- (void)sendReadnSPKStatus;
- (void)sendReadFeatureList;
- (void)sendReadICVersionInformation;
- (void)sendBTMUtilityFunction:(unsigned char)type parameter:(unsigned char)parameter;
- (void)sendNSPKExchangeLinkInfo: (NSData *)data;
- (void)sendPersonalGroupControl:(unsigned char)enable btAddress:(NSData *)addr;
- (void)sendIndividualVolumeControl:(unsigned char)control btAddress:(NSData *)addr;

- (void)configureVendorParameter:(unsigned char)parameter deviceName:(NSString *)name;
- (void)createBtConnection: (NSData *)address;
- (void)sendBtMode:(unsigned char)parameter;
- (void)sendGroupControl:(unsigned char)parameter;
- (void)sendDevelopeData: (NSData *)data;
- (void)sendLEData:(unsigned char)type data:(NSData *)data;
- (void)sendDspRuntimeProgram:(unsigned char)type data:(NSData *)data;
- (void)checkQueuedData;
@end


@protocol MyPeripheralDelegate<NSObject>
@optional
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateConnectionParameterAllowStatus:(BOOL)status;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateConnectionParameterStatus:(BOOL)status interval:(unsigned short)interval timeout:(unsigned short)timeout  latency:(unsigned short)latency;

- (void)MyPeripheral:(MyPeripheral *)peripheral didChangePeripheralName:(NSError *)error;

- (void)MyPeripheral:(MyPeripheral *)peripheral didReceiveTransparentData:(NSData *)data;
- (void)MyPeripheral:(MyPeripheral *)peripheral didReceiveMemoryAddress:(NSData *)address length:(short)length data:(NSData *)data;
- (void)MyPeripheral:(MyPeripheral *)peripheral didReceiveBtAddress:(NSData *)data;
- (void)MyPeripheral:(MyPeripheral *)peripheral didWriteMemoryAddress:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didSendTransparentDataStatus:(NSError *) error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateTransDataNotifyStatus:(BOOL)notify;

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateManufactureName:(NSString *)name error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateModelNumber:(NSString *)modelNumber error:(NSError *)error;

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateSerialNumber:(NSString *)serialNumber error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateHardwareRevision:(NSString *)hardwareRevision error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateFirmwareRevision:(NSString *)firmwareRevision error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateSoftwareRevision:(NSString *)softwareRevision error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateSystemId:(NSData *)systemId error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateIEEE_11073_20601:(NSData *)IEEE_11073_20601 error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateSpecificUUID1:(NSData *)value error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateSpecificUUID2:(NSData *)value error:(NSError *)error;


- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateMasterCapability:(unsigned char)number error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateGroupStatus:(unsigned char)status result:(unsigned char)result error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateRoleOfGroup:(unsigned char)role error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateNumberOfPlayers:(unsigned char)number error:(NSError *)error;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateDevelopLog:(NSData *)log output:(BOOL)output;

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateInputSignalLevel:(NSData *)data;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateLeData:(NSData *)data output:(BOOL)output;

- (void)MyPeripheral:(MyPeripheral *)peripheral CBDataRxReceived:(NSData *)data;
- (void)MyPeripheral:(MyPeripheral *)peripheral checkAck:(unsigned char)cmdID;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateLogForCommand:(NSData *)data;
- (void)MyPeripheral:(MyPeripheral *)peripheral waitAck:(BOOL)ack;

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateFwVersion:(unsigned char)version subVersion:(unsigned char)subVersion;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateIcVersionIn:(NSString *)bodyVersion romVersion:(unsigned char)romVersion romSubVersion:(unsigned char)romSubVersion segment:(unsigned char)segment eepromTableVersion:(unsigned char)eepromTableVersion eepromTableSubVersion:(unsigned char)eepromTableSubVersion dspVersion:(unsigned char)dspVersion;
- (void)MyPeripheral:(MyPeripheral *)peripheral didLinkA2DP:(BOOL)A2DP btmStatus:(unsigned char)btmStatus playStatus:(unsigned char)playStatus streaming:(BOOL)streaming database:(unsigned char)database;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateBtmStatus:(unsigned char)btmStatus;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateDatabase:(unsigned char)database;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdatePlayerStatus:(unsigned char)playStatus;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateRemoteDeviceName:(NSString *)name;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateGroupConnectionState:(unsigned char)state CSB_State:(unsigned char)csbState;
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateEQMode:(unsigned char)EQModes;
@end
