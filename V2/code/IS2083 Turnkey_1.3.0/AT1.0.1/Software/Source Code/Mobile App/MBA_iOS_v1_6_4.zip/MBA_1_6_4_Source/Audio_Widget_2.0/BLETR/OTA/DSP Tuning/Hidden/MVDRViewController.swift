//
//  MVDRViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/12.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit

class MVDRViewController: UIViewController, DSPTuningDelegate, UITextFieldDelegate {
    @IBOutlet var DSPState: UILabel!
    @IBOutlet var TuneDSP: UIButton!
    
    @IBOutlet var m_LinearNoiseSuppCoeffValue: UITextField!
    
    var DSPManager: TuneDSPManager?
    
    var MVDR_Data: [UInt8] = [UInt8]()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.HiddenMVDR_Delegate = self
        
        m_LinearNoiseSuppCoeffValue.delegate = self
        m_LinearNoiseSuppCoeffValue.tag = 100
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[MVDRViewController] viewWillAppear")
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "MVDR")
        
        if(m_LinearNoiseSuppCoeffValue.text == ""){
            DSPTuningDisable()
            DSPManager?.Get_Voice_MVDR()
        }
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        DSPState.text = DSPManager?.DSP_DUT_State
        
        if(DSPManager?.RefreshGUIData(UIView_index: 0x0B) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 0x0B)
            DSPTuningDisable()
            DSPManager?.Get_Voice_MVDR()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    
        if(MVDR_Data.count != 0){
            if(TuneDSP.isEnabled == true){
                DSPManager?.DSPQueueData(module:0x0D, cfg:0x0E, len:UInt8(MVDR_Data.count), data:MVDR_Data)
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func DSPTuning(_ sender: Any) {
        if(MVDR_Data.count != 0){
            print("DSPTuning")
            DSPManager?.DSPTuning(module: 0x0D, cfg: 0x0E, len: UInt8(MVDR_Data.count), data: MVDR_Data)
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    func GUI_Data_Update(){
        if(MVDR_Data.count != 0){
            print("GUI_Data_Update")
            let value = (Int(MVDR_Data[9]) << 8) + Int(MVDR_Data[10])
            m_LinearNoiseSuppCoeffValue.text = String(value)
        }
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if(MVDR_Data.count != 0){
            if(m_LinearNoiseSuppCoeffValue.text != nil){
                let value = (Int(MVDR_Data[9]) << 8) + Int(MVDR_Data[10])
                
                if let new_value = Int(m_LinearNoiseSuppCoeffValue.text!){
                    
                    if(new_value >= 300 && new_value <= 32767){
                        MVDR_Data[9] = UInt8(new_value >> 8)
                        MVDR_Data[10] = UInt8(new_value & 0xff)
                        DSPTuningEnable()
                    }
                    else{
                        m_LinearNoiseSuppCoeffValue.text = String(value)
                    }
                }
                else{
                    m_LinearNoiseSuppCoeffValue.text = String(value)
                }
            }
        }
        
        return true
    }

    // MARK: - TuneDSPDelegate
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        print("[Hidden MVDR] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 14){
                MVDR_Data.removeAll()
                for index in 0..<11 {
                    MVDR_Data.append(buffer[k+3+index])
                }
                print("MVDR_Data = \(MVDR_Data)")
            //    MVDR_byte_9 = buffer[k+12]
            //    MVDR_byte_10 = buffer[k+13]
            }
            
            k += Int(3+len)
        }
        
        GUI_Data_Update()
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 0x0B)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func BLE_ConnectionStatus(status: Bool) {
        print("[MVDR] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func DSPTuningState(state: String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            m_LinearNoiseSuppCoeffValue.isEnabled = false
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            m_LinearNoiseSuppCoeffValue.isEnabled = true
        }
    }
    
    func ExportDSPTuningResult() {
    }
}
