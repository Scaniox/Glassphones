//
//  SpeakerConnectionTableViewCell.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 22/03/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SpeakerConnectionTableViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *remoteDeviceName;
@property (retain, nonatomic) IBOutlet UILabel *A2DP_Status;
@property (retain, nonatomic) IBOutlet UILabel *CellTitleLabel;

@end
