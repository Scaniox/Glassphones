//
//  BSSViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/8/13.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class BSSViewController: UIViewController, DSPTuningDelegate, UITextFieldDelegate {
    var DSPManager: TuneDSPManager?
    
    @IBOutlet var DSPState: UILabel!
    @IBOutlet var TuneDSP: UIButton!
    //BSS
    @IBOutlet var param_1: DropDown!    //MIC Distance
    @IBOutlet var param_2: DropDown!    //Voice Activity Detection Delay Int
    @IBOutlet var param_3: DropDown!    //Voice Activity Detection Delay Frac
    @IBOutlet var param_4: UITextField! //Tap Length
    @IBOutlet var param_5: UITextField! //BSS NR Coeff
    //Line Delay
    @IBOutlet var param_6: DropDown!
    
    let param_1_table = ["2cm", "3cm", "4cm", "5cm", "6cm", "7cm", "8cm", "9cm", "10cm", "11cm"]
    let param_1_ids = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    
    let param_2_3_table = ["0x0", "0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8", "0x9", "0xA", "0xB", "0xC", "0xD", "0xE", "0xF"]
    let param_2_3_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    
    let param_6_table = ["0x01", "0x02", "0x03", "0x04", "0x05", "0x06", "0x07", "0x08", "0x09", "0x0A", "0x0B", "0x0C", "0x0D", "0x0E", "0x0F", "0x10", "0x11", "0x12", "0x13", "0x14"]
    let param_6_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
    
    var param_1_List: Bool!
    var param_2_List: Bool!
    var param_3_List: Bool!
    var param_6_List: Bool!
    
    var LINE_Delay: UInt8 = 0
    var NR_EQ_Mode: UInt8 = 0
    var BSS_Data: [UInt8] = [UInt8]()
    
    var LINE_Delay_Changed: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[BSSViewController]viewDidLoad")
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.HiddenBSS_Delegate = self
        
        param_4.tag = 400
        param_5.tag = 500
        
        param_4.delegate = self
        param_5.delegate = self
        
        param_1.isSearchEnable = false
        param_2.isSearchEnable = false
        param_3.isSearchEnable = false
        param_6.isSearchEnable = false
        
        param_1_List = false
        param_2_List = false
        param_3_List = false
        param_6_List = false
        
        param_3.listHeight = 120
        
        param_1.optionArray = param_1_table
        param_1.optionIds = param_1_ids
        
        param_2.optionArray = param_2_3_table
        param_2.optionIds = param_2_3_ids
        
        param_3.optionArray = param_2_3_table
        param_3.optionIds = param_2_3_ids
        
        param_6.optionArray = param_6_table
        param_6.optionIds = param_6_ids
        
        param_1.didSelect{(selectedText , index , id) in
            if(self.param_1.text != self.param_1_table[self.param_1.selectedIndex!]){
                if(self.BSS_Data.count != 0){
                    let bss_mic_dist = self.param_1.selectedIndex!
                    if(bss_mic_dist == 0){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (0 << 4)
                        self.BSS_Data[3] |= (0 << 4)
                    }
                    else if(bss_mic_dist == 1){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (0 << 4)
                        self.BSS_Data[3] |= (6 << 4)
                    }
                    else if(bss_mic_dist == 2){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (0 << 4)
                        self.BSS_Data[3] |= (7 << 4)
                    }
                    else if(bss_mic_dist == 3){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (0 << 4)
                        self.BSS_Data[3] |= (9 << 4)
                    }
                    else if(bss_mic_dist == 4){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (1 << 4)
                        self.BSS_Data[3] |= (1 << 4)
                    }
                    else if(bss_mic_dist == 5){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (1 << 4)
                        self.BSS_Data[3] |= (3 << 4)
                    }
                    else if(bss_mic_dist == 6){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (1 << 4)
                        self.BSS_Data[3] |= (5 << 4)
                    }
                    else if(bss_mic_dist == 7){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (1 << 4)
                        self.BSS_Data[3] |= (6 << 4)
                    }
                    else if(bss_mic_dist == 8){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (1 << 4)
                        self.BSS_Data[3] |= (8 << 4)
                    }
                    else if(bss_mic_dist == 9){
                        self.BSS_Data[2] &= ~(0xf0)
                        self.BSS_Data[3] &= ~(0xf0)
                        self.BSS_Data[2] |= (2 << 4)
                        self.BSS_Data[3] |= (0 << 4)
                    }
                    print("SelectIndex = \(self.param_1.selectedIndex!)")
                    print("BSS_Data[2] = \(String(format: "0x%02X",self.BSS_Data[2]))")
                    print("BSS_Data[3] = \(String(format: "0x%02X",self.BSS_Data[3]))")
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_2.didSelect{(selectedText , index , id) in
            if(self.param_2.text != self.param_2_3_table[self.param_2.selectedIndex!]){
                self.BSS_Data[4] &= ~(0xf0)
                self.BSS_Data[4] |= UInt8(self.param_2.selectedIndex!) << 4
                self.DSPTuningEnable()
            }
        }
        
        param_3.didSelect{(selectedText , index , id) in
            if(self.param_3.text != self.param_2_3_table[self.param_3.selectedIndex!]){
                self.BSS_Data[4] &= ~(0x0f)
                self.BSS_Data[4] |= UInt8(self.param_3.selectedIndex!)
                self.DSPTuningEnable()
            }
        }
        
        param_6.didSelect{(selectedText , index , id) in
            if(self.param_6.text != self.param_6_table[self.param_6.selectedIndex!]){
                self.LINE_Delay = UInt8(self.param_6.selectedIndex!+1)
                self.DSPTuningEnable()
            }
        }
        
        param_1.listWillAppear {
            self.param_1_List = true
            
            if(self.param_2_List == true){
                self.param_2.hideList()
            }
            
            if(self.param_3_List == true){
                self.param_3.hideList()
            }
            
            if(self.param_6_List == true){
                self.param_6.hideList()
            }
            
            self.param_2.isHidden = true
            self.param_3.isHidden = true
            self.param_6.isHidden = true
            
            self.Hide_UserTextField(IsHidden: true)
        }
        
        param_1.listDidDisappear {
            self.param_1_List = false
            
            self.param_2.isHidden = false
            self.param_3.isHidden = false
            self.param_6.isHidden = false
            
            self.Hide_UserTextField(IsHidden: false)
            
            self.TuneDSP.isHidden = false
        }
        
        param_2.listWillAppear {
            self.param_2_List = true
            
            if(self.param_3_List == true){
                self.param_3.hideList()
            }
            self.param_3.isHidden = true
            
            if(self.param_6_List == true){
                self.param_6.hideList()
            }
            self.param_6.isHidden = true
            
            self.Hide_UserTextField(IsHidden: true)
        }
        
        param_2.listDidDisappear {
            self.param_2_List = false
            
            if(self.param_1_List == false){
                self.param_3.isHidden = false
                self.param_6.isHidden = false
                
                self.Hide_UserTextField(IsHidden: false)
                
                self.TuneDSP.isHidden = false
            }
        }
        
        param_3.listWillAppear {
            self.param_3_List = true
            
            if(self.param_6_List == true){
                self.param_6.hideList()
            }
            self.param_6.isHidden = true
            
            self.Hide_UserTextField(IsHidden: true)
        }
        
        param_3.listDidDisappear {
            self.param_3_List = false
            
            if(self.param_1_List == false && self.param_2_List == false){
                self.param_6.isHidden = false
                self.Hide_UserTextField(IsHidden: false)
                self.TuneDSP.isHidden = false
            }
        }
        
        param_6.listWillAppear {
            self.param_6_List = true
            
            self.TuneDSP.isHidden = true
            
        }
        
        param_6.listDidDisappear {
            self.param_6_List = false
            
            if(self.param_1_List == false && self.param_2_List == false && self.param_3_List == false){
                self.TuneDSP.isHidden = false
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "BSS/Delay")
        
        if(param_1.text == ""){
            DSPTuningDisable()
            DSPManager?.Get_Voice_BSS_Setting()
        }
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        DSPState.text = DSPManager?.DSP_DUT_State

        if(DSPManager?.RefreshGUIData(UIView_index: 0x0A) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 0x0A)
            DSPTuningDisable()
            DSPManager?.Get_Voice_BSS_Setting()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    
        if(TuneDSP.isEnabled == true){
            if(LINE_Delay_Changed){
                LINE_Delay_Changed = false
                DSPManager?.DSPQueueData(module:0x0D, cfg:0x0A, len:0x01, data:[LINE_Delay])
            }
            else{
                DSPManager?.DSPQueueData(module:0x0D, cfg:0x08, len:UInt8(BSS_Data.count), data:BSS_Data)
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func DSPTuning(_ sender: Any) {
        if(BSS_Data.count != 0){
            if(LINE_Delay_Changed){
                LINE_Delay_Changed = false
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x0A, len: 1, data: [LINE_Delay])
            }
            else{
                DSPManager?.DSPTuning(module: 0x0D, cfg: 0x0B, len: UInt8(BSS_Data.count), data: BSS_Data)
            }
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    func GUI_Data_Update(){
        if(BSS_Data.count != 0){
            print("GUI_Data_Update")
            
            /*
            if(NR_EQ_Mode != 0){
                param_4.isEnabled = true
                param_5.isEnabled = true
                
                param_1.isUserInteractionEnabled = true
                param_2.isUserInteractionEnabled = true
                param_3.isUserInteractionEnabled = true
            }
            else{
                param_4.isEnabled = false
                param_5.isEnabled = false
                
                param_1.isUserInteractionEnabled = false
                param_2.isUserInteractionEnabled = false
                param_3.isUserInteractionEnabled = false
            }*/
            
            param_4.text = String(BSS_Data[0])
            param_5.text = String(BSS_Data[1])
            
            //if(BSS_Data[2] == 0 && BSS_Data[3] == 0){
            //    param_1.selectedIndex = 0
            //    param_1.text = param_1_table[param_1.selectedIndex!]
            //}
            
            if(((BSS_Data[2] >> 4) == 0) && ((BSS_Data[3] >> 4) == 0)){
                param_1.selectedIndex = 0
            }
            
            if(((BSS_Data[2] >> 4) == 0) && ((BSS_Data[3] >> 4) == 6)){
                param_1.selectedIndex = 1
            }
            
            if(((BSS_Data[2] >> 4) == 0) && ((BSS_Data[3] >> 4) == 7)){
                param_1.selectedIndex = 2
            }
            
            if(((BSS_Data[2] >> 4) == 0) && ((BSS_Data[3] >> 4) == 9)){
                param_1.selectedIndex = 3
            }
            
            if(((BSS_Data[2] >> 4) == 1) && ((BSS_Data[3] >> 4) == 1)){
                param_1.selectedIndex = 4
            }
            
            if(((BSS_Data[2] >> 4) == 1) && ((BSS_Data[3] >> 4) == 3)){
                param_1.selectedIndex = 5
            }
            
            if(((BSS_Data[2] >> 4) == 1) && ((BSS_Data[3] >> 4) == 5)){
                param_1.selectedIndex = 6
            }
            
            if(((BSS_Data[2] >> 4) == 1) && ((BSS_Data[3] >> 4) == 6)){
                param_1.selectedIndex = 7
            }
            
            if(((BSS_Data[2] >> 4) == 1) && ((BSS_Data[3] >> 4) == 8)){
                param_1.selectedIndex = 8
            }
            
            if(((BSS_Data[2] >> 4) == 2) && ((BSS_Data[3] >> 4) == 0)){
                param_1.selectedIndex = 9
            }
            param_1.text = param_1_table[param_1.selectedIndex!]
            
            param_2.selectedIndex = Int((BSS_Data[4] & 0xf0) >> 4)
            param_2.text = param_2_3_table[param_2.selectedIndex!]
            
            param_3.selectedIndex = Int(BSS_Data[4] & 0x0f)
            param_3.text = param_2_3_table[param_3.selectedIndex!]
            
            param_6.selectedIndex = Int(LINE_Delay-1)
            param_6.text = param_6_table[param_6.selectedIndex!]
            
        }
    }
    
    func Hide_UserTextField(IsHidden:Bool){
        self.param_4.isHidden = IsHidden
        self.param_5.isHidden = IsHidden
        //self.param_6.isHidden = IsHidden
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if(BSS_Data.count != 0){
            print("textFieldShouldReturn")
            if(param_4.text != nil && textField.tag == 400){
                if let param_4_value = Int(param_4.text!){
                    if(param_4_value >= 1 && param_4_value <= 40){
                        BSS_Data[0] = UInt8(param_4_value)
                        DSPTuningEnable()
                        LINE_Delay_Changed = true
                    }
                    else{
                        param_4.text = String(BSS_Data[0])
                    }
                }
                else{
                    param_4.text = String(BSS_Data[0])
                }
            }
            else if(param_5.text != nil && textField.tag == 500){
                if let param_5_value = Int(param_5.text!){
                    if(param_5_value >= 0 && param_5_value <= 255){
                        BSS_Data[1] = UInt8(param_5_value)
                        DSPTuningEnable()
                        LINE_Delay_Changed = true
                    }
                    else{
                        param_5.text = String(BSS_Data[1])
                    }
                }
                else{
                    param_5.text = String(BSS_Data[1])
                }
            }
            
            if(LINE_Delay_Changed){
                DSPTuningEnable()
            }
        }
        
        return true
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        print("[Hidden BSS] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 10){
                if(buffer[k+2] == 1){
                    LINE_Delay = buffer[k+3]
                }
            }
            else if(buffer[k] == 13 && buffer[k+1] == 11){
                if(buffer[k+2] == 7){
                    BSS_Data.removeAll()
                    for index in 0..<7 {
                        BSS_Data.append(buffer[k+3+index])
                    }
                    
                }
            }
            else if(buffer[k] == 3 && buffer[k+1] == 13){
                if(buffer[k+2] == 1){
                    NR_EQ_Mode = buffer[k+3]
                }
            }
            
            k += Int(3+len)
        }
        
        print("NR_EQ_Mode = \(NR_EQ_Mode)")
        print("LINE_Delay = \(LINE_Delay)")
        print("BSS_Data = \(BSS_Data)")
        
        GUI_Data_Update()
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 0x0A)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func BLE_ConnectionStatus(status: Bool) {
        print("[BSS] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func DSPTuningState(state: String) {
        DSPState.text = state
        
        print("[BSS,DSPTuningState]dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(param_1_List)
            {
                param_1.hideList()
            }
            param_1.isUserInteractionEnabled = false
            if(param_2_List)
            {
                param_2.hideList()
            }
            param_2.isUserInteractionEnabled = false
            if(param_3_List)
            {
                param_3.hideList()
            }
            param_3.isUserInteractionEnabled = false
            
            param_4.isEnabled = false
            param_5.isEnabled = false
            if(param_6_List)
            {
                param_6.hideList()
            }
            param_6.isUserInteractionEnabled = false
            
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            if(NR_EQ_Mode != 0){
                param_1.isUserInteractionEnabled = true
                param_2.isUserInteractionEnabled = true
                param_3.isUserInteractionEnabled = true
            
                param_4.isEnabled = true
                param_5.isEnabled = true
            }
            else{
                param_1.isUserInteractionEnabled = false
                param_2.isUserInteractionEnabled = false
                param_3.isUserInteractionEnabled = false
                
                param_4.isEnabled = false
                param_5.isEnabled = false
            }
            param_6.isUserInteractionEnabled = true
        }
    }
    
    func ExportDSPTuningResult() {
    }
}
