//
//  AudioUartCommandHandler.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 21/05/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "AudioUartCommandHandler.h"
#import "ISUtility.h"

typedef struct _AUDIO_COMMAND_HEADER {
    unsigned char start_byte;
    unsigned char length_high;
    unsigned char length_low;
    unsigned char commandID;
}__attribute__((packed)) AUDIO_COMMAND_HEADER;
#define COMMAND_HEADER_SIZE sizeof(AUDIO_COMMAND_HEADER)

typedef struct _AUDIO_UART_EVENT_FORMAT
{
    AUDIO_COMMAND_HEADER eventHeader;
    unsigned char commandParameters[256];
}__attribute__((packed)) AUDIO_UART_EVENT_FORMAT;

typedef enum {
    AUDIO_EVENT_ID_ACK = 0x00,
    AUDIO_EVENT_ID_BTM_STATUS = 0x01,
    AUDIO_EVENT_ID_BATTERY_STATUS = 0x0C,
    AUDIO_EVENT_ID_BTM_CHARGING_STATUS = 0x0D,
    AUDIO_EVENT_ID_EQ_MODE_INDICATION = 0x10,
    AUDIO_EVENT_ID_READ_LINKED_DEVICE_INFORMATION_REPLY = 0x17,
    AUDIO_EVENT_ID_READ_BTM_VERSION_REPLY = 0x18,
    AUDIO_EVENT_ID_AVC_VENDOR_DEPENDENT_RESPONSE = 0x1A,
    AUDIO_EVENT_ID_READ_LINK_STATUS_REPLY = 0x1E,
    AUDIO_EVENT_ID_READ_LOCAL_BD_ADDRESS_REPLY = 0x20,
    AUDIO_EVENT_ID_READ_LOCAL_DEVICE_NAME_REPLY = 0x21,
    AUDIO_EVENT_ID_REPORT_SPP_DATA = 0x22,
    AUDIO_EVENT_ID_REPORT_INPUT_SIGNAL_LEVEL = 0x27,
    AUDIO_EVENT_ID_REPORT_NSPK_LINK_STATUS = 0x33,
    AUDIO_EVENT_ID_REPORT_IC_VERSION_INFO = 0x38,
    AUDIO_EVENT_ID_REPORT_NSPK_EXCHANGE_LINK_INFO = 0x3D,
    AUDIO_EVENT_ID_FEATURE_LIST_REPORT = 0x40,
}AUDIO_EVENT_ID;

typedef enum {
    AUDIO_COMMAND_ID_READ_LINKED_DEVICE_IFORMATION = 0x16,
    AUDIO_COMMAND_ID_READ_FEATURE_LIST = 0x39,
}AUDIO_COMMAND_ID;

enum{
    MMI_ACTION_POWER_ON_BUTTON_PRESS = 0x51,
    MMI_ACTION_POWER_ON_BUTTON_RELEASE,
    MMI_ACTION_POWER_OFF_BUTTON_PRESS,
    MMI_ACTION_POWER_OFF_BUTTON_RELEASE,
};

#define START_BYTE 0xAA
#define POWER_OFF_STATE 0x00
#define POWER_ON_STATE 0x02

@interface ACKTimer2 : NSObject
@property (retain) NSTimer *timer;
@property (assign) uint8_t commandID;
- (id)initWithCommandID:(uint8_t)cmdID timer:(NSTimer *)timer;
@end

@implementation ACKTimer2

- (id)initWithCommandID:(uint8_t)cmdID timer:(NSTimer *)timer {
    self = [super init];
    if (self) {
        self.timer = timer;
        self.commandID = cmdID;
    }
    return self;
}
@end

@interface AudioUartCommandHandler() {
    NSMutableData *_events;
    NSMutableArray *_waitingACK;
    NSArray *errorArray;
}
@end

@implementation AudioUartCommandHandler
@synthesize uartCommandDelegate;
@synthesize connectedPeripheral;

-(id)init{
    self = [super init];
    if (self) {
        errorArray = [[NSArray alloc] initWithObjects:@"Command Complete",@"Command Disallow",@"Unknown Command",@"Parameters Error",@"BTN is Busy",@"BTM Memory is Full", nil];
        _waitingACK = [[NSMutableArray alloc] init];
        _events = [[NSMutableData alloc] init];
    }
    return self;
}

- (void)checkResponseForCommand:(uint8_t)cmdID timeout:(NSTimeInterval)timeout {
    NSMethodSignature *sgn = [self methodSignatureForSelector:@selector(ACKTimeoutOfCommand:)];
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:sgn];
    [invocation setTarget:self];
    [invocation setSelector:@selector(ACKTimeoutOfCommand:)];
    NSNumber *arg = [[[NSNumber alloc] initWithUnsignedChar:cmdID] autorelease];
    [invocation setArgument:&arg atIndex:2];
    [invocation retainArguments];
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:timeout invocation:invocation repeats:NO];
    ACKTimer2 *obj = [[ACKTimer2 alloc] initWithCommandID:cmdID timer:timer];
    [_waitingACK addObject:obj];
}

- (BOOL)removeCheckResponseTimerForCommand:(uint8_t)cmdID {
    ACKTimer2 *obj = nil;
    [connectedPeripheral setWaitACK:FALSE];
    //_connectedPeripheral.waitACK = FALSE;
    for (int i=0; i<[_waitingACK count]; i++) {
        obj = [_waitingACK objectAtIndex:i];
        if (obj.commandID == cmdID) {
            [obj.timer invalidate];
            [_waitingACK removeObject:obj];
            return TRUE;
        }
    }
    return FALSE;
}

- (void)ACKTimeoutOfCommand:(NSNumber *)cmdID {
    [self removeCheckResponseTimerForCommand:[cmdID unsignedCharValue]];
    NSMutableString *errStr = [[NSMutableString alloc] initWithString:@"ACK Timeout"];
    NSString *title = [NSString stringWithFormat:@"Command 0x%02X Error",[cmdID intValue]];
    [errStr appendFormat:@"\n\n"];
    if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateMessage:title:error:)])) {
        [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateMessage:[errStr mutableCopy] title:title error:TRUE];
    }
}

-(void) setPeripheral:(MyPeripheral *)Peripheral{
    //connectedPeripheral = Peripheral;
    [self setConnectedPeripheral:Peripheral];
    if(Peripheral!=nil){
        connectedPeripheral.transDataDelegate = self;
        [connectedPeripheral setServiceNotification:YES];
    }
}

#pragma mark - transDataDelegate
- (void)MyPeripheral:(MyPeripheral *)peripheral checkAck:(unsigned char)cmdID{
    //if (cmdID != 0x14){ //&& (cmdID != 0xCC))///AUDIO_COMMAND_ID_EVENT_ACK
    //if ((cmdID != 0x14) && (cmdID != 0x1C)){//Audio DSP Test2
    if ((cmdID != 0x14) && (cmdID != 0x16)){//BTAS-484
        [self checkResponseForCommand:cmdID timeout:3.0];
    }
}

- (void)MyPeripheral:(MyPeripheral *)peripheral waitAck:(BOOL)ack{
    NSMutableString *errStr = [[NSMutableString alloc] initWithString:@"Please Wait Ack or Ack Timeout to send the next command!"];
    [errStr appendFormat:@"\n\n"];
    if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateMessage:title:error:)])) {
        [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateMessage:[errStr mutableCopy] title:@"Warning" error:FALSE];
    }
}

- (void)MyPeripheral:(MyPeripheral *)peripheral CBDataRxReceived:(NSData *)data;
{
    if(data && ([data length]))
    {
        [_events appendData:data];
        [self parseEvents];
    }
}

- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateLogForCommand:(NSData *)data{
    char headerBuf[10];
    [data getBytes:headerBuf length:COMMAND_HEADER_SIZE];
    AUDIO_COMMAND_HEADER *header = (AUDIO_COMMAND_HEADER *)headerBuf;
    short payloadLen = (header->length_high << 8 | header->length_low);
    short eventLen = payloadLen + COMMAND_HEADER_SIZE;
    unsigned char buf[260];
    [data getBytes:buf length:eventLen];
    
    /*** Write Log To File */
    NSMutableString *logStr = [[NSMutableString alloc] initWithString:@"<- "];
    for (int i = 0; i<eventLen; i++) {
        [logStr appendFormat:@"%02X ",buf[i]];
    }
    [logStr appendFormat:@"\n"];
    if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateLogForCommand:)])) {
        [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateLogForCommand:[logStr mutableCopy]];
    }
}

- (unsigned char)calculateChecksum:(unsigned char *)data dataLength:(unsigned short)length {
    unsigned char checksum = 0x00;
    while (length--) {
        checksum += *data++;
    }
    return (0x100 - checksum);
}

- (void)parseEvents {
    unsigned char start = 0x00;
    
    NSRange range = NSMakeRange(0, 1);
    [_events getBytes:&start length:1];
    
    while (start != START_BYTE && [_events length]) {
        [_events replaceBytesInRange:range withBytes:NULL length:0];
        [_events getBytes:&start length:1];
    }
    if ([_events length] < COMMAND_HEADER_SIZE){
        return;
    }
    
    char headerBuf[10];
    [_events getBytes:headerBuf length:COMMAND_HEADER_SIZE];
    AUDIO_COMMAND_HEADER *header = (AUDIO_COMMAND_HEADER *)headerBuf;
    short payloadLen = (header->length_high << 8 | header->length_low);
    short eventLen = payloadLen + COMMAND_HEADER_SIZE;
    //check if event is complete
    
    //+ start byte AA and checksum
    if ([_events length] < payloadLen +2){
        return;
    }
    
    unsigned char buf[260];
    [_events getBytes:buf length:eventLen];
    
    /*** Write Log To File */
    NSMutableString *logStr = [[NSMutableString alloc] initWithString:@"-> "];
    for (int i = 0; i<eventLen; i++) {
        [logStr appendFormat:@"%02X ",buf[i]];
    }
    [logStr appendFormat:@"\n"];
    if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateLogForCommand:)])){
        [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateLogForCommand:[logStr mutableCopy]];
    }
    
    AUDIO_UART_EVENT_FORMAT *event = (AUDIO_UART_EVENT_FORMAT *)buf;
    unsigned char checksum = [self calculateChecksum:&event->eventHeader.length_high dataLength:eventLen-2]; //minus start_byte and checksum
    range = NSMakeRange(0, eventLen);
    [_events replaceBytesInRange:range withBytes:NULL length:0];
    if (checksum != event->commandParameters[payloadLen-1]) {
        NSMutableString *errStr = [[NSMutableString alloc] initWithString:@"CheckSum Error!\n\n"];
        if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateMessage:title:error:)])) {
            [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateMessage:[errStr mutableCopy] title:@"Error:" error:TRUE];
        }
        return;
    }
    
    if (header->commandID != AUDIO_EVENT_ID_ACK) {
        [connectedPeripheral sendEventAck:header->commandID];
    }
    switch (header->commandID) {
        case AUDIO_EVENT_ID_ACK:{
            uint8_t cmdID = event->commandParameters[0];
            [self removeCheckResponseTimerForCommand:cmdID];
            
            uint8_t status = event->commandParameters[1];
            
            if (status != 0x00) {
                if (cmdID == AUDIO_COMMAND_ID_READ_LINKED_DEVICE_IFORMATION) {
                    if ((connectedPeripheral.playbackControlDelegate != nil) && ([(NSObject *)connectedPeripheral.playbackControlDelegate respondsToSelector:@selector(MyPeripheral:didUpdateRemoteDeviceName:)])) {
                        [connectedPeripheral.playbackControlDelegate MyPeripheral:connectedPeripheral didUpdateRemoteDeviceName:nil];
                    }
                    [connectedPeripheral checkQueuedData];
                    
                }else if(cmdID == AUDIO_COMMAND_ID_READ_FEATURE_LIST){
                    BOOL Feature_StereoMode = TRUE;
                    BOOL Feature_ConcertMode = FALSE;
                    BOOL Feature_EmbeddedMode = TRUE;
                    
                    if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateFeature_StereoMode:Feature_ConcertMode:Feature_EmbeddedMode:)])) {
                        [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateFeature_StereoMode:Feature_StereoMode Feature_ConcertMode:Feature_ConcertMode Feature_EmbeddedMode:Feature_EmbeddedMode];
                    }
                    [connectedPeripheral checkQueuedData];
                    
                }else{
                    NSString *title = [NSString stringWithFormat:@"Command 0x%02X Error:",cmdID];
                    NSString *error = [errorArray objectAtIndex:status];
                    NSMutableString *errStr = [[NSMutableString alloc] initWithString:error];
                    [errStr appendFormat:@"\n\n"];
                    if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateMessage:title:error:)])) {
                        [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateMessage:[errStr mutableCopy] title:title error:TRUE];
                    }
                }
            }else{
                [connectedPeripheral checkQueuedData];
                if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateCommandAck:)])) {
                    [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateCommandAck:cmdID];
                }
            }
            break;
        }
        case AUDIO_EVENT_ID_BTM_STATUS:{
            int btmStatus = event->commandParameters[0];
            BOOL updateDatabase = false;
            unsigned char DatabaseIndex;
            
            if((btmStatus == 0x06) || (btmStatus == 0x05)) {
                //A2DP/HFP Connected
                NSLog(@"[BTM Status]Get data base information , %x",btmStatus);
                DatabaseIndex = (event->commandParameters[1]&0x0f);
                NSLog(@"Database index = %d",DatabaseIndex);
                updateDatabase = true;
            }
            else if((btmStatus == 0x15) || (btmStatus == 0x07) || (btmStatus == 0x08)){
                //ACL Connected/ A2DP/HFP Disconnected
                NSLog(@"[BTM Status]Get data base information, %x", btmStatus);
                DatabaseIndex = event->commandParameters[1];
                NSLog(@"Database index = %d",DatabaseIndex);
                updateDatabase = true;
            }
            
            if ((connectedPeripheral.playbackControlDelegate != nil) && ([(NSObject *)connectedPeripheral.playbackControlDelegate respondsToSelector:@selector(MyPeripheral:didUpdateBtmStatus:)])) {
                [connectedPeripheral.playbackControlDelegate MyPeripheral:connectedPeripheral didUpdateBtmStatus:btmStatus
                 ];
            }
            
            if (btmStatus == POWER_OFF_STATE) {
                if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdatePowerState:)])) {
                    [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdatePowerState:FALSE
                     ];
                }
            }else if(btmStatus == POWER_ON_STATE){
                if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdatePowerState:)])) {
                    [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdatePowerState:TRUE
                     ];
                }
            }
            
            if(updateDatabase) {
                if((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateDatabaseInfo:)])) {
                    [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateDatabaseInfo:DatabaseIndex];
                }
                
                if ((connectedPeripheral.playbackControlDelegate != nil) && ([(NSObject *)connectedPeripheral.playbackControlDelegate respondsToSelector:@selector(MyPeripheral:didUpdateDatabase:)])) {
                    [connectedPeripheral.playbackControlDelegate MyPeripheral:connectedPeripheral didUpdateDatabase:DatabaseIndex
                     ];
                }
            }
            
            break;
        }
        case AUDIO_EVENT_ID_BATTERY_STATUS:{
            break;
        }
        case AUDIO_EVENT_ID_BTM_CHARGING_STATUS:{
            break;
        }
        case AUDIO_EVENT_ID_EQ_MODE_INDICATION:{
            NSLog(@"AUDIO_EVENT_ID_EQ_MODE_INDICATION");
            
            if((connectedPeripheral.EQSettingDelegate != nil) && ([(NSObject *)connectedPeripheral.EQSettingDelegate respondsToSelector:@selector(MyPeripheral:didUpdateEQMode:)])) {
                NSLog(@"value = %d",event->commandParameters[0]);
                [connectedPeripheral.EQSettingDelegate MyPeripheral:connectedPeripheral didUpdateEQMode:event->commandParameters[0]];
            }
            
            break;
        }
        case AUDIO_EVENT_ID_READ_LINKED_DEVICE_INFORMATION_REPLY:{
            NSMutableString *name = [[[NSMutableString alloc] init] mutableCopy];
            [name setString:@""];
            if (event->commandParameters[1] == 0x00) {
                int i = 0;
                while (event->commandParameters[i+2] != 0x00) {
                    [name appendFormat:@"%c",event->commandParameters[i+2]];
                    i++;
                }
                if ((connectedPeripheral.playbackControlDelegate != nil) && ([(NSObject *)connectedPeripheral.playbackControlDelegate respondsToSelector:@selector(MyPeripheral:didUpdateRemoteDeviceName:)])) {
                    [connectedPeripheral.playbackControlDelegate MyPeripheral:connectedPeripheral didUpdateRemoteDeviceName:name];
                }
            }
            break;
        }
        case AUDIO_EVENT_ID_READ_BTM_VERSION_REPLY:{
            if (event->commandParameters[0] == 0x00) {

            }else{
                if ((connectedPeripheral.fWVersionDelegate != nil) && ([(NSObject *)connectedPeripheral.fWVersionDelegate respondsToSelector:@selector(MyPeripheral:didUpdateFwVersion:subVersion:)])) {
                    [connectedPeripheral.fWVersionDelegate MyPeripheral:connectedPeripheral didUpdateFwVersion:event->commandParameters[1] subVersion:event->commandParameters[2]];
                }
            }
            break;
        }
        case AUDIO_EVENT_ID_AVC_VENDOR_DEPENDENT_RESPONSE:{
            if (event->commandParameters[7] == 0x31) {
                if (event->commandParameters[11] == 0x01) {
                    int playStatus = event->commandParameters[12];
                    if ((connectedPeripheral.playbackControlDelegate != nil) && ([(NSObject *)connectedPeripheral.playbackControlDelegate respondsToSelector:@selector(MyPeripheral:didUpdatePlayerStatus:)])) {
                        [connectedPeripheral.playbackControlDelegate MyPeripheral:connectedPeripheral didUpdatePlayerStatus:playStatus
                         ];
                    }
                }
            }
            break;
        }
        case AUDIO_EVENT_ID_READ_LINK_STATUS_REPLY:{
            BOOL linkA2DP = FALSE;
            unsigned char btmStatus = 0;
            unsigned char playStatus = 0;
            BOOL streaming = event->commandParameters[5];//Database0_Stream_Status
            //if (event->commandParameters[1] == 0x0F) {
            //if ((event->commandParameters[1]&0x03) == 0x03) {
                //Database0_Connect_Status
            //    linkA2DP = TRUE;
            //}
            btmStatus = event->commandParameters[0];
            //unsigned char playStatus = event->commandParameters[3];//Database0_Play_Status
            
            //if ((connectedPeripheral.playbackControlDelegate != nil) && ([(NSObject *)connectedPeripheral.playbackControlDelegate respondsToSelector:@selector(MyPeripheral:didLinkA2DP:btmStatus:playStatus:streaming:)])) {
                //[connectedPeripheral.playbackControlDelegate MyPeripheral:connectedPeripheral didLinkA2DP:linkA2DP btmStatus:btmStatus playStatus:playStatus streaming:streaming];
            //}
            
            //BOOL powerOn;
            if (btmStatus == POWER_OFF_STATE) {
                if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdatePowerState:)])) {
                    [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdatePowerState:FALSE
                     ];
                }
            }else{
                if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdatePowerState:)])) {
                    [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdatePowerState:TRUE
                     ];
                }
            }
            
            unsigned char DatabaseIndex;
            
            if((event->commandParameters[1] != 0) && (event->commandParameters[2] == 0)){
                DatabaseIndex = 0x00;
            }
            else if((event->commandParameters[1] == 0) && (event->commandParameters[2] != 0)){
                DatabaseIndex = 0x01;
            }
            else{
                DatabaseIndex = 0x00;
            }
            
            if(DatabaseIndex == 0){
                if ((event->commandParameters[1]&0x03) == 0x03) {//Database0_Connect_Status
                    linkA2DP = TRUE;
                }
                streaming = event->commandParameters[5];//Database0_Stream_Status
                playStatus = event->commandParameters[3];//Database0_Play_Status
            }
            else{
                if ((event->commandParameters[2]&0x03) == 0x03) {//Database1_Connect_Status
                    linkA2DP = TRUE;
                }
                streaming = event->commandParameters[6];//Database1_Stream_Status
                playStatus = event->commandParameters[4];//Database1_Play_Status
            }
                        
            if((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateDatabaseInfo:)])) {
                NSLog(@"[LINK_STATUS_REPLY] DatabaseIndex = %d",DatabaseIndex);
                [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateDatabaseInfo:DatabaseIndex];
            }

            if ((connectedPeripheral.playbackControlDelegate != nil) && ([(NSObject *)connectedPeripheral.playbackControlDelegate respondsToSelector:@selector(MyPeripheral:didLinkA2DP:btmStatus:playStatus:streaming:database:)])) {
                NSLog(@"[LINK_STATUS_REPLY] Update A2DP Status , DatabaseIndex = %d",DatabaseIndex);
                [connectedPeripheral.playbackControlDelegate MyPeripheral:connectedPeripheral didLinkA2DP:linkA2DP btmStatus:btmStatus playStatus:playStatus streaming:streaming database:DatabaseIndex];
            }
            break;
        }
        case AUDIO_EVENT_ID_READ_LOCAL_BD_ADDRESS_REPLY:{
            NSData* addr = [NSData dataWithBytes:event->commandParameters length:6];
            NSData* reverseData = [ISUtility reverseData:addr];
            if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateAddress:)])) {
                [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateAddress:reverseData];
            }
            break;
        }
        case AUDIO_EVENT_ID_READ_LOCAL_DEVICE_NAME_REPLY:{
            break;
        }
        case AUDIO_EVENT_ID_REPORT_SPP_DATA:{
            break;
        }
        case AUDIO_EVENT_ID_REPORT_INPUT_SIGNAL_LEVEL:{
            break;
        }
        case AUDIO_EVENT_ID_REPORT_NSPK_LINK_STATUS:{
            unsigned char CSB_ConnectionState = event->commandParameters[0];
            unsigned char CSB_State = event->commandParameters[1];
            
            NSLog(@"AUDIO_EVENT_ID_REPORT_NSPK_LINK_STATUS, %d, %d",CSB_ConnectionState,CSB_State);
            
            if ((CSB_State == 0x05) || (CSB_State == 0x06)) {
                break;
            }
            
            if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateGroupConnectionState:CSB_State:)])) {
                [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateGroupConnectionState:CSB_ConnectionState CSB_State:CSB_State];
            }
            
            if ((connectedPeripheral.groupSettingDelegate != nil) && ([(NSObject *)connectedPeripheral.groupSettingDelegate respondsToSelector:@selector(MyPeripheral:didUpdateGroupConnectionState:CSB_State:)])) {
                [connectedPeripheral.groupSettingDelegate MyPeripheral:connectedPeripheral didUpdateGroupConnectionState:CSB_ConnectionState CSB_State:CSB_State];
            }
            
            if ((connectedPeripheral.playbackControlDelegate != nil) && ([(NSObject *)connectedPeripheral.playbackControlDelegate respondsToSelector:@selector(MyPeripheral:didUpdateGroupConnectionState:CSB_State:)])) {
                [connectedPeripheral.playbackControlDelegate MyPeripheral:connectedPeripheral didUpdateGroupConnectionState:CSB_ConnectionState CSB_State:CSB_State];
            }
            break;
        }
        case AUDIO_EVENT_ID_REPORT_IC_VERSION_INFO:{
            int index = 0;
            NSMutableString *bodyVersion = [[NSMutableString alloc] init];
            for (int i = 0; i<14; i++) {
                [bodyVersion appendFormat:@"%c",event->commandParameters[i]];
                index++;
            }
            unsigned char romVersion = event->commandParameters[index++];//[NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            unsigned char romSubVersion = event->commandParameters[index++];//[NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            unsigned char segment = event->commandParameters[index++];//[NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            unsigned char eepromTableVersion = event->commandParameters[index++];//[NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            unsigned char eepromTableSubVersion = event->commandParameters[index++];//[NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            unsigned char dspVersion = event->commandParameters[index++];//[NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            //romSubVersion = [NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            //segmentStr = [NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            //eepromTableVersion = [NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            //eepromTableSubVersion = [NSString stringWithFormat:@"%02X",event->commandParameters[index++]];
            //dspVersion = [NSString stringWithFormat:@"%02X%02X",event->commandParameters[index],event->commandParameters[index+1]];
            //[self.tableView reloadData];
            if ((connectedPeripheral.fWVersionDelegate != nil) && ([(NSObject *)connectedPeripheral.fWVersionDelegate respondsToSelector:@selector(MyPeripheral:didUpdateIcVersionIn:romVersion:romSubVersion:segment:eepromTableVersion:eepromTableSubVersion:dspVersion:)])) {
                [connectedPeripheral.fWVersionDelegate MyPeripheral:connectedPeripheral didUpdateIcVersionIn:bodyVersion romVersion:romVersion romSubVersion:romSubVersion segment:segment eepromTableVersion:eepromTableVersion eepromTableSubVersion:eepromTableSubVersion dspVersion:dspVersion];
            }
            break;
        }

        case AUDIO_EVENT_ID_REPORT_NSPK_EXCHANGE_LINK_INFO:{
            break;
        }
        case AUDIO_EVENT_ID_FEATURE_LIST_REPORT:{
            BOOL Feature_StereoMode = FALSE;
            BOOL Feature_ConcertMode = FALSE;
            BOOL Feature_EmbeddedMode = FALSE;
            if ((event->commandParameters[0] & 0x01) == 0x01)
                Feature_StereoMode = TRUE;
            if ((event->commandParameters[0] & 0x02) == 0x02)
                Feature_ConcertMode = TRUE;
            if ((event->commandParameters[0] & 0x04) == 0x04)
                Feature_EmbeddedMode = TRUE;
            
            if ((uartCommandDelegate != nil) && ([(NSObject *)uartCommandDelegate respondsToSelector:@selector(AudioUartCommandHandler:didUpdateFeature_StereoMode:Feature_ConcertMode:Feature_EmbeddedMode:)])) {
                [uartCommandDelegate AudioUartCommandHandler:connectedPeripheral didUpdateFeature_StereoMode:Feature_StereoMode Feature_ConcertMode:Feature_ConcertMode Feature_EmbeddedMode:Feature_EmbeddedMode];
            }
            

            break;
        }
        default:{
            NSLog(@"Non-parser Event: 0x%02X",event->eventHeader.commandID);
        }
            break;
    }
    if ([_events length] >= COMMAND_HEADER_SIZE)
        [self parseEvents];
}

@end
