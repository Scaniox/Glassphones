//
//  SoundEffectViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/5/28.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class SoundEffectViewController: UIViewController, DSPTuningDelegate {
    var DSPManager: TuneDSPManager?
    
    @IBOutlet var MBDRC_checkbox: VKCheckbox!
    @IBOutlet var AW_checkbox: VKCheckbox!
    @IBOutlet var VB_checkbox: VKCheckbox!
    @IBOutlet var AE_Mask_All_Off_checkbox: VKCheckbox!
    @IBOutlet var AE_Mask_MBDRC_On: VKCheckbox!
    @IBOutlet var AE_Mask_All_On_checkbox: VKCheckbox!
    @IBOutlet var AE_Mask_AW_On_checkbox: VKCheckbox!
    @IBOutlet var Audio_Effect_table: DropDown!
    @IBOutlet var AW_Level_table: DropDown! //Audio Widening Level
    
    @IBOutlet var TuneDSP: UIButton!
    @IBOutlet var MBDRC_Setting: UIButton!
    @IBOutlet var DSPState: UILabel!
    
    var Audio_Effect_List: Bool!
    var AW_Level_List: Bool!
    
    //var VB_tmp: UInt8!
    //var AW_Level_tmp: UInt8!
    var MBDRC_Prev_Data: [UInt8] = [UInt8]()
    
    let Audio_Effect_Data = ["All Off", "MB-DRC On", "All On", "AW On"]
    let AW_Level_Data = ["0x00:Lowest", "0x01", "0x02", "0x03", "0x04", "0x05", "0x06", "0x07", "0x08", "0x09", "0x0A", "0x0B", "0x0C", "0x0D", "0x0E", "0x0F:Highest"]
    
    let ids_1 = [1, 2, 3, 4]
    let ids_2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[SoundEffectViewController]viewDidLoad")
        
        TuneDSP.layer.cornerRadius = 10.0
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.AudioEffect_Delegate = self
        
        Audio_Effect_List = false
        AW_Level_List = false
        
        self.Audio_Effect_table.isSearchEnable = false
        self.AW_Level_table.isSearchEnable = false
        
        AW_Level_table.listHeight = 90
        
        Audio_Effect_table.optionArray = Audio_Effect_Data
        Audio_Effect_table.optionIds = ids_1
        
        VB_checkbox.checkboxValueChangedBlock = {
            isOn in
            print("VB_checkbox is \(isOn ? "ON" : "OFF")")
            
            if(isOn == true && ((self.DSPManager?.MBDRC_Data[1])! & 0x40 == 0)){
                self.DSPManager?.MBDRC_Data[1] &= ~(0x40)
                self.DSPManager?.MBDRC_Data[1] |= 0x40
                self.DSPTuningEnable()
                print("Checkbox is on,MBDRC_Data[1] = \(String(format: "0x%02X",(self.DSPManager?.MBDRC_Data[1])!))")
            }
            else if(isOn == false && ((self.DSPManager?.MBDRC_Data[1])! & 0x40 == 0x40)){
                self.DSPManager?.MBDRC_Data[1] &= ~(0x40)
                self.DSPTuningEnable()
                print("Checkbox is off,MBDRC_Data[1] = \(String(format: "0x%02X",(self.DSPManager?.MBDRC_Data[1])!))")
            }
        }
        
        Audio_Effect_table.didSelect{(selectedText , index , id) in
            print("Selected String: \(selectedText) \n index: \(index) \n Id: \(id)")
        }
        
        Audio_Effect_table.arrowSize = 10
        
        AW_Level_table.optionArray = AW_Level_Data
        AW_Level_table.optionIds = ids_2
        
        AW_Level_table.didSelect{(selectedText , index , id) in
            if(self.AW_Level_table.text != self.AW_Level_Data[self.AW_Level_table.selectedIndex!]){
                print("Selected string = \(self.AW_Level_Data[self.AW_Level_table.selectedIndex!])")
                if(self.AW_Level_table.selectedIndex! == 0){
                    self.DSPManager?.MBDRC_Data[5] = 0x0F
                }
                else if(self.AW_Level_table.selectedIndex! == 1){
                    self.DSPManager?.MBDRC_Data[5] = 0x1F
                }
                else if(self.AW_Level_table.selectedIndex! == 2){
                    self.DSPManager?.MBDRC_Data[5] = 0x2F
                }
                else if(self.AW_Level_table.selectedIndex! == 3){
                    self.DSPManager?.MBDRC_Data[5] = 0x3E
                }
                else if(self.AW_Level_table.selectedIndex! == 4){
                    self.DSPManager?.MBDRC_Data[5] = 0x4E
                }
                else if(self.AW_Level_table.selectedIndex! == 5){
                    self.DSPManager?.MBDRC_Data[5] = 0x5E
                }
                else if(self.AW_Level_table.selectedIndex! == 6){
                    self.DSPManager?.MBDRC_Data[5] = 0x6D
                }
                else if(self.AW_Level_table.selectedIndex! == 7){
                    self.DSPManager?.MBDRC_Data[5] = 0x7D
                }
                else if(self.AW_Level_table.selectedIndex! == 8){
                    self.DSPManager?.MBDRC_Data[5] = 0x8D
                }
                else if(self.AW_Level_table.selectedIndex! == 9){
                    self.DSPManager?.MBDRC_Data[5] = 0x9C
                }
                else if(self.AW_Level_table.selectedIndex! == 10){
                    self.DSPManager?.MBDRC_Data[5] = 0xAC
                }
                else if(self.AW_Level_table.selectedIndex! == 11){
                    self.DSPManager?.MBDRC_Data[5] = 0xBC
                }
                else if(self.AW_Level_table.selectedIndex! == 12){
                    self.DSPManager?.MBDRC_Data[5] = 0xCB
                }
                else if(self.AW_Level_table.selectedIndex! == 13){
                    self.DSPManager?.MBDRC_Data[5] = 0xDB
                }
                else if(self.AW_Level_table.selectedIndex! == 14){
                    self.DSPManager?.MBDRC_Data[5] = 0xEA
                }
                else if(self.AW_Level_table.selectedIndex! == 15){
                    self.DSPManager?.MBDRC_Data[5] = 0xF9
                }
                print("MBDRC data[5] = \(String(format: "0x%02X",(self.DSPManager?.MBDRC_Data[5])!))")
                self.DSPTuningEnable()
            }
        }
        
        AW_Level_table.arrowSize = 10
        
        Audio_Effect_table.listWillAppear {
            self.Audio_Effect_List = true
            
            if(self.AW_Level_List){
                self.AW_Level_table.hideList()
            }
            
            self.AW_Level_table.isHidden = true
            self.TuneDSP.isHidden = true
            self.MBDRC_Setting.isHidden = true
        }
        
        AW_Level_table.listWillAppear {
            self.AW_Level_List = true
            self.TuneDSP.isHidden = true
            self.MBDRC_Setting.isHidden = true
        }
        
        Audio_Effect_table.listDidDisappear {
            self.Audio_Effect_List = false
            
            if(self.AW_Level_table.isHidden == true){
                self.AW_Level_table.isHidden = false
            }
            
            if(self.TuneDSP.isHidden == true){
                self.TuneDSP.isHidden = false
            }
            
            if(self.MBDRC_Setting.isHidden == true){
                self.MBDRC_Setting.isHidden = false
            }
        }
        
        AW_Level_table.listDidDisappear {
            self.AW_Level_List = false
            
            if(self.TuneDSP.isHidden == true && self.Audio_Effect_List == false){
                self.TuneDSP.isHidden = false
            }
            
            if(self.MBDRC_Setting.isHidden == true && self.Audio_Effect_List == false){
                self.MBDRC_Setting.isHidden = false
            }
        }
        
        //DSPManager?.DSP_Init()
        //let device_capability = DSPManager?.Get_Device_Capability()
        //print("device_capability = \(device_capability!)")

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("[SoundEffectViewController] viewWillAppear")
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPState.text = DSPManager?.DSP_DUT_State
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "Sound Effect")
        
        //self.TuneDSP.isHidden = true
        
        print("Audio_Config = \(DSPManager?.Audio_Config)")
        
        if(Audio_Effect_table.text == "" && DSPManager?.Audio_Config != nil){
            print("Get Audio effect config data")
            DSPTuningDisable()
            SetAudioEffect()
        }
        
        /*
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport){
            VB_checkbox.isUserInteractionEnabled = false
            AW_Level_table.isUserInteractionEnabled = false
        }*/
        
        if(DSPState.text == "DSP Status: "){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
        
        if(DSPManager?.BLE_Connection != nil && DSPManager?.BLE_Connection == false){
            self.navigationController?.popViewController(animated: true)
            return
        }
        
        if(DSPManager?.RefreshGUIData(UIView_index: 1) == true){
            DSPTuningDisable()
            DSPManager?.ClearRefreshFlag(UIView_index: 1)
            self.DSPManager?.Get_Audio_DSP_Setting_MBDRC()
        }
        
        //TuneDSP.isEnabled = false
        
        /*
        //Simulator
        MBDRC_Data = [0x90, 0x29, 0x35, 0x02, 0x8F, 0xF9, 0x15, 0xC3]
        */
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("[SoundEffect]viewWillDisappear")
        
        if(DSPManager?.MBDRC_Data.count != 0){
            if(VB_checkbox.isOn() == true){
                DSPManager?.MBDRC_Data[1] &= ~(0x40)
                DSPManager?.MBDRC_Data[1] |= 0x40
            }
            else{
                DSPManager?.MBDRC_Data[1] &= ~(0x40)
            }
            
            /*
            if((AW_Level_tmp != DSPManager?.MBDRC_Data[5]) || (VB_tmp != ((DSPManager?.MBDRC_Data[1])! & 0x40))){
                print("[SoundEffect] DSPQueueData")
                var dd = (DSPManager?.MBDRC_Data)!
                let tmp = NSData(bytes: &dd, length: dd.count)
                print("tmp = \(tmp)")
                DSPManager?.DSPQueueData(module: 0x0C, cfg: 0x02, len: 0x08, data: dd)
                AW_Level_tmp = DSPManager?.MBDRC_Data[5]
                VB_tmp = ((DSPManager?.MBDRC_Data[1])! & 0x40)
            }*/
            
            //Check other data
            var tmp = (DSPManager?.MBDRC_Data)!
            let tmp1 = NSData(bytes: &tmp, length: tmp.count)
            print("tmp1 = \(tmp1)")
            let tmp2 = NSData(bytes: &MBDRC_Prev_Data, length: MBDRC_Prev_Data.count)
            print("tmp2 = \(tmp2)")
            if(tmp1.isEqual(to: tmp2 as Data) == false){
                DSPManager?.DSPQueueData(module:0x0C, cfg:0x02, len:0x08, data:tmp)
                MBDRC_Prev_Data.removeAll()
                MBDRC_Prev_Data = tmp
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "MBDRC_Segue") {
            print("prepareForSegue:MBDRCViewController")
            let vc = segue.destination as? MBDRCViewController
            if(vc != nil){
                //print("MBDRC data len = \(vc?.MBDRC_Data.count)")
                //vc?.MBDRC_Data = MBDRC_Data
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func ResetParameters(_ sender: Any) {
        print("ResetParameters")
    }
    
    @IBAction func DSPTuning(_ sender: Any) {
        
        //SetAudioEffect()
        if(DSPManager?.MBDRC_Data.count != 0){
            print("DSP Audio Widening Level")
            
            DSPManager?.DSPTuning(module: 0x0C, cfg: 0x02, len: UInt8(DSPManager!.MBDRC_Data.count), data: DSPManager!.MBDRC_Data)
        }
    }
    
    @IBAction func TuneMBDRCParameters(_ sender: Any) {
        if(DSPManager?.MBDRC_Data.count != 0){
            print("TuneMBDRCParameters")
            
            if(VB_checkbox.isOn() == true){
                DSPManager?.MBDRC_Data[1] &= ~(0x40)
                DSPManager?.MBDRC_Data[1] |= 0x40
            }
            else{
                DSPManager?.MBDRC_Data[1] &= ~(0x40)
            }
            
            let VB_bit = ((DSPManager?.MBDRC_Data[1])! & 0x40) >> 6
            print("VB_bit = \(VB_bit)")
            
            print("MBDRC data[1] = \(String(format: "0x%02X",(DSPManager?.MBDRC_Data[1])!))")
            
            self.performSegue(withIdentifier: "MBDRC_Segue", sender: self)
        }
    }
    
    func SetAudioEffect() {
        
        var audio_effect_mask: UInt8?
        var audio_effect: UInt8?
        
        (audio_effect_mask, audio_effect) = (DSPManager?.GetAudioEffect())!
        
        if(audio_effect_mask != nil && audio_effect != nil) {
            print("audio_effect_mask = \(audio_effect_mask!), audio_effect = \(audio_effect!)")
            
            if((audio_effect_mask! & 0x01) == 0x01){
                AE_Mask_All_Off_checkbox.setOn(true)
            }
            else{
                AE_Mask_All_Off_checkbox.setOn(false)
            }
            AE_Mask_All_Off_checkbox.isUserInteractionEnabled = false
            
            if((audio_effect_mask! & 0x02) == 0x02){
                AE_Mask_MBDRC_On.setOn(true)
            }
            else{
                AE_Mask_MBDRC_On.setOn(false)
            }
            AE_Mask_MBDRC_On.isUserInteractionEnabled = false
            
            if((audio_effect_mask! & 0x04) == 0x04){
                AE_Mask_All_On_checkbox.setOn(true)
            }
            else{
                AE_Mask_All_On_checkbox.setOn(false)
            }
            AE_Mask_All_On_checkbox.isUserInteractionEnabled = false
            
            if((audio_effect_mask! & 0x08) == 0x08){
                AE_Mask_AW_On_checkbox.setOn(true)
            }
            else{
                AE_Mask_AW_On_checkbox.setOn(false)
            }
            AE_Mask_AW_On_checkbox.isUserInteractionEnabled = false
            
            Audio_Effect_table.selectedIndex = Int(audio_effect!)
            if(audio_effect! == 0x00) {
                Audio_Effect_table.text = "All Off"
            }
            else if(audio_effect! == 0x01) {
                Audio_Effect_table.text = "MB-DRC On"
            }
            else if(audio_effect! == 0x02) {
                Audio_Effect_table.text = "All On"
            }
            else if(audio_effect! == 0x03) {
                Audio_Effect_table.text = "AW On"
            }
            
            Audio_Effect_table.isEnabled = false
        }
        
        let (MBDRC_onoff, AW_onoff) = (DSPManager?.CheckAudioMBDRC_AW())!
        if(MBDRC_onoff!){
            MBDRC_checkbox.setOn(true)
        }
        else{
            MBDRC_checkbox.setOn(false)
            VB_checkbox.isUserInteractionEnabled = false
        }
        MBDRC_checkbox.isUserInteractionEnabled = false
        
        if(AW_onoff!){
            AW_checkbox.setOn(true)
        }
        else{
            AW_checkbox.setOn(false)
        }
        AW_checkbox.isUserInteractionEnabled = false
        
        if(AW_Level_table.text == ""){
            self.DSPManager?.Get_Audio_DSP_Setting_MBDRC()
        }
    }
    
    func MBDRC_Init(){
        print("MBDRC_Init")
        
        if(DSPManager?.MBDRC_Data.count != 0){
            //print("AW_Level index = \(Int(MBDRC_Data[5] >> 4))")
            print("AW_Level index = \(Int((DSPManager?.MBDRC_Data[5])! >> 4))")
            //AW_Level_table.selectedIndex = Int(MBDRC_Data[5] >> 4)
            AW_Level_table.selectedIndex = Int((DSPManager?.MBDRC_Data[5])! >> 4)
            AW_Level_table.text = AW_Level_Data[AW_Level_table.selectedIndex!]
            
            //AW_Level_tmp = DSPManager?.MBDRC_Data[5]
            //VB_tmp = ((DSPManager?.MBDRC_Data[1])! & 0x40)
            //print("VB_tmp = \(VB_tmp)")
            
            MBDRC_Prev_Data = DSPManager!.MBDRC_Data
            print("MBDRC_Prev_Data = \(MBDRC_Prev_Data)")
            
            if(((DSPManager?.MBDRC_Data[1])! & 0x40) == 0x40){
                VB_checkbox.bgColor = UIColor.white
                VB_checkbox.bgColorSelected = UIColor.white
                VB_checkbox.setOn(true)
            }
            else{
                VB_checkbox.bgColor = UIColor.white
                VB_checkbox.bgColorSelected = UIColor.white
                VB_checkbox.setOn(false)
            }
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ConnectionStatus(status: Bool) {
        print("[SoundEffect] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func BLE_ServiceReady() {
        print("BLE_ServiceReady")
    }
    
    func RefreshModuleData() {
        print("[Audio Effect] RefreshModuleData")
    }
    
    func RefreshParametersData(dat:Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 12 && buffer[k+1] == 2){
                DSPManager?.MBDRC_Data.removeAll()
                for index in 0..<8 {
                    //MBDRC_Data.append(buffer[index+k+3])
                    DSPManager?.MBDRC_Data.append(buffer[index+k+3])
                }
                print("MBDRC len = \(DSPManager?.MBDRC_Data.count) , data = \(DSPManager?.MBDRC_Data)")
                
                MBDRC_Init()
                break
            }
            
            k += Int(3+len)
        }
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 1)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func DSPTuningState(state:String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            VB_checkbox.isUserInteractionEnabled = false
            if(AW_Level_List == true){
                AW_Level_List = false
                AW_Level_table.hideList()
            }
            AW_Level_table.isUserInteractionEnabled = false
            MBDRC_Setting.isEnabled = false
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            VB_checkbox.isUserInteractionEnabled = true
            AW_Level_table.isUserInteractionEnabled = true
            MBDRC_Setting.isEnabled = true
        }
    }
    
    func ExportDSPTuningResult(){
    }
}
