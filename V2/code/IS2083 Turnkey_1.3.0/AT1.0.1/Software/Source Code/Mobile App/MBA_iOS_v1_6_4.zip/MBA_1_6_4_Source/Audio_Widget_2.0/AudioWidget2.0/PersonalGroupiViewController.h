//
//  PersonalGroupiViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 25/05/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CBController.h"
#import "AudioUartCommandHandler.h"

@interface PersonalGroupiViewController : UIViewController<CBPeripheralManagerDelegate,CBControllerDelegate,UITableViewDataSource,UITableViewDelegate,AudioUartCommandDelegate,UITextFieldDelegate,UITextViewDelegate>{
    
    IBOutlet UITextField *groupName;
    IBOutlet UITableView *masterListTableView;
    IBOutlet UITableView *slaveListTableView;
    IBOutlet UIButton *createGroupButton;
    AudioUartCommandHandler *uartCommandHanlder;
}

@property(assign) CBController *cbController;
@property (retain) NSMutableArray *allMasterList;
@property (retain) NSMutableArray *allSlaveList;
@property (assign) BOOL newPersonalGroup;
@property (assign) int personalGroupMode;
@property (retain) NSString *groupNameStr;
@property (retain) NSMutableArray *masterFlag;
@property (retain) NSMutableArray *slaveFlag;
@property (assign) CBPeripheralManager *pmgr;
@property (nonatomic, strong) id rootViewController;

- (IBAction)createGroupButtonPressed:(id)sender;
@end
