//
//  Main.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/7/11.
//  Copyright © 2019 ISSC. All rights reserved.
//

import Foundation
import UIKit

@objc class MainViewController: UIViewController{
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    let appArray =      [/*"WCT"*/"Wireless Concert Technology (WCT)",        /*"WST"*/"Wireless Stereo Technology (WST)",                  "OTA DFU",                  "OTA DSP Tuninig" ]
    let proArray =      ["BM64/BM83",         "IS2066",             "BM83",                   "BM83" ]
    let imageArray =    ["iconfinder_speaker",  "iconfinder_airpods",   "iconfinder_system_update", "iconfinder_wave" ]
 
    
    let APP_MSPK = 0
    let APP_WST = 1
    let APP_OTA_DFU = 2
    let APP_OTA_TUNING = 3

    
    var estimateWidth = 160.0
    var cellMarginSize = 16.0
    
    var OTA_Func_Selector: Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Microchip Bluetooth Audio"
        // Set Delegates
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
        // Register cells
        self.collectionView.register(UINib(nibName: "MainMenuCell", bundle: nil), forCellWithReuseIdentifier: "MAIN_MENU_CELL")
        
        // SetupGrid view
        self.setupGridView()
        
        if #available(iOS 13.0, *) {
            //self.isModalInPresentation = true
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        self.setupGridView()
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
    
    
    func setupGridView() {
        let flow = collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
        flow.minimumInteritemSpacing = CGFloat(self.cellMarginSize)
        flow.minimumLineSpacing = CGFloat(self.cellMarginSize)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "FORCE_TO_OTA_DFU") {
            print("prepareForSegue: FORCE_TO_OTA_DFU")
            let vc = segue.destination as? DeviceTableViewController
            vc?.OTA_Mode = self.OTA_Func_Selector
        }
    }
}

// MARK: - UICollectionView DataSource
extension MainViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.appArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MAIN_MENU_CELL", for: indexPath) as! MainMenuCell
        cell.setAppName(name: self.appArray[indexPath.row])
        cell.setEvbName(name: self.proArray[indexPath.row])
        cell.setAppImage(imageName: self.imageArray[indexPath.row])
        cell.layer.cornerRadius = 10
        return cell
    }
}

// MARK: - UICollectionView Delegate Flow Layout
extension MainViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = self.calculateWith()
        return CGSize(width: width, height: width)
    }
    
    func calculateWith() -> CGFloat {
        let estimatedWidth = CGFloat(estimateWidth)
        let cellCount = floor(CGFloat(self.view.frame.size.width / estimatedWidth))
        
        let margin = CGFloat(cellMarginSize * 2)
        let width = (self.view.frame.size.width - CGFloat(cellMarginSize) * (cellCount - 1) - margin) / cellCount
        
        return width
    }
    
    //cell上下左右留邊
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets{
        return UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10);
    }
}

// MARK: - UICollectionView Delegate
extension MainViewController: UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch indexPath.item {
            case APP_MSPK:
                performSegue(withIdentifier: "FORCE_TO_MSPK", sender: self)
            case APP_WST:
                performSegue(withIdentifier: "FORCE_TO_WST", sender: self)
                return
            case APP_OTA_DFU:
                OTA_Func_Selector = true
                performSegue(withIdentifier: "FORCE_TO_OTA_DFU", sender: self)
            case APP_OTA_TUNING:
                OTA_Func_Selector = false
                performSegue(withIdentifier: "FORCE_TO_OTA_DFU", sender: self)
            default:
                return
        }
    }
}
