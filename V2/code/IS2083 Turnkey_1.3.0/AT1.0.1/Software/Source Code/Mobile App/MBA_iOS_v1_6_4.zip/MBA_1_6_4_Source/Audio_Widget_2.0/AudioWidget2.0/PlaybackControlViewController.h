//
//  PlaybackControlViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 22/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPeripheral.h"


@interface PlaybackControlViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,MyPeripheralDelegate,UIActionSheetDelegate>{

    IBOutlet UIButton *stopBtn;
    IBOutlet UIButton *playBtn;
    IBOutlet UIButton *nextBtn;
    IBOutlet UIButton *previousBtn;
    IBOutlet UITableView *myTableView;
    IBOutlet UIButton *audioSyncBtn;
}
@property(retain) MyPeripheral    *connectedPeripheral;
@property(assign) BOOL Feature_EmbeddedMode;
@property(retain) NSMutableArray *groupInfo;
@property(assign) BOOL Feature_StereoMode;
@property(assign) BOOL Feature_ConcertMode;
@property(assign) unsigned char DatabaseInfo;

- (IBAction)playBtnPressed:(id)sender;
- (IBAction)nextBtnPressed:(id)sender;
- (IBAction)previoceBtnPressed:(id)sender;
- (IBAction)audioSyncBtnPressed:(id)sender;
- (IBAction)stopBtnPressed:(id)sender;



@end
