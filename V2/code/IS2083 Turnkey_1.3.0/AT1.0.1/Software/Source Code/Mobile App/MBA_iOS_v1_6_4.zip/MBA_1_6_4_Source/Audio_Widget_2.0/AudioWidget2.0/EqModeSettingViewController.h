//
//  EqModeSettingViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 23/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPeripheral.h"

@interface EqModeSettingViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,MyPeripheralDelegate>{
    
    IBOutlet UIButton *manualSettingButton;
    IBOutlet UITableView *myTableView;
}
@property(retain) MyPeripheral    *connectedPeripheral;
@property (retain) NSIndexPath *selectedEqMode;
@property(assign) unsigned char DatabaseInfo;
- (IBAction)manualSettingBtnPressed:(id)sender;

@end
