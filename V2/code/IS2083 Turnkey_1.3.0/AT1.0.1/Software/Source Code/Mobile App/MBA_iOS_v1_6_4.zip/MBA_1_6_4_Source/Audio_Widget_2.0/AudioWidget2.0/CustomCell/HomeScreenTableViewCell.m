//
//  HomeScreenTableViewCell.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 02/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "HomeScreenTableViewCell.h"

@implementation HomeScreenTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_speakerNameLabel release];
    [_groupRoleLabel release];
    [_batteryLevelImageView release];
    [_rssiLevelImageView release];
    [super dealloc];
}
@end
