//
//  SpeakerSettingTableViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 22/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPeripheral.h"

@interface SpeakerSettingTableViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate,MyPeripheralDelegate,UITextFieldDelegate>{

    IBOutlet UITableView *myTableView;
}
@property(retain) MyPeripheral    *connectedPeripheral;

@end
