//
//  WstButtonActionViewController.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/9/20.
//  Copyright © 2019 ISSC. All rights reserved.
//

import Foundation
import UIKit
//import CoreBluetooth

class WstButtonActionTableViewController: UITableViewController {
    var m_parentView: WstTouchpadSettingViewController?
    var actionArray: Array<Any>?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Action"
        
    }
    
    @objc func setBackgroundMode(background:Bool){
        m_parentView!.setBackgroundMode(background:background)
    }
    
    @objc func terminateBle(){
        m_parentView!.terminateBle()
    }
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return actionArray!.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()//tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! WST_ScanResultCell
        cell.textLabel?.text = actionArray![indexPath.row] as? String
        cell.backgroundColor = .groupTableViewBackground
        return cell
    }
    
    // MARK: - Table view delegate
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        m_parentView!.didSelectAction(action:actionArray![indexPath.row] as? String)
    }
}
