//
//  HomeScreenViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 25/01/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "HomeScreenViewController.h"
#import "HomeScreenTableViewHeader.h"
#import "HomeScreenTableViewCell.h"
#import "UIView+Toast.h"
#import "ISUtility.h"
#import "UngroupedHomeScreenViewController.h"
#import "PersonalGroupiViewController.h"

#import "MBA-Swift.h"

@implementation UIView (ParentTableViewCell)
-(UITableViewCell *)parentTableViewCell{
    UIView *aView = self.superview;
    while (aView != nil) {
        if ([aView isKindOfClass:[UITableViewCell class]]) {
            return (UITableViewCell *)aView;
        }
        aView = aView.superview;
    }
    return nil;
}
@end

@interface HomeScreenViewController (){
    CBController *_cbController;
    NSArray *BatteryLevelArray;
    NSArray *RssiLevelArray;
    NSMutableDictionary *MultiSpkRoleDict;
    int groupIndex;
    NSTimer *continousScanTimer;
    int personalGroupMode;
    BOOL newPersonalGroup;
    NSMutableDictionary  *groupRecord;
    
    BOOL filterOn;
}
@end

#define GROUP_MODE_STEREO 0
#define GROUP_MODE_CONCERT 1
@implementation HomeScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _cbController = [[CBController alloc] init];
    [_cbController setRssiFilterValue:-127];
    filterOn = NO;
    pmgr = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
    
    self.title = @"Microchip Bluetooth Audio";
    
    UIBarButtonItem *scanButton = [[UIBarButtonItem alloc] init];
    scanButton.title = @"Scan";
    scanButton.target = self;
    [scanButton setAction:@selector(RefreshScan:)];
    //logButton.enabled = FALSE;
    self.navigationItem.rightBarButtonItem = scanButton;
    
    UIBarButtonItem *OTA_Button = [[UIBarButtonItem alloc] init];
    OTA_Button.title = @"OTA";
    OTA_Button.target = self;
    [OTA_Button setAction:@selector(OTA_Update)];
    self.navigationItem.leftBarButtonItem = OTA_Button;
    
    _ScanButton.layer.cornerRadius = 10.0;
    _DeviceTableView.backgroundColor = [UIColor clearColor];
    _DeviceTableView.delegate = self;
    _DeviceTableView.dataSource = self;
    
    _PersonalGroupingRecordTableView.backgroundColor = [UIColor clearColor];
    _PersonalGroupingRecordTableView.layer.borderWidth = 2.0;
    _PersonalGroupingRecordTableView.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    _PersonalGroupingRecordTableView.delegate = self;
    _PersonalGroupingRecordTableView.dataSource = self;
    
    MultiSpkRoleDict = [@{@0x00:@"Ungrouped",
                          @0x01:@"Stereo Master",
                          @0x04:@"Stereo Slave",
                          @0x05:@"Concert Master",
                          @0x06:@"Concert Slave",
                          @0x07:@"Concert Master"}mutableCopy];
    
    BatteryLevelArray = [[NSArray alloc] initWithObjects:@"battery0.png",@"battery1.png",@"battery2.png",@"battery3.png",@"battery4.png",@"battery5.png", nil];
    RssiLevelArray = [[NSArray alloc] initWithObjects:@"signal0.png",@"signal1.png",@"signal2.png",@"signal3.png",@"signal4.png",@"signal5.png", nil];
    groupIndex = 0;
    newPersonalGroup = TRUE;
    
    [self startScan];
    UILongPressGestureRecognizer *longPressGR = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    longPressGR.minimumPressDuration = 1.5;
    longPressGR.delegate = self;
    [_DeviceTableView addGestureRecognizer:longPressGR];
    [longPressGR release];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_DeviceTableView release];
    [_ScanButton release];
    [_PersonalGroupingRecordTableView release];
    [super dealloc];
}

- (void) displayDevicesList {
    [_DeviceTableView reloadData];
}

- (void)startScan {
    [_cbController startScanWithUUID:nil removeDevice:YES];
    if (!continousScanTimer) {
        continousScanTimer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(continuousScan) userInfo:nil repeats:YES];
    }
    [_DeviceTableView reloadData];
}

- (void)continuousScan {
    [_cbController startScanWithUUID:nil removeDevice:NO];
}

- (void)stopScan {
    if ([continousScanTimer isValid]) {
        [continousScanTimer invalidate];
    }
    continousScanTimer = nil;
    [_cbController stopScan];
    
}

- (IBAction)ScanButtonPressed:(id)sender {
    [self stopScan];
    [self startScan];
}

- (void)RefreshScan:(id)sender{
    [self stopScan];
    [self startScan];
}

- (void)viewDidAppear:(BOOL)animated {
    [_cbController setDelegate:self];
    [pmgr setDelegate:self];
    NSLog(@"viewDidAppear");
    NSDictionary *record = [[NSUserDefaults standardUserDefaults] objectForKey:@"GROUP_RECORD"];
    if (record == nil) {
        groupRecord = [[NSMutableDictionary alloc] init];
    }
    else {
        groupRecord = [record mutableCopy];
        NSLog(@"%@",groupRecord);
    }
    
    if (controlPeripheral!=nil && controlPeripheral.connectStatus == MYPERIPHERAL_CONNECT_STATUS_CONNECTED) {
        [_cbController disconnectDevice:controlPeripheral];
    }
    [_PersonalGroupingRecordTableView reloadData];
    
    [self performSelector:@selector(startScan) withObject:nil afterDelay:0.1];
}

- (void)updateSwitch:(id)sender{
    UISwitch *switcher = (UISwitch *)sender;
    if (switcher.on) {
        [switcher setOn:YES animated:YES];
        filterOn = YES;
        [_cbController setRssiFilterValue:-60];
        
    }else{
        [switcher setOn:NO animated:YES];
        filterOn = NO;
        [_cbController setRssiFilterValue:-127];
    }
    [self performSelector:@selector(startScan) withObject:nil afterDelay:0.1];
}

#pragma mark - OTA
- (void)OTA_Update {
    NSLog(@"OTA_Update");
    
    [self stopScan];
    sleep(2);
    
    if(_BtState == CBPeripheralManagerStatePoweredOn){
        [self performSegueWithIdentifier:@"OTA_Scan" sender:self];
    }
    else{
        NSLog(@"BT State: Power off");
    }
    
    //[self performSegueWithIdentifier:@"OTA_Scan" sender:self];
    
}

#pragma mark - Navigation
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if([[segue identifier] isEqualToString:@"OTA_Scan"]){
        NSLog(@"prepareForSegue:OTA_Scan");
    }
    else if([[segue identifier] isEqualToString:@"FORCE_TO_UNGROUP_HOME_SCREEN"]){
        [self stopScan];
        UIBarButtonItem *backButton = [[UIBarButtonItem alloc] init];
        backButton.title = @"Disconnect";
        self.navigationItem.backBarButtonItem = backButton;
        
        UngroupedHomeScreenViewController *view = segue.destinationViewController;
        view.connectedPeripheral = controlPeripheral;
        CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
        id serviceData = [controlPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
        id Data = [serviceData objectForKey:uuid];
        unsigned char *dataByte;
        dataByte = malloc([Data length]);
        [Data getBytes:dataByte length:[Data length]];
        struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
        view.dataCategory = discoveredSpecialData->batteryLevel_And_Data_Category.category;
        
        if (discoveredSpecialData->batteryLevel_And_Data_Category.category == 0x02) {
            view.groupInfo = [[NSMutableArray alloc]init];
            [view.groupInfo addObject:controlPeripheral];
            //view.genericHS = TRUE;
            view.speakerRole = 0x00;
            view._csbState = 0x00;
            
        }else{
            view.groupInfo = [[NSMutableArray alloc]init];
            
            [view.groupInfo addObject:controlPeripheral];
            view.speakerRole = discoveredSpecialData->multiSpeakerRole;
            view._csbState = discoveredSpecialData->multiSpeakerState;
            //view.genericHS = NO;
            if (discoveredSpecialData->multiSpeakerRole != 0x00) {
                NSArray *groupList = [_cbController.devicesGroupList allKeys];
                NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:Nil ascending:NO selector:@selector(compare:)];
                groupList = [groupList sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
                NSMutableArray *groupMemberList = [_cbController.devicesGroupList objectForKey:groupList[groupIndex]];
                
                for(MyPeripheral *tmpPeripheral in groupMemberList) {
                    if (tmpPeripheral != controlPeripheral) {
                        [view.groupInfo addObject:tmpPeripheral];
                    }
                }
            }
        }
    }else{
        [self stopScan];
        UIBarButtonItem *backButton = [[UIBarButtonItem alloc] init];
        backButton.title = @"Back";
        self.navigationItem.backBarButtonItem = backButton;
        
        PersonalGroupiViewController *view = segue.destinationViewController;
        view.cbController = _cbController;
        view.allMasterList = [[NSMutableArray alloc]init];
        view.allSlaveList = [[NSMutableArray alloc]init];
        view.newPersonalGroup = newPersonalGroup;
        view.masterFlag = [[NSMutableArray alloc]init];
        view.slaveFlag = [[NSMutableArray alloc]init];
        view.pmgr = pmgr;
        view.rootViewController = self;
        
        if (newPersonalGroup) {
            view.personalGroupMode = personalGroupMode;
        }else{
            NSArray *keys = [groupRecord allKeys];
            NSDictionary *dict = [groupRecord objectForKey:[keys objectAtIndex:groupIndex]];
            NSString *groupName = [dict objectForKey:@"GROUP_NAME"];
            view.groupNameStr = groupName;
            view.personalGroupMode = [[dict objectForKey:@"GROUP_MODE"]intValue];
        }
        NSArray *groupList = [_cbController.devicesGroupList allKeys];
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:Nil ascending:NO selector:@selector(compare:)];
        groupList = [groupList sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSMutableArray *groupMemberList = [_cbController.devicesGroupList objectForKey:groupList[[groupList count]-1]];
        for (int i=0; i< [groupMemberList count]; i++) {
            MyPeripheral *tmpPeripheral = [groupMemberList objectAtIndex:i];
            CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
            id serviceData = [tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
            //NSLog(@"adv data = %@", tmpPeripheral.advertiseData);
            
            id Data = [serviceData objectForKey:uuid];
            if(Data){
                unsigned char *dataByte;
                dataByte = malloc([Data length]);
                [Data getBytes:dataByte length:[Data length]];
                struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
                
                if(discoveredSpecialData->batteryLevel_And_Data_Category.category == 0x00) {
                    [view.allMasterList addObject:tmpPeripheral];
                    [view.allSlaveList addObject:tmpPeripheral];
                    [view.masterFlag addObject:[NSNumber numberWithBool:NO]];
                    [view.slaveFlag addObject:[NSNumber numberWithBool:NO]];
                    
                }else {
                    
                    if(view.personalGroupMode == GROUP_MODE_STEREO){
                        if ((discoveredSpecialData->extendData.category1_par.supportFeature & 0x01) == 0x01) {
                            [view.allMasterList addObject:tmpPeripheral];
                            [view.allSlaveList addObject:tmpPeripheral];
                            [view.masterFlag addObject:[NSNumber numberWithBool:NO]];
                            [view.slaveFlag addObject:[NSNumber numberWithBool:NO]];
                            
                        }
                    }else{
                        if ((discoveredSpecialData->extendData.category1_par.supportFeature & 0x02) == 0x02) {
                            [view.allMasterList addObject:tmpPeripheral];
                            [view.allSlaveList addObject:tmpPeripheral];
                            [view.masterFlag addObject:[NSNumber numberWithBool:NO]];
                            [view.slaveFlag addObject:[NSNumber numberWithBool:NO]];
                            
                        }
                    }
                }
                if(!newPersonalGroup){
                    NSArray *keys = [groupRecord allKeys];
                    NSDictionary *dict = [groupRecord objectForKey:[keys objectAtIndex:groupIndex]];
                    NSArray *MasterArray = [dict objectForKey:@"MASTER_LIST"];
                    NSArray *SlaveArray = [dict objectForKey:@"SLAVE_LIST"];
                    
                    for (int j=0; j<[MasterArray count]; j++) {
                        NSString *uuid = [MasterArray objectAtIndex:j];
                        if ([tmpPeripheral.uuidString isEqualToString:uuid]) {
                            [view.masterFlag replaceObjectAtIndex:i withObject:[NSNumber numberWithBool:YES]];
                        }
                    }
                    
                    for (int j=0; j<[SlaveArray count]; j++) {
                        NSString *uuid = [SlaveArray objectAtIndex:j];
                        if ([tmpPeripheral.uuidString isEqualToString:uuid]) {
                            [view.slaveFlag replaceObjectAtIndex:i withObject:[NSNumber numberWithBool:YES]];
                        }
                    }
                }
            }
        }
    }
}

#pragma mark - UIGestureRecognizerDelegate
-(void)handleLongPress:(UILongPressGestureRecognizer *)gestureRecognizer{
    CGPoint p = [gestureRecognizer locationInView:_DeviceTableView];
    NSIndexPath *indexPath = [_DeviceTableView indexPathForRowAtPoint:p];
    if (indexPath == nil) {
    }else{
        /*if (indexPath.row == 0) {
         return;
         }*/
        NSArray *groupList = [_cbController.devicesGroupList allKeys];
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:Nil ascending:NO selector:@selector(compare:)];
        groupList = [groupList sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        MyPeripheral *tmpPeripheral;
        if(indexPath.section == [groupList count]){
            tmpPeripheral = [_cbController.genericHeadsetList objectAtIndex:indexPath.row];
        }else{
            NSMutableArray *groupMemberList = [_cbController.devicesGroupList objectForKey:groupList[indexPath.section]];
            tmpPeripheral = [groupMemberList objectAtIndex:indexPath.row];
        }
        CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
        id serviceData = [tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
        id Data = [serviceData objectForKey:uuid];
        unsigned char *dataByte;
        dataByte = malloc([Data length]);
        [Data getBytes:dataByte length:[Data length]];
        NSMutableString *content = [[NSMutableString alloc]init];
        [content setString:@"0x"];
        for (int i=0; i<[Data length]; i++) {
            [content appendFormat:@"%02X ",dataByte[i]];
        }
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"ADV Data" message:content preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *dafaultAction = [UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){}];
        [alert addAction:dafaultAction];
        UIView *subView1 = alert.view.subviews[0];
        UIView *subView2 = subView1.subviews[0];
        UIView *subView3 = subView2.subviews[0];
        UIView *subView4 = subView3.subviews[0];
        UIView *subView5 = subView4.subviews[0];
        UILabel *contentView = subView5.subviews[1];
        contentView.textAlignment = NSTextAlignmentLeft;
        [self presentViewController:alert animated:YES completion:nil];
    }
}

#pragma mark - Table view data source
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (tableView == _DeviceTableView) {
        HomeScreenTableViewHeader *myHeader = (HomeScreenTableViewHeader*)[tableView dequeueReusableCellWithIdentifier:@"HOME_SCREEN_TABLE_VIEW_HEADER"];
        if (myHeader == nil) {
            myHeader = [[HomeScreenTableViewHeader alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"HOME_SCREEN_TABLE_VIEW_HEADER"];
        }
        myHeader.backgroundColor = [UIColor clearColor];
        
        NSArray *groupList = [_cbController.devicesGroupList allKeys];
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:Nil ascending:NO selector:@selector(compare:)];
        groupList = [groupList sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSString *speakerImage = @"Speaker.png";
        if (section == [groupList count]) {
            speakerImage = @"headset.png";
        }else{
            NSMutableArray *groupMemberList = [_cbController.devicesGroupList objectForKey:groupList[section]];
            switch (section) {
                default:
                {
                    MyPeripheral *tmpPeripheral = [groupMemberList objectAtIndex:0];
                    CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
                    id serviceData = [tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
                    //NSLog(@"adv data = %@", tmpPeripheral.advertiseData);
                    
                    id Data = [serviceData objectForKey:uuid];
                    if(Data){
                        unsigned char *dataByte;
                        dataByte = malloc([Data length]);
                        [Data getBytes:dataByte length:[Data length]];
                        struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
                        
                        NSString *group_id;
                        if(discoveredSpecialData->batteryLevel_And_Data_Category.category == 0x00) {
                            group_id = [NSString stringWithFormat:@"%02X%02X%02X%02X",discoveredSpecialData->extendData.category0_par.group_ID[0],discoveredSpecialData->extendData.category0_par.group_ID[1],discoveredSpecialData->extendData.category0_par.group_ID[2],discoveredSpecialData->extendData.category0_par.group_ID[3]];
                        }else {
                            group_id = [NSString stringWithFormat:@"%02X%02X%02X%02X%02X%02X",discoveredSpecialData->extendData.category1_par.group_ID[0],discoveredSpecialData->extendData.category1_par.group_ID[1],discoveredSpecialData->extendData.category1_par.group_ID[2],discoveredSpecialData->extendData.category1_par.group_ID[3],discoveredSpecialData->extendData.category1_par.group_ID[4],discoveredSpecialData->extendData.category1_par.group_ID[5]];
                        }
                        
                        if ([group_id isEqualToString:@"00000000"] || [group_id isEqualToString:@"000000000000"]) {
                            speakerImage = @"single_speaker.png";
                        }else{
                            unsigned char role = discoveredSpecialData->multiSpeakerRole;
                            if((role == 0x01) || (role == 0x04)){ ///Stereo Master/Slave
                                speakerImage = @"stereo_group.png";
                            }else
                                speakerImage = @"group_speakers.png";
                        }
                    }
                    
                }
            }
        }
        UIImage *imgView = [UIImage imageNamed:speakerImage];
        [myHeader.imageView setImage:imgView];
        myHeader.groupIdentifierLabel.text = @"";
        
        return myHeader;
    }else{
        UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        cell.backgroundColor = [UIColor clearColor];
        if (section == 0 || section == 1) {
            cell.textLabel.text = @"";
        }else{
            cell.textLabel.text = @"Recently created Groups";
        }
        return cell;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == _DeviceTableView) {
        NSArray *keys = [_cbController.devicesGroupList allKeys];
        if ([_cbController.genericHeadsetList count]>0) {
            return ([keys count]+1);
        }else
            return [keys count];
    }else{
        return 3;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == _DeviceTableView) {
        NSArray *keys = [_cbController.devicesGroupList allKeys];
        if (section == [keys count]) {
            return [_cbController.genericHeadsetList count];
        }else{
            NSArray *groupList = [_cbController.devicesGroupList allKeys];
            NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:Nil ascending:NO selector:@selector(compare:)];
            groupList = [groupList sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            NSMutableArray *groupMemberList = [_cbController.devicesGroupList objectForKey:groupList[section]];
            return [groupMemberList count];
        }
    }else{
        switch (section) {
            case 0:
            case 1:
                return 1;
                break;
                
            default:{
                return [groupRecord count];
            }
                break;
        }
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSString *title = nil;
    if (tableView == _DeviceTableView) {
        title = @"Group";
    }else{
        switch (section) {
            case 0:
                title = @"Personal Group";
                break;
                
            default:
                title = @"Recently created Groups";
                break;
        }
        
    }
    return title;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == _DeviceTableView) {
        HomeScreenTableViewCell *myCell = (HomeScreenTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"HOME_SCREEN_TABLE_VIEW_CELL"];
        NSArray *groupList = [_cbController.devicesGroupList allKeys];
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:Nil ascending:NO selector:@selector(compare:)];
        groupList = [groupList sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        
        if (indexPath.section == [groupList count]) {
            MyPeripheral *tmpPeripheral = [_cbController.genericHeadsetList objectAtIndex:indexPath.row];
           
            myCell.speakerNameLabel.text = tmpPeripheral.advName;
            
            if (myCell.speakerNameLabel.text == nil)
                myCell.speakerNameLabel.text = @"Unknow";
            BOOL isConnectable = [[tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataIsConnectable] boolValue];
            if (!isConnectable) {
                myCell.speakerNameLabel.enabled = FALSE;
            }else
                myCell.speakerNameLabel.enabled = TRUE;
            
            int rssiLevelIdx = 0;
            
            if (tmpPeripheral.rssi_Value < -110) {
                rssiLevelIdx = 0;
            }else if (tmpPeripheral.rssi_Value <= -100){
                rssiLevelIdx = 1;
            }else if (tmpPeripheral.rssi_Value <= -85){
                rssiLevelIdx = 2;
            }else if (tmpPeripheral.rssi_Value <= -70){
                rssiLevelIdx = 3;
            }else if (tmpPeripheral.rssi_Value <= -60){
                rssiLevelIdx = 4;
            }else{
                rssiLevelIdx = 5;
            }
            NSString *RssiLevel = RssiLevelArray[rssiLevelIdx];
            
            myCell.groupRoleLabel.text = @"";
            //UIImage *batteryImgView = [UIImage imageNamed:BatteryLevel];
            [myCell.batteryLevelImageView setImage:nil];
            UIImage *rssiImgView = [UIImage imageNamed:RssiLevel];
            [myCell.rssiLevelImageView setImage:rssiImgView];
            myCell.backgroundColor = [UIColor clearColor];
        }else{
            NSMutableArray *groupMemberList = [_cbController.devicesGroupList objectForKey:groupList[indexPath.section]];
            switch (indexPath.section) {
                default:
                {
                    MyPeripheral *tmpPeripheral = [groupMemberList objectAtIndex:indexPath.row];
                    CBUUID *uuid = [CBUUID UUIDWithString:@"FEDA"];
                    NSString *MultiSpkRole = nil;
                    NSString *BatteryLevel = nil;
                    NSString *RssiLevel = nil;
                    
                    unsigned char csbstate = 0x00;
                    
                    id serviceData = [tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataServiceDataKey];
                    //NSLog(@"adv data = %@", tmpPeripheral.advertiseData);
                    
                    id Data = [serviceData objectForKey:uuid];
                    if(Data){
                        
                        unsigned char *dataByte;
                        dataByte = malloc([Data length]);
                        
                        [Data getBytes:dataByte length:[Data length]];
                        struct _SPECIAL_DATA_FORMAT *discoveredSpecialData = (struct _SPECIAL_DATA_FORMAT*)dataByte;
                        
                        int batteryLevelVal = discoveredSpecialData->batteryLevel_And_Data_Category.batteryLevel;
                        int batteryLevelIdx = 0;
                        
                        if (batteryLevelVal == 0x00) {
                            batteryLevelIdx = 0;
                        }else if (batteryLevelVal <= 0x03){
                            batteryLevelIdx = 1;
                        }else if (batteryLevelVal <= 0x06){
                            batteryLevelIdx = 2;
                        }else if (batteryLevelVal <= 0x09){
                            batteryLevelIdx = 3;
                        }else if (batteryLevelVal <= 0x0B){
                            batteryLevelIdx = 4;
                        }else{
                            batteryLevelIdx = 5;
                        }
                        BatteryLevel = BatteryLevelArray[batteryLevelIdx];
                        int rssiLevelIdx = 0;
                        
                        if (tmpPeripheral.rssi_Value < -110) {
                            rssiLevelIdx = 0;
                        }else if (tmpPeripheral.rssi_Value <= -100){
                            rssiLevelIdx = 1;
                        }else if (tmpPeripheral.rssi_Value <= -85){
                            rssiLevelIdx = 2;
                        }else if (tmpPeripheral.rssi_Value <= -70){
                            rssiLevelIdx = 3;
                        }else if (tmpPeripheral.rssi_Value <= -60){
                            rssiLevelIdx = 4;
                        }else{
                            rssiLevelIdx = 5;
                        }
                        
                        RssiLevel = RssiLevelArray[rssiLevelIdx];
                        MultiSpkRole = MultiSpkRoleDict[@(discoveredSpecialData->multiSpeakerRole)];
                        if(!MultiSpkRole)
                            MultiSpkRole = @"unknow";
                        
                        csbstate = discoveredSpecialData->multiSpeakerState;
                    }
                    myCell.speakerNameLabel.text = tmpPeripheral.advName;
                    if (myCell.speakerNameLabel.text == nil)
                        myCell.speakerNameLabel.text = @"Unknow";
                    
                    BOOL isConnectable = [[tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataIsConnectable] boolValue];
                    
                    if (!isConnectable) {
                        myCell.speakerNameLabel.enabled = FALSE;
                    }else
                        myCell.speakerNameLabel.enabled = TRUE;
                    
                    if(csbstate == 0x02){
                        //CSB_STATE_GROUPING
                        myCell.groupRoleLabel.text = @"Grouping";
                    }
                    else{
                        myCell.groupRoleLabel.text = MultiSpkRole;
                    }
                    
                    UIImage *batteryImgView = [UIImage imageNamed:BatteryLevel];
                    [myCell.batteryLevelImageView setImage:batteryImgView];
                    UIImage *rssiImgView = [UIImage imageNamed:RssiLevel];
                    [myCell.rssiLevelImageView setImage:rssiImgView];
                    myCell.backgroundColor = [UIColor clearColor];
                    break;
                }
            }
        }
        return myCell;
        
    }else{
        if (indexPath.section == 0) {
            UITableViewCell *cell;
            UISwitch *mySwitch = [[UISwitch alloc]initWithFrame:CGRectZero];
            
            [mySwitch setOn:filterOn animated:NO];
            [mySwitch addTarget:self action:@selector(updateSwitch:) forControlEvents:UIControlEventAllTouchEvents];
            
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"SwitchCell"];
            cell.textLabel.text = @"Proximity Filter";
            cell.backgroundColor = [UIColor clearColor];
            [cell addSubview:mySwitch];
            cell.accessoryView = mySwitch;
            return cell;
        }else if(indexPath.section == 1) {
            UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
            cell.textLabel.text = @"New Personal Group";
            cell.backgroundColor = [UIColor clearColor];
            cell.detailTextLabel.text = @"Create";
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            return cell;
        }else{
            NSArray *keys = [groupRecord allKeys];
            NSDictionary *groupData = [groupRecord objectForKey:[keys objectAtIndex:indexPath.row]];
            NSString *name = [groupData objectForKey:@"GROUP_NAME"];
            UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
            cell.textLabel.text = name;
            cell.backgroundColor = [UIColor clearColor];
            cell.detailTextLabel.text = @"Create";
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            return cell;
        }
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (tableView == _DeviceTableView) {
        return 60;
    }else{
        if (section == 1) {
            return 0;
        }
        return 35;
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if ((tableView == _PersonalGroupingRecordTableView)&& (section == 0)) {
        return 0;
    }
    return 20;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _DeviceTableView) {
        return 80;
    }else{
        return 50;
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    if ((tableView == _PersonalGroupingRecordTableView) && (indexPath.section == 0x02)) {
        return YES;
    }else{
        return NO;
    }
}

-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleDelete;
}

-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"Delete";
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"delete Row");
    NSArray *keys = [groupRecord allKeys];
    if ([keys count]==0) {
        return;
    }
    [groupRecord removeObjectForKey:[keys objectAtIndex:indexPath.row]];
    [_PersonalGroupingRecordTableView  reloadData];
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:groupRecord forKey:@"GROUP_RECORD"];
    [def synchronize];
    
}
#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(_BtState != CBPeripheralManagerStatePoweredOn){
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Bluetooth state alert" message:@"Please Turn on the Bluetooth" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertView show];
        [alertView release];
        return;
    }
    if (tableView == _DeviceTableView) {
        switch (indexPath.section) {
            default:
                NSLog(@"[ConnectViewController] didSelectRowAtIndexPath section 0, Row = %d",(int)[indexPath row]);
                NSArray *groupList = [_cbController.devicesGroupList allKeys];
                NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:Nil ascending:NO selector:@selector(compare:)];
                groupList = [groupList sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
                
                int count = (int)[groupList count];
                if (indexPath.section == count) {
                    MyPeripheral *tmpPeripheral = [_cbController.genericHeadsetList objectAtIndex:indexPath.row];
                    if (tmpPeripheral.connectStatus != MYPERIPHERAL_CONNECT_STATUS_IDLE) {
                        //NSLog(@"Device is not idle - break");
                        [tableView deselectRowAtIndexPath:indexPath animated:YES];
                        return;
                    }
                    BOOL isConnectable = [[tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataIsConnectable] boolValue];
                    if (!isConnectable) {
                        [tableView deselectRowAtIndexPath:indexPath animated:YES];
                        return;
                    }
                    [self.navigationController.view makeToastActivity:CSToastPositionCenter];
                    //groupIndex = (int)indexPath.section;
                    [_cbController connectDevice:tmpPeripheral];
                }else if ((count != 0) && count > indexPath.section-1) {
                    NSMutableArray *groupMemberList = [_cbController.devicesGroupList objectForKey:groupList[indexPath.section]];
                    MyPeripheral *tmpPeripheral = [groupMemberList objectAtIndex:indexPath.row];
                    if (tmpPeripheral.connectStatus != MYPERIPHERAL_CONNECT_STATUS_IDLE) {
                        //NSLog(@"Device is not idle - break");
                        [tableView deselectRowAtIndexPath:indexPath animated:YES];
                        return;
                    }
                    //For Dudo testing(Enable BLE on CSB slave)
                    ///*
                    BOOL isConnectable = [[tmpPeripheral.advertiseData objectForKey:CBAdvertisementDataIsConnectable] boolValue];
                    if (!isConnectable) {
                        [tableView deselectRowAtIndexPath:indexPath animated:YES];
                        return;
                    }//*/
                    [self.navigationController.view makeToastActivity:CSToastPositionCenter];
                    groupIndex = (int)indexPath.section;
                    [_cbController connectDevice:tmpPeripheral];
                }
                break;
        }
    }else{
        NSArray *groupList = [_cbController.devicesGroupList allKeys];
        if([groupList count]==0){
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Bluetooth Alert" message:@"No Device Discovered!" delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
            [alertView show];
            [alertView release];
            return;
        }
        if (indexPath.section == 0) {
            
        }else if (indexPath.section == 1) {
            newPersonalGroup = TRUE;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select Group Mode:" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil];
            [actionSheet addButtonWithTitle:@"Stereo Mode"];
            [actionSheet addButtonWithTitle:@"Concert Mode"];
            [actionSheet addButtonWithTitle:@"Cancel"];
            actionSheet.cancelButtonIndex = 2;
            actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
            [actionSheet showInView:self.view];
        }else{
            newPersonalGroup = FALSE;
            groupIndex = (int)indexPath.row;
            [self stopScan];
            [self performSegueWithIdentifier:@"FORCE_TO_PERSONAL_GROUP_SETTING" sender:self];
            
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UIActionSheetDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"actionSheet button:%d",(int)buttonIndex);
    if (buttonIndex == 2) {
        return;
    }else{
        [self stopScan];
        personalGroupMode = (int)buttonIndex;
        [self performSegueWithIdentifier:@"FORCE_TO_PERSONAL_GROUP_SETTING" sender:self];
    }
}


#pragma mark - CBController delegate
- (void)CBController:(CBController *)cbController didUpdateDiscoveredPeripherals:(NSArray *)peripherals {
    //NSLog(@"didUpdateDiscoveredPeripherals %@",peripherals);
    [_DeviceTableView reloadData];
}

- (void)CBController:(CBController *)cbController didDisconnectedPeripheral:(MyPeripheral *)myPeripheral {
    NSLog(@"updateMyPeripheralForDisconnect");//, %@", myPeripheral.advName);
    [self.navigationController popToRootViewControllerAnimated:YES];
    [self.navigationController.view hideToastActivity];
    [self displayDevicesList];
    
    if(cbController.isScanning == YES){
        [self stopScan];
        [self startScan];
        [_DeviceTableView reloadData];
    }
    [self.navigationController.view makeToast:@"Disconnected"
                                     duration:1.5
                                     position:CSToastPositionBottom];
}

- (void)CBController:(CBController *)cbController didConnectedPeripheral:(MyPeripheral *)myPeripheral {
    [self.navigationController.view hideToastActivity];
    NSLog(@"[ConnectViewController] updateMyPeripheralForNewConnected");
    
    controlPeripheral = myPeripheral;
    controlPeripheral.connectStatus = MYPERIPHERAL_CONNECT_STATUS_CONNECTED;
    [self performSegueWithIdentifier:@"FORCE_TO_UNGROUP_HOME_SCREEN" sender:self];
}

#pragma mark - CBPeripheral delegate
- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    NSLog(@"state updated");
    _BtState = peripheral.state;
    if (peripheral.state != CBPeripheralManagerStatePoweredOn) {
        [self.navigationController popToRootViewControllerAnimated:YES];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Bluetooth state alert" message:[[NSString alloc] initWithFormat:@"state = %ld", (long)peripheral.state] delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
}


@end
