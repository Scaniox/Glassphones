//
//  VoiceTuningViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/6/6.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit

class VoiceTuningViewController: UIPageViewController , UIPageViewControllerDataSource , RefreshPageView , UIPageViewControllerDelegate{
    var button: UIBarButtonItem?
    
    func UpdateTitle(title: String) {
        //print("[RefreshPageViewDelegate] UpdateTitle")
        self.title = title
        
        if(title == "Filter" || title == "EQ"){
            button?.isEnabled = false
        }
        else{
            button?.isEnabled = true
        }
    }
    
    var viewControllerList: [UIViewController] = [UIViewController]()
    
    var DSPManager: TuneDSPManager?
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        for v in view.subviews {
            if v is UIScrollView {
                v.frame = view.bounds
                break
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[VoiceTuningPageViewController]viewDidLoad")
        
        //button = UIBarButtonItem(title: "Hidden", style: .plain, target: self, action: #selector(HiddenbuttonTapped(_:)))
        //self.navigationItem.rightBarButtonItem = button
        
        DSPManager = TuneDSPManager.sharedInstance()
        DSPManager?.RefreshPageViewDelegate = self
        
        self.title = "Filter"
        //self.title = "Noise Reduction"
        
        let pageControl = UIPageControl.appearance()
        pageControl.pageIndicatorTintColor = UIColor.gray
        pageControl.currentPageIndicatorTintColor = UIColor.red
        
        // 依 storyboard ID 生成 viewController 並加到要用來顯示 pageViewController 畫面的陣列裡
        let vc1 = storyboard?.instantiateViewController(withIdentifier: "VoiceFilterViewController")
        let vc2 = storyboard?.instantiateViewController(withIdentifier: "NRViewController")
        let vc3 = storyboard?.instantiateViewController(withIdentifier: "EQViewController")
        let vc4 = storyboard?.instantiateViewController(withIdentifier: "MICGainViewController")
        let vc5 = storyboard?.instantiateViewController(withIdentifier: "AECViewController")
        //let vc6 = storyboard?.instantiateViewController(withIdentifier: "MVDRViewController")
        
        viewControllerList.append(vc1!)
        viewControllerList.append(vc2!)
        viewControllerList.append(vc3!)
        viewControllerList.append(vc4!)
        viewControllerList.append(vc5!)
        //viewControllerList.append(vc6!)
        
        self.dataSource = self
        self.delegate = self
        
        // 設定 pageViewControoler 的首頁
        self.setViewControllers([self.viewControllerList.first!], direction: UIPageViewController.NavigationDirection.forward, animated: true, completion: nil)
    }
    
    @objc func HiddenbuttonTapped(_ sender:UIBarButtonItem) {
        print("HiddenbuttonTapped, view = \(self.title!)")
        
        DSPManager?.UpdateGUIs(view_title: self.title!)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        // 取得當前頁數的 index(未翻頁前)
        let currentIndex: Int =  self.viewControllerList.index(of: viewController)!
        
        //print("**currentIndex = \(currentIndex)")
        // 設定上一頁的 index
        let priviousIndex: Int = currentIndex - 1
        
        if(currentIndex == 4){
            //self.title = "AEC/AES"
        }
        else if(currentIndex == 3){
            //self.title = "MIC Gain/ComfortNoise"
        }
        else if(currentIndex == 2){
            //self.title = "EQ"
        }
        else if(currentIndex == 1){
            //self.title = "NR"
        }
        else if(currentIndex == 0){
            //self.title = "Filter"
        }
        
        //print("priviousIndex = \(priviousIndex)")
        
        // 判斷上一頁的 index 是否小於 0，若小於 0 則停留在當前的頁數
        return priviousIndex < 0 ? nil : self.viewControllerList[priviousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        // 取得當前頁數的 index(未翻頁前)
        let currentIndex: Int =  self.viewControllerList.index(of: viewController)!
        //print("==currentIndex = \(currentIndex)")
        
        // 設定下一頁的 index
        let nextIndex: Int = currentIndex + 1
        
        if(currentIndex == 1){
            //self.title = "NR"
        }
        else if(currentIndex == 2){
            //self.title = "EQ"
        }
        else if(currentIndex == 3){
            //self.title = "MIC Gain/ComfortNoise"
        }
        else if(currentIndex == 4){
            //self.title = "AEC/AES"
        }
        else if(currentIndex == 5){
            //self.title = "MVDR"
        }
        
        //print("nextIndex = \(nextIndex)")
        
        // 判斷下一頁的 index 是否大於總頁數，若大於則停留在當前的頁數
        return nextIndex > self.viewControllerList.count - 1 ? nil : self.viewControllerList[nextIndex]
    }
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return self.viewControllerList.count
    }
    
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        print("presentationIndex..")
        return 0
    }
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            willTransitionTo pendingViewControllers: [UIViewController]){
        print("pageViewController,willTransitionTo")
        pageViewController.view.isUserInteractionEnabled = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            pageViewController.view.isUserInteractionEnabled = true
            print("pageViewController,willTransitionTo : Enable")
        }
    }
}
