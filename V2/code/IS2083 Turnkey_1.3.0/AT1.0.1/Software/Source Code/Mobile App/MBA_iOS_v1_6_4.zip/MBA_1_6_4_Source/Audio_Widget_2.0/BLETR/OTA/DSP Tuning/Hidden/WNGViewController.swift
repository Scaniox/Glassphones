//
//  WNGViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/8/13.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class WNGViewController: UIViewController, DSPTuningDelegate, UITextFieldDelegate {
    @IBOutlet var DSPState: UILabel!
    @IBOutlet var AVC_onoff: VKCheckbox!
    @IBOutlet var WNG_onoff: VKCheckbox!
    @IBOutlet var AVC_Gain: DropDown!
    @IBOutlet var AVC_MSB: UITextField!
    @IBOutlet var AVC_LSB: UITextField!
    @IBOutlet var WNG_Coeff: UITextField!
    
    @IBOutlet var TuneDSP: UIButton!
    
    var DSPManager: TuneDSPManager?
    
    var AVC_Gain_List: Bool!
    var AVC_Changed: Bool!
    var WNG_Changed: Bool!
    
    let AVC_Gain_table = ["0x0", "0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8", "0x9", "0xA"]
    let AVC_Gain_ids = [0,1,2,3,4,5,6,7,8,9,10]
    
    var CONFIG_Data: [UInt8] = [UInt8]()
    var AVC_Data: [UInt8] = [UInt8]()
    var WNG_Data: [UInt8] = [UInt8]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[WNGViewController]viewDidLoad")
        
        DSPManager = TuneDSPManager.sharedInstance()
        //DSPManager?.DSPTuningDelegate = self
        DSPManager?.HiddenAVC_Delegate = self
        
        AVC_onoff.isUserInteractionEnabled = false
        WNG_onoff.isUserInteractionEnabled = false
        
        AVC_MSB.tag = 100
        AVC_LSB.tag = 200
        WNG_Coeff.tag = 300
        
        AVC_MSB.delegate = self
        AVC_LSB.delegate = self
        WNG_Coeff.delegate = self
        
        AVC_Gain.isSearchEnable = false
        AVC_Gain.optionArray = AVC_Gain_table
        AVC_Gain.optionIds = AVC_Gain_ids
        
        AVC_Gain_List = false
        
        AVC_Changed = false
        WNG_Changed = false
        
        AVC_Gain.didSelect{(selectedText , index , id) in
            if(self.AVC_Gain.text != self.AVC_Gain_table[self.AVC_Gain.selectedIndex!]){
                if(self.AVC_Data.count != 0){
                    self.AVC_Data[2] = UInt8(self.AVC_Gain.selectedIndex!)
                    self.DSPTuningEnable()
                    self.AVC_Changed = true
                }
            }
        }
        
        AVC_Gain.listWillAppear {
            self.AVC_Gain_List = true
            
            print("AVC_Gain.listWillAppear")
            self.AVC_MSB.isHidden = true
            self.AVC_LSB.isHidden = true
            self.WNG_Coeff.isHidden = true
            self.TuneDSP.isHidden = true
        }
        
        AVC_Gain.listDidDisappear {
            self.AVC_Gain_List = false
            
            print("AVC_Gain.listDidDisappear")
            self.AVC_MSB.isHidden = false
            self.AVC_LSB.isHidden = false
            self.WNG_Coeff.isHidden = false
            self.TuneDSP.isHidden = false
        }
        
        DSPTuningDisable()
        
        DSPManager?.DSP_Init()
        let device_capability = DSPManager?.Get_Device_Capability()
        print("device_capability = \(device_capability!)")
        
        if(DSPManager?.Audio_Config == nil){
            LoadDSPConfigData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "AVC/WNG")
        
        if(AVC_Gain.text == "" && DSPManager?.Audio_Config != nil){
            DSPTuningDisable()
            DSPManager?.Get_Voice_AVC_WNG_Setting()
        }
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        DSPState.text = DSPManager?.DSP_DUT_State
        
        if(DSPManager?.RefreshGUIData(UIView_index: 0x08) == true){
            DSPManager?.ClearRefreshFlag(UIView_index: 0x08)
            DSPTuningDisable()
            DSPManager?.Get_Voice_AVC_WNG_Setting()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    
        if(TuneDSP.isEnabled == true){
            if(AVC_Data.count != 0){
                if(AVC_Changed == true){
                    DSPManager?.DSPQueueData(module:0x0D, cfg:0x02, len:UInt8(AVC_Data.count), data:AVC_Data)
                    AVC_Changed = false
                }
            }
            
            if(WNG_Data.count != 0){
                if(WNG_Changed == true){
                    DSPManager?.DSPQueueData(module:0x0D, cfg:0x03, len:UInt8(WNG_Data.count), data:WNG_Data)
                    WNG_Changed = false
                }
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func DSPTuning(_ sender: Any) {
        if(AVC_Data.count != 0){
            if(AVC_Changed == true && WNG_Changed == false){
                DSPManager?.DSPTuning(module:0x0D, cfg:0x02, len:UInt8(AVC_Data.count), data:AVC_Data)
            }
        }
        
        if(WNG_Data.count != 0){
            if(WNG_Changed == true && AVC_Changed == false){
                DSPManager?.DSPTuning(module:0x0D, cfg:0x03, len:UInt8(WNG_Data.count), data:WNG_Data)
            }
        }
        
        if(AVC_Changed == true && WNG_Changed == true){
            if(AVC_Data.count != 0 && WNG_Data.count != 0){
                DSPManager?.DSPTuning2(module: 0x0D, cfg1: 0x02, cfg2: 0x03, len1: UInt8(AVC_Data.count), len2: UInt8(WNG_Data.count), data1: AVC_Data, data2: WNG_Data)
            }
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    func GUI_Data_Update(){
        print("GUI_Data_Update")
        
        if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
            print("**UIAlertController is presenting here!")
            self.dismiss(animated: true, completion: nil)
        }
        
        AVC_Changed = false
        WNG_Changed = false
        
        if(CONFIG_Data.count != 0){
            if((CONFIG_Data[1] & 0x80) == 0x80){
                AVC_onoff.setOn(true)
            }
            else{
                AVC_onoff.setOn(false)
            }
            
            if((CONFIG_Data[2] & 0x10) == 0x10){
                WNG_onoff.setOn(true)
            }
            else{
                WNG_onoff.setOn(false)
            }
            
            //AVC_onoff.isUserInteractionEnabled = false
            //WNG_onoff.isUserInteractionEnabled = false
        }
        
        if(AVC_Data.count != 0){
            AVC_LSB.text = String(AVC_Data[1])
            AVC_MSB.text = String(AVC_Data[0])
            
            AVC_Gain.selectedIndex = Int(AVC_Data[2])
            AVC_Gain.text = AVC_Gain_table[AVC_Gain.selectedIndex!]
        }
        
        if(WNG_Data.count != 0){
            WNG_Coeff.text = String(WNG_Data[2])
        }
        
        if(AVC_onoff.isOn()){
            AVC_Gain.isEnabled = true
            AVC_LSB.isEnabled = true
            AVC_MSB.isEnabled = true
        }
        else{
            AVC_Gain.isEnabled = false
            AVC_LSB.isEnabled = false
            AVC_MSB.isEnabled = false
        }
        
        if(WNG_onoff.isOn()){
            WNG_Coeff.isEnabled = true
        }
        else{
            WNG_Coeff.isEnabled = false
        }
    }
    
    func LoadDSPConfigData() {
        let alertController = UIAlertController(
            title: nil,
            message: "Load DSP Configuration\n\n\n",
            preferredStyle: .alert)
        
        let activityIndicator : UIActivityIndicatorView = UIActivityIndicatorView.init(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
        
        activityIndicator.color = UIColor.black
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        alertController.view.addSubview(activityIndicator)
        
        let centerHorizontally = NSLayoutConstraint(item: activityIndicator,
                                                    attribute: .centerX,
                                                    relatedBy: .equal,
                                                    toItem: activityIndicator.superview,
                                                    attribute: .centerX,
                                                    multiplier: 1.0,
                                                    constant: 0.0)
        
        let centerVertically = NSLayoutConstraint(item: activityIndicator,
                                                  attribute: .centerY,
                                                  relatedBy: .equal,
                                                  toItem: activityIndicator.superview,
                                                  attribute: .centerY,
                                                  multiplier: 1.0,
                                                  constant: 0.0)
        
        NSLayoutConstraint.activate([centerHorizontally, centerVertically])
        
        activityIndicator.startAnimating()
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        //var changed: Bool = false
        
        if(AVC_Data.count != 0){
            if(AVC_LSB.text != nil && textField.tag == 200){
                if let AVC_LSB_value = Int(AVC_LSB.text!){
                    if(AVC_LSB_value >= 0 && AVC_LSB_value <= 127){
                        AVC_Data[1] = UInt8(AVC_LSB_value)
                        AVC_Changed = true
                    }
                    else{
                        AVC_LSB.text = String(AVC_Data[1])
                    }
                }
                else{
                    AVC_LSB.text = String(AVC_Data[1])
                }
            }
            
            if(AVC_MSB.text != nil && textField.tag == 100){
                if let AVC_MSB_value = Int(AVC_MSB.text!){
                    if(AVC_MSB_value >= 0 && AVC_MSB_value <= 127){
                        AVC_Data[0] = UInt8(AVC_MSB_value)
                        AVC_Changed = true
                    }
                    else{
                        AVC_MSB.text = String(AVC_Data[0])
                    }
                }
                else{
                    AVC_MSB.text = String(AVC_Data[0])
                }
            }
        }
        
        if(WNG_Data.count != 0){
            if(WNG_Coeff.text != nil && textField.tag == 300){
                if let WNG_value = Int(WNG_Coeff.text!){
                    if(WNG_value >= 1 && WNG_value <= 127){
                        WNG_Data[2] = UInt8(WNG_value)
                        WNG_Changed = true
                    }
                    else{
                        WNG_Coeff.text = String(WNG_Data[2])
                    }
                }
                else{
                    WNG_Coeff.text = String(WNG_Data[2])
                }
            }
        }
        
        if(AVC_Changed == true || WNG_Changed == true){
            DSPTuningEnable()
        }
     
        return true
    }
    
    // MARK: - TuneDSPDelegate
    func BLE_ServiceReady() {
        print("BLE_ServiceReady")
        
        if(DSPManager?.Audio_Config == nil){
            DSPManager?.Read_Module_Audio_MCU()
        }
        else{
            DSPManager?.Get_Voice_AVC_WNG_Setting()
        }
    }
    
    func RefreshModuleData() {
        print("[Hidden AVC] RefreshModuleData")
    }
    
    func RefreshParametersData(dat: Data) {
        var k:Int = 0
        var buffer = [UInt8](repeating:0, count:(dat as NSData).length)
        (dat as NSData).getBytes(&buffer, length: (dat as NSData).length)
        
        print("Parsing configuration data")
        
        while(k < (dat as NSData).length){
            let len = buffer[k+2]
            let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            print("Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")
            
            if(buffer[k] == 13 && buffer[k+1] == 2){
                if(buffer[k+2] == 3){
                    AVC_Data.removeAll()
                    for index in 0..<3 {
                        AVC_Data.append(buffer[k+3+index])
                    }
                    print("AVC_Data = \(AVC_Data)")
                }
            }
            else if(buffer[k] == 13 && buffer[k+1] == 3){
                if(buffer[k+2] == 3){
                    WNG_Data.removeAll()
                    for index in 0..<3 {
                        WNG_Data.append(buffer[k+3+index])
                    }
                    print("WNG_Data = \(WNG_Data)")
                }
            }
            else if(buffer[k] == 13 && buffer[k+1] == 1){
                if(buffer[k+2] == 4){
                    CONFIG_Data.removeAll()
                    for index in 0..<4 {
                        CONFIG_Data.append(buffer[k+3+index])
                    }
                    print("CONFIG_Data = \(CONFIG_Data)")
                }
            }
            
            k += Int(3+len)
        }
        
        GUI_Data_Update()
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            self.DSPManager?.ClearRefreshFlag(UIView_index: 0x08)
            
            if(self.AVC_Changed){
                self.AVC_Changed = false
            }
            if(self.WNG_Changed){
                self.WNG_Changed = false
            }
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func BLE_ConnectionStatus(status: Bool) {
        print("[WNG] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func DSPTuningState(state: String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(AVC_Gain_List == true){
                AVC_Gain.hideList()
            }
            AVC_Gain.isUserInteractionEnabled = false
            AVC_MSB.isEnabled = false
            AVC_LSB.isEnabled = false
            WNG_Coeff.isEnabled = false
            
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            AVC_Gain.isUserInteractionEnabled = true
            AVC_MSB.isEnabled = true
            AVC_LSB.isEnabled = true
            WNG_Coeff.isEnabled = true
        }
    }
    
    func ExportDSPTuningResult() {
    }
}
