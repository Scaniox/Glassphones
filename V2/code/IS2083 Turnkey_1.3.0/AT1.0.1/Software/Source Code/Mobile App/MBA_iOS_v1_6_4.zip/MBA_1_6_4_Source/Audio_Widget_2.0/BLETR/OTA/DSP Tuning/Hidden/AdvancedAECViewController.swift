//
//  AdvancedAECViewController.swift
//  Audio_Widget_2.0
//
//  Created by TestPC on 2019/8/8.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit
import iOSDropDown

class AdvancedAECViewController: UIViewController, DSPTuningDelegate, UITextFieldDelegate {
    @IBOutlet var DSPState: UILabel!
    
    @IBOutlet var param_1: DropDown!    //Comfort Noise Generator Gain
    @IBOutlet var param_2: DropDown!    //AES Non Linear Thrd
    @IBOutlet var param_3: DropDown!    //AES Begining Suppresion Coef
    @IBOutlet var param_4: DropDown!    //Reference Line Gain(mSBC)
    @IBOutlet var param_5: DropDown!    //AEC FE Detection Thrd
    
    @IBOutlet var param_6: UITextField! //AES Non Linear Boundary
    @IBOutlet var param_7: UITextField! //AES Suppression Max
    @IBOutlet var param_8: UITextField! //Begining Suppresion Time
    @IBOutlet var param_9: UITextField! //Line Mini Voice Activity Detection Thrd
    @IBOutlet var param_10: UITextField!//Echo Only Thrd
    @IBOutlet var param_11: UITextField!//Comfort Noise Generator Thrd
    
    let param_1_3_table = ["0x0", "0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8", "0x9", "0xA", "0xB", "0xC", "0xD", "0xE", "0xF"]
    let param_1_3_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    
    let param_2_table = ["0x0", "0x1", "0x2", "0x3", "0x4"]
    let param_2_ids = [0, 1, 2, 3, 4]
    
    let param_4_table = ["0x00: -19dB -Minimum", "0x03: -16dB", "0x05: -14dB", "0x07: -12dB", "0x09: -10dB", "0x0B:  -8dB", "0x0D:  -6dB","0x0F:  -4dB", "0x11:  -2dB", "0x13:   0dB -Default", "0x15:   2dB", "0x17:   4dB", "0x19:   6dB", "0x1B:   8dB", "0x1D:  10dB", "0x1F:  12dB","0x21:  14dB", "0x23:  16dB", "0x25:  18dB", "0x27:  20dB -Maximum"]
    let param_4_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
    
    let param_5_table = ["0x0", "0x1", "0x2", "0x3", "0x4", "0x5", "0x6", "0x7", "0x8"]
    let param_5_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8]
    
    var param_1_List: Bool!
    var param_2_List: Bool!
    var param_3_List: Bool!
    var param_4_List: Bool!
    var param_5_List: Bool!
    
    @IBOutlet var TuneDSP: UIButton!
    
    var DSPManager: TuneDSPManager?
    
    var AEC_Prev_Data: [UInt8] = [UInt8]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("[AdvancedAECViewController]viewDidLoad")
        
        DSPManager = TuneDSPManager.sharedInstance()
        DSPManager?.DSPTuningDelegate = self
        
        DSPManager?.SetPageViewTitle(title: "Hidden AEC")
        
        param_6.tag = 60
        param_7.tag = 70
        param_8.tag = 80
        param_9.tag = 90
        param_10.tag = 100
        param_11.tag = 110
        
        param_6.delegate = self
        param_7.delegate = self
        param_8.delegate = self
        param_9.delegate = self
        param_10.delegate = self
        param_11.delegate = self
        
        param_1.isSearchEnable = false
        param_2.isSearchEnable = false
        param_3.isSearchEnable = false
        param_4.isSearchEnable = false
        param_5.isSearchEnable = false
        
        param_1_List = false
        param_2_List = false
        param_3_List = false
        param_4_List = false
        param_5_List = false
        
        param_1.optionArray = param_1_3_table
        param_1.optionIds = param_1_3_ids
        
        param_2.optionArray = param_2_table
        param_2.optionIds = param_2_ids
        
        param_3.optionArray = param_1_3_table
        param_3.optionIds = param_1_3_ids
        
        param_4.optionArray = param_4_table
        param_4.optionIds = param_4_ids
        
        param_5.optionArray = param_5_table
        param_5.optionIds = param_5_ids
        
        param_1.didSelect{(selectedText , index , id) in
            if(self.param_1.text != self.param_1_3_table[self.param_1.selectedIndex!]){
                if(self.DSPManager?.AEC_AES_Data.count != 0){
                    self.DSPManager?.AEC_AES_Data[13] &= ~(0xf0)
                    self.DSPManager?.AEC_AES_Data[13] |= UInt8(self.param_1.selectedIndex!) << 4
                    print("AEC_AES_Data[13,bit4_7] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[13]))")
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_2.didSelect{(selectedText , index , id) in
            if(self.param_2.text != self.param_2_table[self.param_2.selectedIndex!]){
                if(self.DSPManager?.AEC_AES_Data.count != 0){
                    self.DSPManager?.AEC_AES_Data[13] &= ~(0x0f)
                    self.DSPManager?.AEC_AES_Data[13] |= UInt8(self.param_2.selectedIndex!)
                    print("AEC_AES_Data[13,bit0_3] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[13]))")
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_3.didSelect{(selectedText , index , id) in
            if(self.param_3.text != self.param_1_3_table[self.param_3.selectedIndex!]){
                if(self.DSPManager?.AEC_AES_Data.count != 0){
                    self.DSPManager?.AEC_AES_Data[14] = UInt8(self.param_3.selectedIndex!)
                    print("AEC_AES_Data[14] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[14]))")
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_4.didSelect{(selectedText , index , id) in
            if(self.param_4.text != self.param_4_table[self.param_4.selectedIndex!]){
                if(self.DSPManager?.AEC_AES_Data.count != 0){
                    if(self.param_4.selectedIndex == 0){
                        self.DSPManager?.AEC_AES_Data[15] = 0
                    }
                    else{
                        self.DSPManager?.AEC_AES_Data[15] = UInt8((self.param_4.selectedIndex! * 2) + 1)
                    }
                    print("AEC_AES_Data[15] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[15]))")
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_5.didSelect{(selectedText , index , id) in
            if(self.param_5.text != self.param_5_table[self.param_5.selectedIndex!]){
                if(self.DSPManager?.AEC_AES_Data.count != 0){
                    self.DSPManager?.AEC_AES_Data[4] &= ~(0x0f)
                    self.DSPManager?.AEC_AES_Data[4] |= (UInt8(self.param_5.selectedIndex!) & 0x0f)
                    print("AEC_AES_Data[4,bit0_3] = \(String(format: "0x%02X",self.DSPManager!.AEC_AES_Data[13]))")
                    self.DSPTuningEnable()
                }
            }
        }
        
        param_1.listWillAppear {
            self.param_1_List = true
            
            self.GUI_HideTextfield(status: 4)
        }
        
        param_1.listDidDisappear {
            self.param_1_List = false
            
            self.GUI_ShowTextfield(status: 4)
        }
        
        param_2.listWillAppear {
            self.param_2_List = true
            
            self.GUI_HideTextfield(status: 3)
        }
        
        param_2.listDidDisappear {
            self.param_2_List = false

            self.GUI_ShowTextfield(status: 3)
        }
        
        param_3.listWillAppear {
            self.param_3_List = true

            self.GUI_HideTextfield(status: 2)
        }
        
        param_3.listDidDisappear {
            self.param_3_List = false
            
            self.GUI_ShowTextfield(status: 2)
        }
        
        param_4.listWillAppear {
            self.param_4_List = true

            self.GUI_HideTextfield(status: 1)
        }
        
        param_4.listDidDisappear {
            self.param_4_List = false

            self.GUI_ShowTextfield(status: 1)
        }
        
        param_5.listWillAppear {
            self.param_5_List = true

            self.GUI_HideTextfield(status: 0)
        }
        
        param_5.listDidDisappear {
            self.param_5_List = false

            self.GUI_ShowTextfield(status: 0)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    
        if(param_1.text == "" && DSPManager?.AEC_AES_Data.count != 0){
            DSPTuningDisable()
            GUI_Data_Update()
            if(AEC_Prev_Data.count == 0){
                AEC_Prev_Data = DSPManager!.AEC_AES_Data
            }
        }
        
        if(DSPManager?.dynamicToolMode != nil){
            print("dynamicToolMode = \(DSPManager?.dynamicToolMode!)")
            DSPTuningState(state: (DSPManager?.DSP_DUT_State)!)
        }
        
        if(DSPState.text == "DSP Status: "){
            DSPState.text = DSPManager?.DSP_DUT_State
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    
        //if(self.isMovingFromParentViewController) {
        //    print("[AdvancedAECViewController] Detecting 'BACK' button event!!")
        //}
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func DSPTuning(_ sender: Any) {
        if(DSPManager!.AEC_AES_Data.count != 0){
            print("DSPTuning")
            DSPManager?.DSPTuning(module: 0x0D, cfg: 0x05, len: UInt8(DSPManager!.AEC_AES_Data.count), data: DSPManager!.AEC_AES_Data)
        }
    }
    
    func DSPTuningEnable(){
        TuneDSP.setTitleColor(.white, for: .normal)
        TuneDSP.isEnabled = true
    }
    
    func DSPTuningDisable(){
        TuneDSP.setTitleColor(.gray, for: .normal)
        TuneDSP.isEnabled = false
    }
    
    func GUI_Data_Update(){
        print("GUI_Data_Update")
        
        param_1.selectedIndex = Int((DSPManager!.AEC_AES_Data[13] & 0xf0) >> 4)
        param_1.text = param_1_3_table[param_1.selectedIndex!]
        
        param_2.selectedIndex = Int((DSPManager!.AEC_AES_Data[13] & 0x0f))
        param_2.text = param_2_table[param_2.selectedIndex!]
        
        param_3.selectedIndex = Int(DSPManager!.AEC_AES_Data[14])
        param_3.text = param_1_3_table[param_3.selectedIndex!]
        
        if(DSPManager!.AEC_AES_Data[15] == 0){
            param_4.selectedIndex = 0
        }
        else{
            param_4.selectedIndex = (Int(DSPManager!.AEC_AES_Data[15]-1))/2
        }
        param_4.text = param_4_table[param_4.selectedIndex!]
        
        param_5.selectedIndex = Int(DSPManager!.AEC_AES_Data[4] & 0x0f)
        param_5.text = param_5_table[param_5.selectedIndex!]
        
        param_6.text = String(DSPManager!.AEC_AES_Data[7])
        param_7.text = String(DSPManager!.AEC_AES_Data[8])
        param_8.text = String(DSPManager!.AEC_AES_Data[9])
        param_9.text = String(DSPManager!.AEC_AES_Data[10])
        param_10.text = String(DSPManager!.AEC_AES_Data[11])
        param_11.text = String(DSPManager!.AEC_AES_Data[12])
    }
    
    func GUI_HideTextfield(status:Int){
        print("GUI_HideTextfield = \(status)")
        
        if(param_2_List == true && status >= 4){
            param_2.hideList()
        }
        
        if(param_3_List == true && status >= 3){
            param_3.hideList()
        }
        
        if(param_4_List == true && status >= 2){
            param_4.hideList()
        }
        
        if(param_5_List == true && status >= 1){
            param_5.hideList()
        }
        
        if(status >= 4){
            param_2.isHidden = true
        }
        
        if(status >= 3){
            param_3.isHidden = true
        }
        
        if(status >= 2){
            param_4.isHidden = true
        }
        
        if(status >= 1){
            param_5.isHidden = true
        }
        
        if(status != 4){
            Hide_UserTextField(IsHidden: true)
        }
        
        self.TuneDSP.isHidden = true
    }
    
    func GUI_ShowTextfield(status:Int){
        print("GUI_ShowTextfield = \(status)")
        
        var display = false
        if(status >= 3){
            if(param_1_List == false){
                display = true
            }
        }
        else if(status >= 2){
            if(param_1_List == false && param_2_List == false){
                display = true
            }
        }
        else if(status >= 1){
            if(param_1_List == false && param_2_List == false && param_3_List == false){
                display = true
            }
        }
        else if(status >= 0){
            if(param_1_List == false && param_2_List == false && param_3_List == false && param_4_List == false){
                display = true
            }
        }
        
        if(status >= 4){
            param_2.isHidden = false
        }
        if(status >= 3){
            if(display){
                param_3.isHidden = false
            }
        }
        if(status >= 2){
            if(display){
                param_4.isHidden = false
            }
        }
        if(status >= 1){
            if(display){
                param_5.isHidden = false
            }
        }
        
        if(display){
            Hide_UserTextField(IsHidden: false)
            
            self.TuneDSP.isHidden = false
        }
    }
    
    func Hide_UserTextField(IsHidden:Bool){
        
        param_6.isHidden = IsHidden
        param_7.isHidden = IsHidden
        param_8.isHidden = IsHidden
        param_9.isHidden = IsHidden
        param_10.isHidden = IsHidden
        param_11.isHidden = IsHidden
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if(DSPManager?.AEC_AES_Data.count != 0){
            print("textFieldShouldReturn")
            if(param_6.text != nil && textField.tag == 60){
                if let param_6_value = Int(param_6.text!){
                    if(param_6_value >= 10 && param_6_value <= 63){
                        DSPManager?.AEC_AES_Data[7] = UInt8(param_6_value)
                    }
                    else{
                        param_6.text = String(DSPManager!.AEC_AES_Data[7])
                    }
                }
                else{
                    param_6.text = String(DSPManager!.AEC_AES_Data[7])
                }
            }
            else if(param_7.text != nil && textField.tag == 70){
                if let param_7_value = Int(param_7.text!){
                    if(param_7_value >= 0 && param_7_value < 128){
                        DSPManager?.AEC_AES_Data[8] = UInt8(param_7_value)
                    }
                    else{
                        param_7.text = String(DSPManager!.AEC_AES_Data[8])
                    }
                }
                else{
                    param_7.text = String(DSPManager!.AEC_AES_Data[8])
                }
            }
            else if(param_8.text != nil && textField.tag == 80){
                if let param_8_value = Int(param_8.text!){
                    if(param_8_value >= 1 && param_8_value < 128){
                        DSPManager?.AEC_AES_Data[9] = UInt8(param_8_value)
                    }
                    else{
                        param_8.text = String(DSPManager!.AEC_AES_Data[9])
                    }
                }
                else{
                    param_8.text = String(DSPManager!.AEC_AES_Data[9])
                }
            }
            else if(param_9.text != nil && textField.tag == 90){
                if let param_9_value = Int(param_9.text!){
                    if(param_9_value >= 1 && param_9_value < 128){
                        DSPManager?.AEC_AES_Data[10] = UInt8(param_9_value)
                    }
                    else{
                        param_9.text = String(DSPManager!.AEC_AES_Data[10])
                    }
                }
                else{
                    param_9.text = String(DSPManager!.AEC_AES_Data[10])
                }
            }
            else if(param_10.text != nil && textField.tag == 100){
                if let param_10_value = Int(param_10.text!){
                    if(param_10_value >= 20 && param_10_value < 128){
                        DSPManager?.AEC_AES_Data[11] = UInt8(param_10_value)
                    }
                    else{
                        param_10.text = String(DSPManager!.AEC_AES_Data[11])
                    }
                }
                else{
                    param_10.text = String(DSPManager!.AEC_AES_Data[11])
                }
            }
            else if(param_11.text != nil && textField.tag == 110){
                if let param_11_value = Int(param_11.text!){
                    if(param_11_value >= 20 && param_11_value < 128){
                        DSPManager?.AEC_AES_Data[12] = UInt8(param_11_value)
                    }
                    else{
                        param_11.text = String(DSPManager!.AEC_AES_Data[12])
                    }
                }
                else{
                    param_11.text = String(DSPManager!.AEC_AES_Data[12])
                }
            }
            
            let tmp1 = NSData(bytes: &(DSPManager!.AEC_AES_Data), length: DSPManager!.AEC_AES_Data.count)
            print("tmp1 = \(tmp1)")
            let tmp2 = NSData(bytes: &AEC_Prev_Data, length: AEC_Prev_Data.count)
            print("tmp2 = \(tmp2)")
            if(tmp1.isEqual(to: tmp2 as Data) == false){
                DSPTuningEnable()
            }
        }
        
        return true
    }
    
 
    // MARK: - TuneDSPDelegate
    func BLE_ServiceReady() {
        
    }
    
    func RefreshModuleData() {
        
    }
    
    func RefreshParametersData(dat: Data) {
        
    }
    
    func DSPTuningComplete(result: UInt8) {
        var str:String = ""
        
        if(result == 0x01){
            str = "Successfully"
        }
        else{
            str = "Failed " + String(result)
        }
        
        let alertController = UIAlertController(
            title: "Tune DSP Parameters",
            message: str,
            preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("okAction")
            self.DSPTuningDisable()
            //self.DSPManager?.ClearRefreshFlag(UIView_index: 7)
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func BLE_ConnectionStatus(status: Bool) {
        print("[AdvancedAEC] BLE_ConnectionStatus = \(status)")
        if(status == false){
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func DSPTuningState(state: String) {
        DSPState.text = state
        
        if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_NotSupport || DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Audio){
            if(param_1_List == true){
                param_1.hideList()
            }
            param_1.isUserInteractionEnabled = false
            
            if(param_2_List == true){
                param_2.hideList()
            }
            param_2.isUserInteractionEnabled = false
            
            if(param_3_List == true){
                param_3.hideList()
            }
            param_3.isUserInteractionEnabled = false
            
            if(param_4_List == true){
                param_4.hideList()
            }
            param_4.isUserInteractionEnabled = false
            
            if(param_5_List == true){
                param_5.hideList()
            }
            param_5.isUserInteractionEnabled = false
            
            param_6.isEnabled = false
            param_7.isEnabled = false
            param_8.isEnabled = false
            param_9.isEnabled = false
            param_10.isEnabled = false
            param_11.isEnabled = false
            
            DSPTuningDisable()
        }
        else if(DSPManager?.dynamicToolMode == DSPManager?.TuneDSPMode_Voice){
            param_1.isUserInteractionEnabled = true
            param_2.isUserInteractionEnabled = true
            param_3.isUserInteractionEnabled = true
            param_4.isUserInteractionEnabled = true
            param_5.isUserInteractionEnabled = true
            
            param_6.isEnabled = true
            param_7.isEnabled = true
            param_8.isEnabled = true
            param_9.isEnabled = true
            param_10.isEnabled = true
            param_11.isEnabled = true
        }
    }
    
    func ExportDSPTuningResult() {
        
    }
}
