//
//  DeviceTableViewController.swift
//  TestOTA
//
//  Created by TestPC on 27/10/2017.
//  Copyright © 2017 TestPC. All rights reserved.
//

import UIKit
import CoreBluetooth

class DeviceTableViewController: UITableViewController, BLEAdapterDelegate {
    
    var bleAdapter : BLEAdapter?
    var peripherals: NSMutableArray = []
    var ADV: NSMutableArray = []
    var ScanOption: Int = 0
    var BT_Name: String!
    //var ModeSelected: String?
    var OTA_Mode: Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("[DeviceTableViewController]viewDidLoad")
        
        bleAdapter = BLEAdapter.sharedInstance()
        bleAdapter?.OTA_Selector = OTA_Mode
        
        bleAdapter?.bleAdapterDelegate = self
        bleAdapter?.WstBleAdapterDelegate = nil
        
        let ScanButton = UIBarButtonItem(title: "Scan", style: UIBarButtonItem.Style.plain, target: self, action: #selector(DeviceTableViewController.ScanbuttonTapped(_:)))
        
        self.navigationItem.rightBarButtonItem = ScanButton
        
        print("OTA_Mode = \(OTA_Mode)")

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        bleAdapter?.bleAdapterDelegate = self
        bleAdapter?.WstBleAdapterDelegate = nil
        
        peripherals.removeAllObjects()
        
        ADV.removeAllObjects()
        
        //print("viewWillAppear \(String(describing: bleAdapter?.centralManager?.state.rawValue))")
        print("[DeviceTableViewController]viewWillAppear:\(ScanOption)")
        
        //Debug for simulator
        //performSegue(withIdentifier: "OTA_Main", sender: self)
        //self.performSegue(withIdentifier: "OTA_DSP_Main", sender: self)
        
        ///*
        var ok:Int = 0
        
        ok = (bleAdapter?.findAllBLEPeripherals(3.0))!
       
        if(ok == 0)
        {
            Scan_Waiting()
            Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(DeviceTableViewController.connectionTimer), userInfo: nil, repeats: false)
        }
        else
        {
            Scan_Waiting()
            Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(DeviceTableViewController.ScanDevice), userInfo: nil, repeats: false)
            
        }//*/
    }
    
    func Scan_Waiting() {
        let alertController = UIAlertController(
            title: nil,
            message: "Scanning,please wait...\n\n\n",
            preferredStyle: .alert)
        
        let activityIndicator : UIActivityIndicatorView = UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.whiteLarge)
        
        activityIndicator.color = UIColor.black
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        alertController.view.addSubview(activityIndicator)
        
        let centerHorizontally = NSLayoutConstraint(item: activityIndicator,
                                                    attribute: .centerX,
                                                    relatedBy: .equal,
                                                    toItem: activityIndicator.superview,
                                                    attribute: .centerX,
                                                    multiplier: 1.0,
                                                    constant: 0.0)
        
        let centerVertically = NSLayoutConstraint(item: activityIndicator,
                                                  attribute: .centerY,
                                                  relatedBy: .equal,
                                                  toItem: activityIndicator.superview,
                                                  attribute: .centerY,
                                                  multiplier: 1.0,
                                                  constant: 0.0)
        
        NSLayoutConstraint.activate([centerHorizontally, centerVertically])
        
        activityIndicator.startAnimating()
        
        self.present(alertController, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "OTA_Main") {
            print("prepareForSegue:OTA_Main")
        }
    }
    
    @objc func ScanbuttonTapped(_ sender:UIBarButtonItem!) {
        
        peripherals.removeAllObjects()
        
        ADV.removeAllObjects()
        
        self.tableView.reloadData()
        
        ScanDevice()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //return 5
        return peripherals.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LabelCell", for: indexPath)

        // Configure the cell...
        
        //cell.textLabel?.text = "Row \(indexPath.row)"
        let p:CBPeripheral = peripherals.object(at: indexPath.row) as! CBPeripheral
        if(p.name != nil) {
            let advdata = ADV.object(at: indexPath.row) as! [String : Any]
            let name = advdata["kCBAdvDataLocalName"]
            if(name != nil) {
                cell.textLabel!.text = name as? String
            }
            else {
                cell.textLabel!.text = p.name
            }
        } else {
            cell.textLabel!.text = "Unknown"
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Select device:\(indexPath.row)")
        
        let cell = tableView.cellForRow(at: indexPath)
        let labelContent = cell?.textLabel?.text
        print("BT Name = \(labelContent!)")
        BT_Name = labelContent!
        
        bleAdapter?.connectPeripheral(indexPath.row)
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @objc func connectionTimer() {
        print("Update table")
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        
        self.dismiss(animated: true, completion: nil)
        
        if(bleAdapter?.peripherals.count != 0)
        {
            peripherals = NSMutableArray(array: (bleAdapter?.peripherals)!)
            
            ADV = NSMutableArray(array: (bleAdapter?.advertisementDataArray)!)
            
            /*
            if let list = bleAdapter?.peripherals{
                for i in 0 ..< list.count
                {
                    peripherals.insert(bleAdapter?.peripherals.object(at:i) as! CBPeripheral, at: 0)
                }
            }*/
            
            self.tableView.reloadData()
        }
        
        //Debug
        //performSegue(withIdentifier: "OTA_Main", sender: self)
    }
    
    @objc func ScanDevice() {
        print("ScanDevice")
        
        var ok:Int = 0
        
        ok = (bleAdapter?.findAllBLEPeripherals(3.0))!
        
        //if((bleAdapter?.findBLEPeripherals(3.0)) == 0)
        if(ok == 0)
        {
            //self.dismiss(animated: true, completion: nil)
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            
            Scan_Waiting()
            Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(DeviceTableViewController.connectionTimer), userInfo: nil, repeats: false)
        }
        else{
            print("BT state : Unknown")
            if(self.navigationController?.visibleViewController?.isKind(of: UIAlertController.self))! {
                print("_UIAlertController is presenting here!")
                self.dismiss(animated: true, completion: nil)
            }
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func OnConnected(_ connectionStatus: Bool) {
        if(connectionStatus) {
            print("[DeviceTableViewController]Device is Connected")
            
            bleAdapter?.Peripheral_Name = BT_Name
            
            //Debug
            //self.performSegue(withIdentifier: "OTA_Main", sender: self)
            
            if(OTA_Mode!){
                //OTA DFU
                self.performSegue(withIdentifier: "OTA_Main", sender: self)
            }
            else{
                self.performSegue(withIdentifier: "OTA_DSP_Main", sender: self)
            }
            
            /*
            let alertController = UIAlertController(
                title: "OTA",
                message: "",
                preferredStyle: .alert)
            
            let okAction = UIAlertAction(
                title: "FW update",
                style: .default,
                handler: {
                    (action: UIAlertAction!) -> Void in
                    self.performSegue(withIdentifier: "OTA_Main", sender: self)
            })
            
            let cancelAction = UIAlertAction(
                title: "DSP Tuning",
                style: .default,
                handler: {
                    (action: UIAlertAction!) -> Void in
                    self.performSegue(withIdentifier: "OTA_DSP_Main", sender: self)
            })
            
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
            */
        }
        else {
            print("_Device is Disconnected")
        }
    }
    
    func BLEDataIn(_ dataIn: Data) {
    }
    
    func UpdateMTU(_ mtu: Int) {
    }
    
    func ISSC_Peripheral_Device(_ device_found: Bool) {
    }
    
    func DSPTuningResponse(_ dataIn: Data) {
    }
    
    func DSPTuningResponse_Read(_ dataIn:Data) {
    }
    
    func DSPTuningCommandComplete(_ dataIn: Data) {
    }
    
    func DSPTuningLogs(_ state: Data) {
    }
}
