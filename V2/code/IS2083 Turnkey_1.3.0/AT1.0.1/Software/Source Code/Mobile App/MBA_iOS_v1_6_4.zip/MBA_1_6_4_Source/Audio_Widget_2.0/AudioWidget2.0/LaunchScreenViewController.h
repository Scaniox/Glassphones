//
//  LaunchScreenViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 25/01/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LaunchScreenViewController : UIViewController
@property (retain, nonatomic) IBOutlet UILabel *versionLabel;

@end
