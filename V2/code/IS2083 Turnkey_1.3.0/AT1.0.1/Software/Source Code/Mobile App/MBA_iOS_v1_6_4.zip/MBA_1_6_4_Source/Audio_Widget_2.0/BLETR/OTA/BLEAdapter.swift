//
//  BLEAdapter.swift
//  TestOTA
//
//  Created by TestPC on 30/10/2017.
//  Copyright © 2017 TestPC. All rights reserved.
//

import UIKit
import CoreBluetooth

protocol BLEAdapterDelegate {
    func OnConnected(_ connectionStatus:Bool)
    func BLEDataIn(_ dataIn:Data)
    func UpdateMTU(_ mtu:Int)
    func ISSC_Peripheral_Device(_ device_found:Bool)
    func DSPTuningResponse(_ dataIn:Data)
    func DSPTuningResponse_Read(_ dataIn:Data)
    func DSPTuningCommandComplete(_ dataIn:Data)
    func DSPTuningLogs(_ state:Data)
}

@objc protocol BLE_ADV_Bypass {
    @objc func didDiscoverBlePeripheral(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber)
}

protocol WST_BLEAdapterDelegate {
    func didDiscoverPeripheral(Peripheral: CBPeripheral, AdvertisementData: [String : Any], Rssi RSSI: NSNumber)
    func didConnected()
    func didDisconnected()
    func didReceiveAudioEvent(data:Data)
    func didReceiveControlPointEvent(data: Data)
}

struct WST_BEACON_FORMAT {
    var batteryLevel: UInt8
    var dataCategory: UInt8
    var btmStatus: UInt8
    var primaryEarbudStatus_side: UInt8
    var primaryEarbudStatus_boxState: UInt8
    var primaryEarbudStatus_wstState: UInt8
    var secondaryBatteryLevel: UInt8
    var groupID: [UInt8] = [UInt8](repeating: 0, count: 6)
    var groupID_Str: String
}

extension WST_BEACON_FORMAT {
    init(_ beaconData: UnsafePointer<UInt8>) {
        self.batteryLevel = ((beaconData[0] & 0xF0)>>4)
        self.dataCategory = (beaconData[0] & 0x0F)
        self.btmStatus = beaconData[1]
        self.primaryEarbudStatus_side = (beaconData[2] & 0x01)
        self.primaryEarbudStatus_boxState = ((beaconData[2] & 0x02) >> 1)
        self.primaryEarbudStatus_wstState = ((beaconData[2] & 0x04) >> 2)
        self.secondaryBatteryLevel = (beaconData[3] & 0x0F)
        var ID = ""
        for i in 0...5{
            self.groupID[i] = beaconData[i+4]
            ID += String(format: "%02X", beaconData[i+4])
        }
        self.groupID_Str = ID
    }
}

@objc class BLEAdapter: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate{
    //================================================================================//
    let UUIDSTR_MCHP_OTA_SERVICE = "49535343-C9D0-CC83-A44A-6FE238D06D66"
    let UUIDSTR_ISSC_AIR_PATCH_CONTROL = "49535343-ACA3-481C-91EC-D85E28A60318"
    let UUIDSTR_ISSC_AIR_PATCH_CHAR = "49535343-18E4-4149-BDD4-1A7610F6844F"
    //================================================================================//
    let UUIDSTR_ISSC_PERIPHERAL_SERVICE = "49535343-4E64-482B-9F8E-668002726F2D"
    let UUIDSTR_ISSC_SPCP_CHAR = "49535343-5B15-447D-B42D-EC9255A04AF0"
    //================================================================================//
    let UUIDSTR_MCHP_PROPRIETARY_SERVICE = "49535343-FE7D-4AE5-8FA9-9FAFD205E455"
    let UUIDSTR_MCHP_CONNECTION_PARAMETER_CHAR = "49535343-6DAA-4D02-ABF6-19569ACA69FE"
    let UUIDSTR_MCHP_TRANS_TX = "49535343-1E4D-4BD9-BA61-23C647249616"
    let UUIDSTR_MCHP_TRANS_RX = "49535343-8841-43F4-A8D4-ECBE34729BB3"
    let UUIDSTR_MCHP_TRANS_CONTROL_POINT = "49535343-4C8A-39B3-2F49-511CFF073B7E"
    let UUIDSTR_MCHP_MP = "49535343-ACA3-481C-91EC-D85E28A60318"
    //================================================================================/
    let UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE = "49535343-87E0-4C24-83CD-A9AF7933EAC2"
    let UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR = "49535343-B75C-4470-9621-16B7F26C1045"
    let UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR = "49535343-4BB6-4977-B521-F04466776A3F"
    let UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR = "49535343-2DD1-45A3-94DE-8810F6436D78"
    //================================================================================//
    let BLE_OTA_Service_uuid = "0x1827"
    let BLE_OTA_Characteristic1_uuid = "2ADC"
    let BLE_OTA_Characteristic2_uuid = "2ADB"
    
    var centralManager: CBCentralManager?
    var peripherals: NSMutableArray = NSMutableArray()
    var advertisementDataArray: NSMutableArray = NSMutableArray()
    //WST Peripheral
    var wstPeripherals: NSMutableArray = NSMutableArray()
    var wstAdvertisementDataArray: NSMutableArray = NSMutableArray()
    var wstPeripheralsRssiArray: NSMutableArray = NSMutableArray()
    var activePeripheral: CBPeripheral?
    var bleAdapterDelegate:BLEAdapterDelegate?
    //WST delegate
    var WstBleAdapterDelegate:WST_BLEAdapterDelegate?
    var WriteCharacteristic:CBCharacteristic?
    var WriteCharacteristicResponse:CBCharacteristic?
    //WST characteristics
    var TransparentTxChar:CBCharacteristic?
    var TransparentRxChar:CBCharacteristic?
    var TransparentControlPointChar:CBCharacteristic?
    
    @objc var BLE_ADV_Bypass_Delegate: BLE_ADV_Bypass?
    
    var canSendData:Bool = false
    
    var mtu : Int = 0
    
    var ISSC_Peripheral : Bool = false
    //var BTEnable : Bool = false
    
    var TransmitCharacteristic = false
    var ReceiveCharacteristic = false
    
    var Peripheral_Name : String!
    
    //DSP Tuning
    var Capability_DSPTuning: Bool = false
    var ConnectService: Bool = false
    
    var Characteristic_Read_Operation: Bool = false
    var OTA_Selector: Bool?
    
    override init() {
        super.init()
        self.centralManager = CBCentralManager(delegate: self, queue: nil)
        activePeripheral = nil
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if #available(iOS 10.0, *) {
            switch (central.state) {
            case CBManagerState.poweredOff:
                print("Status of CoreBluetooth Central Manager = Power Off")
                //UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!)
                break
            case CBManagerState.unauthorized:
                print("Status of CoreBluetooth Central Manager = Does Not Support BLE")
                break
            case CBManagerState.unknown:
                print("Status of CoreBluetooth Central Manager = Unknown Wait for Another Event")
                break
            case CBManagerState.poweredOn:
                print("Status of CoreBluetooth Central Manager = Powered On")
                break
            case CBManagerState.resetting:
                print("Status of CoreBluetooth Central Manager = Resetting Mode")
                break
            case CBManagerState.unsupported:
                print("Status of CoreBluetooth Central Manager = Un Supported")
                break
            default:
                print("Status of CoreBluetooth Central Manager = Unknown Status")
                break
            }
        } else {
            // Fallback on earlier versions
            switch (central.state.rawValue) {
                case 3: //CBCentralManagerState.unauthorized
                    print("This app is not authorized to use Bluetooth low energy")
                    break
                case 4:
                    print("Bluetooth is currently powered off")
                    break
                case 5:
                    print("Bluetooth is currently powered on and available to use")
                    break
                default:break
            }
        }
    }
    
    private static var mInstance:BLEAdapter?
    
    @objc class func sharedInstance() -> BLEAdapter {
        if(mInstance == nil) {
            mInstance = BLEAdapter()
            print("New BLEAdapter object")
        }
        return mInstance!
    }
    
    func deleteInstance(){
        if(BLEAdapter.mInstance != nil) {
            BLEAdapter.mInstance = nil
        }
    }
    
    @objc func findAllBLEPeripherals(_ timeOut:Double) -> Int {
        if #available(iOS 10.0, *) {
            if(self.centralManager?.state != CBManagerState.poweredOn){
                print("BLE is not avaliable!")
                print("BT state = \(centralManager?.state.rawValue ?? -1)")
                return -1
            }
        } else {
            // Fallback on earlier versions
        }
        
        if #available(iOS 9.0, *) {
            if(self.centralManager!.isScanning)
            {
                print("Stop Scan")
                self.centralManager?.stopScan()
                sleep(1)
            }
        } else {
            // Fallback on earlier versions
            print("Stop Scan")
            self.centralManager?.stopScan()
            sleep(1)
        }
        
        self.peripherals.removeAllObjects()
        self.advertisementDataArray.removeAllObjects()
        
        self.wstPeripherals.removeAllObjects()
        self.wstAdvertisementDataArray.removeAllObjects()
        self.wstPeripheralsRssiArray.removeAllObjects()
        
        if(timeOut != 0){
            Timer.scheduledTimer(timeInterval: timeOut, target: self, selector: #selector(BLEAdapter.connectionTimer), userInfo: nil, repeats: false)
        }
        
        print("Scan ALL device")
        
        centralManager?.scanForPeripherals(withServices: nil, options: nil)   //Scan All Device
        //centralManager?.scanForPeripherals(withServices: [CBUUID(string: UUIDSTR_ISSC_AIR_PATCH_SERVICE)], options: nil)
        
        return 0
    }

    func findBLEPeripherals(_ timeOut:Double)->Int {
        if #available(iOS 10.0, *) {
            if(self.centralManager?.state != CBManagerState.poweredOn){
                print("BLE is not avaliable!")
                print("BT state = \(centralManager?.state.rawValue ?? -1)")
                return -1
            }
        } else {
            // Fallback on earlier versions
            print("Stop Scan")
            self.centralManager?.stopScan()
            sleep(1)
        }
        
        //print("BT state = \(centralManager?.state.rawValue ?? -1)")
        
        self.peripherals.removeAllObjects()
        self.advertisementDataArray.removeAllObjects()
        
        self.wstPeripherals.removeAllObjects()
        self.wstAdvertisementDataArray.removeAllObjects()
        self.wstPeripheralsRssiArray.removeAllObjects()
        
        Timer.scheduledTimer(timeInterval: timeOut, target: self, selector: #selector(BLEAdapter.connectionTimer), userInfo: nil, repeats: false)
        
        print("Scan ISSC device")
        centralManager?.scanForPeripherals(withServices: [CBUUID(string: UUIDSTR_ISSC_PERIPHERAL_SERVICE)], options: nil)
        
        //centralManager?.scanForPeripherals(withServices: [CBUUID(string: UUIDSTR_ISSC_AIR_PATCH_SERVICE)], options: nil)
        return 0
    }
    
    func stopScan(){
        if #available(iOS 9.0, *) {
            if(self.centralManager!.isScanning)
            {
                print("BLEAdapter - Stop Scan")
                self.centralManager?.stopScan()
                sleep(1)
            }
        } else {
            // Fallback on earlier versions
            print("BLEAdapter - Stop Scan")
            self.centralManager?.stopScan()
            sleep(1)
        }
    }
    
    func GetISSCDevice() {
        print("GetISSCDevice")
        self.bleAdapterDelegate?.ISSC_Peripheral_Device(ISSC_Peripheral)
    }
    
    func GetMTUSize() {
        //OTA DFU
        if #available(iOS 9.0, *) {
            mtu = (activePeripheral?.maximumWriteValueLength(for:CBCharacteristicWriteType.withoutResponse))!
        } else {
            // Fallback on earlier versions
        }
        print("GetMTUSize = \(mtu)")
        
        self.bleAdapterDelegate?.UpdateMTU(mtu)
    }
    
    func BLEDataOut(_ DataOut: Data) {
        print("BLE DataOut")
        
        if(WriteCharacteristic == nil){
            return
        }
        
        activePeripheral?.writeValue(DataOut, for: WriteCharacteristic!, type: CBCharacteristicWriteType.withoutResponse)
    }
    
    func BLEDataOut1(_ DataOut: Data) {
        print("BLE DataOut")
        
        if(WriteCharacteristic == nil){
            return
        }
        
        activePeripheral?.writeValue(DataOut, for: WriteCharacteristic!, type: CBCharacteristicWriteType.withResponse)
    }
    
    func BLE_WriteValue(_ characteristic:CBCharacteristic, data:Data, writeType:CBCharacteristicWriteType) {
        print("BLEAdapter - Write Value")
        /*if(characteristic == nil){
         return
         }*/
        
        activePeripheral?.writeValue(data, for: characteristic, type: writeType)
    }
    
    func BLEDataOut_WriteResponse(_ DataOut: Data) {
        print("BLEDataOut_WriteResponse")
        
        if(WriteCharacteristicResponse == nil){
            return
        }
        
        activePeripheral?.writeValue(DataOut, for: WriteCharacteristicResponse!, type: CBCharacteristicWriteType.withResponse)
    }
    
    func BLEDataOut_WriteNoResponse(_ DataOut: Data) {
        print("BLEDataOut_WriteNoResponse")
        
        if(WriteCharacteristic == nil){
            return
        }
        
        activePeripheral?.writeValue(DataOut, for: WriteCharacteristic!, type: CBCharacteristicWriteType.withoutResponse)
    }
    
    func prepareForDisconnect() {
        if(WriteCharacteristicResponse!.isNotifying){
            activePeripheral?.setNotifyValue(false, for: WriteCharacteristicResponse!)
            
            print("setNotifyValue = false")
        }
        else{
            print("Notification is disabled")
        }
    }
    
    func disconnectPeripheral() {
        if(activePeripheral != nil) {
            print("disconnectPeripheral")
            
            centralManager!.cancelPeripheralConnection(activePeripheral!)
        }
    }
    
    func connecPeripheral(_ peripheral: CBPeripheral) {
        //let peripheral:CBPeripheral = wstPeripherals[Selected] as! CBPeripheral
        
        print("Peripheral name = \(peripheral.name!) , \(peripheral.state.rawValue)")
        
        if(peripheral.state == CBPeripheralState.disconnected)
        {
            if(peripheral.name != nil) {
                print("Connect to a device:\(peripheral.name!)")
            }
            activePeripheral = peripheral
            activePeripheral?.delegate = self
            centralManager?.connect(peripheral, options: nil)
        }
    }
    
    func connectPeripheral(_ Selected:Int) {
        let peripheral:CBPeripheral = peripherals[Selected] as! CBPeripheral
        
        print("Peripheral name = \(peripheral.name!) , \(peripheral.state.rawValue)")
        
        if(peripheral.state == CBPeripheralState.disconnected)
        {
            if(peripheral.name != nil) {
                print("Connect to a device:\(peripheral.name!)")
            }
            activePeripheral = peripheral
            activePeripheral?.delegate = self
            centralManager?.connect(peripheral, options: nil)
        }
    }
    
    @objc func connectionTimer() {
        centralManager?.stopScan()
        print("Stopped Scanning")
        print("Known Peripherals = \(self.peripherals.count)")
        
        printKnownPeripherals()
    }
    
    func printKnownPeripherals() {
        print("Prints All Known Peripherals ")
        
        for i in 0 ..< self.peripherals.count {
            let p:CBPeripheral = self.peripherals.object(at: i) as! CBPeripheral
            printPeripheralInfo(p)
            let adv = self.advertisementDataArray.object(at: i)
            print("ADV = \(adv)")
            print("-------------------------------------\r\n");
            print("Parsing advertisement data...[kCBAdvDataServiceData]")
            /*
             let servicedata = advertisementData["kCBAdvDataServiceData"] as! [CBUUID : Any]
             let dat = servicedata[CBUUID(string:"FEDA")]
             if(dat != nil) {
             print("** dat = \(dat! as! NSData)")
             }
             */
            let test = adv as! [String:Any]
            if let test1 = test["kCBAdvDataServiceData"] as? [NSObject:AnyObject] {
                if let test2 = test1[CBUUID(string:"FEDA")] as? NSData {
                    print("** dat = \(test2 )")
                }
            }
            
        }
    }
    
    func printPeripheralInfo(_ peripheral: CBPeripheral) {
        print("------------------------------------\r\n");
        print("Peripheral Info :\r\n");
        //print("RSSI : \(peripheral.rssi?.int32Value)");
        if(peripheral.name != nil) {
            print("Peripheral Name : \(peripheral.name!)");
        }
        else {
            print("Name : nil")
        }
        print("isConnected : \(peripheral.state)");
        //print("-------------------------------------\r\n");
    }
    

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        print("ADV = \(advertisementData)")
        print("ID = \(peripheral.identifier)")
        print("-------->");
        
        //if let testdata = advertisementData["kCBAdvDataManufacturerData"]{
        //if let testdata = advertisementData[CBAdvertisementDataManufacturerDataKey]{
        //    print("ManufacturerData = \(testdata)")
        //}
 
        /*
        if let localname = advertisementData["kCBAdvDataLocalName"]{
            print("localname = \(localname)")
        }*/
        
        for i in 0 ..< self.peripherals.count {
            let p:CBPeripheral = self.peripherals.object(at: i) as! CBPeripheral
            
            if(p.identifier == peripheral.identifier) {
                //Identifiers Match
                self.peripherals.replaceObject(at: i, with: peripheral)
                self.advertisementDataArray.replaceObject(at: i, with: advertisementData)
                print("Duplicate UUID, Updating Peripherals Array")
                return;
            }
            /*else {
                if (p.name == peripheral.name){
                    self.peripherals.replaceObject(at: i, with: peripheral)
                    self.advertisementDataArray.replaceObject(at: i, with: advertisementData)
                    print("Duplicate UUID, Updating Peripherals Array")
                    return;
                }
            }*/
        }
        
        for i in 0 ..< self.wstPeripherals.count {
            let p:CBPeripheral = self.wstPeripherals.object(at: i) as! CBPeripheral
            
            if(p.identifier == peripheral.identifier) {
                //Identifiers Match
                print(p)
                self.wstPeripherals.replaceObject(at: i, with: peripheral)
                self.wstAdvertisementDataArray.replaceObject(at: i, with: advertisementData)
                self.wstPeripheralsRssiArray.replaceObject(at: i, with: RSSI)
                if(self.WstBleAdapterDelegate != nil) {
                    self.WstBleAdapterDelegate?.didDiscoverPeripheral(Peripheral: peripheral, AdvertisementData: advertisementData, Rssi: RSSI)
                }
                return
            }
            /*else {
             if (p.name == peripheral.name){
             self.peripherals.replaceObject(at: i, with: peripheral)
             self.advertisementDataArray.replaceObject(at: i, with: advertisementData)
             print("Duplicate UUID, Updating Peripherals Array")
             return;
             }
             }*/
        }
        
        if let Service_data_dic = advertisementData["kCBAdvDataServiceData"] as? [NSObject:AnyObject] {
            if let Service_data = Service_data_dic[CBUUID(string:"FEDA")] as? NSData {
                print("[OTA Peripheral] Service data = \(Service_data )")
                var dataByte = [UInt8] (Service_data as Data)
                let dataCategory = ((dataByte[0] & 0xF0)>>4)
                if (dataCategory == 0x03){
                    //                    let wst_beacon = WST_BEACON_FORMAT(dataByte[0], dataCategory: dataByte[0], btmStatus: dataByte[1], primaryEarbudStatus_side: dataByte[2], primaryEarbudStatus_boxState: dataByte[2], primaryEarbudStatus_wstState: dataByte[2], SecondaryBatteryLevel: dataByte[3],                                                       groupID:UnsafeMutablePointer<UInt8>(&dataByte[4]))
                    
                    //                    let wst_beacon = WST_BEACON_FORMAT(UnsafeMutablePointer<UInt8>(&dataByte))
                    //                    print(" wst_beacon.batteryLevel = \(wst_beacon.batteryLevel )")
                    //                    print(" wst_beacon.dataCategory = \(wst_beacon.dataCategory )")
                    //                    print(" wst_beacon.btmStatus = \(wst_beacon.btmStatus )")
                    //                    print(" wst_beacon.primaryEarbudStatus_side = \(wst_beacon.primaryEarbudStatus_side )")
                    //                    print(" wst_beacon.primaryEarbudStatus_boxState = \(wst_beacon.primaryEarbudStatus_boxState )")
                    //                    print(" wst_beacon.primaryEarbudStatus_wstState = \(wst_beacon.primaryEarbudStatus_wstState )")
                    //                    print(" wst_beacon.secondaryBatteryLevel = \(wst_beacon.secondaryBatteryLevel )")
                    //                    print(" wst_beacon.groupID = \(wst_beacon.groupID )")
                    //beacon.batteryLevel
                    self.wstPeripherals.add(peripheral)
                    self.wstAdvertisementDataArray.add(advertisementData)
                    self.wstPeripheralsRssiArray.add(RSSI)
                    
                    if(self.WstBleAdapterDelegate != nil) {
                        self.WstBleAdapterDelegate?.didDiscoverPeripheral(Peripheral: peripheral, AdvertisementData: advertisementData, Rssi: RSSI)
                    }
                }else{
                    self.peripherals.add(peripheral)
                    self.advertisementDataArray.add(advertisementData)
                    
                    if(self.BLE_ADV_Bypass_Delegate != nil){
                        self.BLE_ADV_Bypass_Delegate?.didDiscoverBlePeripheral(central, didDiscover: peripheral, advertisementData: advertisementData, rssi: RSSI)
                    }
                }
                
                //self.peripherals.add(peripheral)
                //self.advertisementDataArray.add(advertisementData)
            }
        }
        
        //self.peripherals.add(peripheral)
        //self.advertisementDataArray.add(advertisementData)
        
        //print("New Peripheral Adding to the List")
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("[centralManager] didConnect")
        activePeripheral = peripheral
        print("Peripheral ID = " + activePeripheral!.identifier.uuidString)
        
        if #available(iOS 9.0, *) {
            if(central.isScanning)
            {
                print("Stop Scan")
                central.stopScan()
            }
        } else {
            // Fallback on earlier versions
        }
        
        print("DiscoverServices")
        activePeripheral?.discoverServices(nil)
        
        //if(self.bleAdapterDelegate != nil) {
        //    self.bleAdapterDelegate?.OnConnected(true)
        //}
        
        if #available(iOS 9.0, *) {
            mtu = (activePeripheral?.maximumWriteValueLength(for:CBCharacteristicWriteType.withoutResponse))!
            
        } else {
            // Fallback on earlier versions
        }
        
        if #available(iOS 11.0, *){
            canSendData = (activePeripheral?.canSendWriteWithoutResponse)!
            if(canSendData){
                print("canSendWriteWithoutResponse = True")
            }
            else{
                print("canSendWriteWithoutResponse = False")
            }
        }else {
            if #available(iOS 10, *) {
                // iOS 10+
                print("current version is iOS 10+")
            } else {
                if #available(iOS 9, *) {
                    // iOS 9+
                    print("current version is iOS 9+")
                } else {
                    let minimumVersion = OperatingSystemVersion(majorVersion: 8, minorVersion: 1, patchVersion: 2)
                    if ProcessInfo().isOperatingSystemAtLeast(minimumVersion) {
                        //current version is >= (8.1.2)
                        print("current version is >= (8.1.2)")
                    } else {
                        //current version is < (8.1.2)
                        print("current version is < (8.1.2)")
                    }
                }
            }
        }
        
        print("OTA_Selector = \(OTA_Selector)")
        if(OTA_Selector == true){
            self.bleAdapterDelegate?.OnConnected(true)
        }
    }
    
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        print("[centralManager] didFailToConnect")
        
        if(self.bleAdapterDelegate != nil) {
            self.bleAdapterDelegate?.OnConnected(false)
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("[centralManager] didDisconnectPeripheral")
        
        if(self.bleAdapterDelegate != nil) {
            self.bleAdapterDelegate?.OnConnected(false)
        }
        
        ISSC_Peripheral = false
        
        activePeripheral = nil
        
        self.Capability_DSPTuning = false
        
        self.bleAdapterDelegate?.ISSC_Peripheral_Device(ISSC_Peripheral)
        
        if(self.WstBleAdapterDelegate != nil) {
            self.WstBleAdapterDelegate?.didDisconnected()
        }
    }
    
    //=======================================================================================================
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if (error == nil) {
            print("didDiscoverServices,Peripheral UUID : \(peripheral.identifier.uuidString.utf8) found\r\n" );
            
            for service in peripheral.services! {
                let thisService = service as CBService
                print("Service uuid = \(thisService.uuid.uuidString)")
                
                activePeripheral?.discoverCharacteristics(nil, for: thisService)
            }
        } else {
            print("Service discovery was unsuccessfull");
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        
        
        if(error == nil) {
            print("didDiscoverCharacteristics");
            
            for Char in service.characteristics! {
                let thisChar = Char as CBCharacteristic
                print("Characteristic uuid = \(thisChar.uuid.uuidString)")
                
                if(thisChar.uuid.uuidString == BLE_OTA_Characteristic1_uuid) {
                    print("SetNotify")
                }
                else if(thisChar.uuid.uuidString == BLE_OTA_Characteristic2_uuid) {
                    print("OTA Write Characteristic found!")
                }
                else if(thisChar.uuid.uuidString == UUIDSTR_ISSC_SPCP_CHAR) {
                    print("ISSC_SPCP_CHAR found")
                }
                else if(thisChar.uuid.uuidString == UUIDSTR_ISSC_AIR_PATCH_CONTROL) {
                    print("UUIDSTR_ISSC_AIR_PATCH_CONTROL ,setNotify")
                    peripheral.setNotifyValue(true, for: thisChar)
                    WriteCharacteristicResponse = Char
                    
                    ReceiveCharacteristic = true
                }
                else if(thisChar.uuid.uuidString == UUIDSTR_ISSC_AIR_PATCH_CHAR) {
                    print("UUIDSTR_ISSC_AIR_PATCH_CHAR")
                    
                    WriteCharacteristic = Char
                    TransmitCharacteristic = true
                }
                
                if(service.uuid.uuidString == UUIDSTR_MCHP_PROPRIETARY_SERVICE) {
                    print("ISSC_PROPRIETARY_SERVICE")
                    if(thisChar.uuid.uuidString == UUIDSTR_MCHP_TRANS_RX) {
                        print("ISSC_TRANS_RX")
                        TransparentRxChar = thisChar
                    }
                    else if(thisChar.uuid.uuidString == UUIDSTR_MCHP_TRANS_TX) {
                        print("ISSC_TRANS_TX")
                        TransparentTxChar = thisChar
                        //print("ISSC_TRANS_TX,Set Notify")
                        //Set Notify
                        peripheral.setNotifyValue(true, for: TransparentTxChar!)
                    }
                    else if(thisChar.uuid.uuidString == UUIDSTR_MCHP_CONNECTION_PARAMETER_CHAR) {
                        print("CONNECTION_PARAMETER_CHAR")
                    }
                    else if(thisChar.uuid.uuidString == UUIDSTR_MCHP_TRANS_CONTROL_POINT){
                        print("ISSC_TRANS_CONTROL_POINT_CHAR")
                        TransparentControlPointChar  = thisChar
                        peripheral.setNotifyValue(true, for: TransparentControlPointChar!)
                    }
                }
                
                if(service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE) {
                    print("MCHP_OTA_CFG_UPD_SERVICE")
                    
                    if(thisChar.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR) {
                        //print("MCHP_OTA_CFG_UPD_PARAMETER_CHAR,SetNotify enabled")
                        //peripheral.setNotifyValue(true, for: thisChar)
                    }
                    else if(thisChar.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR) {
                        print("MCHP_OTA_CFG_UPD_CTRL_CHAR,SetNotify enabled")
                        peripheral.setNotifyValue(true, for: thisChar)
                    }
                    else if(thisChar.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR) {
                        //print("MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR,SetNotify enabled")
                        //peripheral.setNotifyValue(true, for: thisChar)
                    }
                }
            }
        }
        else {
            print("Characteristics discovery was unsuccessfull");
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if(error == nil) {
            print("didWriteValueForCharacteristic");
            print("Characteristic uuid = \(characteristic.uuid.uuidString)")
        }
        else {
            print("didWriteValueForCharacteristic,Error,\(characteristic.uuid.uuidString)")
            print("Error = \(error?.localizedDescription)")
            
            if(characteristic.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR){
                print("SetNofity value = false")
                activePeripheral?.setNotifyValue(false, for: characteristic)
            
                sleep(1)
                print("Enable CCCD")
                activePeripheral?.setNotifyValue(true, for: characteristic)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if(error == nil) {
            //print("didUpdateValueForCharacteristic");
            //print("Characteristic uuid = \(characteristic.uuid.uuidString)")
            
            if(characteristic.uuid.uuidString == UUIDSTR_MCHP_TRANS_TX) {
                print("ISSC_TRANS_TX")
                
                if(characteristic.value != nil) {
                    //Parse command / data
                    if(self.WstBleAdapterDelegate != nil) {
                        self.WstBleAdapterDelegate?.didReceiveAudioEvent(data: characteristic.value!)
                    }
                    else{
                        print("Parse Event =  \(characteristic.value! as NSData)")
                    }
                }
            }
            else if(characteristic.uuid.uuidString == UUIDSTR_MCHP_TRANS_CONTROL_POINT) {
                if(characteristic.value != nil) {
                    //Parse command / data
                    print("Control Point Event =  \(characteristic.value! as NSData)")
                    if(self.WstBleAdapterDelegate != nil) {
                        self.WstBleAdapterDelegate?.didReceiveControlPointEvent(data:  characteristic.value!)
                    }
                }
            }
            else if((characteristic.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR) || (characteristic.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR) || (characteristic.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR)) {
                //print("MCHP_OTA_CFG_UPD_Service")
                
                if(characteristic.value != nil) {
                    //Parse command / data
                    //print("Data =  \(characteristic.value! as NSData)")
                    
                    if(characteristic.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR){
                        self.bleAdapterDelegate?.DSPTuningCommandComplete(characteristic.value!)
                    }
                    else if(characteristic.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR){
                        if(Characteristic_Read_Operation == true){
                            Characteristic_Read_Operation = false
                            self.bleAdapterDelegate?.DSPTuningResponse_Read(characteristic.value!)
                        }
                        else{
                            self.bleAdapterDelegate?.DSPTuningResponse(characteristic.value!)
                        }
                    }
                    else {
                        print("[BLEAdapter]DSP Tuning Logs =  \(characteristic.value! as NSData)")
                        self.bleAdapterDelegate?.DSPTuningLogs(characteristic.value!)
                    }
                }
            }
            else {
                if(self.bleAdapterDelegate != nil) {
                    self.bleAdapterDelegate?.BLEDataIn(characteristic.value!)
                }
            }
        }
        else {
            print("didUpdateValueForCharacteristic,Error,\(characteristic.uuid.uuidString)")
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if(error == nil) {
            print("didUpdateNotificationStateForCharacteristic");
            print("Characteristic uuid = \(characteristic.uuid.uuidString)")
            if(characteristic.isNotifying) {
                print("Notification has started")
                
                if(self.bleAdapterDelegate != nil) {
                    
                    if(TransmitCharacteristic && ReceiveCharacteristic) {
                        ISSC_Peripheral = true
                    }
                    else {
                        ISSC_Peripheral = false
                    }
                    
                    //print("ISSC_Peripheral = \(ISSC_Peripheral)")
                    
                    //self.bleAdapterDelegate?.UpdateMTU(mtu)
                    
                    //self.bleAdapterDelegate?.ISSC_Peripheral_Device(ISSC_Peripheral)
                }
                
                if characteristic.uuid.uuidString == UUIDSTR_MCHP_TRANS_CONTROL_POINT {
                    if(self.WstBleAdapterDelegate != nil) {
                        self.WstBleAdapterDelegate?.didConnected()
                    }
                }
                
                //BTAS-1355
                if characteristic.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR {
                    BLE_PARAMUpdate_CCCD_Enable()
                }
                
                if characteristic.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR {
                    BLE_LOG_CCCD_Enable()
                    
                    //BTAS-1465
                    //If DSP is runing in SCO stage, sometimes it will take long time to enable the BLE CCCD
                    if(OTA_Selector == false){
                        self.bleAdapterDelegate?.OnConnected(true)
                    }
                }
            }
        }
        else {
            print("didUpdateNotificationStateForCharacteristic,Error,\(characteristic.uuid.uuidString)")
        }
    }
    
    func peripheralIsReady(toSendWriteWithoutResponse peripheral: CBPeripheral) {
        //print("peripheralIsReady to SendWriteWithoutResponse data")
        
        if #available(iOS 11.0, *){
            canSendData = peripheral.canSendWriteWithoutResponse
        
            print("[BLEAdapter]canSendData = \(canSendData)")
        }
    }
    
    // MARK: - DSP Tuning
    
    func BLE_PARAMUpdate_CCCD_Enable(){
        guard activePeripheral != nil else { return }
        
        print("BLE_PARAMUpdate_CCCD_Enable")
        
        var ble_char : CBCharacteristic?
        var ble_service : CBService?
        
        if let a = activePeripheral?.services?.count {
            for index in 0..<a {
                if let service = activePeripheral?.services?[index]{
                    if service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE {
                        ble_service = service
                        break
                    }
                }
            }
            
            guard ble_service != nil else { return }
            
            if let b = ble_service?.characteristics?.count{
                for index in 0..<b {
                    if let char = ble_service?.characteristics?[index]{
                        if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR {
                            ble_char = char
                            activePeripheral?.setNotifyValue(true, for: ble_char!)
                            break
                        }
                    }
                }
            }
        }
    }
    
    func BLE_LOG_CCCD_Enable(){
        guard activePeripheral != nil else { return }
        
        print("BLE_LOG_CCCD_Enable")
        
        var ble_char : CBCharacteristic?
        var ble_service : CBService?
        
        if let a = activePeripheral?.services?.count {
            for index in 0..<a {
                if let service = activePeripheral?.services?[index]{
                    if service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE {
                        ble_service = service
                        break
                    }
                }
            }
            
            guard ble_service != nil else { return }
            
            if let b = ble_service?.characteristics?.count{
                for index in 0..<b {
                    if let char = ble_service?.characteristics?[index]{
                        if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR {
                            ble_char = char
                            activePeripheral?.setNotifyValue(true, for: ble_char!)
                            break
                        }
                    }
                }
            }
        }
    }
    
    func GetCapability() -> (Bool){
        var ble_char : CBCharacteristic?
        var ble_service : CBService?
        
        if(self.Capability_DSPTuning == true){
            return self.Capability_DSPTuning
        }
        
        if let a = activePeripheral?.services?.count {
            for index in 0..<a {
                if let service = activePeripheral?.services?[index]{
                    if service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE {
                        ble_service = service
                        break
                    }
                }
            }
            
            guard ble_service != nil else {
                self.Capability_DSPTuning = false
                return (Capability_DSPTuning)
                
            }
            
            if let b = ble_service?.characteristics?.count{
                for index in 0..<b {
                    if let char = ble_service?.characteristics?[index]{
                        if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR {
                            ble_char = char
                            break
                        }
                    }
                }
            }
            
            guard ble_char != nil else {
                self.Capability_DSPTuning = false
                return (Capability_DSPTuning)
                
            }
            
            self.Capability_DSPTuning = true
            
            print("GetCapability, DSPTuning = true")
            ChkConnectService()
            
            return (Capability_DSPTuning)
        }
        
        return (Capability_DSPTuning)
    }
    
    func ChkConnectService() -> Bool{
        print("*ConnectService = \(ConnectService)")
        if(ConnectService == false){
            print("[DSPTuning]Connect Service")
            let connect_command = Data(bytes: [0x02])
            DSPControlCommmand(connect_command)
        }
        
        return ConnectService
    }
    
    func DSPControlCommmand(_ DataOut: Data) {
        var ble_char : CBCharacteristic?
        var ble_service : CBService?
        
        if let a = activePeripheral?.services?.count {
            for index in 0..<a {
                if let service = activePeripheral?.services?[index]{
                    if service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE {
                        ble_service = service
                        break
                    }
                }
            }
            
            guard ble_service != nil else { return }
            
            if let b = ble_service?.characteristics?.count{
                for index in 0..<b {
                    if let char = ble_service?.characteristics?[index]{
                        //if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR {
                        if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR {
                            ble_char = char
                            break
                        }
                    }
                }
            }
            
            guard ble_char != nil else { return }
            
            print("DSP Control")
            print("Command = \(DataOut as NSData)")
            
            print("isNotifying = \(ble_char?.isNotifying)")
            
            if(ble_char?.isNotifying == false){
                return
            }
            
            activePeripheral?.writeValue(DataOut, for: ble_char!, type: CBCharacteristicWriteType.withResponse)
        }
    }
    
    func DSPConfigParameterUpdate(_ DataOut: Data) {
        var ble_char : CBCharacteristic?
        var ble_service : CBService?
        
        if let a = activePeripheral?.services?.count {
            for index in 0..<a {
                if let service = activePeripheral?.services?[index]{
                    if service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE {
                        ble_service = service
                        break
                    }
                }
            }
            
            guard ble_service != nil else { return }
            
            if let b = ble_service?.characteristics?.count{
                for index in 0..<b {
                    if let char = ble_service?.characteristics?[index]{
                        if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR {
                            ble_char = char
                            break
                        }
                    }
                }
            }
            
            guard ble_char != nil else { return }
            
            print("DSPConfigParameterUpdate")
            print("Data = \(DataOut as NSData)")
            
            print("isNotifying = \(ble_char?.isNotifying)")
            
            if(ble_char?.isNotifying == false){
                activePeripheral?.setNotifyValue(true, for: ble_char!)
                return
            }
            
            activePeripheral?.writeValue(DataOut, for: ble_char!, type: CBCharacteristicWriteType.withResponse)
            
        }
    }
    
    func DSPConfigParameterUpdate_Read(_ DataOut: Data) {
        var ble_char : CBCharacteristic?
        var ble_service : CBService?
        
        if let a = activePeripheral?.services?.count {
            for index in 0..<a {
                if let service = activePeripheral?.services?[index]{
                    if service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE {
                        ble_service = service
                        break
                    }
                }
            }
            
            guard ble_service != nil else { return }
            
            if let b = ble_service?.characteristics?.count{
                for index in 0..<b {
                    if let char = ble_service?.characteristics?[index]{
                        if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR {
                            ble_char = char
                            break
                        }
                    }
                }
            }
            
            guard ble_char != nil else { return }
            
            print("DSPConfigParameterUpdate")
            print("Data = \(DataOut as NSData)")
            
            print("isNotifying = \(ble_char?.isNotifying)")
            
            if(ble_char?.isNotifying == false){
                activePeripheral?.setNotifyValue(true, for: ble_char!)
                return
            }
        
            Characteristic_Read_Operation = true
            activePeripheral?.readValue(for: ble_char!)
        }
    }
    
    func DSPLogsCommand_Read() {
        var ble_char : CBCharacteristic?
        var ble_service : CBService?
        
        if let a = activePeripheral?.services?.count {
            for index in 0..<a {
                if let service = activePeripheral?.services?[index]{
                    if service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE {
                        ble_service = service
                        break
                    }
                }
            }
            
            guard ble_service != nil else { return }
            
            if let b = ble_service?.characteristics?.count{
                for index in 0..<b {
                    if let char = ble_service?.characteristics?[index]{
                        if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR {
                            ble_char = char
                            break
                        }
                    }
                }
            }
        
            guard ble_char != nil else { return }
            
            print("DSPLogsCommand_Read")

            activePeripheral?.readValue(for: ble_char!)
        }
    }
    
    func DSPLogsCommand(_ DataOut: Data) {
        var ble_char : CBCharacteristic?
        var ble_service : CBService?
        
        if let a = activePeripheral?.services?.count {
            for index in 0..<a {
                if let service = activePeripheral?.services?[index]{
                    if service.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE {
                        ble_service = service
                        break
                    }
                }
            }
            
            guard ble_service != nil else { return }
            
            if let b = ble_service?.characteristics?.count{
                for index in 0..<b {
                    if let char = ble_service?.characteristics?[index]{
                        if char.uuid.uuidString == UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR {
                            ble_char = char
                            break
                        }
                    }
                }
            }
            
            guard ble_char != nil else { return }
            
            print("DSPConfigParameterUpdate")
            print("Data = \(DataOut as NSData)")
            
            print("isNotifying = \(ble_char?.isNotifying)")
            
            if(ble_char?.isNotifying == false){
                activePeripheral?.setNotifyValue(true, for: ble_char!)
                return
            }
            
            activePeripheral?.writeValue(DataOut, for: ble_char!, type: CBCharacteristicWriteType.withResponse)
            
        }
    }
}
