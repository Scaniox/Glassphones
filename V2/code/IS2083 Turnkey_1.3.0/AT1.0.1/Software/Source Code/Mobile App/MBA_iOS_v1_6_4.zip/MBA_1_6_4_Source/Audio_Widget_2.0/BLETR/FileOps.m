//
//  FileOps.m
//  FileManagerTest
//
//  Created by d500_MacMini on 05/12/2016.
//  Copyright © 2016 MCHP_ISSC. All rights reserved.
//

#import "FileOps.h"
#import <UIKit/UIKit.h>

@implementation FileOps
@synthesize fileMgr;
@synthesize homeDir;
@synthesize filename;
@synthesize filepath;


-(NSString *) setFilename{
    filename = @"/Log.txt";
    
    return filename;
}

/*
 Get a handle on the directory where to write and read our files. If
 it doesn't exist, it will be created.
 */

-(NSString *)GetDocumentDirectory{
    //NSArray *myDocument = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //NSString *filePath = [NSString stringWithFormat:@"%@/Log.txt",[myDocument objectAtIndex:0]];
    fileMgr = [NSFileManager defaultManager];
    //homeDir = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    NSArray *myDocument = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    homeDir = [myDocument objectAtIndex:0];//[NSString stringWithFormat:@"%@/Log.txt",[myDocument objectAtIndex:0]];
    
    return homeDir;
}


/*Create a new file*/
-(void)createFileWithContent:(NSMutableString *)string{
    filepath = [[NSString alloc] init];
    NSError *err;
    
    filepath = [self.GetDocumentDirectory stringByAppendingPathComponent:self.setFilename];
    
    BOOL ok = [string writeToFile:filepath atomically:YES encoding:NSUnicodeStringEncoding error:&err];
    
    if (!ok) {
        NSLog(@"Error writing file at %@\n%@",
              filepath, [err localizedFailureReason]);
    }
}

-(void)WriteToFile:(NSMutableString *)textToWrite{
    filepath = [[NSString alloc] init];
    //NSError *err;
    
    filepath = [self.GetDocumentDirectory stringByAppendingPathComponent:self.setFilename];
    
    NSData *data = [textToWrite dataUsingEncoding:NSUnicodeStringEncoding];
    //BOOL ok =
    [self appendToFile:filepath data:data];//[textToWrite writeToFile:filepath atomically:YES encoding:NSUnicodeStringEncoding error:&err];
    
    /*if (!ok) {
        NSLog(@"Error writing file at %@\n%@",
              filepath, [err localizedFailureReason]);
    }*/
}

-(BOOL) appendToFile:(NSString *)path data:(NSData *)data{
    BOOL result = YES;
    //NSLog(@"Log is %@",data);
    NSFileHandle* fh = [NSFileHandle fileHandleForWritingAtPath:path];
    if(!fh){
        [[NSFileManager defaultManager] createFileAtPath:path contents:nil attributes:nil];
        fh = [NSFileHandle fileHandleForWritingAtPath:path];
    }
    if (!fh) {
        return NO;
    }
    
    @try {
        [fh seekToEndOfFile];
        [fh writeData:data];
    }@catch(NSException *e){
        result = NO;
    }
    [fh closeFile];
    
    return result;
}
/*
 Read the contents from file
 */
-(NSString *) readFromFile
{
    filepath = [[NSString alloc] init];
    NSError *error;
    //NSString *title;
    filepath = [self.GetDocumentDirectory stringByAppendingPathComponent:self.setFilename];
    NSString *txtInFile = [[NSString alloc] initWithContentsOfFile:filepath encoding:NSUnicodeStringEncoding error:&error];
    
    if(!txtInFile)
    {
        UIAlertView *tellErr = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Unable to get text from file." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [tellErr show];
    }
    return txtInFile;
}

@end
