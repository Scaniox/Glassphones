//
//  EQ_Calculate.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 16/03/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#ifndef EQ_Calculate_h
#define EQ_Calculate_h

#include <stdio.h>
int* getEqualizerParameters(double Gain[5],double freq[5],double q[5]);
//int* BM83_getEqualizerParameters(double Gain[5],double freq[5],double q[5],double global_gain,int stage);
int* BM83_getEqualizerParameters(double Gain[5],double freq[5],double q[5],double global_gain,int stage,double new_freq);
double GTodB(double in);
int BM83_GetErrorCode(void);
#endif /* EQ_Calculate_h */
