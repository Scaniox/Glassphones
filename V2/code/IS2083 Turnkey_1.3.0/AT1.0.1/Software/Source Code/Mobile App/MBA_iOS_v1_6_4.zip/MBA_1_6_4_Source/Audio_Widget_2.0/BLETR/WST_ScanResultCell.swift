//
//  WST_ScanResultCell.swift
//  Audio_Widget_2.0
//
//  Created by Derek_Mac on 2019/7/31.
//  Copyright © 2019 ISSC. All rights reserved.
//

import UIKit

class WST_ScanResultCell: UITableViewCell {
    
    @IBOutlet var rssiImage: UIImageView!
    @IBOutlet var deviceNameLabel: UILabel!
    @IBOutlet var groupIDLabel: UILabel!
    
    func setRssiImage(imageName: String) {
        let myImage: UIImage = UIImage(named: imageName)!
        self.rssiImage.image = myImage
    }
    
    func setDeviceName(name: String) {
        self.deviceNameLabel.text = name
    }
    
    func setGroupID(ID: String) {
        self.groupIDLabel.text = ID
    }
}
