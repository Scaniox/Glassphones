//
//  AudioSettingMessageViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 23/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "AudioSettingMessageViewController.h"

@interface AudioSettingMessageViewController (){
    NSString *messageText;
}

@end

@implementation AudioSettingMessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    messageTextView.scrollEnabled = FALSE;
    messageTextView.delegate = self;
    messageTextView.editable = FALSE;
    messageTextView.backgroundColor = [UIColor clearColor];
    messageTextView.layer.borderWidth = 2.0;
    messageTextView.text = messageText;
    // Do any additional setup after loading the view.
    self.title = @"Message";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)setMessage:(NSString *)text{
    messageText = text;
}

- (void)dealloc {
    [messageTextView release];
    [super dealloc];
}
@end
