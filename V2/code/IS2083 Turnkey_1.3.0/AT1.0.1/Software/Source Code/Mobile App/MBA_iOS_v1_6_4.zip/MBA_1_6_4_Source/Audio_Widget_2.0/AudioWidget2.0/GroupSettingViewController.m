//
//  GroupSettingViewController.m
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 24/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import "GroupSettingViewController.h"

@interface GroupSettingViewController (){
    NSArray *ungroupedControlArr;
    NSArray *ungroupedControlArr_StereoMode;
    NSArray *groupedControlArr;
    int cancelBtnIdx;
    NSMutableDictionary *MultiSpkRoleDict;
    NSString *groupRoleStr;
}

enum{
    CSB_STATE_GROUPING = 0x02,
    CSB_STATE_STOP_ADD_SPEAKER = 0x03,
    CSB_STATE_ADDING_NEW_SLAVE = 0x09,
};

enum{
    eENTER_NSPK_MODE = 0xF4,
    eENTER_BORADCAST_MODE = 0xF5,
    eCANCEL_NSPK_CREATION = 0xE3,
    eTERMINATE_CANCEL_NSPK_CONNECTION = 0xE5,
    eTRIGGER_NSPK_MASTER = 0xE0,
    eTRIGGER_NSPK_SLAVE = 0xE1,
    eNSPK_ADD_THIRD_SPEAKER = 0xF6,
};

enum{
    GROUP_STATUS_UNGROUPED = 0x00,
    GROUP_STATUS_STEREO_MASTER,
    GROUP_STATUS_STEREO_SLAVE = 0x04,
    GROUP_STATUS_CONCERT_MASTER,
    GROUP_STATUS_CONCERT_SLAVE,
    GROUP_STATUS_CONCERT_MASTER_STOP_ADD_NEW_SLAVE,
};

@end

@implementation GroupSettingViewController
@synthesize _csbState;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    MultiSpkRoleDict = [@{@0x00:@"Ungrouped",
                          @0x01:@"Stereo Master",
                          @0x04:@"Stereo Slave",
                          @0x05:@"Concert Master",
                          @0x06:@"Concert Slave",
                          @0x07:@"Concert Master"}mutableCopy];

    _connectedPeripheral.groupSettingDelegate = self;
    
    ungroupedControlArr = [[NSArray alloc] initWithObjects:@"Stereo  Master",@"Stereo Slave",@"Concert Master",@"Concert Slave", nil];
    ungroupedControlArr_StereoMode = [[NSArray alloc] initWithObjects:@"Stereo  Master",@"Stereo Slave", nil];
    groupedControlArr = [[NSArray alloc] initWithObjects:@"Ungrouped", nil];
    
    groupRoleStr = MultiSpkRoleDict[@(_speakerRole)];
    myTableView.backgroundColor = [UIColor clearColor];
    myTableView.delegate = self;
    myTableView.dataSource = self;
    self.title = @"Group Setting";
    if (_Feature_StereoMode || _Feature_ConcertMode) {
        [_connectedPeripheral sendReadnSPKStatus];
    }else{
        NSString* image = @"warning.png";;
        [self.navigationController.view makeToast:@"The Speaker doesn't support Group Feature!"
                                         duration:100.0
                                         position:CSToastPositionCenter
                                            title:@"Warning"
                                            image:[UIImage imageNamed:image]
                                            style:nil
                                       completion:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)dealloc {
    [myTableView release];
    //[stopNewConnectionBtn release];
    //[stopGroupingBtn release];
    _connectedPeripheral.groupSettingDelegate = nil;
    //[addNewSpeakerBtn release];
    [super dealloc];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell;// = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier" forIndexPath:indexPath];
    
    
    switch (indexPath.row) {
        case 0:{
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"DefaultCell"];
            cell.textLabel.text = @"Group Status";
            if(_csbState == CSB_STATE_GROUPING){
                cell.detailTextLabel.text = @"Grouping...";
            }else{
                cell.detailTextLabel.text = groupRoleStr;
            }
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
            break;
    }
    cell.backgroundColor = [UIColor clearColor];
    BOOL on = (_Feature_StereoMode | _Feature_ConcertMode);
    cell.userInteractionEnabled = on;
    
    return cell;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    switch (indexPath.row) {
        case 0:{
            if(_csbState == CSB_STATE_GROUPING){
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Do you want to cancel Grouping?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
                [alert show];
            }else{
                UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Set Speaker as:" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil];
                if (_speakerRole == GROUP_STATUS_UNGROUPED) {
                    if (!_Feature_ConcertMode) {
                        for(NSString *title in ungroupedControlArr_StereoMode){
                            [actionSheet addButtonWithTitle:title];
                        }
                    }else{
                        for(NSString *title in ungroupedControlArr){
                            [actionSheet addButtonWithTitle:title];
                        }
                    }
                }else{
                    for(NSString *title in groupedControlArr){
                        [actionSheet addButtonWithTitle:title];
                    }
                    if ((_speakerRole == GROUP_STATUS_CONCERT_MASTER_STOP_ADD_NEW_SLAVE) || ((_speakerRole == GROUP_STATUS_CONCERT_MASTER)&&(_csbState == CSB_STATE_STOP_ADD_SPEAKER)) ){
                        [actionSheet addButtonWithTitle:@"Add New Speaker"];
                    }
                }
                
                [actionSheet addButtonWithTitle:@"Cancel"];
                
                if (_speakerRole == GROUP_STATUS_UNGROUPED) {
                    if (!_Feature_ConcertMode) {
                        actionSheet.cancelButtonIndex = [ungroupedControlArr_StereoMode count];
                        cancelBtnIdx = (int)[ungroupedControlArr_StereoMode count];
                    }else{
                        actionSheet.cancelButtonIndex = [ungroupedControlArr count];
                        cancelBtnIdx = (int)[ungroupedControlArr count];
                    }
                }else{
                    actionSheet.cancelButtonIndex = [groupedControlArr count];
                    cancelBtnIdx = (int)[groupedControlArr count];
                    if ((_speakerRole == GROUP_STATUS_CONCERT_MASTER_STOP_ADD_NEW_SLAVE) || ((_speakerRole == GROUP_STATUS_CONCERT_MASTER)&&(_csbState == CSB_STATE_STOP_ADD_SPEAKER)) ) {
                        actionSheet.cancelButtonIndex++;// = [groupedControlArr count];
                        cancelBtnIdx++;
                    }
                }
                actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
                [actionSheet showInView:self.view];
            }
        }
        default:
            break;
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UIActionSheetDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"actionSheet button:%d",(int)buttonIndex);
    if (buttonIndex == cancelBtnIdx) {
        return;
    }else if (_speakerRole == GROUP_STATUS_UNGROUPED && !_Feature_ConcertMode){
        if (buttonIndex == 0) {
            [_connectedPeripheral sendMmiAction:eTRIGGER_NSPK_MASTER];
        }else if (buttonIndex ==1){
            [_connectedPeripheral sendMmiAction:eTRIGGER_NSPK_SLAVE];
        }
    }else if (_speakerRole == GROUP_STATUS_UNGROUPED && _Feature_ConcertMode){
        if (buttonIndex == 0) {
            [_connectedPeripheral sendMmiAction:eENTER_NSPK_MODE];
            [_connectedPeripheral sendMmiAction:eTRIGGER_NSPK_MASTER];
        }else if (buttonIndex ==1){
            [_connectedPeripheral sendMmiAction:eENTER_NSPK_MODE];
            [_connectedPeripheral sendMmiAction:eTRIGGER_NSPK_SLAVE];
        }else if (buttonIndex == 2){
            [_connectedPeripheral sendMmiAction:eENTER_BORADCAST_MODE];
            [_connectedPeripheral sendMmiAction:eTRIGGER_NSPK_MASTER];
        }else{
            [_connectedPeripheral sendMmiAction:eENTER_BORADCAST_MODE];
            [_connectedPeripheral sendMmiAction:eTRIGGER_NSPK_SLAVE];
        }
    }else if ((_speakerRole == GROUP_STATUS_CONCERT_MASTER_STOP_ADD_NEW_SLAVE) || ((_speakerRole == GROUP_STATUS_CONCERT_MASTER)&&(_csbState == CSB_STATE_STOP_ADD_SPEAKER)) ) {
        if (buttonIndex == 0){
            [_connectedPeripheral sendMmiAction:eTERMINATE_CANCEL_NSPK_CONNECTION];
        }else if(buttonIndex == 1){
            [_connectedPeripheral sendMmiAction:eNSPK_ADD_THIRD_SPEAKER];
        }
    }else{
        [_connectedPeripheral sendMmiAction:eTERMINATE_CANCEL_NSPK_CONNECTION];
    }
}

#pragma mark - UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 1:
            [_connectedPeripheral sendMmiAction:eCANCEL_NSPK_CREATION];
            break;
        default:
            break;
    }
}


#pragma mark - groupSettingDelegate
- (void)MyPeripheral:(MyPeripheral *)peripheral didUpdateGroupConnectionState:(unsigned char)state CSB_State:(unsigned char)csbState{
    _speakerRole = state;
    _csbState = csbState;
    groupRoleStr = MultiSpkRoleDict[@(_speakerRole)];
    [myTableView reloadData];
}
@end
