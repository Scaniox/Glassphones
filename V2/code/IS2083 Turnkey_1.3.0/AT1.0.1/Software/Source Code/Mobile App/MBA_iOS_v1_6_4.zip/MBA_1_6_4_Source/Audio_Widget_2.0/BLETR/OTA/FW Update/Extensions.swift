//
//  Extensions.swift
//  EADemo
//
//  Created by Farhad Rismanchian on 10/12/16.
//
//

import Foundation

/*
extension String {
    
    func dataFromHexadecimalString() -> Data? {
        
        guard let chars = cString(using: String.Encoding.utf8) else { return nil}
        let length = characters.count
        
        guard let data = NSMutableData(capacity: length/2) else { return nil }
        var byteChars: [CChar] = [0, 0, 0]
        var wholeByte: CUnsignedLong = 0
        
        for i in stride(from: 0, to: length, by: 2) {
            byteChars[0] = chars[i]
            byteChars[1] = chars[i + 1]
            wholeByte = strtoul(byteChars, nil, 16)
            data.append(&wholeByte, length: 1)
        }
        return data as Data
        //return data
    }
    
    
    init?(hexadecimalString: String) {
        guard let data = hexadecimalString.dataFromHexadecimalString() else {
            return nil
        }
        
        self.init(data: data , encoding: String.Encoding.utf8)
    }
    
    
    func hexadecimalString() -> String? {
        return data(using: String.Encoding.utf8)?.hexEncodedString()
    }
}
*/


extension String.Index{
    
    func successor(in string:String)->String.Index{
        return string.index(after: self)
    }
    
    
    func predecessor(in string:String)->String.Index{
        return string.index(before: self)
    }
    
    
    func advance(_ offset:Int, `for` string:String)->String.Index{
        return string.index(self, offsetBy: offset)
    }
}


extension Data {
    
    func hexEncodedString() -> String {
        return map { String(format: "%02hhx", $0) }.joined()
    }
}

extension Data {
    struct HexEncodingOptions: OptionSet {
        let rawValue: Int
        static let upperCase = HexEncodingOptions(rawValue: 1 << 0)
    }
    
    func hexEncodedString(options: HexEncodingOptions = []) -> String {
        let format = options.contains(.upperCase) ? "%02hhX" : "%02hhx"
        return map { String(format: format, $0) }.joined()
    }
}

/*
extension String {
    public func substring(from index: Int) -> String {
        if self.characters.count > index {
            let startIndex = self.index(self.startIndex, offsetBy: index)
            let subString = self[startIndex..<self.endIndex]
            
            return String(subString)
        } else {
            return self
        }
    }
}*/

