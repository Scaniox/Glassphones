//
//  AudioSettingMessageViewController.h
//  Audio_Widget_2.0
//
//  Created by d500_MacMini on 23/02/2017.
//  Copyright © 2017 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AudioSettingMessageViewController : UIViewController<UITextViewDelegate>{
    
    IBOutlet UITextView *messageTextView;
}

-(void)setMessage:(NSString *)text;
@end
