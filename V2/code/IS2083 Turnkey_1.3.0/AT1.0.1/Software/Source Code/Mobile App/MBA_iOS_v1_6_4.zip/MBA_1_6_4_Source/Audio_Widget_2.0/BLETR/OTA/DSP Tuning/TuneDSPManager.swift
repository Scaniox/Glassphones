//
//  TuneDSPManager.swift
//  
//
//  Created by TestPC on 2019/6/14.
//

import Foundation

protocol RefreshPageView {
    func UpdateTitle(title:String)
}

protocol DSPTuningDelegate {
    func BLE_ServiceReady()
    func RefreshModuleData()
    func RefreshParametersData(dat:Data)
    func DSPTuningComplete(result:UInt8)
    func BLE_ConnectionStatus(status:Bool)
    func DSPTuningState(state:String)
    func ExportDSPTuningResult()
}

enum DSPTuningErrorCodes{
   
}

class TuneDSPManager: BLEAdapterDelegate {
    
    struct DSP_Parameter {
        var Module_id: UInt8
        var Config_id: UInt8
        var len: UInt8
        var dat: [UInt8]
        
        init(module_id:UInt8, cfg_id:UInt8, length:UInt8, data:[UInt8]) {
            self.Module_id = module_id
            self.Config_id = cfg_id
            self.len = length
            self.dat = data
        }
    }
    
    let TuneDSPMode_NotSupport: UInt8 = 0x00
    let TuneDSPMode_Audio: UInt8 = 0x01
    let TuneDSPMode_Voice: UInt8 = 0x02
    
    let Audio_LineIn = 0x00
    let Audio_SoundEffect = 0x01
    let Audio_EQ = 0x02
    let Voice_Filter = 0x03
    let Voice_NR = 0x04
    let Voice_EQ = 0x05
    let Voice_MIC = 0x06
    let Voice_AEC = 0x07
    let Voice_WNG = 0x08
    let Voice_DRC = 0x09
    let Voice_BSS = 0x0A
    let Voice_MVDR = 0x0B
    let Voice_SYS = 0x0C
    
    private static var mInstance: TuneDSPManager?
    
    var bleAdapter : BLEAdapter?
    var DSPTuningDelegate: DSPTuningDelegate?
    var VoiceNR_Delegate: DSPTuningDelegate?
    var VoiceFilter_Delegate: DSPTuningDelegate?
    var VoiceEQ_Delegate: DSPTuningDelegate?
    var VoiceMIC_Delegate: DSPTuningDelegate?
    var VoiceAEC_Delegate: DSPTuningDelegate?
    var AudioLineIn_Delegate: DSPTuningDelegate?
    var AudioEffect_Delegate: DSPTuningDelegate?
    var AudioEQ_Delegate: DSPTuningDelegate?
    var HiddenAVC_Delegate: DSPTuningDelegate?
    var HiddenDRC_Delegate: DSPTuningDelegate?
    var HiddenBSS_Delegate: DSPTuningDelegate?
    var HiddenSYS_Delegate: DSPTuningDelegate?
    var HiddenMVDR_Delegate: DSPTuningDelegate?
    
    var RefreshPageViewDelegate: RefreshPageView?
    
    var Audio_Config: Data? //MODULE_AUDIO_MCU
    
    var DSPTuningInProgress: Bool = false
    
    var MBDRC_Data: [UInt8] = [UInt8]()
    var EQMode: UInt8?
    var EQ_Data: [UInt8] = [UInt8]()
    
    var AEC_AES_Data: [UInt8] = [UInt8]()
    
    var BLE_Connection: Bool?
    var BLE_MTU: Int?
    
    var DSP_State: UInt8 = 0x10
    var DUT_State: UInt8 = 0x10
    var DSP_DUT_State: String = ""
    
    var dynamicToolMode: UInt8!
    var QueueParameters: NSMutableArray = NSMutableArray()
    
    var Backup_DSP_State: UInt8!
    
    var Module_Config_data: Data?
    var Config_data_flag: UInt8?
    
    var TuneDSPParametersComplete: Bool = false
    
    var GUIDataRefresh = [false, false, false, false, false, false, false, false, false, false, false, false, false]
    
    var View_title: String?
    
    var ff: UnsafeMutablePointer<FILE>?
    
    class func sharedInstance() -> TuneDSPManager {
        if(mInstance == nil) {
            mInstance = TuneDSPManager()
            print("[TuneDSPManager]New object")
        }
        return mInstance!
    }
    
    func SetPageViewTitle(title:String){
        View_title = title
        RefreshPageViewDelegate?.UpdateTitle(title: title)
    }
    
    //BTAS-1464
    func Keep_DSP_State(){
        if(dynamicToolMode != TuneDSPMode_NotSupport){
            Backup_DSP_State = dynamicToolMode
            print("Keep_DSP_State")
        }
    }
    
    func Restore_DSP_State(){
        if(Backup_DSP_State != TuneDSPMode_NotSupport){
            if(dynamicToolMode != Backup_DSP_State){
                dynamicToolMode = Backup_DSP_State
                print("Restore_DSP_State")
            }
        }
    }
    
    func DSP_Init(){
        if(ff == nil){
            //redirectLogToFile(filename: "DSPTuning_Log.txt", open: true)
        }
        print("DSP_Init")
        bleAdapter = BLEAdapter.sharedInstance()
        bleAdapter?.bleAdapterDelegate = self
        DSPTuningInProgress = false
        dynamicToolMode = TuneDSPMode_NotSupport
        bleAdapter?.GetMTUSize()  //Disable for test
        print("mtu = \(bleAdapter?.mtu)")
        if(BLE_MTU != nil && BLE_MTU! == 20){
            BLE_MTU = bleAdapter?.mtu
            print("[BLE] MTU = \(BLE_MTU!)")
        }
    }
    
    func DSP_Disconnect_Device(){
        print("DSP_Disconnect_Device")
        bleAdapter?.disconnectPeripheral()
    }
    
    func DSP_Disconnect_Reset(){
        print("DSP_Disconnect_Reset")
        BLE_Connection = nil
        BLE_MTU = nil
        Audio_Config = nil
        DSPTuningInProgress = false
        MBDRC_Data.removeAll()
        AEC_AES_Data.removeAll()
        EQ_Data.removeAll()
        EQMode = 0x00
        DSP_State = 0x10
        DUT_State = 0x10
        DSP_DUT_State = ""
        QueueParameters.removeAllObjects()
        dynamicToolMode = TuneDSPMode_NotSupport
        Module_Config_data = nil
        Config_data_flag = nil
        TuneDSPParametersComplete = false
        for index in 0..<GUIDataRefresh.count{
            GUIDataRefresh[index] = false
        }
    }
    
    func DSP_End_Read_Session(){
        print("End Read Session")
        DSPTuningCommand(dat: Data(bytes: [0x09]))
    }
    
    func DSPQueueData(module:UInt8, cfg:UInt8, len:UInt8, data:[UInt8]){
        
        print("DSPQueueData = \(module),\(cfg),\(len),\(data)")
        
        if((module == 0x0C && cfg == 0x01) || (module == 0x0C && cfg == 0x05)){
            GUIDataRefresh[Audio_LineIn] = true
        }
        else if(module == 0x0C && cfg == 0x02){
            GUIDataRefresh[Audio_SoundEffect] = true
        }
        else if(module == 0x0C && cfg == 0x04){
            //GUIDataRefresh[Audio_EQ] = true
        }
        else if(module == 0x0D && cfg == 0x09){
            GUIDataRefresh[Voice_Filter] = true
        }
        else if((module == 0x0D && cfg == 0x06) || (module == 0x0D && cfg == 0x07)){
            GUIDataRefresh[Voice_NR] = true
        }
        else if(module == 0x0D && cfg == 0x0F){
            //GUIDataRefresh[Voice_EQ] = true
        }
        else if((module == 0x0D && cfg == 0x03) || (module == 0x0D && cfg == 0x04)){
            GUIDataRefresh[Voice_MIC] = true
        }
        else if(module == 0x0D && cfg == 0x05){
            GUIDataRefresh[Voice_AEC] = true
        }
        else if((module == 0x0D && cfg == 0x02) || (module == 0x0D && cfg == 0x03)){
            GUIDataRefresh[Voice_WNG] = true
        }
        else if(module == 0x0D && cfg == 0x08){
            GUIDataRefresh[Voice_DRC] = true
        }
        else if((module == 0x0D && cfg == 0x0A) || (module == 0x0D && cfg == 0x08)){
            GUIDataRefresh[Voice_BSS] = true
        }
        else if(module == 0x0D && cfg == 0x0E){
            GUIDataRefresh[Voice_MVDR] = true
        }
        else if(module == 0x0D && cfg == 0x0D){
            GUIDataRefresh[Voice_SYS] = true
        }
        
        var count = 0
        for index in 0..<QueueParameters.count {
            let obj = QueueParameters.object(at: index) as! DSP_Parameter
            if(obj.Module_id == module && obj.Config_id == cfg){
                print("DSP parameter exist! Update data")
                //obj.dat = data
                let new_obj = DSP_Parameter(module_id: obj.Module_id, cfg_id: obj.Config_id, length: obj.len, data: data)
                QueueParameters.replaceObject(at: index, with: new_obj)
                print("index = \(index)")
                print("new_obj = \(new_obj.Module_id),\(new_obj.Config_id),\(new_obj.len),\(new_obj.dat)")
                break
            }
            count += 1
        }
        
        if(count == QueueParameters.count){
            QueueParameters.add(DSP_Parameter(module_id: module, cfg_id: cfg, length: len, data: data))
        }
        
        print("========  QueueParameters ======== ")
        for index in 0..<QueueParameters.count {
            let obj = QueueParameters.object(at: index) as! DSP_Parameter
            print("index = \(index)")
            print("obj = \(obj.Module_id),\(obj.Config_id),\(obj.len),\(obj.dat)")
        }
        
        print("GUIDataRefresh = \(GUIDataRefresh)")
        
        /*
        if(QueueParameters.count != 0){
            var count = 0
            for index in 0..<QueueParameters.count {
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                if(obj.Module_id == module && obj.Config_id == cfg){
                    print("DSP parameter exist! Update data")
                    //obj.dat = data
                    let new_obj = DSP_Parameter(module_id: obj.Module_id, cfg_id: obj.Config_id, length: obj.len, data: data)
                    QueueParameters.replaceObject(at: index, with: new_obj)
                    print("index = \(index)")
                    print("new_obj = \(new_obj.Module_id),\(new_obj.Config_id),\(new_obj.len),\(new_obj.dat)")
                    break
                }
                count += 1
            }
            
            if(count == QueueParameters.count){
                QueueParameters.add(DSP_Parameter(module_id: module, cfg_id: cfg, length: len, data: data))
            }
            
            print("========  QueueParameters ======== ")
            for index in 0..<QueueParameters.count {
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                print("index = \(index)")
                print("obj = \(obj.Module_id),\(obj.Config_id),\(obj.len),\(obj.dat)")
            }
        }
        else{
            QueueParameters.add(DSP_Parameter(module_id: module, cfg_id: cfg, length: len, data: data))
        
            //Debug
            print("========  QueueParameters init======== ")
            for index in 0..<QueueParameters.count {
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                print("index = \(index)")
                print("obj = \(obj.Module_id),\(obj.Config_id),\(obj.len),\(obj.dat)")
            }
        }*/
    }
    
    func DSPTuning(module:UInt8, cfg:UInt8, len:UInt8, data:[UInt8]){
        if(!DSPTuningInProgress){
            DSPTuningInProgress = true
            print("Tune DSP parameters")
            
            var dd: [UInt8] = [UInt8]()
            var total_len: UInt8 = 0
            
            DSPQueueData(module: module, cfg: cfg, len: len, data: data)
            
            dd.append(0x06) //Tune DSP
            dd.append(UInt8(QueueParameters.count))     //Number of parameters
            for index in 0..<QueueParameters.count {   //Calculate total length
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                total_len += obj.len
                total_len += 3
            }
            dd.append(0x00) //Totoal_length_H
            dd.append(total_len) //Total_length_L
            for index in 0..<QueueParameters.count {   //Calculate total length
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                dd.append(obj.Module_id)
                dd.append(obj.Config_id)
                dd.append(obj.len)
                dd += obj.dat
            }
            
            let dsp_data = NSData(bytes: &dd, length: dd.count)
            print("[DSPTuning] dsp_data = \(dsp_data)")
            
            if(BLE_MTU != nil && dd.count > BLE_MTU!){
                print("[DSPTuning] Data length > MTU size")
                print("BLE_MTU = \(BLE_MTU!)")
                print("Send data, len = \(dd.count)")
                return
            }
            
            let send_data = Data(bytes: dd)
            bleAdapter?.DSPConfigParameterUpdate(send_data)
            QueueParameters.removeAllObjects()
        }
    }
    
    func DSPTuning2(module:UInt8, cfg1:UInt8, cfg2:UInt8, len1:UInt8, len2:UInt8, data1:[UInt8], data2:[UInt8]){
        if(!DSPTuningInProgress){
            DSPTuningInProgress = true
            print("Tune DSP parameters 2")
            
            var dd: [UInt8] = [UInt8]()
            var len: UInt8 = 0
            
            DSPQueueData(module: module, cfg: cfg1, len: len1, data: data1)
            DSPQueueData(module: module, cfg: cfg2, len: len2, data: data2)
            
            dd.append(0x06) //Tune DSP
            dd.append(UInt8(QueueParameters.count))     //Number of parameters
            for index in 0..<QueueParameters.count {   //Calculate total length
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                len += obj.len
                len += 3
            }
            dd.append(0x00) //Totoal_length_H
            dd.append(len) //Total_length_L
            for index in 0..<QueueParameters.count {   //Calculate total length
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                dd.append(obj.Module_id)
                dd.append(obj.Config_id)
                dd.append(obj.len)
                dd += obj.dat
            }
            
            let dsp_data = NSData(bytes: &dd, length: dd.count)
            print("[DSPTuning2] dsp_data = \(dsp_data)")
            
            if(BLE_MTU != nil && dd.count > BLE_MTU!){
                print("[DSPTuning2] Data length > MTU size")
                return
            }
            
            let send_data = Data(bytes: dd)
            bleAdapter?.DSPConfigParameterUpdate(send_data)
            QueueParameters.removeAllObjects()
        }
    }
    
    func DSPTuning3(){
        if(!DSPTuningInProgress){
            DSPTuningInProgress = true
            print("Tune DSP parameters 3")
            
            var dd: [UInt8] = [UInt8]()
            var total_len: UInt8 = 0
            
            dd.append(0x06) //Tune DSP
            dd.append(UInt8(QueueParameters.count))     //Number of parameters
            for index in 0..<QueueParameters.count {   //Calculate total length
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                total_len += obj.len
                total_len += 3
            }
            dd.append(0x00) //Totoal_length_H
            dd.append(total_len) //Total_length_L
            for index in 0..<QueueParameters.count {   //Calculate total length
                let obj = QueueParameters.object(at: index) as! DSP_Parameter
                dd.append(obj.Module_id)
                dd.append(obj.Config_id)
                dd.append(obj.len)
                dd += obj.dat
            }
            
            let dsp_data = NSData(bytes: &dd, length: dd.count)
            print("[DSPTuning] dsp_data = \(dsp_data)")
            
            if(BLE_MTU != nil && dd.count > BLE_MTU!){
                print("[DSPTuning] Data length > MTU size")
                return
            }
            
            let send_data = Data(bytes: dd)
            bleAdapter?.DSPConfigParameterUpdate(send_data)
            QueueParameters.removeAllObjects()
        }
    }
    
    func DSP_ClearQueueData(){
        if(QueueParameters.count != 0){
            print("DSP_ClearQueueData")
            QueueParameters.removeAllObjects()
        }
    }
    
    func DSPTuningCommand(dat:Data){
        print("Execute DSPTuningCommand")
        bleAdapter?.DSPControlCommmand(dat)
    }
    
    func Get_Device_Capability() -> Bool {
        print("Get_Device_Capability")
        if(bleAdapter == nil){
            print("bleAdapter = nil")
        }
        let capability = bleAdapter?.GetCapability()
        return capability!
    }
    
    func Read_Module_DSP_ALL(){
        if(Config_data_flag == nil){
            print("Read_Module_DSP_ALL")
            
            Config_data_flag = 0x80
            
            Read_Module_Audio_DSP()
        }
    }
    
    func Read_Module_Audio_MCU(){
        print("Read_Module_Audio_MCU")
        
        if(self.Audio_Config == nil){
        
            let Command = Data(bytes: [0x05,0x03])//Read Module:MODULE_AUDIO_MCU
        
            bleAdapter?.DSPConfigParameterUpdate(Command)
        }
        else {
            DSPTuningDelegate?.RefreshModuleData()
        }
    }
    
    func Read_Module_Audio_DSP(){
        print("Read_Module_Audio_DSP")
        
        Module_Config_data?.append(Data(bytes: [0x0C, 0x05]))   //MODULE_AUDIO_DSP, num_cfg_ids = 0x05
        Module_Config_data?.append(Data(bytes: [0x00, 0xC5]))   //Config_data length = 197
        
        let Command = Data(bytes: [0x05,0x0C])//Read Module:MODULE_AUDIO_DSP
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Read_Module_Voice_DSP(){
        print("Read_Module_Voice_DSP")
        
        Module_Config_data?.append(Data(bytes: [0x0D, 0x12]))   //MODULE_VOICE_DSP, num_cfg_ids = 0x12
        Module_Config_data?.append(Data(bytes: [0x01, 0xC0]))   //Config_data length = 448
        
        let Command = Data(bytes: [0x05,0x0D])//Read Module:MODULE_VOICE_DSP
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Read_Module_I2S_DSP(){
        print("Read_Module_I2S_DSP")
        
        Module_Config_data?.append(Data(bytes: [0x0E, 0x01]))   //MODULE_I2S_DSP, num_cfg_ids = 0x01
        Module_Config_data?.append(Data(bytes: [0x00, 0xC0]))   //Config_data length = 192
        
        let Command = Data(bytes: [0x05,0x0E])//Read Module:MODULE_I2S_DSP
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func ClearModifiedBit(data:Data) -> Data{
        //var Config_data: Data = Data()
        
        print("ClearModifiedBit =========>")
        
        let bytes : NSData = data as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        while(k < bytes.length) {
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            print("Offset = \(k), cfg_id = \((buf[k])), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if((buf[k] & 0x80) == 0x80){
                buf[k] &= 0x7F
                print("Clear cfg_id bit7, New cfg_id = \((buf[k]))")
            }
            
            //Debug
            //for index in 0..<buf[k+1]{
            //    buf[k + 2 + Int(index)] = 0xAA
            //}
            
            k += Int(2+buf[k+1])
        }
        print("<=========")
        
        let Config_data = Data(bytes:buf)
        
        return Config_data
    }
    
    func Read_DSP_State() {
        bleAdapter?.DSPLogsCommand_Read()
    }
    
    func Get_Audio_DSP_CustomEQ_SPK(){
        print("Get_Audio_DSP_CustomEQ_SPK")
        
        let Command = Data(bytes: [0x04,0x01,0x0C,0x04])//Read Parameters:AUD_DSP_CFG_KEY_CUSTOM_EQ_SPK_AUDIO
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Audio_DSP_Setting_MBDRC(){
        print("Get_Audio_DSP_Setting_MBDRC")
        
        let Command = Data(bytes: [0x04,0x01,0x0C,0x02])//Read Parameters:AUD_DSP_CFG_KEY_MBDRC
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
        
        //DSPTuningResponse = <01040100 000b0c02 08a06935 028ff915 c3>, length = 17
    }
    
    func Get_Audio_DSP_Setting_LineIn(){
        print("Get_Audio_DSP_Setting_LineIn")
        
        let Command = Data(bytes: [0x04,0x01,0x0C,0x01])//Read Parameters:AUD_DSP_CFG_KEY_LINEIN
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_DSP_Setting_Filter(){
        print("Get_Voice_DSP_Setting_Filter")
        
        //Read Parameters:
        //Module_id = 0x0D
        //Cfg_id = 0x09
        let Command = Data(bytes: [0x04,0x01,0x0D,0x09])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_DSP_Setting_NR(){
        print("Get_Voice_DSP_Setting_NR")
        
        //Read Parameters:
        //Module_id = 0x0D
        //Cfg_id = 0x06, VOICE_DSP_CFG_KEY_TUNING_FENR
        //Cfg_id = 0x07, VOICE_DSP_CFG_KEY_TUNING_NENR
        //Cfg_id = 0x01 , VOICE_DSP_CFG_KEY_CONFIG_WORD
        
        //Module_id = 0x03
        //Cfg_id = 0x0D , AUD_MCU_CFG_KEY_NR_EQ_MODE
        
        //let Command = Data(bytes: [0x04,0x03,0x0D,0x06,0x0D,0x07,0x03,0x0D])
        let Command = Data(bytes: [0x04,0x04,0x0D,0x06,0x0D,0x07,0x03,0x0D,0x0D,0x0C])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_DSP_Setting_AEC_AES(){
        print("Get_Voice_DSP_Setting_AEC_AES")
        
        //Read Parameters:
        //Module_id = 0x0D
        //Cfg_id = 0x05 , VOICE_DSP_CFG_KEY_TUNING_AEC_AES
        //Cfg_id = 0x01 , VOICE_DSP_CFG_KEY_CONFIG_WORD
        
        //let Command = Data(bytes: [0x04,0x01,0x0D,0x05])
        let Command = Data(bytes: [0x04,0x02,0x0D,0x05,0x0D,0x01])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_MIC_Gain(){
        print("Get_Voice_MIC_Gain")
        
        //Read Parameters:
        //Module_id = 0x0D
        //Cfg_id = 0x03, VOICE_DSP_CFG_KEY_TUNING_WNG
        //Cfg_id = 0x04, VOICE_DSP_CFG_KEY_TUNING_DIGITAL_AND_CODEC_GAIN
        let Command = Data(bytes: [0x04,0x02,0x0D,0x03,0x0D,0x04])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_AVC_WNG_Setting(){
        print("Get_Voice_AVC_WNG_Setting")
        
        //Read Parameters:
        //Module_id = 0x0D,MODULE_VOICE_DSP
        //Cfg_id = 0x01, VOICE_DSP_CFG_KEY_CONFIG_WORD
        //Cfg_id = 0x02, VOICE_DSP_CFG_KEY_H_TUNING_AVC
        //Cfg_id = 0x03, VOICE_DSP_CFG_KEY_TUNING_WNG
        let Command = Data(bytes: [0x04,0x03,0x0D,0x01,0x0D,0x02,0x0D,0x03])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_DRC_Setting(){
        print("Get_Voice_DRC_Setting")
    
        //Read Parameters:
        //Module_id = 0x0D,MODULE_VOICE_DSP
        //Cfg_id = 0x01, VOICE_DSP_CFG_KEY_CONFIG_WORD
        //Cfg_id = 0x08, VOICE_DSP_CFG_KEY_H_TUNING_DRC_COM
        
        let Command = Data(bytes: [0x04,0x02,0x0D,0x01,0x0D,0x08])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_BSS_Setting(){
        print("Get_Voice_BSS_Setting")
        
        //Read Parameters:
        //Module_id = 0x0D,MODULE_VOICE_DSP
        //Cfg_id = 0x0B, VOICE_DSP_CFG_KEY_TUNING_BSS
        //Cfg_id = 0x0A, VOICE_DSP_CFG_KEY_H_TUNING_LINE_DELAY
        
        //Module_id = 0x03
        //Cfg_id = 0x0D , AUD_MCU_CFG_KEY_NR_EQ_MODE
        
        let Command = Data(bytes: [0x04,0x03,0x03,0x0D,0x0D,0x0A,0x0D,0x0B])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_MVDR(){
        print("Get_Voice_MVDR")
        
        //Read Parameters:
        //Module_id = 0x0D,MODULE_VOICE_DSP
        //Cfg_id = 0x0E, VOICE_DSP_CFG_KEY_MVDR
        
        let Command = Data(bytes: [0x04,0x01,0x0D,0x0E])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func Get_Voice_SYS_PARA(){
        print("Get_Voice_SYS_PARA")
        
        //Read Parameters:
        //Module_id = 0x0D,MODULE_VOICE_DSP
        //Cfg_id = 0x0D, VOICE_DSP_CFG_KEY_H_TUNING_SYS_PARA
        let Command = Data(bytes: [0x04,0x01,0x0D,0x0D])
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func All_Audio_DSP_Setting(){
        print("All_Audio_DSP_Setting")
        
        
    }
    
    func Get_BT_Device_Name() {
        print("Get_BT_Device_Name")
        
        let Command = Data(bytes: [0x04,0x01,0x02,0x0B])//Read Parameters:BT_CFG_KEY_DEVICE_NAME
        
        bleAdapter?.DSPConfigParameterUpdate(Command)
    }
    
    func  EnableDSPTuningLogs() {
        print("EnableDSPTuningLogs")
        
        let Command = Data(bytes: [0x01,0x01])//Enable DUT Logs and DSP Logs
        
        bleAdapter?.DSPLogsCommand(Command)
    }
    
    func ParsingAudioConfigData() {
        guard Audio_Config != nil else {return}
        
        print("ParsingAudioConfigData")
        
        //Paramter format : [cfg_id,len,data]
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        while(k < bytes.length) {
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            print("Offset = \(k), cfg_id = \((buf[k] & 0x7F)), data len = \(buf[k+1]), dat = \(dat as NSData)")
            k += Int(2+buf[k+1])
        }
        
        DSPTuningDelegate?.RefreshModuleData()
        
        /*
         Offset = 0, cfg_id = 1, data len = 1, dat = <f0>
         Offset = 3, cfg_id = 2, data len = 1, dat = <03>
         Offset = 6, cfg_id = 3, data len = 1, dat = <01>
         Offset = 9, cfg_id = 4, data len = 1, dat = <02>
         Offset = 12, cfg_id = 5, data len = 1, dat = <00>
         Offset = 15, cfg_id = 6, data len = 1, dat = <ff>
         Offset = 18, cfg_id = 135, data len = 8, dat = <20222222 22222222>
         Offset = 28, cfg_id = 136, data len = 1, dat = <0a>
         Offset = 31, cfg_id = 9, data len = 1, dat = <f0>
         Offset = 34, cfg_id = 10, data len = 16, dat = <00a2a5c2 c5e2e5e8 ebeef1f4 f7fafbfc>
         Offset = 52, cfg_id = 139, data len = 1, dat = <22>
         Offset = 55, cfg_id = 12, data len = 2, dat = <03fe>
         Offset = 59, cfg_id = 13, data len = 1, dat = <11>
         Offset = 62, cfg_id = 14, data len = 16, dat = <00a2a5c2 c5e2e5e8 ebeef1f4 f7fafbfc>
         Offset = 80, cfg_id = 23, data len = 1, dat = <67>
         Offset = 83, cfg_id = 16, data len = 1, dat = <01>
         Offset = 86, cfg_id = 17, data len = 1, dat = <67>
         Offset = 89, cfg_id = 18, data len = 1, dat = <0a>
         Offset = 92, cfg_id = 19, data len = 1, dat = <0a>
         Offset = 95, cfg_id = 20, data len = 1, dat = <0a>
         Offset = 98, cfg_id = 21, data len = 1, dat = <0a>
         Offset = 101, cfg_id = 22, data len = 1, dat = <00>
         Offset = 104, cfg_id = 15, data len = 1, dat = <a0>
         Offset = 107, cfg_id = 24, data len = 1, dat = <59>
         Offset = 110, cfg_id = 25, data len = 1, dat = <2e>
         Offset = 113, cfg_id = 26, data len = 1, dat = <00>
         Offset = 116, cfg_id = 27, data len = 1, dat = <22>
         Offset = 119, cfg_id = 28, data len = 1, dat = <00>
         Offset = 122, cfg_id = 29, data len = 1, dat = <93>
         Offset = 125, cfg_id = 30, data len = 1, dat = <05>
         Offset = 128, cfg_id = 31, data len = 1, dat = <00>
         Offset = 131, cfg_id = 32, data len = 1, dat = <0e>
         Offset = 134, cfg_id = 33, data len = 1, dat = <02>
         Offset = 137, cfg_id = 34, data len = 1, dat = <f0>
         Offset = 140, cfg_id = 35, data len = 1, dat = <08>
         Offset = 143, cfg_id = 36, data len = 11, dat = <01c00000 00000007 000100>
         Offset = 156, cfg_id = 37, data len = 1, dat = <05>
         Offset = 159, cfg_id = 38, data len = 1, dat = <04>
         Offset = 162, cfg_id = 39, data len = 1, dat = <0c>
         Offset = 165, cfg_id = 40, data len = 1, dat = <00>
         */
    }
    
    func GetDefaultEqualizerMode() -> (UInt8? , UInt8?) {
        guard Audio_Config != nil else {return (nil, nil)}
        
        print("GetDefaultEqualizerMode")
        
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        var EQ_OnOff: UInt8 = 0
        var Default_EQ: UInt8 = 0
        
        while(k < bytes.length) {
            let cfg_id = buf[k]
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if(cfg_id == 0x0F){     //AUD_MCU_CFG_KEY_AUDIO_RPU_STATUS
                //Default_EQ = buf[k+2]
                EQ_OnOff = buf[k+2]
            }
            else if(cfg_id == 0x04){     //AUD_MCU_CFG_KEY_TX_EQ_MODE
                Default_EQ = buf[k+2]
            }
            
            k += Int(2+buf[k+1])
        }
        
        return ((EQ_OnOff & 0x20) , Default_EQ)
    }
    
    func GetAudioEQMask() -> (UInt16){
        guard Audio_Config != nil else {return (0)}
        
        print("GetAudioEQMask")
        
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        var EQ_Mask_byte1: UInt8 = 0
        var EQ_Mask_byte2: UInt8 = 0
        
        while(k < bytes.length) {
            let cfg_id = buf[k]
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if(cfg_id == 0x0C){     //AUD_MCU_CFG_KEY_EQ_MASK
                EQ_Mask_byte1 = buf[k+2]
                EQ_Mask_byte2 = buf[k+3]
                print("EQMask = \((UInt16(EQ_Mask_byte1) << 8) ),\(UInt16(EQ_Mask_byte2))")
            }
            
            k += Int(2+buf[k+1])
        }
        
        return ((UInt16(EQ_Mask_byte1) << 8) + UInt16(EQ_Mask_byte2))
    }
    
    func GetAudioEffect() -> (UInt8?, UInt8?) {
        guard Audio_Config != nil else {return (nil, nil)}
        
        print("GetAudioEffect")
        
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        var Audio_Effect_Mask: UInt8 = 0
        var Audio_Effect: UInt8 = 0
        
        while(k < bytes.length) {
            let cfg_id = buf[k]
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if(cfg_id == 0x20){     //AUD_MCU_CFG_KEY_EFFECT_MASK
                Audio_Effect_Mask = buf[k+2]
            }
            else if(cfg_id == 0x21){    //AUD_MCU_CFG_KEY_EFFECT
                Audio_Effect = buf[k+2]
                break
            }
            
            k += Int(2+buf[k+1])
        }
        
        return (Audio_Effect_Mask, Audio_Effect)
    }
    
    func CheckAudioMBDRC_AW() ->(Bool?, Bool?){
        guard Audio_Config != nil else {return (nil, nil)}
        
        print("CheckAudioMBDRC_AW")
        
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        var Audio_RPU_Status: UInt8 = 0
        var Audio_Effect: UInt8 = 0
        
        while(k < bytes.length) {
            let cfg_id = buf[k]
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if(cfg_id == 0x0F){     //AUD_MCU_CFG_KEY_AUDIO_RPU_STATUS
                Audio_RPU_Status = buf[k+2]
            }
            else if(cfg_id == 0x20){    //AUD_MCU_CFG_KEY_EFFECT_MASK
                Audio_Effect = buf[k+2]
            }
            
            k += Int(2+buf[k+1])
        }
        
        var MBDRC_onoff: Bool = false
        var AW_onoff: Bool = false
        
        if(((Audio_RPU_Status & 0x80) == 0x80) && ((Audio_Effect & 0x06) != 0)){
            MBDRC_onoff = true
        }
        
        if(((Audio_RPU_Status & 0x80) == 0x80) && ((Audio_Effect & 0x0C) != 0)){
            AW_onoff = true
        }
        
        return (MBDRC_onoff, AW_onoff)
    }
    
    func GetVoiceAECMode() -> (UInt8?){
        guard Audio_Config != nil else {return (nil)}
        
        print("GetVoiceAECMode")
        
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        var AEC_Mode: UInt8 = 0
        var Voice_RPU_Status: UInt8 = 0
        
        while(k < bytes.length) {
            let cfg_id = buf[k]
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if(cfg_id == 0x10){     //AUD_MCU_CFG_KEY_AEC_MODE
                AEC_Mode = buf[k+2]
            }
            else if(cfg_id == 0x17){    //AUD_MCU_CFG_KEY_VOICE_RPU_STATUS
                Voice_RPU_Status = buf[k+2]
            }
            
            k += Int(2+buf[k+1])
        }
        
        print("AEC_Mode = \(AEC_Mode)")
        print("Voice_RPU_Status,bit 0 = \((Voice_RPU_Status & 0x01))")
        
        return (AEC_Mode & (Voice_RPU_Status & 0x01))
    }
    
    func GetVoiceEQMode() -> (UInt8?, UInt8?, UInt8?, UInt8?){
        guard Audio_Config != nil else {return (nil, nil, nil, nil)}
        
        print("GetVoiceEQMode")
        
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        var EQMode1: UInt8 = 0x0f
        var EQMode2: UInt8 = 0x0f
        var EQMode3: UInt8 = 0x0f
        var EQMode4: UInt8 = 0x0f
        
        while(k < bytes.length) {
            let cfg_id = buf[k]
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if(cfg_id == 0x12){         //AUD_MCU_CFG_KEY_CVSD_RX_EQ_MODE
                EQMode1 = buf[k+2]
            }
            else if(cfg_id == 0x13){    //AUD_MCU_CFG_KEY_CVSD_TX_EQ_MODE
                EQMode2 = buf[k+2]
            }
            if(cfg_id == 0x14){         //AUD_MCU_CFG_KEY_MSBC_RX_EQ_MODE
                EQMode3 = buf[k+2]
            }
            else if(cfg_id == 0x15){    //AUD_MCU_CFG_KEY_MSBC_TX_EQ_MODE
                EQMode4 = buf[k+2]
            }
            
            k += Int(2+buf[k+1])
        }
        
        return (EQMode1, EQMode2, EQMode3, EQMode4)
    }
    
    func GetAudioLineInEQMode() -> UInt8?{
        guard Audio_Config != nil else {return (nil)}
        
        print("GetAudioLineInEQMode")
        
        var mode: UInt8 = 0x00
        
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        while(k < bytes.length) {
            let cfg_id = buf[k]
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if(cfg_id == 0x05){     //AUD_MCU_CFG_KEY_H_RX_EQ_MODE
                mode = buf[k+2]
            }
            
            k += Int(2+buf[k+1])
        }
        
        return mode
    }
    
    func GetAudioMCUOption3() -> UInt8?{
        guard Audio_Config != nil else {return (nil)}
        
        print("GetAudioMCUOption3")
        
        var Option3: UInt8 = 0x00
        
        let bytes : NSData = Audio_Config! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        var k:Int = 0
        
        while(k < bytes.length) {
            let cfg_id = buf[k]
            let len = buf[k+1]
            let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            
            if(cfg_id == 0x1B){     //AUD_MCU_CFG_KEY_OPTION3
                Option3 = buf[k+2]
            }
            
            k += Int(2+buf[k+1])
        }
        
        return Option3
    }
    
    func RefreshGUIData(UIView_index: Int) -> Bool{
        print("UIViewIndex = \(UIView_index), RefreshGUIData = \(GUIDataRefresh[UIView_index])")
        
        return GUIDataRefresh[UIView_index]
    }
    
    func ClearRefreshFlag(UIView_index: Int){
        print("ClearRefreshFlag")
        
        GUIDataRefresh[UIView_index] = false
    }
    
    func GetCurrentView() -> Int{
        if(self.View_title == "Noise Reduction"){
            return 1
        }
        if(self.View_title == "Filter"){
            return 2
        }
        if(self.View_title == "MIC Gain/ComfortNoise"){
            return 3
        }
        if(self.View_title == "AEC/AES"){
            return 4
        }
        if(self.View_title == "EQ"){
            return 5
        }
        if(self.View_title == "LineIn"){
            return 6
        }
        if(self.View_title == "Sound Effect"){
            return 7
        }
        if(self.View_title == "Audio EQ"){
            return 8
        }
        if(self.View_title == "AVC/WNG"){
            return 9
        }
        if(self.View_title == "DRC"){
            return 10
        }
        if(self.View_title == "BSS/Delay"){
            return 11
        }
        if(self.View_title == "SYS_PARA"){
            return 12
        }
        if(self.View_title == "MVDR"){
            return 13
        }
        else{
            return 0
        }
    }
    
    func UpdateGUIs(view_title:String){
        //self.DSPTuningDelegate?.DSPTuningState(state: view_title)
        
        guard self.View_title != nil else {return}
        let view = GetCurrentView()
        switch view{
        case 1:
            self.VoiceNR_Delegate?.DSPTuningState(state: view_title)
        case 2:
            self.VoiceFilter_Delegate?.RefreshModuleData()
        case 3:
            self.VoiceMIC_Delegate?.DSPTuningState(state: view_title)
        case 4:
            self.VoiceAEC_Delegate?.DSPTuningState(state: view_title)
        case 5:
            self.VoiceEQ_Delegate?.RefreshModuleData()
        case 6:
            self.AudioLineIn_Delegate?.DSPTuningState(state: view_title)
        case 7:
            self.AudioEffect_Delegate?.RefreshModuleData()
        case 8:
            self.AudioEQ_Delegate?.RefreshModuleData()
        case 9:
            self.HiddenAVC_Delegate?.RefreshModuleData()
        case 10:
            self.HiddenDRC_Delegate?.RefreshModuleData()
        case 11:
            self.HiddenBSS_Delegate?.RefreshModuleData()
        case 12:
            self.HiddenSYS_Delegate?.RefreshModuleData()
        case 13:
            self.HiddenMVDR_Delegate?.RefreshModuleData()
        default:
            print("Error,Unknown state")
        }
    }
    
    func GetTime() -> String {
        // get the current date and time
        let currentDateTime = Date()
        
        // initialize the date formatter and set the style
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        formatter.dateStyle = .none
        
        // get the date time String from the date object
        let CurrentTime = formatter.string(from: currentDateTime)
        print("\(CurrentTime)")
        
        return CurrentTime
    }
    
    func redirectLogToFile(filename: String , open: Bool) {
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            if(open){
                do {
                    let fileURLs = try FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)
                    
                    let txtFiles = fileURLs.filter{ $0.pathExtension == "txt" }
                    
                    print("Log files URLs = \(txtFiles)")
                    
                    let txtFileNames = txtFiles.map{ $0.deletingPathExtension().lastPathComponent }
                    print("file name list = ", txtFileNames)
                    
                    if(txtFileNames.count != 0){
                        for i in 0..<txtFileNames.count {
                            if("DSPTuning_Log" == txtFileNames[i]) {
                                let filepath = txtFiles[i].path
                                print("Log file is Found! = \(filepath)")
                                if(try? FileManager.default.removeItem(atPath: filepath)) != nil {
                                    print("Delete DSPTuning_Log.txt success ")
                                }
                                else {
                                    print("Delete DSPTuning_Log.txt failed")
                                }
                                break
                            }
                        }
                    }
                }
                catch {
                    print("Error while enumerating files. \(error.localizedDescription)")
                    return
                }
                
                let fileURL = dir.appendingPathComponent(filename)
                
                let file_path = fileURL.path
                
                ff = freopen((file_path as NSString).cString(using: String.Encoding.ascii.rawValue), "a+", stdout)
                
                GetTime()
                print("[Open]redirectLogToFile = \(file_path)")
            }
            else{
                if(ff != nil){
                    GetTime()
                    print("[Close]LogFile")
                    fclose(ff)
                    ff = nil
                }
            }
        }
    }
    
    // MARK: - BLEAdapterDelegate
    func OnConnected(_ connectionStatus: Bool) {
        print("BLE Connection Status = \(connectionStatus)")
        
        BLE_Connection = connectionStatus
        
        if(BLE_Connection == false){
            print("Claer Audio data")
            Audio_Config = nil
            if(MBDRC_Data.count != 0){
                MBDRC_Data.removeAll()
            }
            if(AEC_AES_Data.count != 0){
                AEC_AES_Data.removeAll()
            }
            DSP_ClearQueueData()
        }
        
        //self.DSPTuningDelegate?.BLE_ConnectionStatus(status: connectionStatus)
        
        let view = GetCurrentView()
        switch view{
        case 1:
            print("delegate")
            self.VoiceNR_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 2:
            print("delegate")
            self.VoiceFilter_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 3:
            print("delegate")
            self.VoiceMIC_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 4:
            print("delegate")
            self.VoiceAEC_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 5:
            print("delegate")
            self.VoiceEQ_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 6:
            print("delegate")
            self.AudioLineIn_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 7:
            print("delegate")
            self.AudioEffect_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 8:
            print("delegate")
            self.AudioEQ_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 9:
            print("delegate")
            self.HiddenAVC_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 10:
            print("delegate")
            self.HiddenDRC_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 11:
            print("delegate")
            self.HiddenBSS_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 12:
            print("delegate")
            self.HiddenSYS_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        case 13:
            print("delegate")
            self.HiddenMVDR_Delegate?.BLE_ConnectionStatus(status: connectionStatus)
        default:
            print("Error,Unknown state")
            self.DSPTuningDelegate?.BLE_ConnectionStatus(status: connectionStatus)
        }
    }
    
    func BLEDataIn(_ dataIn: Data) {
        
    }
    
    func UpdateMTU(_ mtu: Int) {
        if(BLE_MTU == nil){
            BLE_MTU = mtu
            print("[DSPTuning]UpdateMTU = \(BLE_MTU)")
        }
    }
    
    func ISSC_Peripheral_Device(_ device_found: Bool) {
        
    }
    
    func DSPTuningResponse(_ dataIn: Data) {
        
        let bytes : NSData = dataIn as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        
        print("DSPTuningResponse = \(dataIn as NSData), length = \(dataIn.count)")
        
        var data_len : Int = 0
        
        if(buf[0] == 0x01 && buf[1] == 0x05) {    //Response = 0x01,Request op-code = 0x05(Read Module)
            let audio_config = Data(bytes:[0x01, 0x05, 0x01, 0x00, 0x03])
            let subdata = bytes.subdata(with: NSMakeRange(0, 5))
            
            //let len = bytes.subdata(with: NSMakeRange(6, 2))
            //(len as NSData).getBytes(&data_len, length: 2)
            data_len = (Int(buf[6]) << 8) + Int(buf[7])
            print("data_len = \(data_len)")
            
            if(buf[2] != 0x01){//Operation result = 0x01(Success)
                print("Operation result is fail!,module_id = \(buf[4])")
                return
            }
            
            //if(((audio_config as NSData).isEqual(to: subdata)) && (bytes.length == (data_len+8))){
            if(buf[4] == 0x03)//module_id = MODULE_AUDIO_MCU
            {
                let config = bytes.subdata(with: NSMakeRange(8, bytes.length-8))
                print("Audio config = \(config as NSData)")
                Audio_Config = config
                
                if(Module_Config_data == nil){
                    print("Module data init..")
                    Module_Config_data = Data()
                    Module_Config_data?.append(Data(bytes: [0x00])) 
                    Module_Config_data?.append(Data(bytes: [0x03, 0xFE]))   //Total length = 1022 = (1+4+168+4+197+4+448+4+192)
                    Module_Config_data?.append(Data(bytes: [0x04]))     //num_modules = 0x04
                    Module_Config_data?.append(Data(bytes: [0x03, 0x28]))   //MODULE_AUDIO_MCU = 0x03,num_cfg_ids = 0x28
                    Module_Config_data?.append(Data(bytes: [0x00, 0xA8]))   //config_data lengt = 168
                    //Module_Config_data?.append(Audio_Config!)
                    let new_config_data = ClearModifiedBit(data: Audio_Config!)
                    Module_Config_data?.append(new_config_data)
                    
                    //Debug
                    //let hexString = Module_Config_data?.hexEncodedString()
                    //print("hexString = \(hexString) , len = \(hexString?.count)")
                    //let hexString = Module_Config_data?.hexEncodedString(options: .upperCase)
                    //print("hexString = \(hexString) , len = \(hexString?.count)")
                }
                
                ParsingAudioConfigData()
                
                //self.DSPTuningDelegate?.BLE_ServiceReady()
                let view = GetCurrentView()
                if(view == 2){
                    self.VoiceFilter_Delegate?.BLE_ServiceReady()
                }
                else if(view == 6){
                    self.AudioLineIn_Delegate?.BLE_ServiceReady()
                }
                else if(view == 9){
                    self.HiddenAVC_Delegate?.BLE_ServiceReady()
                }
            }
            else{
                if(buf[3] == 0x00)
                {
                    //Type = 0x00-The configuration data is sent in notification
                    
                    let config_data = bytes.subdata(with: NSMakeRange(8, bytes.length-8))
                    print("[Notification]Module configuration data = \(config_data as NSData)")
                    
                    if(Module_Config_data != nil){
                        print("[Notification]Append Module_Config_data")
                        //Module_Config_data?.append(config_data)
                        let new_config_data = ClearModifiedBit(data: config_data)
                        Module_Config_data?.append(new_config_data)
                        
                        if(Config_data_flag != nil && Config_data_flag == 0x80){
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                            {
                                self.Read_Module_Voice_DSP()
                                self.Config_data_flag = 0x81
                            }
                        }
                        else if(Config_data_flag != nil && Config_data_flag == 0x81){
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                            {
                                self.Read_Module_I2S_DSP()
                                self.Config_data_flag = 0x82
                            }
                        }
                        else if(Config_data_flag != nil && Config_data_flag == 0x82){
                            self.Config_data_flag = nil
                            
                            if((Module_Config_data!.count % 16) != 0){
                                let new_size = ((Module_Config_data!.count/16)+1) * 16
                                print("Adjust the Data size = \(new_size)")
                                
                                let padding_len = new_size - Module_Config_data!.count
                                for _ in 0..<padding_len {
                                    Module_Config_data?.append(Data(bytes: [0xff]))
                                }
                            }
                            
                            //Module_Config_data
                            print("Module_Config_data,len = \(Module_Config_data?.count)")
                            print("data = \(Module_Config_data as! NSData)")
                            
                            self.DSPTuningDelegate?.ExportDSPTuningResult()
                        }
                    }
                }
                else{
                    //Type = 0x01-The configuration data should be read using read characteristic method
                    print("Read module, Response data byte 3(Type) = 0x01")
                    var Command = Data(bytes: [0x05])//Read Module
                    let module = buf[4]
                    Command.append(Data(bytes: [module]))
                    print("Command = \(Command)")
                    bleAdapter?.DSPConfigParameterUpdate_Read(Command)
                }
                
            }
        }
        else if(buf[0] == 0x01 && buf[1] == 0x04) {     //Response = 0x01,Request op-code = 0x04(Read Parameter)
            if(buf[2] == 0x01) {    //Result = Success = 0x01
                //DSPTuningResponse = <01040100 000b0c02 08a06935 028ff915 c3>, length = 17
                
                data_len = (Int(buf[4]) << 8) + Int(buf[5])
                print("Length of the configuration data = \(data_len)")
                
                let config_data = bytes.subdata(with: NSMakeRange(6, (bytes.length-6)))
                
                //DSPTuningDelegate?.RefreshParametersData(dat: config_data)
                
                let view = GetCurrentView()
                switch view{
                case 1:
                    print("delegate")
                    self.VoiceNR_Delegate?.RefreshParametersData(dat: config_data)
                case 2:
                    print("delegate")
                    self.VoiceFilter_Delegate?.RefreshParametersData(dat: config_data)
                case 3:
                    print("delegate")
                    self.VoiceMIC_Delegate?.RefreshParametersData(dat: config_data)
                case 4:
                    print("delegate")
                    self.VoiceAEC_Delegate?.RefreshParametersData(dat: config_data)
                case 5:
                    print("delegate")
                    self.VoiceEQ_Delegate?.RefreshParametersData(dat: config_data)
                case 6:
                    print("delegate")
                    self.AudioLineIn_Delegate?.RefreshParametersData(dat: config_data)
                case 7:
                    print("delegate")
                    self.AudioEffect_Delegate?.RefreshParametersData(dat: config_data)
                case 8:
                    print("delegate")
                    self.AudioEQ_Delegate?.RefreshParametersData(dat: config_data)
                case 9:
                    print("delegate")
                    self.HiddenAVC_Delegate?.RefreshParametersData(dat: config_data)
                case 10:
                    print("delegate")
                    self.HiddenDRC_Delegate?.RefreshParametersData(dat: config_data)
                case 11:
                    print("delegate")
                    self.HiddenBSS_Delegate?.RefreshParametersData(dat: config_data)
                case 12:
                    print("delegate")
                    self.HiddenSYS_Delegate?.RefreshParametersData(dat: config_data)
                case 13:
                    print("delegate")
                    self.HiddenMVDR_Delegate?.RefreshParametersData(dat: config_data)
                default:
                    print("Error,Unknown state")
                }
            }
        }
        else if(buf[0] == 0x01 && buf[1] == 0x06) { //Response = 0x01,Request op-code = 0x06(Tune DSP parameters)
            DSPTuningInProgress = false
            //DSPTuningDelegate?.DSPTuningComplete(result: buf[2])
            let view = GetCurrentView()
            switch view{
            case 1:
                print("delegate")
                self.VoiceNR_Delegate?.DSPTuningComplete(result: buf[2])
            case 2:
                print("delegate")
                self.VoiceFilter_Delegate?.DSPTuningComplete(result: buf[2])
            case 3:
                print("delegate")
                self.VoiceMIC_Delegate?.DSPTuningComplete(result: buf[2])
            case 4:
                print("delegate")
                self.VoiceAEC_Delegate?.DSPTuningComplete(result: buf[2])
            case 5:
                print("delegate")
                self.VoiceEQ_Delegate?.DSPTuningComplete(result: buf[2])
            case 6:
                print("delegate")
                self.AudioLineIn_Delegate?.DSPTuningComplete(result: buf[2])
            case 7:
                print("delegate")
                self.AudioEffect_Delegate?.DSPTuningComplete(result: buf[2])
            case 8:
                print("delegate")
                self.AudioEQ_Delegate?.DSPTuningComplete(result: buf[2])
            case 9:
                print("delegate")
                self.HiddenAVC_Delegate?.DSPTuningComplete(result: buf[2])
            case 10:
                print("delegate")
                self.HiddenDRC_Delegate?.DSPTuningComplete(result: buf[2])
            case 11:
                print("delegate")
                self.HiddenBSS_Delegate?.DSPTuningComplete(result: buf[2])
            case 12:
                print("delegate")
                self.HiddenSYS_Delegate?.DSPTuningComplete(result: buf[2])
            case 13:
                print("delegate")
                self.HiddenMVDR_Delegate?.DSPTuningComplete(result: buf[2])
            default:
                print("Error,Unknown state")
                DSPTuningDelegate?.DSPTuningComplete(result: buf[2])
            }
            print("DSPTuningComplete..")
            TuneDSPParametersComplete = true
        }
    }
    
    func DSPTuningResponse_Read(_ dataIn:Data) {
        print("[Characteristic Read]Module configuration data = \(dataIn as NSData), length = \(dataIn.count)")
        
        print("Append data")
        //Module_Config_data?.append(dataIn)
        let new_config_data = ClearModifiedBit(data: dataIn)
        Module_Config_data?.append(new_config_data)
            
        DSP_End_Read_Session()
    }
    
    func DSPTuningCommandComplete(_ dataIn:Data) {
        
        let bytes : NSData = dataIn as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        
        print("DSPTuningCommandComplete = \(dataIn as NSData), length = \(dataIn.count)")
        
        if(buf[0] != 0x01) {    //Response
            print("Invalid data")
            return
        }
        
        if((buf[2] != 0x01) || (dataIn.count < 3) ) {   //Success = 0x01
            print("Execute command failed!")
            if(buf[1] >= 0x04 && buf[1] <= 0x09){
                //Dynamic Tuning Commands
                print("Dynamic Tuning Commands : response")
                DSPTuningDelegate?.DSPTuningComplete(result: buf[2])
            }
            return
        }
        
        print("Success,Request op code = \(buf[1])")
        
        if(buf[1] == 0x09){
            if(Config_data_flag != nil && Config_data_flag == 0x80){
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                {
                    self.Read_Module_Voice_DSP()
                    self.Config_data_flag = 0x81
                }
            }
            else if(Config_data_flag != nil && Config_data_flag == 0x81){
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                {
                    self.Read_Module_I2S_DSP()
                    self.Config_data_flag = 0x82
                }
            }
            else if(Config_data_flag != nil && Config_data_flag == 0x82){
                self.Config_data_flag = nil
                
                if((Module_Config_data!.count % 16) != 0){
                    let new_size = ((Module_Config_data!.count/16)+1) * 16
                    print("Adjust the Data size = \(new_size)")
                    
                    let padding_len = new_size - Module_Config_data!.count
                    for _ in 0..<padding_len {
                        Module_Config_data?.append(Data(bytes: [0xff]))
                    }
                }
                
                //Module_Config_data
                print("Module_Config_data,len = \(Module_Config_data?.count)")
                print("data = \(Module_Config_data as! NSData)")
                
                self.DSPTuningDelegate?.ExportDSPTuningResult()
            }
            return
        }
        
        let connect_success = Data(bytes: [0x01,0x02,0x01]) //Response,Request op-code,Result
        if (dataIn == connect_success){
            print("Get MTU Size")
            let GetMTUCommand = Data(bytes:[0x0a])
            bleAdapter?.DSPControlCommmand(GetMTUCommand)
        }
        else {
            let mtu = bytes.subdata(with: NSMakeRange(3, bytes.length-3))
            print("MTU = \(mtu as NSData)")
            Get_BT_Device_Name()
            
            EnableDSPTuningLogs()
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                if(self.Audio_Config == nil){
                    //self.DSPTuningDelegate?.BLE_ServiceReady()
                    let view = self.GetCurrentView()
                    if(view == 2){
                        self.VoiceFilter_Delegate?.BLE_ServiceReady()
                    }
                    else if(view == 6){
                        self.AudioLineIn_Delegate?.BLE_ServiceReady()
                    }
                    else if(view == 9){
                        self.HiddenAVC_Delegate?.BLE_ServiceReady()
                    }
                }
            }
        }
    }
    
    func DSPTuningLogs(_ state: Data) {
        //print("DSP Tuning Logs =  \(state as NSData)")
        
        let bytes : NSData = state as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        
        DSP_DUT_State = ""
        
        if(buf[0] < 8){
            //DSP Current State
            DSP_State = buf[2]
        }
        else if(buf[0] <= 15 && buf[0] >= 8){
            //DUT Current State
            DUT_State = buf[2]
        }
        else{
            print("Unknown State")
        }
        
        switch(DSP_State){
        case 0:
            //print("DSP State:STANDBY")
            //print("DSP:STANDBY")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:STANDBY")
            break
        case 1:
            //print("DSP:WAIT CODEC PD")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:WAIT CODEC PD")
            break
        case 2:
            //print("DSP:WAIT DSP PD")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:WAIT DSP PD")
            break
        case 3:
            //print("DSP:WAIT REACTIVE")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:WAIT REACTIVE")
            break
        case 4:
            //print("DSP:WAIT ACTIVE")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:WAIT ACTIVE")
            break
        case 5:
            //print("DSP:PREPARE READY")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:PREPARE READY")
            break
        case 6:
            //print("DSP:RESTART DSP")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:RESTART DSP")
            break
        case 7:
            //print("DSP:TEST MODE")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:TEST MODE")
            break
        case 8:
            //print("DSP:LINE IN READY")
            dynamicToolMode = TuneDSPMode_Audio
            DSP_DUT_State.append("DSP:LINE IN READY")
            break
        case 9:
            //print("DSP:PCM READY")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:PCM READY")
            break
        case 10:
            //print("DSP:RINGTONE READY")
            dynamicToolMode = TuneDSPMode_Audio
            DSP_DUT_State.append("DSP:RINGTONE READY")
            break
        case 11:
            //print("DSP:AUX RINGTONE READY")
            dynamicToolMode = TuneDSPMode_Audio
            DSP_DUT_State.append("DSP:AUX RINGTONE READY")
            break
        case 12:
            //print("DSP:SCO READY")
            dynamicToolMode = TuneDSPMode_Voice
            DSP_DUT_State.append("DSP:SCO READY")
            break
        case 13:
            //print("DSP:SBC DECODE READY")
            dynamicToolMode = TuneDSPMode_Audio
            DSP_DUT_State.append("DSP:SBC DECODE READY")
            break
        case 14:
            //print("DSP:SBC ENCODE READY")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:SBC ENCODE READY")
            break
        case 15:
            //print("DSP:VOICE RECOGNITION READY")
            dynamicToolMode = TuneDSPMode_NotSupport
            DSP_DUT_State.append("DSP:VOICE RECOGNITION READY")
            break
        default:
            //print("DSP:Unknown")
            DSP_DUT_State.append("DSP:Unknown")
            break
        }
        
        DSP_DUT_State.append(" / ")
        
        switch(DUT_State){
        case 0:
            //print("DUT:OFF")
            DSP_DUT_State.append("DUT:OFF")
            break
        case 1:
            //print("DUT:STANDBY")
            DSP_DUT_State.append("DUT:STANDBY")
            break
        case 2:
            //print("DUT:PAIRING")
            DSP_DUT_State.append("DUT:PAIRING")
            break
        case 3:
            //print("DUT:PAGING")
            DSP_DUT_State.append("DUT:PAGING")
            break
        case 4:
            //print("DUT:ACTIVE")
            DSP_DUT_State.append("DUT:ACTIVE")
            break
        case 5:
            //print("DUT:SHUTDOWN")
            DSP_DUT_State.append("DUT:SHUTDOWN")
            break
        default:
            //print("DUT:Unknown")
            DSP_DUT_State.append("DUT:Unknown")
            break
        }
        
        //Debug Audio funtion
        //dynamicToolMode = TuneDSPMode_Audio
        
        //Debug Voice funtion
        //dynamicToolMode = TuneDSPMode_Voice
        
        if(Backup_DSP_State != dynamicToolMode){
            Backup_DSP_State = dynamicToolMode
        }
        
        print("\(DSP_DUT_State)")
        //self.DSPTuningDelegate?.DSPTuningState(state: DSP_DUT_State)
        
        let view = GetCurrentView()
        switch view{
        case 1:
            print("delegate")
            self.VoiceNR_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 2:
            print("delegate")
            self.VoiceFilter_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 3:
            print("delegate")
            self.VoiceMIC_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 4:
            print("delegate")
            self.VoiceAEC_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 5:
            print("delegate")
            self.VoiceEQ_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 6:
            print("delegate")
            self.AudioLineIn_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 7:
            print("delegate")
            self.AudioEffect_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 8:
            print("delegate")
            self.AudioEQ_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 9:
            print("delegate")
            self.HiddenAVC_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 10:
            print("delegate")
            self.HiddenDRC_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 11:
            print("delegate")
            self.HiddenBSS_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 12:
            print("delegate")
            self.HiddenSYS_Delegate?.DSPTuningState(state: DSP_DUT_State)
        case 13:
            print("delegate")
            self.HiddenMVDR_Delegate?.DSPTuningState(state: DSP_DUT_State)
        default:
            print("Error,Unknown state")
            self.DSPTuningDelegate?.DSPTuningState(state: DSP_DUT_State)
        }
    }
}

