//
//  ISRootViewController.h
//  AutoTest
//
//  Created by Rick on 13/12/18.
//  Copyright (c) 2013年 Rick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ISRootViewController : UIViewController

@end
