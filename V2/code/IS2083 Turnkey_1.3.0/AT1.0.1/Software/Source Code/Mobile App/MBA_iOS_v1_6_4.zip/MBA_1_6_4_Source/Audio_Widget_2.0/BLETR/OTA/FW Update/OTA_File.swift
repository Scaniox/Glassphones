//
//  OTA_File.swift
//  TestOTA
//
//  Created by TestPC on 29/03/2018.
//  Copyright © 2018 TestPC. All rights reserved.
//

import Foundation
import CommonCrypto

class OTA_File {
    
    class func dataWithHexString(hex: String) -> Data {
        var hex = hex
        var data = Data()
        while(hex.count > 0) {
            let subIndex = hex.index(hex.startIndex, offsetBy: 2)
            let c = String(hex[..<subIndex])
            hex = String(hex[subIndex...])
            var ch: UInt32 = 0
            Scanner(string: c).scanHexInt32(&ch)
            var char = UInt8(ch)
            data.append(&char, count: 1)
        }
        return data
        
        /*
         let data = dataWithHexString(hex: "68656c6c6f2c20776f726c64") // <68656c6c 6f2c2077 6f726c64>
         let string = String(data: data, encoding: .utf8) // "hello, world"
         */
    }
    
    class func EncryptNewFile(name:String) -> String{
        var filepath:String = ""
        var newfilepath:String = ""
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
            let txtFileNames = fileURLs.map{ $0.deletingPathExtension().lastPathComponent }
            //print("txt list:", txtFileNames)
            
            for i in 0..<txtFileNames.count {
                if(name == txtFileNames[i]) {
                    filepath = fileURLs[i].path
                    newfilepath = fileURLs[i].deletingPathExtension().path
                    print("OTAFilePath = \(filepath)")
                    print("NEW OTAFilePath = \(newfilepath)")
                    break
                }
            }
            
            let date = Date()
            let calendar = Calendar.current
            let hour = calendar.component(.hour, from: date)
            let minutes = calendar.component(.minute, from: date)
            newfilepath = newfilepath + "_" + String(hour) + String(minutes) + ".HEX"
            print("NEW OTAFilePath = \(newfilepath)")
            
            let data = fileManager.contents(atPath: filepath)
            //print("\(data! as NSData)")
            //let subdata = (data! as NSData).subdata(with: NSMakeRange(0, 64))
            //print("\(subdata as NSData)")
            //print("len = \(data!.count)")
            
            let encrypt_data = OTASecurity.cbc(withOperation: true, ivString: "00000000000000000000000000000000", andKey: "10a58869d74be5a374cf867cfb473859", andInput1: nil, andInput2: data!)
            
            print("encrypt_len = \(encrypt_data!.count)")
            //print("\(encrypt_data! as NSData)")
            
            let newfile = fileManager.createFile(atPath: newfilepath, contents: encrypt_data, attributes: nil)
            if(newfile) {
                print("Create new file")
                
                if(try? fileManager.removeItem(atPath: filepath)) != nil {
                    print("Delete file : success ")
                }
                else {
                    print("Delete file : fail")
                }
                
                //return (name + "_" + String(hour) + String(minutes) + ".HEX")
                return (name + "_" + String(hour) + String(minutes))
            }
            else {
                return ""
            }
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
            return ""
        }
    }
    
    class func EncryptFile(name:String) {
        var filepath:String = ""
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            // process files
            
            print("fileURLs = \(fileURLs)")
            
            for item in fileURLs {
                print("found \(item)")
            }
            
            let txtFiles = fileURLs.filter{ $0.pathExtension == "HEX" }
            //let txtFiles = fileURLs.filter{ $0.pathExtension == "hex" }
            print("txtFiles = \(txtFiles)")
            
            //if(txtFiles.count == 1) {
            //    filepath = txtFiles[0].path
            //    print("filepath = \(filepath)")
            //}
            
            let txtFileNames = txtFiles.map{ $0.deletingPathExtension().lastPathComponent }
            print("txt list:", txtFileNames)
            
            for i in 0..<txtFileNames.count {
                if(name == txtFileNames[i]) {
                    filepath = txtFiles[i].path
                    print("OTAFilePath = \(filepath)")
                    break
                }
            }
            
            let data = fileManager.contents(atPath: filepath)
            //print("\(data! as NSData)")
            //let subdata = (data! as NSData).subdata(with: NSMakeRange(0, 64))
            //print("\(subdata as NSData)")
            //print("len = \(data!.count)")
            
            let encrypt_data = OTASecurity.cbc(withOperation: true, ivString: "00000000000000000000000000000000", andKey: "10a58869d74be5a374cf867cfb473859", andInput1: nil, andInput2: data!)
            
            //print("\(encrypt_data! as NSData)")
            print("encrypt_len = \(encrypt_data!.count)")
            
            do{
                try fileManager.removeItem(atPath: filepath)
                
                print("Delete file")
                sleep(1)
                
                let newfile = fileManager.createFile(atPath: filepath, contents: encrypt_data, attributes: nil)
                if(newfile) {
                    print("Create new file")
                }
            }
            catch {
                print("Can't create new file")
            }
            //let fileURL = documentsURL.appendingPathComponent("STACK_TEST_DEBUG_Rehex_10A6.HEX")
            //print("fileURL.path = \(fileURL.path)")
            //reading
            //do {
            //    let text2 = try String(contentsOf: fileURL, encoding: .utf8)
            //    print("text2 = \(text2)")
            //}
            //catch {/* error handling here */}
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
        }
    }
    
    class func CheckHexFormat(name:String) -> Bool{
        var filepath:String = ""
        
        print("CheckHexFormat...")
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
            let txtFiles = fileURLs.filter{ $0.pathExtension == "HEX" }
            
            print("txtFiles = \(txtFiles)")
            
            let txtFileNames = txtFiles.map{ $0.deletingPathExtension().lastPathComponent }
            print("txt list:", txtFileNames)
            
            if(txtFileNames.count == 0) {
                return false
            }
            
            for i in 0..<txtFileNames.count {
                if(name == txtFileNames[i]) {
                    filepath = txtFiles[i].path
                    print("OTAFilePath = \(filepath)")
                    break
                }
            }
            
            let data = fileManager.contents(atPath: filepath)
            //print("\(data! as NSData)")
            let subdata = (data! as NSData).subdata(with: NSMakeRange(0, 17))
            print("First 17 bytes = \(subdata as NSData)")  //:020000040000FA
            print("len = \(data!.count)")
            
            let bytes = [UInt8](subdata)
            //print("byte 0 = \(bytes[0])")
            
            if((bytes[0] == 58) && (bytes[15] == 13) && (bytes[16] == 10)) {
                print("hex format : correct")
                
                let hex_string = NSString(data: subdata.subdata(in: 1..<15) , encoding: String.Encoding.ascii.rawValue)
                let hex_data = dataWithHexString(hex: hex_string! as String)
                print("hex_data = \(hex_data as NSData)")
                
                let bytes : NSData = hex_data as NSData
                var buf = [UInt8](repeating:0, count:bytes.length)
                bytes.getBytes(&buf, length: bytes.length)
                
                var checksum : UInt16 = 0
                for index in 0..<bytes.length {
                    checksum += UInt16(buf[index])
                }
                
                if(checksum == 0x100) {
                    return true
                }
                else {
                    print("hex file : invalid format")
                    return false
                }
                //return nil
            }
            else {
                return false
            }
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
            return false
        }
    }
    
    class func DecryptFile(name:String) -> Data? {
        
        var filepath:String = ""
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
            let txtFiles = fileURLs.filter{ $0.pathExtension == "HEX" }
            //let txtFiles = fileURLs.filter{ $0.pathExtension == "hex" }
            print("txtFiles = \(txtFiles)")
            
            let txtFileNames = txtFiles.map{ $0.deletingPathExtension().lastPathComponent }
            print("txt list:", txtFileNames)
            
            for i in 0..<txtFileNames.count {
                if(name == txtFileNames[i]) {
                    filepath = txtFiles[i].path
                    print("OTAFilePath = \(filepath)")
                    break
                }
            }
            
            let data = fileManager.contents(atPath: filepath)
            //print("\(data! as NSData)")
            let subdata = (data! as NSData).subdata(with: NSMakeRange(0, 16))
            print("First 16 bytes = \(subdata as NSData)")
            print("len = \(data!.count)")
            
            let bytes = [UInt8](subdata)
            //print("byte 0 = \(bytes[0])")
            
            let otadefault = UserDefaults.standard.integer(forKey: "SecuringOTA")
            
            //if((bytes[0] != 58) && (otadefault == 2)) { // ':' = 0x3a = 58
            if((bytes[0] != 58) && (otadefault == ViewController.OTA_Encrypted.Disable.rawValue)) { // ':' = 0x3a = 58
                print("NO_ENC_Data errorXXX")
                return nil
            }
            
            //if((bytes[0] == 58) && (otadefault == 1)) {
            if((bytes[0] == 58) && (otadefault == ViewController.OTA_Encrypted.Enable.rawValue)) {
                print("ENC_Data errorXXX")
                return nil
            }
            
            //if(otadefault == 1) {
            if(otadefault == ViewController.OTA_Encrypted.Enable.rawValue) {
                
                print("[OTA_File]Decrypt...")
                
                let decrypt_data = OTASecurity.cbc(withOperation: false, ivString: "00000000000000000000000000000000", andKey: "10a58869d74be5a374cf867cfb473859", andInput1: nil, andInput2: data!)
                
                let dd1 = (decrypt_data! as NSData).subdata(with: NSMakeRange(0, 16))
                print(" **First 16 bytes = \(dd1 as NSData)")
                
                //print("\(decrypt_data! as NSData)")
                print("decrypt_len = \(decrypt_data!.count)")
                
                return decrypt_data
            }
            else {
                return data
            }
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
            
            return nil
        }
    }
    
    
    //class func Load_OTA_UI(name:String) -> (NSData?) {
    class func Load_OTA_UI(name:String) -> (NSData?, UInt16) {
        print("Load_OTA_UI: " + name)
        
        var i:Int = 0
        var index:Int = 0
        var LineNum = 0
        var EndOfFile = false
        var filePos:Int = 0
        var BankfirstLine:Int = 0
        
        var ui_checksum:UInt16 = 0
        
        var Data_error:Bool = false
        
        //var FWImageStart:Bool = false
        var Flash_Header_Exist:Bool = true
        
        let LINE_END_d = 0x0d
        let LINE_END_a = 0x0a
        
        var c : UInt8 = 0
        var line = [UInt8](repeating:0, count:100)
        var lineEnd = [UInt8](repeating:0, count:2)
        
        let HEX_TYPE_ELA = 0x04
        let HEX_TYPE_DATA = 0x00
        
        var hexdata:NSMutableData = NSMutableData()
        var bindata:NSMutableData = NSMutableData()
        
        //let nil_data = Data(bytes:[0xff,0xff,0xff,0xff])
        let nil_data = Data(bytes:[0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff])
        
        var user_config:NSData = NSData()
        
        //MCU code : 0x10000 ~ 0x90000
        let mcu_bank_start = Data(bytes:[0x00,0x01])
        
        var len:UInt8 = 0
        
        var filepath:String = ""
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
            let txtFiles = fileURLs.filter{ $0.pathExtension == "HEX" }
            print("txtFiles = \(txtFiles)")
            
            let txtFileNames = txtFiles.map{ $0.deletingPathExtension().lastPathComponent }
            print("txt list:", txtFileNames)
            
            for i in 0..<txtFileNames.count {
                if(name == txtFileNames[i]) {
                    filepath = txtFiles[i].path
                    print("OTAFilePath = \(filepath)")
                    break
                }
            }
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
            return (nil, 0x00)
        }
        
        if(filepath == ""){
            return (nil, 0x00)
        }
        
        let file_data = fileManager.contents(atPath: filepath)
        
        let bytes : NSData = file_data! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        
        while(index < bytes.length) {
            i = 0
            c = 0
            lineEnd[0] = 0
            lineEnd[1] = 0
            
            while true {
                c = buf[index]
                index += 1
                
                if(c != LINE_END_d) {
                    if((c != LINE_END_a) && (lineEnd[0] != LINE_END_d)) {
                        line[i] = c
                        i += 1
                    }
                    else if((lineEnd[0] == LINE_END_d) && (c == LINE_END_a)) {
                        lineEnd[1] = c;
                        line[i] = c
                        i += 1
                    }
                    
                    if ((lineEnd[0] == LINE_END_d) && (lineEnd[1] == LINE_END_a)) {
                        line[i] = 0
                        //print("count = \(i)")
                        filePos += i
                        break
                    }
                }
                else {
                    lineEnd[0] = c;
                    line[i] = c
                    i += 1
                }
            }
            
            if((line[0] == 0x3a) && (EndOfFile == false)) {
                for index in 1..<i {
                    hexdata.append(&line[index], length: 1)
                }
                
                let ss = NSString(data: (hexdata.copy() as! NSData) as Data , encoding : String.Encoding.ascii.rawValue)
                //print("ss = \(ss!), len = \(ss!.length)")
                let str = (ss?.substring(with: NSMakeRange(0, ss!.length-2)))! as String    //Remove "\r\n"
                //print("str = \(str)")
                
                let data = dataWithHexString(hex: str)
                //print("Hexdat = \(data as NSData)")
                
                if(LineNum < 10){
                    print("Line = \(LineNum+1) , Hexdata = \(data as NSData) , len = \(data.count)")
                }
                else {
                    //EndOfFile = true
                }
                
                //LineNum += 1
                
                line = [UInt8](repeating:0, count:100)
                
                hexdata = NSMutableData()
                
                //Get data
                var byteBuffer = [UInt8](repeating:0 , count:data.count)
                (data as NSData).getBytes(&byteBuffer, length: data.count)
                
                if((byteBuffer[3] == HEX_TYPE_ELA) && (data.count == 7)) {
                    let ff = (data as NSData).subdata(with: NSMakeRange(4, 2))
                    print("Line = \(LineNum+1),(HEX_TYPE_ELA) Address = \(ff as NSData)")
                    
                    let dat:NSData = ff as NSData
                    
                    if(dat.isEqual(to: mcu_bank_start)) {
                        
                        //Get checksum
                        print("Get checksum")
                        var blockInfo = [UInt8](repeating:0, count:bindata.length)
                        bindata.getBytes(&blockInfo, length: bindata.length)
                        
                        var k:Int = 0
                        var length:Int = 0
                        
                        print("==================================")
                        print("Parsing...Flash header")
                        while(k < bindata.length) {
                            if((blockInfo[k] == 0x90) || (blockInfo[k] == 0x91) || (blockInfo[k] == 0xd0) || (blockInfo[k] == 0x92))
                            {
                                //print("ID:Voice_Prompt_FD")
                                if(blockInfo[k] == 0x90) {
                                    print("ID:DSP_Image_Destination")
                                }
                                else if(blockInfo[k] == 0x91) {
                                    print("ID:DSP_Image_FD")
                                }
                                else if(blockInfo[k] == 0xd0) {
                                    print("ID:Voice_Prompt_FD")
                                }
                                else {
                                    print("ID:DSP_Image_Version_4_bytes")   //DSP Version : 00900002
                                }
                                
                                length = Int(blockInfo[k+1])
                                let dd = bindata.subdata(with: NSMakeRange(k, length+2))
                                print("offset = \(k),data = \(dd as NSData)")  //Debug
                                
                                k += (length+2)
                                
                                //FlashHeader.append(dd)
                            }
                            else{
                                if((blockInfo[k] == 0x81) && (blockInfo[k+1] == 0x04)){
                                    print("Flash Header : END")
                                    let gg = bindata.subdata(with: NSMakeRange(k+2, 4))
                                    //print("str = \(str as NSData)")
                                    let str_end = String(decoding: gg, as: UTF8.self)
                                    print("str_end = \(str_end)")
                                    if(str_end == "#END"){
                                        (_, _, _, ui_checksum) = GetExtraInformation(data: blockInfo, offset: k+6, bindata: bindata)
                                        k = bindata.length
                                        
                                        if(ui_checksum == 0){
                                            index = bytes.length
                                            Data_error = true
                                        }
                                    }
                                }
                                else {
                                    k += 1
                                }
                            }
                        }
                        
                        //Check config data. Start address = 0x6000, length = 4k or 8k
                        let config_dat_start4k = bindata.subdata(with: NSMakeRange(0x6000, 16))
                        print("config_dat_4k_start = \(config_dat_start4k as NSData)")
                        let config_dat_start4k_end = bindata.subdata(with: NSMakeRange(0x7000, 16))
                        print("config_dat_4k_end = \(config_dat_start4k_end as NSData)")
                        let config_dat_start8k_end = bindata.subdata(with: NSMakeRange(0x8000, 16))
                        print("config_dat_8k_start = \(config_dat_start8k_end as NSData)")
                        
                        if(config_dat_start4k == nil_data){
                            bindata.setData(Data())
                            Flash_Header_Exist = false
                        }
                        else{
                            if(config_dat_start4k_end == nil_data){
                                print("Config data length = 4k")
                                user_config = bindata.subdata(with: NSMakeRange(0x6000, 0x1000)) as NSData
                            }
                            else if(config_dat_start8k_end == nil_data){
                                print("Config data length = 8k")
                                user_config = bindata.subdata(with: NSMakeRange(0x6000, 0x2000)) as NSData
                            }
                        }
                        
                        index = bytes.length
                    }
                    
                    BankfirstLine = LineNum + 2
                    print("BankfirstLine = \(BankfirstLine)")
                    //Prev_Offset = 0
                }
                else if(byteBuffer[3] == HEX_TYPE_DATA) {
                    len = byteBuffer[0]
                    
                    if(Flash_Header_Exist){
                        bindata.append((data as NSData).subdata(with: NSMakeRange(4, Int(len))))
                    }
                    
                    //let Address:UInt = (UInt(byteBuffer[1]) << 8) + UInt(byteBuffer[2])
                    //print("Address = \(Address)")
                    
                    if((LineNum == 1) || ((LineNum+1) == BankfirstLine)) {
                        let gg = (data as NSData).subdata(with: NSMakeRange(4, Int(len)))
                        print("**Line = \(LineNum+1),Data len = \(len) , bindata = \(gg as NSData)")
                        print("Start Address = \((byteBuffer[1] << 8)+byteBuffer[2])")
                    }
                }
                
                LineNum += 1
            }
            else {
                print("Hex:Invalid data format")
                EndOfFile = true
            }
        }
        
        if((user_config.length == 0) || (ui_checksum == 0) || (Data_error == true)) {
            return (nil, 0x00)
        }
        else{
            print("user_config = \(user_config)")
            return (user_config, ui_checksum)
        }
    }
    
    class func Load_OTA_DSP(name:String) -> (NSData?, NSData?, String?, UInt16) {
        print("Load_OTA_DSP&Voice prompt: " + name)
        let LINE_END_d = 0x0d
        let LINE_END_a = 0x0a
        
        var c : UInt8 = 0
        var line = [UInt8](repeating:0, count:100)
        var lineEnd = [UInt8](repeating:0, count:2)
        
        let HEX_TYPE_ELA = 0x04
        let HEX_TYPE_DATA = 0x00
        
        var len:UInt8 = 0
        
        var onelinestring:NSMutableData = NSMutableData()
        var bindata:NSMutableData = NSMutableData()
        var FlashHeader:NSMutableData = NSMutableData()
        var VP_data:NSMutableData = NSMutableData()
        
        var UpdateVersion:String?
        var dsp_checksum:UInt16 = 0
        
        #if Debug
            var filepath:String = ""
        
            let fileManager = FileManager.default
            let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
            do {
                let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
                let txtFiles = fileURLs.filter{ $0.pathExtension == "HEX" }
                print("txtFiles = \(txtFiles)")
            
                let txtFileNames = txtFiles.map{ $0.deletingPathExtension().lastPathComponent }
                print("txt list:", txtFileNames)
            
                for i in 0..<txtFileNames.count {
                    if(name == txtFileNames[i]) {
                        filepath = txtFiles[i].path
                        print("OTAFilePath = \(filepath)")
                        break
                    }
                }
            } catch {
                print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
                return (nil, nil, nil, 0x00)
            }
        
            if(filepath == ""){
                return (nil, nil, nil, 0x00)
            }
        
            let decrypt_data = fileManager.contents(atPath: filepath)
        #else
            //Decrypt the encrypted hex file
            let decrypt_data = DecryptFile(name:name)
        #endif
        
        if(decrypt_data == nil) {
            return (nil,nil,nil,0x00)
        }
        
        let bytes : NSData = decrypt_data! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        
        print("\(bytes.length)")
        
        var i:Int = 0
        var index:Int = 0
        var LineNum = 0
        var EndOfFile = false
        var filePos:Int = 0
        var BankfirstLine:Int = 0
        
        var Flash_Header_Exist:Bool = false
        var DSP_Data_Exist:Bool = false
        var VP_Data_Exist:Bool = false
        var VPImageStart:Bool = false
        var DSP_Data_error:Bool = false
        
        var dsp_bank_number : UInt8 = 0
        var dsp_bank_number_end : UInt8 = 0
        var vp_bank_number_start : UInt8 = 0
        var vp_bank_number_end : UInt8 = 0
        var current_bank_number : UInt8 = 0
        
        var VP_length : UInt = 0
        
        let header_bank = Data(bytes:[0x00,0x00])
        
        //Read one Line  :100000000080040000030E9008000030000200028F
        while(index < bytes.length) {
            i = 0
            c = 0
            lineEnd[0] = 0
            lineEnd[1] = 0
            
            while true {
                c = buf[index]
                index += 1
                
                if(c != LINE_END_d) {
                    if((c != LINE_END_a) && (lineEnd[0] != LINE_END_d)) {
                        line[i] = c
                        i += 1
                    }
                    else if((lineEnd[0] == LINE_END_d) && (c == LINE_END_a)) {
                        lineEnd[1] = c;
                        line[i] = c
                        i += 1
                    }
                    
                    if ((lineEnd[0] == LINE_END_d) && (lineEnd[1] == LINE_END_a)) {
                        line[i] = 0
                        filePos += i
                        break
                    }
                }
                else {
                    lineEnd[0] = c;
                    line[i] = c
                    i += 1
                }
            }
            
            if((line[0] == 0x3a) && (EndOfFile == false)) {
                for index in 1..<i {
                    onelinestring.append(&line[index], length: 1)
                }
                
                let ss = NSString(data: (onelinestring.copy() as! NSData) as Data , encoding : String.Encoding.ascii.rawValue)
                //print("ss = \(ss!), len = \(ss!.length)")
                let str = (ss?.substring(with: NSMakeRange(0, ss!.length-2)))! as String    //Remove "\r\n"
                //print("str = \(str)")
                
                let data = dataWithHexString(hex: str)  //Convert Hex string to Hex data
                //print("Hexdat = \(data as NSData)")
                
                if(LineNum < 10){
                    print("Hex file Line number= \(LineNum+1) , Hexdata = \(data as NSData) , len = \(data.count)")
                }
                else {
                    //EndOfFile = true
                }
                
                line = [UInt8](repeating:0, count:100)
                
                onelinestring = NSMutableData()
                
                //Get data
                var byteBuffer = [UInt8](repeating:0 , count:data.count)
                (data as NSData).getBytes(&byteBuffer, length: data.count)
                
                if((byteBuffer[3] == HEX_TYPE_ELA) && (data.count == 7)) {  //Record type = Address (:020000040015E5)
                    let hex_addr = (data as NSData).subdata(with: NSMakeRange(4, 2))
                    print("Hex file Line number= \(LineNum+1),(HEX_TYPE_ELA) Address = \(hex_addr as NSData)")
                    
                    (((hex_addr as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&current_bank_number, length: MemoryLayout<UInt8>.size)
                    print("Current bank num = \(current_bank_number)")
                    
                    print("DSP_DAT len = \(bindata.length)")
                    print("VP_DAT len = \(VP_data.length)")
                    
                    if((current_bank_number != 0) && (dsp_bank_number != 0)){
                        if(current_bank_number == (dsp_bank_number+1)){
                            print("[Check first block of DSP code]DSP_DAT len = \(bindata.length)")
                            if(bindata.length != 0){
                                if(bindata.length < 65536){
                                    print("DSP data error XXX")
                                    DSP_Data_error = true
                                    index = bytes.length
                                }
                            }
                        }
                    }
                    
                    if((current_bank_number != 0) && (dsp_bank_number_end != 0)){
                        if((current_bank_number > dsp_bank_number_end) && (vp_bank_number_start == 0)){
                            print("[DSP only]DSP data : END")
                            index = bytes.length
                        }
                    }
                    
                    if((current_bank_number != 0) && (vp_bank_number_end != 0)){
                        if(current_bank_number > vp_bank_number_end){
                            if((bindata.length != 0) && (VP_data.length != 0)) {
                                print("Read OTA file..End")
                                index = bytes.length
                            }
                        }
                    }
                    
                    let dat:NSData = hex_addr as NSData
                    
                    if(!(dat.isEqual(to: header_bank))) {
                        if(!Flash_Header_Exist){
                            Flash_Header_Exist = true
                        }
                    }
                    
                    if(Flash_Header_Exist && (!DSP_Data_Exist) && (!VP_Data_Exist)) {
                        print("Read Flash header, len = \(bindata.length)")
                        
                        var blockInfo = [UInt8](repeating:0, count:bindata.length)
                        bindata.getBytes(&blockInfo, length: bindata.length)
                        
                        //print("binData len = \(bindata.length)")
                        //print("==================================")
                        //print("\(bindata)")
                        //print("==================================")
                        
                        var k:Int = 0
                        var length:Int = 0
                        
                        print("==================================")
                        print("[DSP_Voice prompt] flash header")
                        while(k < bindata.length) {
                            
                            if((blockInfo[k] == 0x90) || (blockInfo[k] == 0x91) || (blockInfo[k] == 0xd0) || (blockInfo[k] == 0x92)) {
                                if(blockInfo[k] == 0x90) {
                                    if(blockInfo[k+1] == 0x08){
                                        print("ID:DSP_Image_Destination")
                                    }
                                    else{
                                        DSP_Data_error = true
                                        index = bytes.length
                                    }
                                }
                                else if(blockInfo[k] == 0x91) {
                                    print("ID:DSP_Image_FD")
                                    DSP_Data_Exist = true
                                }
                                else if(blockInfo[k] == 0xd0) {
                                    if(DSP_Data_Exist){
                                        print("ID:Voice_Prompt_FD")
                                        VP_Data_Exist = true
                                    }
                                }
                                else {
                                    print("ID:DSP_Image_Version_4_bytes")   //DSP Version : 00900002
                                }
                                
                                length = Int(blockInfo[k+1])
                                let dd = bindata.subdata(with: NSMakeRange(k, length+2))
                                print("offset = \(k),data = \(dd as NSData)")  //Debug
                                
                                //if((dsp_bank.count == 0) && (blockInfo[k] == 0x91)){
                                //if((dsp_bank_number == 0) && (blockInfo[k] == 0x91)){
                                if((blockInfo[k] == 0x91)){
                                    let dsp_bank_info = (dd as NSData).subdata(with: NSMakeRange(12, 2))
                                    //print("dsp_bank = \(dsp_bank_info as NSData)")
                                    //(((dsp_bank_info as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&dsp_bank_number, length: MemoryLayout<UInt8>.size)
                                    //print("dsp bank num start= \(dsp_bank_number)") //:020000040011E9,dsp_bank_number = 0x11 = 17
                                    
                                    var number_dsp:UInt8 = 0
                                    (((dsp_bank_info as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&number_dsp, length: MemoryLayout<UInt8>.size)
                                    
                                    if(dsp_bank_number == 0){
                                        dsp_bank_number = number_dsp
                                    }
                                    else{
                                        if(number_dsp > dsp_bank_number) {
                                            dsp_bank_number_end = number_dsp
                                        }
                                    }
                                }
                                else if(blockInfo[k] == 0xd0){
                                    if(DSP_Data_Exist){
                                        print("DSP_Image_FD is found = true")
                                    
                                        VP_length = UInt(blockInfo[k+5]) * 256 + UInt(blockInfo[k+6]) + UInt(blockInfo[k+4]) * 65536
                                        print("VP_length = \(VP_length)")
                                    
                                        let voice_prompt_bank_info = (dd as NSData).subdata(with: NSMakeRange(12, 2))
                                        //print("** voice_prompt_bank = \(voice_prompt_bank_info as NSData)")
                                        var number:UInt8 = 0
                                        (((voice_prompt_bank_info as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&number, length: MemoryLayout<UInt8>.size)
                                        if(vp_bank_number_start == 0){
                                            vp_bank_number_start = number
                                        }
                                        else {
                                            if(number > vp_bank_number_start) {
                                                vp_bank_number_end = number
                                            }
                                        }
                                    }
                                    else{
                                        print("DSP_Image_FD is found = false")
                                        DSP_Data_error = true
                                        index = bytes.length
                                    }
                                }
                                else if((blockInfo[k] == 0x92) && (blockInfo[k+1] == 4)){
                                    let ver = bindata.subdata(with: NSMakeRange(k+2, 4))
                                    print("DSP Version = \(ver as NSData)")
                                    UpdateVersion = ver.hexEncodedString()
                                }
                                
                                k += (length+2)
                                
                                FlashHeader.append(dd)
                            }
                            else {
                                if((blockInfo[k] == 0x81) && (blockInfo[k+1] == 0x04)){
                                    print("Flash Header : END")
                                    let gg = bindata.subdata(with: NSMakeRange(k+2, 4))
                                    //print("str = \(str as NSData)")
                                    let str_end = String(decoding: gg, as: UTF8.self)
                                    print("str_end = \(str_end)")
                                    if(str_end == "#END"){
                                        (_, _, dsp_checksum, _) = GetExtraInformation(data: blockInfo, offset: k+6, bindata: bindata)
                                        k = bindata.length
                                        
                                        if(dsp_checksum == 0){
                                            index = bytes.length
                                            DSP_Data_error = true
                                        }
                                    }
                                }
                                else{
                                    
                                    if(blockInfo[k] == 0x80 && blockInfo[k+1] == 0x04){
                                        print("Flash header start:0x80")
                                        k += (Int(blockInfo[k+1]) + 2)
                                        print("offset = \(k)")
                                    }
                                    if(blockInfo[k] == 0x82 && blockInfo[k+1] == 0x04){
                                        print("8051 FW:0x82")
                                        k += (Int(blockInfo[k+1]) + 2)
                                        print("offset = \(k)")
                                    }
                                    if(blockInfo[k] == 0x83){
                                        print("8051 FW file descriptor:0x83")
                                        k += (Int(blockInfo[k+1]) + 2)
                                        print("offset = \(k)")
                                    }
                                    else{
                                        k += 1
                                    }
                                    
                                    //k += 1
                                }
                                
                                /*
                                if((blockInfo[k] == 0x81) && (blockInfo[k+1] == 0x04) && (blockInfo[k+2] == 0x23)){
                                    if((blockInfo[k+3] == 0x45) && (blockInfo[k+4] == 0x4E) && (blockInfo[k+5] == 0x44)){
                                        print("Flash Header : END")
                                        k += 6
                                    }
                                }
                                else{
                                    k += 1
                                }*/
                            }
                        }
                        
                        //if(vp_bank_number_end == 0) {
                        if(vp_bank_number_end == 0 && VP_length <= 65536) {
                            vp_bank_number_end = vp_bank_number_start
                        }
                        else if(vp_bank_number_end == 0 && VP_length > 65536){
                            let calc_bank: UInt = VP_length / 65536
                            print("calc_bank = \(calc_bank)")
                            vp_bank_number_end  = vp_bank_number_start + UInt8(calc_bank)
                            //print("vp bank num end = \(vp_bank_number_end)")
                        }
                        print("dsp bank num start= \(dsp_bank_number)")         //:020000040011E9,dsp_bank_number = 0x11 = 17
                        print("vp bank num start = \(vp_bank_number_start)")    //:020000040015E5,vp_bank_number_start = 0x15 = 21
                        print("vp bank num end = \(vp_bank_number_end)")
                        
                        bindata.setData(Data())
                        
                        if(VP_Data_Exist && DSP_Data_Exist){
                            print("OTA data = DSP + Voice prompt")
                            VPImageStart = false
                        }
                        else if(DSP_Data_Exist && (!VP_Data_Exist)){
                            print("OTA data : DSP only")
                            
                            print("dsp bank num start= \(dsp_bank_number)")
                            print("dsp bank num end= \(dsp_bank_number_end)")
                            VPImageStart = false
                        }
                        else if((!DSP_Data_Exist) && VP_Data_Exist){
                            print("OTA data : Voice prompt only")
                            VPImageStart = true
                        }
                        
                        print("==================================")
                    }
                    else{
                        if(VP_Data_Exist && DSP_Data_Exist){
                            if(current_bank_number != 0){
                                if(current_bank_number == dsp_bank_number){
                                    print("DSP data : START")
                                    VPImageStart = false
                                }
                                else if(current_bank_number == vp_bank_number_start){
                                    print("Voice data: START")
                                    VPImageStart = true
                                }
                            }
                        }
                        else{
                            if(VPImageStart){
                                if(current_bank_number != 0){
                                    if(current_bank_number == vp_bank_number_start){
                                        print(" Voice data : START")
                                    }
                                }
                            }
                            else{
                                if(current_bank_number != 0){
                                    if(current_bank_number == dsp_bank_number){
                                        print(" DSP data : START")
                                    }
                                }
                            }
                        }
                    }
                    
                    BankfirstLine = LineNum + 2
                    //Debug
                    print("firstLineNumber = \(BankfirstLine)")
                    
                }
                else if(byteBuffer[3] == HEX_TYPE_DATA) {   //Record type = Data (:100000000080040000030E9008000030000200028F)
                    len = byteBuffer[0]
                    if(VPImageStart) {
                        if((current_bank_number >= vp_bank_number_start) && (current_bank_number <= vp_bank_number_end)){
                            //VP data
                            VP_data.append((data as NSData).subdata(with: NSMakeRange(4, Int(len))))
                        }
                    }
                    else{
                        if(current_bank_number != 0){
                            if(vp_bank_number_start != 0){
                                if((current_bank_number >= dsp_bank_number) && (current_bank_number < vp_bank_number_start)){
                                    //DSP data
                                    bindata.append((data as NSData).subdata(with: NSMakeRange(4, Int(len))))
                                }
                            }
                            else{
                                //DSP data only
                                if(current_bank_number >= dsp_bank_number){
                                    bindata.append((data as NSData).subdata(with: NSMakeRange(4, Int(len))))
                                }
                            }
                        }
                        else if(current_bank_number == 0) {
                            //Flash header
                            bindata.append((data as NSData).subdata(with: NSMakeRange(4, Int(len))))
                        }
                    }
                    
                    //Debug
                    if((LineNum == 1) || ((LineNum+1) == BankfirstLine)) {
                        let gg = (data as NSData).subdata(with: NSMakeRange(4, Int(len)))
                        print("Hex file Line number= \(LineNum+1),Data len = \(len) , bindata = \(gg as NSData)")
                        print("Start Address = \((byteBuffer[1] << 8)+byteBuffer[2])")
                    }
                }
                LineNum += 1
            }
            else {
                print("Hex:Invalid data format")
                EndOfFile = true
            }
        }
        print("HexLineNum = \(LineNum)")//Debug
        
        print("Block info len = \(FlashHeader.length)")
        print("\(FlashHeader as NSData)")
        print("DSP len = \(bindata.length)")
        //print("\(bindata as NSData)")
        print("Voice bank len = \(VP_data.length), data len = \(VP_length)")
        //print("\(VP_data as NSData)")
        
        if((DSP_Data_error) || (dsp_checksum == 0)){
            return(nil, nil, nil, 0x00)
        }
        
        if(VP_Data_Exist){
            if(VP_data.length < VP_length){
                print("Voice data error XXX")
                return(nil, nil, nil, 0x00)
            }
            else{
                print("Voice data length = \(VP_data.length),\(VP_length)")
            }
        }
        
        if((VP_data.length != 0) && (bindata.length != 0)){
            var total_dsp_size:Int = 0
            //DSP Size = (VP Data bank number - DSP bank number) * 64K
            //bank size = 0x0000 ~ 0xFFFF = 64K
            total_dsp_size = (Int)(vp_bank_number_start - dsp_bank_number) * 64 * 1024
            print("total_dsp_size = \(total_dsp_size)")
            
            if(total_dsp_size > bindata.length){
                let padding_len = total_dsp_size - bindata.length
                for _ in 0..<padding_len {
                    bindata.append(Data(bytes:[0xff]))
                }
                print("Fill unused space with 0xff, DSP data len = \(bindata.length)")
            }
            
            //let voice_data = VP_data.subdata(with: NSMakeRange(0, Int(VP_length)))
            
            if((VP_length % 16) != 0){
                let voice_size = ((VP_length/16)+1) * 16
                print("Voice data alignment issue,\(voice_size-VP_length)")
                print("adjust voice data length = \(voice_size)")
                let voice_data = VP_data.subdata(with: NSMakeRange(0, Int(voice_size)))
                bindata.append(voice_data)
                //print("voice data = \(voice_data as NSData)")
            }
            else{
                let voice_data = VP_data.subdata(with: NSMakeRange(0, Int(VP_length)))
                bindata.append(voice_data)
            }
            //bindata.append(VP_data as Data)
            
            print("OTA(DSP + Voice) data len = \(bindata.length)")
        }
        
        if(!DSP_Data_Exist && (VP_Data_Exist)){
            return(FlashHeader, VP_data, nil, dsp_checksum)
        }
        else{
            return(FlashHeader, bindata, UpdateVersion, dsp_checksum)
        }
    }
    
    class func Load_OTA_MCU(name:String) -> (NSData? , String? , UInt16, UInt16, UInt16) {
        print("Load_OTA_MCU = \(name)")
        let LINE_END_d = 0x0d
        let LINE_END_a = 0x0a
        
        var c : UInt8 = 0
        var line = [UInt8](repeating:0, count:100)
        var lineEnd = [UInt8](repeating:0, count:2)
        
        let HEX_TYPE_ELA = 0x04
        let HEX_TYPE_DATA = 0x00
        
        var len:UInt8 = 0
        
        var hexdata:NSMutableData = NSMutableData()
        var bindata:NSMutableData = NSMutableData()
        
        var Flash_Header_Exist:Bool = true
        //let header_bank = Data(bytes:[0x00,0x00])
        
        var mcu_ver_string:String = ""
        var mcu_checksum:UInt16 = 0
        var dsp_checksum:UInt16 = 0
        var ui_checksum:UInt16 = 0
        
        var current_bank_number : UInt8 = 0
        
        var Data_error:Bool = false
        
        #if Debug
            var filepath:String = ""
        
            //let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) as NSArray
            //let documentsDir = paths.firstObject as! String
            //print("Path to the Documents directory\n\(documentsDir)")
        
            let fileManager = FileManager.default
            let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
            do {
                let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
                let txtFiles = fileURLs.filter{ $0.pathExtension == "HEX" }
                print("txtFiles = \(txtFiles)")
            
                let txtFileNames = txtFiles.map{ $0.deletingPathExtension().lastPathComponent }
                print("txt list:", txtFileNames)
            
                for i in 0..<txtFileNames.count {
                    if(name == txtFileNames[i]) {
                        filepath = txtFiles[i].path
                        print("OTAFilePath = \(filepath)")
                        break
                    }
                }
            } catch {
                print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
                return (nil, nil, 0, 0, 0)
            }
        
            if(filepath == ""){
                return (nil, nil, 0, 0, 0)
            }
        
            let decrypt_data = fileManager.contents(atPath: filepath)
            //let str1 = filepath as NSString
            //print("LoadOTAFile = \(str1)")
            //let fp = fopen(str1.cString(using: 1) , "r")
        #else
            let decrypt_data = DecryptFile(name:name)
        #endif
        
        if(decrypt_data == nil) {
            return (nil, nil, 0, 0, 0)
        }
        
        let bytes : NSData = decrypt_data! as NSData
        var buf = [UInt8](repeating:0, count:bytes.length)
        bytes.getBytes(&buf, length: bytes.length)
        
        print("\(bytes.length)")
        
        var i:Int = 0
        var index:Int = 0
        var LineNum = 0
        var EndOfFile = false
        var filePos:Int = 0
        var BankfirstLine:Int = 0
        var Offset:Int = 0
        var Prev_Offset:Int = 0
        var FWImageStart:Bool = false
        /*
        var Test : NSMutableData = NSMutableData()
        var dd = 0x00
        Test.append(&dd, length: 1)
        dd = 0x01
        Test.append(&dd, length: 1)
        print("Test = \(Test)")
         */
        
        //MCU code : 0x10000 ~ 0x90000
        let mcu_bank_start = Data(bytes:[0x00,0x01])
        let mcu_bank_stop = Data(bytes:[0x00,0x09])
        
        //while(!EndOfFile) {
        while(index < bytes.length) {
            i = 0
            c = 0
            lineEnd[0] = 0
            lineEnd[1] = 0
            
            //if(index >= bytes.length) {
            //    break;
            //}
            
            //Read one Line
            while true {
                c = buf[index]
                index += 1
                
                if(c != LINE_END_d) {
                    if((c != LINE_END_a) && (lineEnd[0] != LINE_END_d)) {
                        line[i] = c
                        i += 1
                    }
                    else if((lineEnd[0] == LINE_END_d) && (c == LINE_END_a)) {
                        lineEnd[1] = c;
                        line[i] = c
                        i += 1
                    }
                    
                    if ((lineEnd[0] == LINE_END_d) && (lineEnd[1] == LINE_END_a)) {
                        line[i] = 0
                        //print("count = \(i)")
                        filePos += i
                        break
                    }
                }
                else {
                    lineEnd[0] = c;
                    line[i] = c
                    i += 1
                }
            }
            
            if((line[0] == 0x3a) && (EndOfFile == false)) {
                for index in 1..<i {
                    hexdata.append(&line[index], length: 1)
                }
                
                let ss = NSString(data: (hexdata.copy() as! NSData) as Data , encoding : String.Encoding.ascii.rawValue)
                //print("ss = \(ss!), len = \(ss!.length)")
                let str = (ss?.substring(with: NSMakeRange(0, ss!.length-2)))! as String    //Remove "\r\n"
                //print("str = \(str)")
                
                let data = dataWithHexString(hex: str)
                //print("Hexdat = \(data as NSData)")
                
                if(LineNum < 10){
                    print("Line = \(LineNum+1) , Hexdata = \(data as NSData) , len = \(data.count)")
                }
                else {
                    //EndOfFile = true
                }
                
                //LineNum += 1
                
                line = [UInt8](repeating:0, count:100)
                
                hexdata = NSMutableData()
                
                //Get data
                var byteBuffer = [UInt8](repeating:0 , count:data.count)
                (data as NSData).getBytes(&byteBuffer, length: data.count)
                
                if((byteBuffer[3] == HEX_TYPE_ELA) && (data.count == 7)) {
                    let ff = (data as NSData).subdata(with: NSMakeRange(4, 2))
                    print("Line = \(LineNum+1),(HEX_TYPE_ELA) Address = \(ff as NSData)")
                    
                    (((ff as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&current_bank_number, length: MemoryLayout<UInt8>.size)
                    print("Current bank num = \(current_bank_number)")
                    
                    let dat:NSData = ff as NSData
                    //if(dat.isEqual(to: Test as Data)) {
                    if(dat.isEqual(to: mcu_bank_start)) {
                        
                        //Get MCU version & checksum
                        print("Get MCU version and checksum")
                        var blockInfo = [UInt8](repeating:0, count:bindata.length)
                        bindata.getBytes(&blockInfo, length: bindata.length)
                        
                        var k:Int = 0
                        var length:Int = 0
                        
                        print("==================================")
                        print("Parsing...Flash header")
                        while(k < bindata.length) {
                                if((blockInfo[k] == 0x81) && (blockInfo[k+1] == 0x04)){
                                    print("Flash Header : END")
                                    let gg = bindata.subdata(with: NSMakeRange(k+2, 4))
                                    //print("str = \(str as NSData)")
                                    let str_end = String(decoding: gg, as: UTF8.self)
                                    print("str_end = \(str_end)")
                                    if(str_end == "#END"){
                                        (mcu_checksum, mcu_ver_string, dsp_checksum, ui_checksum) = GetExtraInformation(data: blockInfo, offset: k+6, bindata: bindata)
                                        k = bindata.length
                                        
                                        if(mcu_checksum == 0){
                                            index = bytes.length
                                            Data_error = true
                                        }
                                    }
                                }
                                else {
                                    k += 1
                                }
                        }
                        
                        bindata.setData(Data())
                        Flash_Header_Exist = false
                        
                        FWImageStart = true
                        print("MCU code start address : 0x10000")
                    }
                    
                    if(dat.isEqual(to: mcu_bank_stop)) {
                        FWImageStart = false
                        index = bytes.length
                        print("MCU code stop address: 0x90000")
                    }
                    
                    var mcu_stop : UInt8 = 0
                    (((mcu_bank_stop as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&mcu_stop, length: MemoryLayout<UInt8>.size)
                    print("mcu stop = \(mcu_stop)")
                    if(current_bank_number > mcu_stop){
                        FWImageStart = false
                        index = bytes.length
                        print("MCU : End!!")
                    }
                    
                    if(Flash_Header_Exist == false){
                        print("Code size = \(bindata.length)")
                    }
                    
                    /*
                    if(!(dat.isEqual(to: header_bank))) {
                        if(!Flash_Header_Exist){
                            Flash_Header_Exist = true
                        }
                    }*/
                    
                    BankfirstLine = LineNum + 2
                    print("BankfirstLine = \(BankfirstLine)")
                    Prev_Offset = 0
                }
                else if(byteBuffer[3] == HEX_TYPE_DATA) {
                    len = byteBuffer[0]
                    
                    if(FWImageStart) {
                        bindata.append((data as NSData).subdata(with: NSMakeRange(4, Int(len))))
                    }
                    
                    if(Flash_Header_Exist){
                        bindata.append((data as NSData).subdata(with: NSMakeRange(4, Int(len))))
                    }
                    
                    //let Address:UInt = (UInt(byteBuffer[1]) << 8) + UInt(byteBuffer[2])
                    //print("Address = \(Address)")
                    
                    if((LineNum == 1) || ((LineNum+1) == BankfirstLine)) {
                        let gg = (data as NSData).subdata(with: NSMakeRange(4, Int(len)))
                        print("**Line = \(LineNum+1),Data len = \(len) , bindata = \(gg as NSData)")
                        print("Start Address = \((byteBuffer[1] << 8)+byteBuffer[2])")
                    }
                }
                
                LineNum += 1
            }
            else {
                print("Hex:Invalid data format")
                EndOfFile = true
            }
        }
        
        print("binData len = \(bindata.length)")
        
        /*
        //[BM83] FW version address = 0x2021FC , Data length = 4 bytes
        let mcu_ver_dat = bindata.subdata(with: NSMakeRange(0x21FC, 4))
        //let mcu_ver_dat = bindata.subdata(with: NSMakeRange(0x21FC, 2)
        let mcu_ver_string = mcu_ver_dat.hexEncodedString()
        print("MCU Version = " + mcu_ver_string)
        */
        
        if(bindata.length == 0x80000){
            print("[MCU]Remove unusned data:0xff")
            var nil_data_len : Int = 16
            let nil_data = Data(bytes:[0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff])
            var compare = Data()
            
            while(true) {
                
                compare = bindata.subdata(with: NSMakeRange(bindata.length-nil_data_len, 16))
                if(nil_data == compare){
                    nil_data_len += 16
                }
                else {
                    if(nil_data_len == 16) {
                        nil_data_len = 0
                    }
                    else{
                    }
                    break
                }
            }
            
            if(nil_data_len != 0)  {
                let newdata = bindata.subdata(with: NSMakeRange(0, bindata.length-nil_data_len+16))
                bindata = NSMutableData()
                bindata.append(newdata)
                print("bindata len = \(bindata.length)")
            }
            
            //print("==================================================")
            //print("\(bindata as NSData)")
        }
        
        if((bindata.length > 0x80000) || (bindata.length < 0x10000) || (Data_error == true)){
            return(nil , nil, 0, 0, 0)
        }
        else{
            //print("\(bindata as NSData)")
            print("data length = \(bindata.length)")
            print("+ok,ok")
            return(bindata, mcu_ver_string, mcu_checksum, dsp_checksum, ui_checksum)
        }
    }
    
    class func GetExtraInformation(data:[UInt8], offset:Int, bindata:NSData) -> (UInt16 , String, UInt16, UInt16){
        var num1:UInt8 = 0
        var num2:UInt8 = 0
        var mcu_checksum:UInt16 = 0
        var mcu_ver_string:String! = ""
        var dsp_checksum:UInt16 = 0
        var ui_checksum:UInt16 = 0
        var voice_checksum:UInt16 = 0
        var index:Int = 0
        var length:Int = 0
        
        index = offset
        
        while(true){
            if(data[index] != 0xFF){
                if((data[index] == 0xFB) || (data[index] == 0xFC) || (data[index] == 0xFD) || (data[index] == 0xFE)){
                    length = Int(data[index+1])
                    
                    if(data[index] == 0xFB){
                        //MCU checksum & verion
                        let mcu_crc = bindata.subdata(with: NSMakeRange(index+4, 2))
                        print("MCU checksum = \(mcu_crc as NSData)")
                        
                        (((mcu_crc as NSData).subdata(with: NSMakeRange(0, 1))) as NSData).getBytes(&num1, length: MemoryLayout<UInt8>.size)
                        (((mcu_crc as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&num2, length: MemoryLayout<UInt8>.size)
                        
                        print("num1 = \(num1)")
                        print("num2 = \(num2)")
                        
                        mcu_checksum = UInt16(num1) * 256 +  UInt16(num2)
                        print("mcu checksum = \(mcu_checksum)")
                        
                        let mcu_version = bindata.subdata(with: NSMakeRange(index+10, 4))
                        print("mcu version = \(mcu_version as NSData)")
                        mcu_ver_string = mcu_version.hexEncodedString()
                        print("MCU Version String= " + mcu_ver_string!)
                    }
                    else if(data[index] == 0xFC){
                        //DSP checksum
                        let dsp_crc = bindata.subdata(with: NSMakeRange(index+4, 2))
                        print("DSP checksum = \(dsp_crc as NSData)")
                        
                        (((dsp_crc as NSData).subdata(with: NSMakeRange(0, 1))) as NSData).getBytes(&num1, length: MemoryLayout<UInt8>.size)
                        (((dsp_crc as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&num2, length: MemoryLayout<UInt8>.size)
                        
                        dsp_checksum = UInt16(num1) * 256 +  UInt16(num2)
                        print("dsp checksum = \(dsp_checksum)")
                    }
                    else if(data[index] == 0xFD){
                        //UI Config data checksum
                        let ui_crc = bindata.subdata(with: NSMakeRange(index+4, 2))
                        
                        (((ui_crc as NSData).subdata(with: NSMakeRange(0, 1))) as NSData).getBytes(&num1, length: MemoryLayout<UInt8>.size)
                        (((ui_crc as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&num2, length: MemoryLayout<UInt8>.size)
                        
                        ui_checksum = UInt16(num1) * 256 +  UInt16(num2)
                        print("UI checksum = \(ui_crc as NSData)")
                        print("ui checksum = \(ui_checksum)")
                    }
                    else if(data[index] == 0xFE){
                        //Voice data checksum
                        let voice_crc = bindata.subdata(with: NSMakeRange(index+4, 2))
                        
                        (((voice_crc as NSData).subdata(with: NSMakeRange(0, 1))) as NSData).getBytes(&num1, length: MemoryLayout<UInt8>.size)
                        (((voice_crc as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&num2, length: MemoryLayout<UInt8>.size)
                        
                        voice_checksum = UInt16(num1) * 256 +  UInt16(num2)
                        print("VOICE checksum = \(voice_crc as NSData)")
                        print("voice checksum = \(voice_checksum)")
                    }
                    
                    index += (length+2)
                }
            }
            else{
                if((data[0] == 0xFF) && (data[1] == 0xFF)){
                    print("GetExtraInformation : Errorxxx")
                    return(0, "", 0, 0)
                }
                break;
            }
        }
        
        //return(mcu_checksum, mcu_ver_string, dsp_checksum, ui_checksum, voice_checksum)
        return(mcu_checksum, mcu_ver_string, dsp_checksum, ui_checksum)
        
        /*
        if((data[offset] == 0xFB) && (data[offset+1] == 0x0C)) {
            let mcu_crc = bindata.subdata(with: NSMakeRange(offset+4, 2))
            print("MCU checksum = \(mcu_crc as NSData)")
            
            (((mcu_crc as NSData).subdata(with: NSMakeRange(0, 1))) as NSData).getBytes(&num1, length: MemoryLayout<UInt8>.size)
            (((mcu_crc as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&num2, length: MemoryLayout<UInt8>.size)
            
            print("num1 = \(num1)")
            print("num2 = \(num2)")
            
            mcu_checksum = UInt16(num1) * 256 +  UInt16(num2)
            print("checksum = \(mcu_checksum)")
            
            let mcu_version = bindata.subdata(with: NSMakeRange(offset+10, 4))
            print("mcu version = \(mcu_version as NSData)")
            mcu_ver_string = mcu_version.hexEncodedString()
            print("MCU Version String= " + mcu_ver_string!)
            
            //return(0xFB, checksum, mcu_ver_string)
        }
        else if((data[offset] == 0xFC) && (data[offset+1] == 0x04)){
            let dsp_crc = bindata.subdata(with: NSMakeRange(offset+4, 2))
            print("DSP checksum = \(dsp_crc as NSData)")
            
            (((dsp_crc as NSData).subdata(with: NSMakeRange(0, 1))) as NSData).getBytes(&num1, length: MemoryLayout<UInt8>.size)
            (((dsp_crc as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&num2, length: MemoryLayout<UInt8>.size)
            
            dsp_checksum = UInt16(num1) * 256 +  UInt16(num2)
            print("checksum = \(dsp_checksum)")
            
            //return(0xFC, checksum, "")
        }
        else if((data[offset] == 0xFD) && (data[offset+1] == 0x04)){
            let ui_crc = bindata.subdata(with: NSMakeRange(offset+4, 2))
            
            (((ui_crc as NSData).subdata(with: NSMakeRange(0, 1))) as NSData).getBytes(&num1, length: MemoryLayout<UInt8>.size)
            (((ui_crc as NSData).subdata(with: NSMakeRange(1, 1))) as NSData).getBytes(&num2, length: MemoryLayout<UInt8>.size)
            
            ui_checksum = UInt16(num1) * 256 +  UInt16(num2)
            print("checksum = \(ui_checksum)")
            
            //print("UI checksum = \(ui_crc as NSData)")
            
            //return(0xFD, checksum, "")
        }*/
        
        //return(0x00, 0x00, "")
    }
    
    class func LoadOTAFile(name:String) -> NSData {
        
        let LINE_END_d = 0x0d
        let LINE_END_a = 0x0a
        
        var c : UInt8 = 0
        var line = [UInt8](repeating:0, count:100)
        var lineEnd = [UInt8](repeating:0, count:2)
        
        let HEX_TYPE_ELA = 0x04
        let HEX_TYPE_DATA = 0x00
        
        var len:UInt8 = 0
        
        var hexdata:NSMutableData = NSMutableData()
        var bindata:NSMutableData = NSMutableData()
        
        let str = Bundle.main.path(forResource: name, ofType: "HEX")
        
        let str1 = str! as NSString
        
        print("LoadOTAFile = \(str1)")
        
        let fp = fopen(str1.cString(using: 1) , "r")
        
        var i:Int = 0
        var LineNum = 0
        var EndOfFile = false
        var filePos:Int = 0
        var BankfirstLine:Int = 0
        var Offset:Int = 0
        var Prev_Offset:Int = 0
        var FWImageStart:Bool = false
        
        /*
        var Test : NSMutableData = NSMutableData()
        var dd = 0x00
        Test.append(&dd, length: 1)
        dd = 0x01
        Test.append(&dd, length: 1)
        print("Test = \(Test)")
         */
        
        let mcu_bank = Data(bytes:[0x00,0x01])
        
        while(!EndOfFile) {
            i = 0
            c = 0
            lineEnd[0] = 0
            lineEnd[1] = 0
        
            //Read one Line
            while true {
                let ret = fread(&c, 1, 1, fp)
                if( ret <= 0){
                    EndOfFile = true
                    break
                }
            
                if(c != LINE_END_d) {
                    if((c != LINE_END_a) && (lineEnd[0] != LINE_END_d)) {
                        line[i] = c
                        i += 1
                    }
                    else if((lineEnd[0] == LINE_END_d) && (c == LINE_END_a)) {
                        lineEnd[1] = c;
                        line[i] = c
                        i += 1
                    }
                
                    if ((lineEnd[0] == LINE_END_d) && (lineEnd[1] == LINE_END_a)) {
                        line[i] = 0
                        //print("count = \(i)")
                        filePos += i
                        break
                    }
                }
                else {
                    lineEnd[0] = c;
                    line[i] = c
                    i += 1
                }
            }
        
            if((line[0] == 0x3a) && (EndOfFile == false)) {
                for index in 1..<i {
                    hexdata.append(&line[index], length: 1)
                }
                
                let ss = NSString(data: (hexdata.copy() as! NSData) as Data , encoding : String.Encoding.ascii.rawValue)
                //print("ss = \(ss!), len = \(ss!.length)")
                let str = (ss?.substring(with: NSMakeRange(0, ss!.length-2)))! as String    //Remove "\r\n"
                //print("str = \(str)")
                
                let data = dataWithHexString(hex: str)
                //print("Hexdat = \(data as NSData)")
                
                if(LineNum < 10){
                    print("Line = \(LineNum+1) , Hexdata = \(data as NSData) , len = \(data.count)")
                }
                else {
                    //EndOfFile = true
                }
                
                //LineNum += 1
                
                line = [UInt8](repeating:0, count:100)
                
                hexdata = NSMutableData()
                
                fseek(fp, filePos, SEEK_SET)
                
                //Get data
                var byteBuffer = [UInt8](repeating:0 , count:data.count)
                (data as NSData).getBytes(&byteBuffer, length: data.count)
                
                if((byteBuffer[3] == HEX_TYPE_ELA) && (data.count == 7)) {
                    let ff = (data as NSData).subdata(with: NSMakeRange(4, 2))
                    print("Line = \(LineNum+1),(HEX_TYPE_ELA) Address = \(ff as NSData)")
                    
                    let dat:NSData = ff as NSData
                    //if(dat.isEqual(to: Test as Data)) {
                    if(dat.isEqual(to: mcu_bank)) {
                        
                        FWImageStart = true
                        print("(HEX_TYPE_ELA) Address = 0x0001")
                    }
                    
                    BankfirstLine = LineNum + 2
                    print("BankfirstLine = \(BankfirstLine)")
                    Prev_Offset = 0
                }
                else if(byteBuffer[3] == HEX_TYPE_DATA) {
                    len = byteBuffer[0]
                    
                    if(FWImageStart) {
                        bindata.append((data as NSData).subdata(with: NSMakeRange(4, Int(len))))
                    }
                    
                    //let Address:UInt = (UInt(byteBuffer[1]) << 8) + UInt(byteBuffer[2])
                    //print("Address = \(Address)")
                    
                    if((LineNum == 1) || ((LineNum+1) == BankfirstLine)) {
                    //if(LineNum == 6) {
                        let gg = (data as NSData).subdata(with: NSMakeRange(4, Int(len)))
                        print("**Line = \(LineNum+1),Data len = \(len) , bindata = \(gg as NSData)")
                        print("Start Address = \((byteBuffer[1] << 8)+byteBuffer[2])")
                    }
                    
                    /*
                    if(Address != 0) {
                        if((Prev_Offset + Int(len)) != Int((byteBuffer[1] << 8)+byteBuffer[2])) {
                            print("\(Prev_Offset)")
                            print("\(((byteBuffer[1] << 8)+byteBuffer[2]))")
                            print("xxLine = \(LineNum+1) , \(data as NSData)")
                        }
                        else {
                            Prev_Offset = Int((byteBuffer[1] << 8) + byteBuffer[2])
                            print("__Line = \(LineNum+1), offset= \(Prev_Offset)")
                        }
                    }*/
                }
                
                //if(LineNum == 10){
                //    print("==========================")
                //    print("binData = \(bindata)")
                //    print("==========================")
                //}
                
                LineNum += 1
                
                //if(LineNum == 27347) {
                //    print("End...,Hexdata = \(data as NSData) , len = \(data.count)")
                //}
            }
            else {
                print("Hex:Invalid data format")
                EndOfFile = true
            }
        }
        
        print("binData len = \(bindata.length)")
        
        return bindata
        
        //return ConvertHexToBin(dat: hexdata)
    }
    
}
