package com.app.microchip.audiowidget.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.managers.TransparentServiceManager;
import com.app.microchip.audiowidget.util.BLELog;

public class EqualizerModesActivity extends AppCompatActivity {
    private static final String TAG = EqualizerModesActivity.class.getSimpleName();
    private final static String UART_CMD_EQ_MODE_SETTING = "1C ";
    private final static String UART_CMD_MMI_ACTION_GET_EQ_MODE = "2 0 3F";
    private final static int UART_CURRENT_EQ_MODE_EVENT = 16;//0x10
    private ListView lv;
    private TransparentServiceManager mainActivity;
    private Button manualSettingsBtn;

    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver eqmodeInfoReceiver;

    private int DELAY = 1500;
    private Handler mHandler;
    private ProgressDialog mUpdateStateDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equalizer_modes);
        setTitle("Equalizer Settings");
        mainActivity = TransparentServiceManager.getInstance();
        InitializeUI();
        transRxIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(TransparentServiceManager.BLE_DISCONNECTED);
        eqmodeInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                Message msg = Message.obtain();
                String action = intent.getAction();
                if (TransparentServiceManager.BLE_DISCONNECTED.equals(action)) {
                    handleBLEDisconnection();
                }
                if (TransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (TransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(TransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i;
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Received Data byte[" + i + "]=" + (rxBytes[i] & 0xff));

                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            switch (rxBytes[3] & 0xff) {
                                case UART_CURRENT_EQ_MODE_EVENT:
                                    BLELog.d(TAG, "Current EQ mode =" + (rxBytes[4] & 0xff));
                                    lv.setItemChecked(rxBytes[4] & 0xff, true);
                                    break;
                            }
                        }
                    }
                }
            }
        };
    }

    public void InitializeUI() {
        mHandler = new Handler();
        mUpdateStateDialog = new ProgressDialog(this);
        mUpdateStateDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mUpdateStateDialog.setMessage(getString(R.string.updating_message));
        mUpdateStateDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mUpdateStateDialog.setIndeterminate(true);
        mUpdateStateDialog.setCanceledOnTouchOutside(false);

        String[] modes = getResources().getStringArray(R.array.EqModes);
        lv = (ListView) findViewById(R.id.eqModeslist);
        ArrayAdapter<String> ListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_checked, modes);
        lv.setAdapter(ListAdapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BLELog.d(TAG, "Clicked index=" + position);
                if (position < 11) {
                    sendCommand(UART_CMD_EQ_MODE_SETTING + position);
                    showProcessing();
                } /*else if (position == 10) {
                    //  sendCommand(UART_CMD_EQ_MODE_SETTING + "A");
                    //Intent newScreen = new Intent(getApplicationContext(), CustomEqSettingsActivity.class);
                   // startActivity(newScreen);
                }*/
            }
        });

        manualSettingsBtn = (Button) findViewById(R.id.manualeqMode);
        manualSettingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO new screen
                Intent newScreen = new Intent(getApplicationContext(), CustomEqSettingsActivity.class);
                startActivity(newScreen);
            }
        });
    }


    public void showProcessing() {
        if (mUpdateStateDialog != null)
            mUpdateStateDialog.show();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mUpdateStateDialog != null && mUpdateStateDialog.isShowing())
                    mUpdateStateDialog.dismiss();
            }
        }, DELAY);
    }

    public void sendCommand(String cmd) {
        if (mainActivity.isConnected() == false) {
            handleBLEDisconnection();
        }
        if (mainActivity != null) {
            mainActivity.packAndSendCommand(cmd);
        }
    }

    public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
            }
        });
        builder.show();
    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                Intent home = new Intent(getApplicationContext(), HomeScreenActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mainActivity.unregisterFragReceiver(eqmodeInfoReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mainActivity.registerFragReceiver(eqmodeInfoReceiver, transRxIntentFilter);
        mainActivity.registerFragReceiver(eqmodeInfoReceiver, transReadyIntentFilter);
        mainActivity.registerFragReceiver(eqmodeInfoReceiver, disconnectionfilter);
        sendInitCommands();
    }

    public void sendInitCommands() {
        BLELog.d(TAG, "sendInitCommands called");
        sendCommand(UART_CMD_MMI_ACTION_GET_EQ_MODE);
    }
}
