package com.app.microchip.wstearbuds.managers;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.wstearbuds.ui.EarbudsControllerActivity;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Random;

/**
 * Created by I17163 on 8/13/2019.
 */

public class BundleHandler {
    public static final String TAG = BundleHandler.class.getSimpleName();

    public static final byte BUNDLE_APP_CONNECT_REQUEST = 0x01;
    public static final byte BUNDLE_APP_CONNECT_RESPONSE = 0x02;
    public static final byte BUNDLE_APP_CHALLENGE_REQ = 0x03;
    public static final byte BUNDLE_APP_CHALLENGE_RESPONSE = 0x04;
    public static final byte BUNDLE_APP_NEW_BUNDLE_REQ = 0x05;
    public static final byte BUNDLE_APP_NEW_BUNDLE_RESPONSE = 0x06;

    private final static byte OPCODE_RESPONSE_SUCCESS = 0x01;

    public int bundleProcessstate = -1;
    private boolean isBundlePresent = false;

    private byte[] bundle_id ; // 6 bytes
    private byte[] group_id ; // 6 bytes

    private byte[] app_chal_rand_res = new byte[6];
    private byte[] chal_res = new byte[6];
    private byte[] cha_val = new byte[6];

   // private byte[] app_rand_req = new byte[6];
    private byte[] sres = new byte[6];

    public BundleHandler(byte[] group_id) {
        this.group_id = group_id;
    }


    public void sendConnectReq(EarbudsTransparentServiceManager mgr) {
        BLELog.d(TAG, "sendConnectReq ");

        bundleProcessstate = BUNDLE_APP_CONNECT_REQUEST;
        ByteBuffer buffer = prepareOutputBuffer(BUNDLE_APP_CONNECT_REQUEST, 2);
        buffer.put(0, BUNDLE_APP_CONNECT_REQUEST);
        buffer.put(1, (byte) 0x00);
        mgr.sendDataByCtrlPoint( buffer.array());
        return ;

    }
    public void sendNewBundleReq(EarbudsTransparentServiceManager mgr) {

        int putIndex = 0 ;
        Random random = new Random();

        bundleProcessstate = BUNDLE_APP_NEW_BUNDLE_REQ;
        ByteBuffer buffer = prepareOutputBuffer(8);

        int randInt = random.nextInt();

        byte[] randomBytes = HexTool.toByteArray(randInt);
        BLELog.d(TAG, "rand num generated =  "+ randInt);

        app_chal_rand_res[0] = randomBytes[0];
        app_chal_rand_res[1] = randomBytes[1];
        app_chal_rand_res[2] = randomBytes[2];
        app_chal_rand_res[3] = randomBytes[3];

        app_chal_rand_res[4] = randomBytes[0];
        app_chal_rand_res[5] = randomBytes[1];

        buffer.put(putIndex++, BUNDLE_APP_NEW_BUNDLE_REQ);
        buffer.put(putIndex++, (byte) 0x06);
        buffer.put(putIndex++, app_chal_rand_res[0]);
        buffer.put(putIndex++, app_chal_rand_res[1]);
        buffer.put(putIndex++, app_chal_rand_res[2]);
        buffer.put(putIndex++, app_chal_rand_res[3]);
        buffer.put(putIndex++, app_chal_rand_res[4]);
        buffer.put(putIndex++, app_chal_rand_res[5]);

        BLELog.d(TAG, "sendNewBundleReq app_chal_rand_res="+ HexTool.byteArrayToHexString(buffer.array()));

        mgr.sendDataByCtrlPoint( buffer.array());
        return ;

    }

    public void  sendAppChallengeResponse(EarbudsTransparentServiceManager mgr) {

        int putIndex = 0 ;

        bundleProcessstate = BUNDLE_APP_CHALLENGE_RESPONSE;
        ByteBuffer buffer = prepareOutputBuffer(8);

        buffer.put(putIndex++, BUNDLE_APP_CHALLENGE_RESPONSE);
        buffer.put(putIndex++, (byte) 0x06);
        buffer.put(putIndex++, chal_res[0]);
        buffer.put(putIndex++, chal_res[1]);
        buffer.put(putIndex++, chal_res[2]);
        buffer.put(putIndex++, chal_res[3]);
        buffer.put(putIndex++, chal_res[4]);
        buffer.put(putIndex++, chal_res[5]);

        BLELog.d(TAG, "sendAppChallengeResponse chal_res="+ HexTool.byteArrayToHexString(buffer.array()));

        mgr.sendDataByCtrlPoint( buffer.array());
        return ;

    }


    public void handleBundleResonse(byte[] responseData, EarbudsTransparentServiceManager mgr) {


        byte commandID;

            BLELog.d(TAG, " Bundle Response/Notification from Server: " + HexTool.byteArrayToHexString(responseData));
            ByteBuffer bb = ByteBuffer.wrap(responseData);
            bb.order(ByteOrder.LITTLE_ENDIAN);
            commandID = bb.get();
            byte len ;


            switch (commandID) {
                case BUNDLE_APP_CONNECT_RESPONSE:
                    len = bb.get();
                    byte status = bb.get();
                    if(status!=0) {
                        storeBundleId(mgr);
                        // Connect succes
                        // Send transparent ready
                        Intent intent = new Intent(EarbudsTransparentServiceManager.BLE_TRANS_READY);
                        mgr.m_context.sendBroadcast(intent);
                        BLELog.d(TAG, "Bundle Successful");
                    } else {
                        // clear bundle id
                        BLELog.d(TAG, "Bundle fail CLear Bundle stored");
                        saveRecentBundleId("","",mgr);
                        if ((EarbudsControllerActivity.getInstance())!= null) {
                            EarbudsControllerActivity.getInstance().setTryRetryOnce(true) ;
                        }

                        // Retry
                    }


                    break;
                case BUNDLE_APP_CHALLENGE_REQ:

                    len = bb.get();

                    cha_val[0] = bb.get();
                    cha_val[1] = bb.get();
                    cha_val[2] = bb.get();
                    cha_val[3] = bb.get();
                    cha_val[4] = bb.get();
                    cha_val[5] = bb.get();


                    BLELog.d(TAG, "BUNDLE_APP_CHALLENGE_REQ cha_val="+ HexTool.byteArrayToHexString(cha_val));

                    if(isValidBundleIDPresent(mgr)) {
                        retrieveBundleId(mgr);
                        generateChalRes();
                        sendAppChallengeResponse(mgr);
                    } else {
                        sendNewBundleReq(mgr);
                    }

                    break;
                case BUNDLE_APP_NEW_BUNDLE_RESPONSE:
                    len = bb.get();

                    sres[0] = bb.get();
                    sres[1] = bb.get();
                    sres[2] = bb.get();
                    sres[3] = bb.get();
                    sres[4] = bb.get();
                    sres[5] = bb.get();

                    BLELog.d(TAG, "BUNDLE_APP_NEW_BUNDLE_RESPONSE sres="+ HexTool.byteArrayToHexString(sres));

                    generateBundleId();
                    generateChalRes();
                    sendAppChallengeResponse(mgr);

                    break;
                default:
                    BLELog.d(TAG, "Bundle Default opcode " + commandID);
                    break;
            }

    }


    private void generateBundleId () {
        bundle_id = HexTool.xorOprArr(HexTool.xorOprArr(group_id,app_chal_rand_res),sres);
        BLELog.d(TAG, "generateBundleId " + HexTool.byteArrayToHexString(bundle_id));
        //byte[] bundleId =
        return;

    }

    private void generateChalRes () {
        chal_res = HexTool.xorOprArr(HexTool.xorOprArr(bundle_id,group_id),cha_val);
        BLELog.d(TAG, "generateChalRese " + HexTool.byteArrayToHexString(chal_res));
        //byte[] bundleId =
        return;

    }

    private boolean isValidBundleIDPresent (EarbudsTransparentServiceManager mgr) {
        String currentGrpAccress = HexTool.byteArrayToHexString(group_id);
        String storedGrpAddress = getRecentBundleGroupAddress(mgr);


        if (currentGrpAccress.equalsIgnoreCase(storedGrpAddress)) {
            BLELog.d(TAG, "isValidBundleIDPresent  valid" + currentGrpAccress);
            return  true;

        } else {
            BLELog.d(TAG, "isValidBundleIDPresent  NOT valid" + currentGrpAccress+ storedGrpAddress);
            saveRecentBundleId("","",mgr);
            return false;
        }


    }

    private void storeBundleId( EarbudsTransparentServiceManager mgr) {
        if((null!= bundle_id) && (null!= group_id)) {
            saveRecentBundleId(HexTool.byteArrayToHexString(bundle_id),
                    HexTool.byteArrayToHexString(group_id), mgr);
        }

        return;
    }

    private void retrieveBundleId (EarbudsTransparentServiceManager mgr) {
        bundle_id = HexTool.hexStringToByteArray(getRecentBundleId(mgr));
        //byte[] bundleId =
        return;
    }

    public boolean saveRecentBundleId(String bundleId, String  bundleGroupAddress,EarbudsTransparentServiceManager mgr) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mgr.m_context);
        SharedPreferences.Editor mEdit1 = sp.edit();

        mEdit1.putString("RecentBundleId" , bundleId);
        mEdit1.putString("RecentBundleGroupAddress" , bundleGroupAddress);

        BLELog.d(TAG, "saveRecentBundleId  " + bundleId+" bundleGroupAddress " + bundleGroupAddress);

        return mEdit1.commit();
    }

    public String getRecentBundleId(EarbudsTransparentServiceManager mgr) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mgr.m_context);
        String value = sp.getString("RecentBundleId" , "");
        BLELog.d(TAG, "getRecentBundleId  " + value);
        return value;
    }

    public String getRecentBundleGroupAddress(EarbudsTransparentServiceManager mgr) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mgr.m_context);
        String value = sp.getString("RecentBundleGroupAddress" , "");
        return value;
    }



    private ByteBuffer prepareOutputBuffer(byte commend, int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        tempBuffer.put(commend);
        return tempBuffer;
    }

    private ByteBuffer prepareOutputBuffer(int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        return tempBuffer;
    }



}
