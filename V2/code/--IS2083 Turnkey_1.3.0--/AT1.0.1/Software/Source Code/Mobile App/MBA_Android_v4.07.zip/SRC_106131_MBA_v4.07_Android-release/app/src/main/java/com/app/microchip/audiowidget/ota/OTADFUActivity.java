package com.app.microchip.audiowidget.ota;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ui.HomeLaunchDashboard;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.FileUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class OTADFUActivity extends AppCompatActivity {
    public static final int MCU_IMAGE = 0;
    public static final int DSP_IMAGE = 1;
    public static final int UI_CFG_IMAGE = 2;

    public static final String DEFAULT_KEY = "22222222222222222222222222222222";
    public static final String DEFAULT_IV =  "00000000000000000000000000000000";

    private static final String TAG = OTADFUActivity.class.getSimpleName();
    private static final int SETTINGS = 1;
    private static final int BACK_PRESSED = 2;
    private static final int RESET = 3;
    private static final CharSequence[] imageTypes = {"MCU", "VP_DSP"};
    private static final int FILE_SELECT_CODE = 1;
    private static final int OTA_COMMAND_SUCCESS = 0;
    private static OTADFUActivity INSTANCE;
   // public static Uri mFileUri;
    private String mFilePath;

    private int Imageselected = -1;
    private String mcuCurrrentVersionVal;
    private String mcuCurrentSubVersionVal;
    private String dspCurrentVersionVal;
    private String dspCurrentSubVersionVal;
    private String updateVersionStr;
    private String updateSubVersionStr;
    private String updateDSPVersionStr = null;
    private String updateDSPSubVersionStr = null;
    private Button settingsBtn;
    private Button runButton;
    private Button encryptionSettingsBtn;
    private String address;
    private String deviceName;
    private String otaUpdateType = "MCU";
    private int otaProgressValue;
    private String otaStartTime;
    private String otaStopTime;
    private ProgressBar mProgressBar;
    private BLEService mBLEService;
    private ProgressDialog mSpinnerDialog;
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            BLELog.d(TAG, "onServiceConnected");
            displaySpinnerDialog();
            Intent i = new Intent(BLEService.ACTION_CONNECT);
            i.putExtra("ADDRESS", address);
            sendBroadcast(i);

            mBLEService = ((BLEService.LocalBinder) service).getService();
            BLELog.d(TAG, " mBLEService onServiceConnected");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };
    private TextView mOtaState;
    private TextView mTVOtaFileName;
    private TextView dspVersion;
    private TextView mcuVersion;

   /* private void requestAppPermissions() {
        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        }

       if (hasReadPermissions() && hasWritePermissions()) {
            Log.d(TAG , "balaji if (hasReadPermissions() && hasWritePermissions()");
            return;
        }

        requestPermissions(
                new String[] {
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    }, REQUEST_WRITE_STORAGE_REQUEST_CODE); // your request code
    }

    private boolean hasReadPermissions() {
        return (checkSelfPermission( Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED);
    }

    private boolean hasWritePermissions() {
        return (checkSelfPermission( Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED);
    }*/

    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            BLELog.d(TAG, "BroadcastReceiver action: " + action);
            if (action.equals(BLEService.ACTION_GATT_SERVICES_DISCOVERED)) {
                dismissSpinnerDialog();
                Toast.makeText(OTADFUActivity.this, "Connected", Toast.LENGTH_SHORT).show();
                mOtaState.setText("Connected");
                Intent i = new Intent(BLEService.OTA_ACTION_INFO_REQUEST);
                i.putExtra(BLEService.OTA_PARAMETER_IS_APP_INFO_REQUEST, true);
                sendBroadcast(i);

            } else if (action.equals(BLEService.ACTION_GATT_SERVICES_DISCOVERY_FAILED)) {
                dismissSpinnerDialog();
                Toast.makeText(OTADFUActivity.this, "This device doesn't support OTA update.", Toast.LENGTH_LONG).show();
                finish();
            } else if (action.equals(BLEService.ACTION_GATT_DISCONNECTED)) {
                dismissSpinnerDialog();
                Toast.makeText(OTADFUActivity.this, "Disconnected", Toast.LENGTH_SHORT).show();
                finish();
            }  else if (action.equals(BLEService.OTA_ACTION_UPDATE_FAILED)) {
                BLELog.d(TAG, " OTA_ACTION_UPDATE_FAILED");
                String response = intent.getStringExtra(BLEService.OTA_UPDATE_FAILED_RESPONSE);
                Toast.makeText(OTADFUActivity.this, "Update Failed: " + response, Toast.LENGTH_SHORT).show();
                mOtaState.setText("Update Failed");
            } else if (action.equals(BLEService.OTA_ACTION_UPDATE_PROGRESS)) {
                int value = intent.getIntExtra(BLEService.OTA_PROGRESS_VALUE, 0);
                BLELog.d(TAG, " OTA_ACTION_UPDATE_PROGRESS value =" + value);
                //otaProgressValue = value;
                updateProgress(value);
                if (value == 100)
                    Toast.makeText(OTADFUActivity.this, "100%", Toast.LENGTH_SHORT).show();
            } else if (action.equals(BLEService.OTA_ACTION_END_REQUEST_RESPONSE)) {
                byte status = intent.getByteExtra(BLEService.OTA_ACTION_END_REQUEST_RESPONSE, (byte) 0);
                BLELog.d(TAG, " OTA_ACTION_END_REQUEST_RESPONSE ");
                if (status == 0x01) {
                    showAlertDialog(RESET);
                }
            } else if (action.equals(BLEService.OTA_ACTION_INFO_REQUEST_RESPONSE)) {
                final String  mcu_version = intent.getStringExtra((BLEService.OTA_PARAMETER_MCU_VERSION));
                final String  dsp_version = intent.getStringExtra(BLEService.OTA_PARAMETER_DSP_VERSION);
                final String  mcu_sub_version = intent.getStringExtra(BLEService.OTA_PARAMETER_MCU_SUB_VERSION);
                final String  dsp_sub_version = intent.getStringExtra(BLEService.OTA_PARAMETER_DSP_SUB_VERSION);
                updateVersionStr =  intent.getStringExtra(BLEService.OTA_PARAMETER_UPDATE_VERSION);
                updateSubVersionStr =  intent.getStringExtra(BLEService.OTA_PARAMETER_UPDATE_SUB_VERSION);

                updateDSPVersionStr = intent.getStringExtra(BLEService.OTA_PARAMETER_DSP_UPDATE_VERSION);
                updateDSPSubVersionStr = intent.getStringExtra(BLEService.OTA_PARAMETER_DSP_UPDATE_SUB_VERSION);


                mcuCurrrentVersionVal = mcu_version;
                mcuCurrentSubVersionVal = mcu_sub_version;
                dspCurrentVersionVal = dsp_version;
                dspCurrentSubVersionVal = dsp_sub_version;

                BLELog.d(TAG, " OTA_ACTION_INFO_REQUEST_RESPONSE ");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        mcuVersion.setText(mcuCurrrentVersionVal+"."+mcuCurrentSubVersionVal);

                        dspVersion.setText(dspCurrentVersionVal+"."+dspCurrentSubVersionVal);
                    }
                });
            } else if (action.equals(BLEService.OTA_ACTION_UPDATE_UI)) {
                final int state = intent.getIntExtra(BLEService.OTA_PARAMETER_STATE_UPDATE, -1);
                BLELog.d(TAG, " OTA_ACTION_UPDATE_UI ");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        switch (state) {
                            case BLEService.OTA_STATE_CONNECTED:
                                otaProgressValue = 0;
                                mOtaState.setText("Connected");
                                break;
                            case BLEService.OTA_STATE_UPDATE_CONFIRM:
                                otaUpdateType = "MCU";
                                mOtaState.setText("Initializing update..");
                                if (mSpinnerDialog != null && mSpinnerDialog.isShowing()) {
                                    mSpinnerDialog.dismiss();
                                }
                                confirmOTAVersionDialog();
                                break;
                            case BLEService.OTA_STATE_DISCONNECTED:
                                mOtaState.setText("Disconnected");
                                break;
                            case BLEService.OTA_STATE_UPDATE:
                                if (mSpinnerDialog != null && mSpinnerDialog.isShowing()) {
                                    mSpinnerDialog.dismiss();
                                }
                                mOtaState.setText(otaUpdateType + " Updating..." + otaProgressValue +"%");
                                break;
                            case BLEService.OTA_STATE_VALIDATION:
                                mOtaState.setText(otaUpdateType + " Validating...");

                                mSpinnerDialog = new ProgressDialog(OTADFUActivity.this);
                                mSpinnerDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                                mSpinnerDialog.setMessage("Validating. Please wait...");
                                mSpinnerDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
                                mSpinnerDialog.setIndeterminate(true);
                                mSpinnerDialog.setCancelable(true);
                                mSpinnerDialog.setCanceledOnTouchOutside(false);
                                mSpinnerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                                                       @Override
                                                                       public void onCancel(DialogInterface dialog) {
                                                                           BLELog.d(TAG, "Cancelling during validation");
                                                                           onBackPressed();
                                                                       }
                                                                   }
                                );

                                mSpinnerDialog.show();

                                break;
                            case BLEService.OTA_STATE_VALIDATED:
                                if (mSpinnerDialog != null && mSpinnerDialog.isShowing()) {
                                    mSpinnerDialog.dismiss();
                                }
                                mOtaState.setText("Validated");
                                if (otaUpdateType.compareTo("MCU") == 0)
                                   otaUpdateType = "DSP";
                                else if (otaUpdateType.compareTo("DSP") == 0)
                                    otaUpdateType = "CFG";

                                break;
                        }
                    }
                });

            }


        }
    };

    private static IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BLEService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BLEService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BLEService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BLEService.ACTION_GATT_SERVICES_DISCOVERY_FAILED);
        intentFilter.addAction(BLEService.OTA_ACTION_START_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_START_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_INFO_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_INFO_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_INIT_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_INIT_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_VALIDATE_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_VALIDATE_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_END_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_END_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_RESET_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_OPEN_FILE);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_FAILED);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_PROGRESS);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_UI);
        intentFilter.addAction(BLEService.OTA_ACTION_COMPLETE_REQUEST);

        return intentFilter;
    }

    public static synchronized OTADFUActivity getInstance() {
        return INSTANCE;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otadfu);


        INSTANCE = this;
        address = getIntent().getStringExtra("Address");
        deviceName = getIntent().getStringExtra("Name");
        setTitle(deviceName);
        mOtaState = (TextView) findViewById(R.id.otastatevalue);
        mTVOtaFileName = (TextView) findViewById(R.id.otaFilevalue);
        mcuVersion = (TextView) findViewById(R.id.mcuversionvalue);
        dspVersion = (TextView) findViewById(R.id.dspversionvalue);
        settingsBtn = (Button) findViewById(R.id.otasettings);
        runButton = (Button) findViewById(R.id.otarun);
        encryptionSettingsBtn = (Button) findViewById(R.id.otaEncryptionSettings);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
                //showAlertDialog(SETTINGS)
                ;
            }
        });

        encryptionSettingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //showAlertDialog(SETTINGS);
                showEncryptionSettings();
            }
        });

        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmOTAFileDialog();
            }
        });
        mSpinnerDialog = new ProgressDialog(this);
        mSpinnerDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mSpinnerDialog.setMessage("Connecting. Please wait...");
        mSpinnerDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mSpinnerDialog.setIndeterminate(true);
        mSpinnerDialog.setCancelable(true);
        mSpinnerDialog.setCanceledOnTouchOutside(false);
        mSpinnerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                               @Override
                                               public void onCancel(DialogInterface dialog) {
                                                   BLELog.d(TAG, "Cancelling Connection");
                                                   stopConnect();
                                               }
                                           }
        );

        Intent gattServiceIntent = new Intent(this, BLEService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
        registerReceiver(mGattUpdateReceiver, makeIntentFilter());

        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        registerReceiver(mReceiver, new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED));
       // requestAppPermissions();
    }

    private void stopConnect() {
        if (mBLEService != null) {
            mBLEService.disconnect();
        }
        finish();
    }

    private void dismissSpinnerDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSpinnerDialog != null && mSpinnerDialog.isShowing()) {
                    mSpinnerDialog.dismiss();
                }
            }
        });
    }

    private void displaySpinnerDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSpinnerDialog != null)
                    mSpinnerDialog.show();
            }
        });
    }

    private void updateProgress(final int value) {
        runOnUiThread(new Runnable() {
            public void run() {
                mProgressBar.setProgress(value);
                mOtaState.setText(otaUpdateType+" Updating..." + value +"%");;
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(mGattUpdateReceiver);
        unregisterReceiver(mReceiver);
        unbindService(mServiceConnection);
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public void onBackPressed() {
        if (mProgressBar.getProgress() != 0 && mProgressBar.getProgress() != 100) {
            showAlertDialog(BACK_PRESSED);
        } else
            backPressed();
    }

    private void backPressed() {
        if (mBLEService != null)
            mBLEService.disconnect();
        super.onBackPressed();
    }

    private void setEncryptionKey (String key) {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("ENCRYPT_PREF", 0); // 0 - for private mode
        SharedPreferences.Editor  editor = pref.edit();
        editor.putString("encrypt_key", key); // Storing string
        editor.commit(); // commit changes
    }

    private void  setEncryptionIV (String iv) {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("ENCRYPT_PREF", 0); // 0 - for private mode
        SharedPreferences.Editor  editor = pref.edit();
        editor.putString("encrypt_iv"    ,iv); // getting String
        editor.commit(); // commit changes

    }



    private String getEncryptionKey () {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("ENCRYPT_PREF", 0); // 0 - for private mode
        return pref.getString("encrypt_key", DEFAULT_KEY); // getting String

    }


    private String getEncryptionIV () {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("ENCRYPT_PREF", 0); // 0 - for private mode
        return pref.getString("encrypt_iv", DEFAULT_IV); // getting String

    }



    private void showEncryptionSettings() {
        Context context = getApplicationContext();
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);


// Add another TextView here for the "Description" label
        final EditText keyBox = new EditText(context);
        keyBox.setHint("Key(16 Bytes)");
        keyBox.setText(getEncryptionKey());
        layout.addView(keyBox); // Another add method

        final EditText ivBox = new EditText(context);
        ivBox.setHint("IV(16 Bytes)");
        ivBox.setText(getEncryptionIV());
        layout.addView(ivBox); // Another add method

        final AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("AES Settings :"+ "\r\n" +
                "Key/IV (16 Bytes)" ).setView(layout).setPositiveButton("Save",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int whichButton) {


                        Log.i("AlertDialog","Key Entered "+keyBox.getText().toString());
                        Log.i("AlertDialog","IV Entered "+ivBox.getText().toString());
                       // setEncryptionKey(keyBox.getText().toString());
                        //setEncryptionIV(ivBox.getText().toString());
                        if ((keyBox.getText().toString().length() == 32) && (ivBox.getText().toString().length() == 32)) {
                            showKeyIVConfirmation(keyBox.getText().toString(), ivBox.getText().toString());
                        } else {
                            Toast.makeText(OTADFUActivity.this, "Key & IV should be 16 bytes", Toast.LENGTH_LONG).show();
                        }
    /* User clicked OK so do some stuff */
                    }
                }).setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int whichButton) {
     /*
     * User clicked cancel so do some stuff
     */
                    }
                });
        alert.show();

        //alert.setView(layout); // Again this is a set method, not add
    }

    private void showAlertDialog(final int id) {
        runOnUiThread(new Runnable() {
            public void run() {
                switch (id) {
                    case SETTINGS:
                        settingsDialog();
                        break;
                    case BACK_PRESSED:
                        updateInterruptDialog();
                        break;
                    case RESET:
                        resetDialog();
                        break;
                }

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_SELECT_CODE) {
            if (resultCode == RESULT_OK) {
                try {

                    Uri uri = data.getData();
                    String mimeType = getContentResolver().getType(uri);
                    //Log.d(TAG , "balaji uri = " + uri);
                    //mFilePath = Util.getPath(this, uri);

                    mFilePath = FileUtils.getPath(this, uri);

                    // For oreo working for file name
                   /* File file = new File(uri.getPath());//create path from uri
                    final String[] split = file.getPath().split(":");//split the path.
                    mFilePath = split[1];//assign it to a string(your choice).
                    Log.d(TAG , "balaji file.exists() = " + file.exists());*/
                    // mFileUri = uri;

                    BLELog.d(TAG, "mFilePath=" + mFilePath);
                    Toast.makeText(OTADFUActivity.this, "File Selected " + mFilePath , Toast.LENGTH_SHORT).show();

                    File file = new File(mFilePath);
                    String fileName = file.getName();
                    if (fileName.length() > 22) {
                        fileName = fileName.substring(0, 20);
                        fileName = fileName + " ..";
                    }
                    mTVOtaFileName.setText(fileName);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void showFileChooser() {

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");      //all files
        //  intent.setType("text/xml");   //XML file only
        //  intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"), FILE_SELECT_CODE);
        } catch (android.content.ActivityNotFoundException ex) {
            // Potentially direct the user to the Market with a Dialog
            Toast.makeText(this, "Please install a File Manager.", Toast.LENGTH_SHORT).show();
        }
    }

    private void settingsDialog() {
        AlertDialog alert = null;
        final AlertDialog.Builder ad = new AlertDialog.Builder(OTADFUActivity.this, R.style.MyDialogTheme);
        //   ad.setMessage("Select Image");
        ad.setSingleChoiceItems(imageTypes, -1, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                Imageselected = arg1;
            }
        });
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showFileChooser();
            }
        });

        alert = ad.create();
        alert.setTitle("Select OTA Image type");
        alert.show();
    }

    private void resetDialog() {

        otaStopTime = getCurrentTimeString();
        final AlertDialog.Builder ad = new AlertDialog.Builder(OTADFUActivity.this, R.style.MyDialogTheme);
        ad.setMessage("OTA Start time :"+ otaStartTime+ "\r\n" +
                "OTA Stop time :" + otaStopTime);

        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
                sendBroadcast(i);
                  mOtaState.setText("Completed");*/
            }
        });

        final AlertDialog  alert = ad.create();
        alert.setTitle("OTA Update Success!!");
        alert.show();

        // Hide after some seconds
        final Handler handler  = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (alert.isShowing()) {
                    alert.dismiss();
                }
            }
        };

        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                handler.removeCallbacks(runnable);
                Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
                sendBroadcast(i);
                mOtaState.setText("Completed");
            }
        });

        handler.postDelayed(runnable, 20000);
    }

    private void showKeyIVConfirmation(final String key, final String iv) {
        AlertDialog alert = null;
        otaStopTime = getCurrentTimeString();
        final AlertDialog.Builder ad = new AlertDialog.Builder(OTADFUActivity.this, R.style.MyDialogTheme);
        ad.setMessage("Key:"+ key+ "\r\n" +
                "IV:" + iv);

        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                    setEncryptionKey(key);
                    setEncryptionIV(iv);
            }
        });

        ad.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        alert = ad.create();
        alert.setTitle("Confirm Key and IV ?");
        alert.show();
    }

    private void updateInterruptDialog() {
        AlertDialog alert = null;
        final AlertDialog.Builder ad = new AlertDialog.Builder(OTADFUActivity.this, R.style.MyDialogTheme);
        ad.setMessage("Firmware Update will be interrupted, Do you want to Continue?");
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                backPressed();
            }
        });

        alert = ad.create();
        alert.setTitle("Warning");
        alert.show();
    }

    private void confirmOTAFileDialog() {
        AlertDialog alert = null;
        final AlertDialog.Builder ad = new AlertDialog.Builder(OTADFUActivity.this, R.style.MyDialogTheme);
        ad.setMessage("MCU file :"+ mTVOtaFileName.getText());
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (mFilePath != null) {
                    Intent i = new Intent(BLEService.OTA_ACTION_OPEN_FILE);
                    i.putExtra(BLEService.OTA_PARAMETER_FILE_PATH, mFilePath);
                    i.putExtra(BLEService.OTA_PARAMETER_IMAGE_TYPE, Imageselected);
                    sendBroadcast(i);

                    mSpinnerDialog = new ProgressDialog(OTADFUActivity.this);
                    mSpinnerDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    mSpinnerDialog.setMessage("Initializing. Please wait...");
                    mSpinnerDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
                    mSpinnerDialog.setIndeterminate(true);
                    mSpinnerDialog.setCancelable(false);
                    mSpinnerDialog.setCanceledOnTouchOutside(false);

                    mSpinnerDialog.show();

                } else {
                    Toast.makeText(OTADFUActivity.this, "Select File Before update", Toast.LENGTH_SHORT).show();
                }
            }
        });

        alert = ad.create();
        alert.setTitle("OTA update file");
        alert.show();
    }

    private void confirmOTAVersionDialog() {
        AlertDialog alert = null;
        final AlertDialog.Builder ad = new AlertDialog.Builder(OTADFUActivity.this, R.style.MyDialogTheme);
        if (updateDSPVersionStr == null) {

            String versionCurrentStr = mcuCurrrentVersionVal+"."+ mcuCurrentSubVersionVal;

            ad.setMessage("MCU Current version :" + versionCurrentStr + "\r\n" +
                    "MCU Update version :"  + updateSubVersionStr);
        } else {

            String versionCurrentStr = mcuCurrrentVersionVal+"."+mcuCurrentSubVersionVal;

            String versionDspCurrentStr = dspCurrentVersionVal+"."+dspCurrentSubVersionVal;

            ad.setMessage("MCU Current version :" + versionCurrentStr + "\r\n" +
                    "DSP Current version :" + versionDspCurrentStr + "\r\n" +
                    "MCU Update version :" + updateSubVersionStr + "\r\n" +
                    "DSP Update version :" +  updateDSPVersionStr + "." + updateDSPSubVersionStr);

        }
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                backPressed();
            }
        });

        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (mFilePath != null) {
                    Intent i = new Intent(BLEService.OTA_ACTION_CONFIRM_UPDATE_FILE_RESPONSE);
                    sendBroadcast(i);
                    otaStartTime = getCurrentTimeString();
                } else {
                    Toast.makeText(OTADFUActivity.this, "Select File Before update", Toast.LENGTH_SHORT).show();
                }
            }
        });

        alert = ad.create();
        alert.setTitle("Confirm OTA update ?");
        alert.show();
    }

    private String getCurrentTimeString () {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.S aa");
        String formattedDate = dateFormat.format(new Date()).toString();
        return formattedDate.substring(10);
    }


    private BluetoothAdapter mBluetoothAdapter;

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            String action = intent.getAction();

            // It means the user has changed his bluetooth state.
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {


                if (mBluetoothAdapter.getState() == BluetoothAdapter.STATE_OFF) {
                    launchHomeScreen();
                    // The user bluetooth is already disabled.
                    return;
                }

            }
        }
    };



    private void launchHomeScreen() {

        try {
            Thread.sleep(500);

        } catch (java.lang.InterruptedException e) {
            e.printStackTrace();
        }

        runOnUiThread(new Runnable() {
            public void run() {

                try {
                    Thread.sleep(500);

                } catch (java.lang.InterruptedException e) {
                    e.printStackTrace();
                }

                Intent home = new Intent(getApplicationContext(), HomeLaunchDashboard.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }

}
