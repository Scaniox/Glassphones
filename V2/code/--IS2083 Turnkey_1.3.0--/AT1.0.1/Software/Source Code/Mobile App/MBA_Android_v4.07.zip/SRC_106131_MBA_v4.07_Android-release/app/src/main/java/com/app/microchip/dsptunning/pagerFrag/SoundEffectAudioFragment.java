package com.app.microchip.dsptunning.pagerFrag;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningMBDRCActivity;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;
import com.app.microchip.dsptunning.ui.DspTuningAudioPagerActivity;

import java.util.Arrays;

/**
 * Created by I17163 on 12/12/2019.
 */

public class SoundEffectAudioFragment extends Fragment implements DSPTuningDelegate {

    private static final String TAG = SoundEffectAudioFragment.class.getSimpleName();

    CheckBox MBDRC_checkbox;
    CheckBox AW_checkbox;
    CheckBox VB_checkbox;
    CheckBox AE_Mask_All_Off_checkbox;
    CheckBox AE_Mask_MBDRC_On;
    CheckBox AE_Mask_All_On_checkbox;
    CheckBox AE_Mask_AW_On_checkbox;
    Spinner Audio_Effect_table;
    Spinner AW_Level_table; //Audio Widening Level

    private Button TuneDSP;
    private TextView DSPState;
    private DspTuningAudioPagerActivity mActivity;
    private DspOTATunningBLEService mService;
    private Button MBDRC_Setting;

    String[] Audio_Effect_Data = {"All Off", "MB-DRC On", "All On", "AW On"};
    String[] AW_Level_Data = {"0x00:Lowest", "0x01", "0x02", "0x03", "0x04", "0x05", "0x06", "0x07",
            "0x08", "0x09", "0x0A", "0x0B", "0x0C", "0x0D", "0x0E", "0x0F:Highest"};

    byte[]  ids_1 = {1, 2, 3, 4};
    byte[]  ids_2 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};

    byte[] MBDRC_Prev_Data;

    private int audioEffectSlectIndex = 0;
    private int AWSelectIndex = 0;
    private boolean registerAgain = false;
    private long fragFocusStartTime = 0;

    public SoundEffectAudioFragment () {
        Log.d(TAG, "SoundEffectAudioFragment Constructor");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.sound_effect_audio_fragment, container, false);

        Log.d(TAG, "SoundEffectAudioFragment onCreateView");

        MBDRC_checkbox = (CheckBox) view.findViewById(R.id.checkBoxmbdrc);
        AW_checkbox = (CheckBox) view.findViewById(R.id.checkBoxAW);
        VB_checkbox = (CheckBox) view.findViewById(R.id.checkBoxVB);
        AE_Mask_All_Off_checkbox = (CheckBox) view.findViewById(R.id.alloff);
        AE_Mask_MBDRC_On = (CheckBox) view.findViewById(R.id.mbdrscheck);
        AE_Mask_All_On_checkbox = (CheckBox) view.findViewById(R.id.allon);
        AE_Mask_AW_On_checkbox = (CheckBox) view.findViewById(R.id.awon);
        Audio_Effect_table= (Spinner)view.findViewById(R.id.Spinner1);
        AW_Level_table = (Spinner)view.findViewById(R.id.Spinner2);

        DSPState =(TextView) view.findViewById(R.id.deviceStatus);
        TuneDSP = (Button) view.findViewById(R.id.tuneDspButton);
        MBDRC_Setting = (Button) view.findViewById(R.id.mbrcSettingbutton);

        MBDRC_checkbox.setEnabled(false);
        AW_checkbox.setEnabled(false);
        AE_Mask_All_Off_checkbox.setEnabled(false);
        AE_Mask_MBDRC_On.setEnabled(false);
        AE_Mask_All_On_checkbox.setEnabled(false);
        AE_Mask_AW_On_checkbox.setEnabled(false);
        Audio_Effect_table.setEnabled(false);

        //VB_checkbox.setEnabled(true);
        //AW_Level_table.setEnabled(true);

        return view;
                
    }
    public void initModule(DspTuningAudioPagerActivity act) {
        mActivity = act;

        mService = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        mService.setListener(SoundEffectAudioFragment.this);

        /*mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                initUI();            }
        }));*/

        initUI();

        mService.Get_Audio_DSP_Setting_MBDRC();

        fragFocusStartTime = System.currentTimeMillis();

    }

    public void cleanModule() {

    }


    public void onResume() {
        Log.d(TAG, "onResume of SoudEffect Audio Frag");

        if (registerAgain) {
            mService.setListener(SoundEffectAudioFragment.this);
            registerAgain = false;
            updateFunctionButtonsState();

        }

        super.onResume();
    }



    private void initUI () {

        if (DSPState!= null)
            DSPState.setText(mService.DSP_DUT_State);

        VB_checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

               @Override
               public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
                   Log.d(TAG,"VB_checkbox is isOn "+ isChecked);
                   if (mService.MBDRC_Data == null) {
                       Log.d(TAG, "mService.MBDRC_Data == null");
                       return;
                   }


                   long fragFocucEndTime =  System.currentTimeMillis();

                   long fragAutoEventTimeElapsed = fragFocucEndTime - fragFocusStartTime ;

                   Log.d(TAG,"VB_checkbox fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

                   if (fragAutoEventTimeElapsed > 2000) {
                       enableTuneDspButton();
                   }

                   if(isChecked == true && ((mService.MBDRC_Data[1]) & 0x40) == 0){
                       mService.MBDRC_Data[1] &= ~(0x40);
                       mService.MBDRC_Data[1] |= 0x40;
                   }
                    else if(isChecked == false && ((mService.MBDRC_Data[1]) & 0x40) == 0x40){
                       mService.MBDRC_Data[1] &= ~(0x40);
                   }
               }
           }
        );




        //AW_Level_table.optionIds = ids_2

        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, AW_Level_Data);

        AW_Level_table.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos,long id) {

                String displayStr= parent.getItemAtPosition(pos).toString();

                if (mService.MBDRC_Data == null) {
                    Log.d(TAG, "mService.MBDRC_Data == null");
                    return;
                }


                long fragFocucEndTime =  System.currentTimeMillis();

                long fragAutoEventTimeElapsed = fragFocucEndTime - fragFocusStartTime ;

                Log.d(TAG,"AW_Level_table fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

                if (fragAutoEventTimeElapsed > 2000) {
                    enableTuneDspButton();
                }

                if(pos == 0){
                    mService.MBDRC_Data[5] = (byte) 0x0F;
                }
                else if(pos == 1){
                    mService.MBDRC_Data[5] = (byte)0x1F;
                }
                else if(pos == 2){
                    mService.MBDRC_Data[5] = (byte)0x2F;
                }
                else if(pos == 3){
                    mService.MBDRC_Data[5] = (byte)0x3E;
                }
                else if(pos == 4){
                    mService.MBDRC_Data[5] = (byte)0x4E;
                }
                else if(pos == 5){
                    mService.MBDRC_Data[5] = (byte)0x5E;
                }
                else if(pos == 6){
                    mService.MBDRC_Data[5] = (byte)0x6D;
                }
                else if(pos == 7){
                    mService.MBDRC_Data[5] = (byte)0x7D;
                }
                else if(pos == 8){
                    mService.MBDRC_Data[5] = (byte) 0x8D;
                }
                else if(pos == 9){
                    mService.MBDRC_Data[5] = (byte)0x9C;
                }
                else if(pos == 10){
                    mService.MBDRC_Data[5] = (byte)0xAC ;
                }
                else if(pos == 11){
                    mService.MBDRC_Data[5] = (byte)0xBC;
                }
                else if(pos == 12){
                    mService.MBDRC_Data[5] = (byte)0xCB;
                }
                else if(pos == 13){
                    mService.MBDRC_Data[5] = (byte)0xDB;
                }
                else if(pos == 14){
                    mService.MBDRC_Data[5] = (byte)0xEA;
                }
                else if(pos == 15){
                    mService.MBDRC_Data[5] = (byte)0xF9;
                }
                Log.d(TAG, "MBDRC data[5] = " + mService.MBDRC_Data[5]);

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        AW_Level_table.setAdapter(adapter);




        ArrayAdapter<String> adapter1;
        adapter1 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, Audio_Effect_Data);

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Audio_Effect_table.setAdapter(adapter1);
        Audio_Effect_table.setSelection(0);

        if(mService.Audio_Config != null){
            SetAudioEffect();
        }


        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DSPTuning();
            }
        });

        MBDRC_Setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mActivity.getApplicationContext(), DspOTATunningMBDRCActivity.class);
                startActivity(intent);;
                registerAgain = true;
            }
        });

        disableTuneDspButton();

        updateFunctionButtonsState();



    }
    private void  enableTuneDspButton() {
        TuneDSP.setEnabled(true);
        TuneDSP.setTextColor(Color.WHITE);
    }

    private void  disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }

    private synchronized void updateFunctionButtonsState () {
        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {

                if(mService.dynamicToolMode == mService.TuneDSPMode_NotSupport || mService.dynamicToolMode == mService.TuneDSPMode_Voice){
                    AW_Level_table.setEnabled(false);
                    VB_checkbox.setEnabled(false);
                    MBDRC_Setting.setEnabled(false);
                    MBDRC_Setting.setTextColor(Color.LTGRAY);
                    disableTuneDspButton();
                }
                else if(mService.dynamicToolMode == mService.TuneDSPMode_Audio){
                    AW_Level_table.setEnabled(true);
                    VB_checkbox.setEnabled(true);
                    MBDRC_Setting.setEnabled(true);
                    MBDRC_Setting.setTextColor(Color.WHITE);

                }

            }

        }));
    }

    private void DSPTuning() {
        if(mService.MBDRC_Data != null) {
            mService.DSPTuning((byte) 0x0C, (byte) 0x02, (byte) mService.MBDRC_Data.length, mService.MBDRC_Data);
            mActivity.showSpinnerDialog(true);
        }
    }


    private void SetAudioEffect() {

        byte audio_effect_mask = 0;
        byte audio_effect = 0;


             //   (audio_effect_mask, audio_effect) = (DSPManager?.GetAudioEffect())!
        byte[] aud_eff_data = mService.GetAudioEffect();
        audio_effect_mask = aud_eff_data[0] ;
        audio_effect = aud_eff_data[1];


        //if(audio_effect_mask != 0 && audio_effect != 0) {
            Log.d(TAG, ("audio_effect_mask = "+ audio_effect_mask+"audio_effect ="+audio_effect));

            if((audio_effect_mask & 0x01) == 0x01){
                AE_Mask_All_Off_checkbox.setChecked(true);
            }
            else{
                AE_Mask_All_Off_checkbox.setChecked(false);
            }
           // AE_Mask_All_Off_checkbox.isUserInteractionEnabled = false

            if((audio_effect_mask & 0x02) == 0x02){
                AE_Mask_MBDRC_On.setChecked(true);
            }
            else{
                AE_Mask_MBDRC_On.setChecked(false);
            }
            //AE_Mask_MBDRC_On.isUserInteractionEnabled = false

            if((audio_effect_mask & 0x04) == 0x04){
                AE_Mask_All_On_checkbox.setChecked(true);
            }
            else{
                AE_Mask_All_On_checkbox.setChecked(false);
            }
           // AE_Mask_All_On_checkbox.isUserInteractionEnabled = false

            if((audio_effect_mask & 0x08) == 0x08){
                AE_Mask_AW_On_checkbox.setChecked(true);
            }
            else{
                AE_Mask_AW_On_checkbox.setChecked(false);
            }
            //AE_Mask_AW_On_checkbox.isUserInteractionEnabled = false

            int selectedIndex = audio_effect;
            Audio_Effect_table.setSelection(selectedIndex);
            /*if(audio_effect == 0x00) {
                Audio_Effect_table.text = "All Off";
            }
            else if(audio_effect == 0x01) {
                Audio_Effect_table.text = "MB-DRC On";
            }
            else if(audio_effect == 0x02) {
                Audio_Effect_table.text = "All On";
            }
            else if(audio_effect == 0x03) {
                Audio_Effect_table.text = "AW On";
            }

            Audio_Effect_table.isEnabled = false;*/
       // }


        //let (MBDRC_onoff, AW_onoff) = (DSPManager?.CheckAudioMBDRC_AW())!
        boolean[] mbrc_aw = mService.CheckAudioMBDRC_AW();
        boolean MBDRC_onoff = mbrc_aw[0] ;
        boolean AW_onoff = mbrc_aw[1];

        if(MBDRC_onoff){
            MBDRC_checkbox.setChecked(true);
        }
        else{
            MBDRC_checkbox.setChecked(false);
            //VB_checkbox.isUserInteractionEnabled = false;
        }
       // MBDRC_checkbox.isUserInteractionEnabled = false;

        if(AW_onoff){
            AW_checkbox.setChecked(true);
        }
        else{
            AW_checkbox.setChecked(false);
        }
        //AW_checkbox.isUserInteractionEnabled = false

       /* if(AW_Level_table.text == ""){
            self.DSPManager?.Get_Audio_DSP_Setting_MBDRC()
        }*/
    }

    public void MBDRC_Init(boolean isReset){
        Log.d(TAG,"MBDRC_Init");

        if(mService.MBDRC_Data != null) {
            //print("AW_Level index = \(Int(MBDRC_Data[5] >> 4))")

            //AW_Level_table.selectedIndex = Int(MBDRC_Data[5] >> 4)
            AWSelectIndex = (int)( (((mService.MBDRC_Data[5]) & 0xFF) >> 4));
            Log.d(TAG, "AW_Level index = " + AWSelectIndex);

            mActivity.runOnUiThread(new Thread(new Runnable() {
                @Override
                public void run() {
                    AW_Level_table.setSelection(AWSelectIndex);
                    Log.d(TAG, "AW_Level_table threholdSlectIndex=" + AWSelectIndex);

                }
            }));

            //AW_Level_tmp = DSPManager?.MBDRC_Data[5]
            //VB_tmp = ((DSPManager?.MBDRC_Data[1])! & 0x40)
            //print("VB_tmp = \(VB_tmp)")
            if (isReset) {
                MBDRC_Prev_Data = Arrays.copyOfRange(mService.MBDRC_Data, 0, mService.MBDRC_Data.length);
                Log.d(TAG, "MBDRC_Prev_Data = "+ HexTool.byteArrayToHexString(MBDRC_Prev_Data));
             }



            mActivity.runOnUiThread(new Thread(new Runnable() {
                @Override
                public void run() {
                    if(((mService.MBDRC_Data[1]) & 0x40) == 0x40){
                        VB_checkbox.setChecked(true);
                    }
                    else{
                        VB_checkbox.setChecked(false);
                    }
                }
            }));

        }
    }



    @Override
    public void onAttach(Context context) {
        Log.d(TAG, "SoundEffectAudioFragment onAttach");
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        Log.d(TAG, "SoundEffectAudioFragment onDetach");
        super.onDetach();
    }


    @Override
    public void BLE_ServiceReady() {

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] Data) {

        int k = 0;
        byte[] buffer = Data;

        //(dat as NSData).getBytes(&buffer, length: (dat as NSData).length)

        Log.d(TAG,"Parsing configuration data");

        while(k < buffer.length){
            byte len = buffer[k+2];
            //let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))

            byte[] param_dat = Arrays.copyOfRange(buffer, k+3, k+3+ len);;

            Log.d(TAG,"Offset = "+k+" module_id ="+buffer[k]+ "cfg_id ="+buffer[k+1]+
                    "data len = "+len+" dat = "+ HexTool.byteArrayToHexString(param_dat));

            if(buffer[k] == 12 && buffer[k+1] == 2){
                mService.MBDRC_Data = null;

                //ByteBuffer tempBB = ByteBuffer.allocate(10);
                for(int index=0; index< 8;index++)  {
                    //MBDRC_Data.append(buffer[index+k+3])
                    //DSPManager?.MBDRC_Data.append(buffer[index+k+3]);
                }

                mService.MBDRC_Data = Arrays.copyOfRange(buffer, k+3 , k+3+ 8);

                Log.d(TAG,"MBDRC len = "+mService.MBDRC_Data.length +  "data ="+
                                HexTool.byteArrayToHexString(mService.MBDRC_Data));

                MBDRC_Init(false);
                break;
            }

            k += (int)(3+len);
        }


    }
    private String  dspStatusMsgDialog= "";
    private void showTuneDspDialog(String message) {

        dspStatusMsgDialog = message;

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder ad = new AlertDialog.Builder(getActivity() , R.style.MyDialogTheme);
                ad.setMessage(dspStatusMsgDialog);

                ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
                sendBroadcast(i);
                  mOtaState.setText("Completed");*/
                    }
                });

                final AlertDialog  alert = ad.create();
                alert.setTitle("Tune DSP Status!!");
                alert.show();



                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {

                    }
                });

            }
        }));


    }
    @Override
    public void DSPTuningComplete(byte result) {
        String  status = "";

        mActivity.dismissSpinnerDialog();

        if(result == 0x01){
            status = "Success";
        }
        else{
            status = "Failed " + result;
        }

        showTuneDspDialog(status);

        if(result != 0x01){
            //LineIn_Config_Init(null, true);
        }
       // LineIn_Prev_Data = LineIn_Data;

        getActivity().runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                disableTuneDspButton();

            }
        }));
    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {
         mActivity.finish();
    }

    @Override
    public void DSPTuningState(String state) {
        Log.d(TAG, " DSPTuningState" + state);
        if (DSPState!= null)
            DSPState.setText(state);

        updateFunctionButtonsState();


    }

    @Override
    public void ExportDSPTuningResult() {

    }
}
