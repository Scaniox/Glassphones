package com.app.microchip.audiowidget.ota;

import android.annotation.SuppressLint;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import com.app.microchip.audiowidget.util.BLELog;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

@SuppressLint("SimpleDateFormat")
public class BLEService extends Service {
    public final static UUID SERVICE_UUID_DEVICE_INFO = BTUUID
            .uuidFromString("180A");
    public final static UUID CHAR_UUID_SERIAL_NUMBER = BTUUID
            .uuidFromString("2A25");


   // public final static UUID SERVICE_UUID_ISSC_AIR_PATCH_16 = BTUUID
           // .uuidFromString("49535343-C9D0-CC83-A44A-6FE238D06D33");

    public final static UUID SERVICE_UUID_ISSC_AIR_PATCH_16 = BTUUID
            .uuidFromString("49534343-C9D0-CC83-A44A-6FE238D06D66");

    public final static UUID NEW_CHAR_UUID_ISSC_AIR_PATCH_CTRL_PT = BTUUID
            .uuidFromString("49534343-ACA3-481C-91EC-D85E28A60318");
    public final static UUID NEW_CHAR_UUID_ISSC_AIR_PATCH_PACKET = BTUUID
            .uuidFromString("49534343-18E4-4149-BDD4-1A7610F6844F");


    public final static UUID SERVICE_UUID_ISSC_AIR_PATCH_16_BAK = BTUUID
            .uuidFromString("49535343-C9D0-CC83-A44A-6FE238D06D66");

    public final static UUID CHAR_UUID_ISSC_AIR_PATCH_CTRL_PT= BTUUID
            .uuidFromString("49535343-ACA3-481C-91EC-D85E28A60318");
    public final static UUID CHAR_UUID_ISSC_AIR_PATCH_PACKET= BTUUID
            .uuidFromString("49535343-18E4-4149-BDD4-1A7610F6844F");

    public final static int OTA_UPDATE_SUCCESS = 1;
    public final static int OTA_UPDATE_FAIL = 2;
    public final static int OTA_STATE_DISCONNECTED = 0;
    public final static int OTA_STATE_CONNECTED = 1;
    public final static int OTA_STATE_UPDATE_CONFIRM = 2;
    public final static int OTA_STATE_UPDATE = 3;
    public final static int OTA_STATE_VALIDATION = 4;
    public final static int OTA_STATE_VALIDATED = 5;
    private final static String TAG = BLEService.class.getSimpleName();
    private final static String PACKAGE = BLEService.class.getName();
    public final static String ACTION_GATT_CONNECTED = PACKAGE
            + "bluetooth.le.ACTION_GATT_CONNECTED";
    //AirPatch Control point
    public final static String ACTION_GATT_DISCONNECTED = PACKAGE
            + "bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED = PACKAGE
            + "bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_GATT_SERVICES_DISCOVERY_FAILED = PACKAGE
            + "bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED_FAILED";
    public final static String ACTION_DATA_AVAILABLE = PACKAGE
            + "bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String ACTION_CONNECT = PACKAGE
            + "bluetooth.le.ACTION_CONNECT";
    public final static String ACTION_DISCONNECT = PACKAGE
            + "bluetooth.le.ACTION_DISCONNECT";
    public final static String ACTION_LOG = PACKAGE + "bluetooth.le.ACTION_LOG";
    public final static String OTA_ACTION_UPDATE_FAILED = PACKAGE + "OTA_UPDATE_FAILED";
    public final static String OTA_ACTION_OPEN_FILE = PACKAGE + "OTA_OPEN_FILE";
    public final static String OTA_ACTION_CONFIRM_UPDATE_FILE = PACKAGE + "OTA_CONFIRM_UPDATE";
    public final static String OTA_ACTION_CONFIRM_UPDATE_FILE_RESPONSE = PACKAGE + "OTA_CONFIRM_UPDATE_RESPONSE";
    public final static String OTA_ACTION_START_REQUEST = PACKAGE + "OTA_START_REQUEST";
    public final static String OTA_ACTION_START_REQUEST_RESPONSE = PACKAGE + "OTA_START_REQUEST_RESPONSE";
    public final static String OTA_ACTION_INFO_REQUEST = PACKAGE + "OTA_INFO_REQUEST";
    public final static String OTA_ACTION_INFO_REQUEST_RESPONSE = PACKAGE + "OTA_INFO_REQUEST_RESPONSE";
    public final static String OTA_ACTION_INIT_REQUEST = PACKAGE + "OTA_INIT_REQUEST";
    public final static String OTA_ACTION_INIT_REQUEST_RESPONSE = PACKAGE + "OTA_INIT_REQUEST_RESPONSE";
    public final static String OTA_ACTION_UPDATE_REQUEST = PACKAGE + "OTA_UPDATE_REQUEST";
    public final static String OTA_ACTION_UPDATE_REQUEST_RESPONSE = PACKAGE + "OTA_UPDATE_REQUEST_RESPONSE";
    public final static String OTA_ACTION_VALIDATE_REQUEST = PACKAGE + "OTA_VALIDATE_REQUEST";
    public final static String OTA_ACTION_VALIDATE_REQUEST_RESPONSE = PACKAGE + "OTA_VALIDATE_REQUEST_RESPONSE";
    public final static String OTA_ACTION_END_REQUEST = PACKAGE + "OTA_END_REQUEST";
    public final static String OTA_ACTION_END_REQUEST_RESPONSE = PACKAGE + "OTA_END_REQUEST_RESPONSE";
    public final static String OTA_ACTION_COMPLETE_REQUEST = PACKAGE + "OTA_COMPLETE_REQUEST";
    public final static String OTA_ACTION_RESET_REQUEST = PACKAGE + "OTA_RESET_REQUEST";
    public final static String OTA_ACTION_UPDATE_PROGRESS = PACKAGE + "OTA_UPDATE_PROGRESS";
    public final static String OTA_ACTION_UPDATE_UI = PACKAGE + "OTA_UPDATE_UI";
    public final static String OTA_PARAMETER_IS_APP_INFO_REQUEST = PACKAGE + "OTA_IS_APP_INFO_REQUEST";
    public final static String OTA_PARAMETER_FILE_PATH = PACKAGE + "OTA_FILE_PATH";
    public final static String OTA_UPDATE_FAILED_RESPONSE = PACKAGE + "OTA_UPDATE_FAILED_RESPONSE";
    public final static String OTA_PROGRESS_VALUE = PACKAGE + "PROGRESS_VALUE";
    public final static String OTA_PARAMETER_IMAGE_TYPE = PACKAGE + "IMAGE_TYPE";
    public final static String OTA_PARAMETER_STATE_UPDATE = PACKAGE + "UI_UPDATE";
    public final static String OTA_PARAMETER_MCU_VERSION = PACKAGE + "MCU_VERSION";
    public final static String OTA_PARAMETER_MCU_SUB_VERSION = PACKAGE + "MCU_SUB_VERSION";
    public final static String OTA_PARAMETER_DSP_VERSION = PACKAGE + "DSP_VERSION";
    public final static String OTA_PARAMETER_DSP_SUB_VERSION = PACKAGE + "DSP_SUB_VERSION";
    public final static String OTA_PARAMETER_UPDATE_VERSION = PACKAGE + "MCU_UPDATE_VERSION";
    public final static String OTA_PARAMETER_UPDATE_SUB_VERSION = PACKAGE + "MCU_UPDATE_SUB_VERSION";
    public final static String OTA_PARAMETER_DSP_UPDATE_VERSION = PACKAGE + "DSP_UPDATE_VERSION";
    public final static String OTA_PARAMETER_DSP_UPDATE_SUB_VERSION = PACKAGE + "DSP_UPDATE_SUB_VERSION";
    //command set
    private final static byte OTA_OPCODE_RESPONSE = 0x01;
    private final static byte OTA_OPCODE_START_REQUEST = 0x02;
    private final static byte OTA_OPCODE_INFO_REQUEST = 0x03;
    private final static byte OTA_OPCODE_INIT_REQUEST = 0x04;
    private final static byte OTA_OPCODE_UPDATE_REQUEST = 0x05;
    private final static byte OTA_OPCODE_VALIDATE_REQUEST = 0x06;
    private final static byte OTA_OPCODE_END_REQUEST = 0x07;
    private final static byte OTA_OPCODE_RESET_REQUEST = 0x08;

    private final static byte OPCODE_RESPONSE_SUCCESS = 0x01;
    private final static byte OPCODE_RESPONSE_INAVALID_STATE = 0x02;
    private final static byte OPCODE_RESPONSE_NOT_SUPPORTED = 0x03;
    private final static byte OPCODE_RESPONSE_OPERATION_FAILED = 0x04;
    private final static byte OPCODE_RESPONSE_INAVLID_PARAMETER = 0x05;
    private  final static int DSP_CODE_SEGMENT_LEN = 262144;

    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;
    private final IBinder mBinder = new LocalBinder();
    private int UPDATE_IMAGE_MAX_SIZE = 512;
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private String mBluetoothDeviceAddress;
    private BluetoothGatt mBluetoothGatt;
    private int mConnectionState = STATE_DISCONNECTED;

    private BluetoothGattCharacteristic isscOTACtrlPtChar;
    private BluetoothGattCharacteristic isscOTAPacketChar;
    private byte[] serialNumber;
    private Queue<BluetoothGattDescriptor> descriptorWriteQueue = new LinkedList<BluetoothGattDescriptor>();
    private Queue<TempQueueObject> characteristicWriteQueue = new LinkedList<TempQueueObject>();


    private int OTA_TotalLength;
    private int CRC_Value = 0xffff;
    private int dspHeaderParseDataLen = 0;
    private int dspFlashHeaderLen = 0;
    private int userConfigLen = 0;
    private int fwCodeLen = 0;
    private int dspCodeLen = 0;
    private int voiceDataLen = 0;
    private int rawVoiceDataLen = 0;

    //private byte[] mRehexData = new byte[524288];
    private byte[] mRehexData = new byte[917504]; // 512+256+128 k
    private byte[] mRawVoiceData = new byte[917504];
    private byte[] mEncryptedRehexData;
    byte[] mDspHeaderParseData = new byte[4000];; //initialize
    byte[] mDspFlashHeader = new byte[4000];; //initialize
    private int mProccessedBytes = 0;
    private int mUpdateRequestImageSize = 0;
    private int MAX_MTU_DATA_SIZE = 0;
    private int OTA_MTU_SIZE = 0;
    private String mVersionStr = null ;
    private String mSubVersionStr = null;
    private String mDSPVersionStr = null ;
    private String mDSPSubVersionStr = null;
    //private String mMCUVersionStr = null ;
    //private String mMCUSubVersionStr = null;
    private boolean mResetRequest;
    private FlashHeader flashHeader = null ;

    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status,
                                            int newState) {
            String intentAction;
            BLELog.d(TAG, "onConnectionStateChange");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    intentAction = ACTION_GATT_CONNECTED;
                    mConnectionState = STATE_CONNECTED;
                    broadcastUpdate(intentAction);
                    BLELog.d(TAG, "Connected to GATT server.");

                    if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        BLELog.d(TAG, "Attempting Exchange MTU:" + mBluetoothGatt.requestMtu(247));
                    }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    intentAction = ACTION_GATT_DISCONNECTED;
                    mConnectionState = STATE_DISCONNECTED;
                    BLELog.d(TAG, "Disconnected from GATT server.");
                    broadcastUpdate(intentAction);
                    isscOTAPacketChar = null;
                    isscOTACtrlPtChar = null;
                }
            } else {
                BLELog.d(TAG, "GATT error code = " + status);
                broadcastUpdate(ACTION_GATT_DISCONNECTED);
            }
        }

        public void onMtuChanged(BluetoothGatt Gatt, int mtu, int status) {
            BLELog.d("onMtuChanged", "MTU: " + mtu + "status: " + status);
            BLELog.d(TAG, "Attempting to start service discovery:"
                    + mBluetoothGatt.discoverServices());
            OTA_MTU_SIZE = mtu;
            MAX_MTU_DATA_SIZE = OTA_MTU_SIZE - 3;
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            BLELog.d(TAG, "onServicesDiscovered status=" + status);
            List<BluetoothGattService> list = gatt.getServices();
            for (BluetoothGattService service : list) {
                BLELog.d(TAG, "Service:" + service.getUuid().toString());
            }
            if (status == BluetoothGatt.GATT_SUCCESS) {
                //  broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                BluetoothGattService service = gatt
                        .getService(SERVICE_UUID_DEVICE_INFO);
                if (service != null) {
                    for (BluetoothGattCharacteristic ch : service
                            .getCharacteristics()) {
                        if (ch.getUuid().equals(CHAR_UUID_SERIAL_NUMBER)) {
                            //mBluetoothGatt.readCharacteristic(ch);
                            characteristicWriteQueue.add(new TempQueueObject(ch, null, true));
                        }
                    }

                }

                service = gatt.getService(SERVICE_UUID_ISSC_AIR_PATCH_16);
                if (service != null) {
                    for (BluetoothGattCharacteristic ch : service.getCharacteristics()) {
                        if (ch.getUuid().equals(CHAR_UUID_ISSC_AIR_PATCH_CTRL_PT)) {
                            isscOTACtrlPtChar = ch;
                            setNotification(ch, true);
                            BLELog.d(TAG, "CHAR_UUID_ISSC_AIR_PATCH_CTRL_PT : SetNotification");
                        }
                        if (ch.getUuid().equals(CHAR_UUID_ISSC_AIR_PATCH_PACKET)) {
                            isscOTAPacketChar = ch;
                            BLELog.d(TAG, "CHAR_UUID_ISSC_AIR_PATCH_PACKET : Discovered");
                        }

                    }

                    broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                } else  {

                    broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERY_FAILED);

                }

            } else {
                BLELog.d(TAG, "onServicesDiscovered received: " + status);
                mBluetoothGatt.discoverServices();
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic, int status) {
            characteristicWriteQueue.remove();
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
                checkCharacteristicQueue();
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            //BLELog.d(TAG,"onCharacteristicChanged calling broadcastUpdate");
            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            checkCharacteristicQueue();
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt,
                                      BluetoothGattDescriptor descriptor, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                BLELog.d(TAG, "Callback: Wrote GATT Descriptor successfully.");
            } else {
                BLELog.d(TAG, "Callback: Error writing GATT Descriptor: " + status);
            }
            descriptorWriteQueue.remove(); //pop the item that we just finishing writing
            //if there is more to write, do it!
            if (descriptorWriteQueue.size() > 0)
                mBluetoothGatt.writeDescriptor(descriptorWriteQueue.element());
            else
                checkCharacteristicQueue();
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt,
                                          BluetoothGattCharacteristic characteristic, int status) {
            BLELog.d("onCharacteristicWrite", "onCharacteristicWrite");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                BLELog.d(TAG, "GattWrite callback: SUCCESS");
            } else {
                BLELog.d(TAG, "Callback: Error writing GATT Characteristic: "
                        + status);
            }
            if (characteristicWriteQueue.size() > 0) {
                characteristicWriteQueue.remove();
                checkCharacteristicQueue();
            }
        }
    };
    private int mCRCValue;
    //private Uri OTAFile_Uri;
    private int mImageType = -1;
    private boolean isAppInfoRequest = false;
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            BLELog.d(TAG, "BroadcastReceiver action: " + action);

            if (action.equals(ACTION_CONNECT)) {
                if (initialize()) {
                    String address = intent.getStringExtra("ADDRESS");
                    if (address != null) {
                        connect(address);
                    }
                }
            } else if (action.equals(ACTION_DISCONNECT)) {
                disconnect();
            } else if (action.equals(OTA_ACTION_OPEN_FILE)) {
                BLELog.d(TAG, " BroadcastReceiver OTA_ACTION_OPEN_FILE");
                OTAFile_AbsolutePath = intent.getStringExtra(OTA_PARAMETER_FILE_PATH);
                //OTAFile_Uri= intent.getData();
                //OTAFile_Uri = OTADFUActivity.mFileUri;
                mImageType = OTADFUActivity.MCU_IMAGE;
                boolean result = true;
               // result =  openFileMCU();

                new Timer().schedule(
                        new TimerTask() {
                            @Override
                            public void run() {

                                BLELog.v(TAG, "Handling in separate thread OTA_ACTION_OPEN_FILE");

                                boolean result = true;
                                result =  openFileMCU();
                                Intent intent = new Intent();

                                if (result) {

                                    int dspOtaLen = 0;
                                    int uiCfgOtaLen = 0;
                                    int mcuOtaLen = 0;

                                    if (flashHeader.isDSPupdateRequired) {
                                        OpenDSPVPFile();
                                        dspOtaLen = OTA_TotalLength;
                                    }

                                    if (flashHeader.isUICfgUpdateRequired) {
                                        openFileUiCfg();
                                        uiCfgOtaLen = OTA_TotalLength;
                                    }

                                    openFileMCU();
                                    mcuOtaLen = OTA_TotalLength;

                                    sendBroadcast(intent);
                                    OTAStartRequest();
                                    OTASendImageSize(mcuOtaLen,dspOtaLen,uiCfgOtaLen);

                                    intent.setAction(OTA_ACTION_UPDATE_UI);
                                    intent.putExtra(OTA_PARAMETER_STATE_UPDATE, OTA_STATE_CONNECTED);
                                } else {
                                    intent.setAction(OTA_ACTION_UPDATE_FAILED);
                                    intent.putExtra(OTA_UPDATE_FAILED_RESPONSE, "Update Failed: Error in File open!!");
                                    sendBroadcast(intent);
                                    return;
                                }

                            }
                        },
                        10);



            } else if (action.equals(OTA_ACTION_INFO_REQUEST)) {
                boolean value = intent.getBooleanExtra(BLEService.OTA_PARAMETER_IS_APP_INFO_REQUEST, false);
                isAppInfoRequest = value;
                BLELog.d(TAG, " BroadcastReceiver OTA_ACTION_INFO_REQUEST isAppInfoRequest ="+ isAppInfoRequest);
                OTAInfoRequest();
            } else if (action.equals(OTA_ACTION_INFO_REQUEST_RESPONSE)) {
                BLELog.d(TAG, " BroadcastReceiver OTA_ACTION_INFO_REQUEST_RESPONSE isAppInfoRequest"+ isAppInfoRequest);
                if (isAppInfoRequest == false) {
                    if (flashHeader.isMCUupdateRequired == true) {
                        intent.setAction(OTA_ACTION_UPDATE_UI);
                        intent.putExtra(OTA_PARAMETER_STATE_UPDATE, OTA_STATE_UPDATE_CONFIRM);
                        sendBroadcast(intent);
                        flashHeader.isMCUupdateRequired = false;
                    } else {
                        OTAInitRequest();
                        OTASendImageInfo();
                    }
                }else {
                    isAppInfoRequest = false;
                }
            } else if (action.equals(OTA_ACTION_CONFIRM_UPDATE_FILE_RESPONSE)) {
                BLELog.d(TAG, " BroadcastReceiver OTA_ACTION_CONFIRM_UPDATE_FILE_RESPONSE");
                OTAInitRequest();
                OTASendImageInfo();
            } else if (action.equals(OTA_ACTION_INIT_REQUEST_RESPONSE)) {
                BLELog.d(TAG, " BroadcastReceiver OTA_ACTION_INIT_REQUEST_RESPONSE");
                intent.setAction(OTA_ACTION_UPDATE_UI);
                intent.putExtra(OTA_PARAMETER_STATE_UPDATE, OTA_STATE_UPDATE);
                sendBroadcast(intent);
                OTAUpdateRequest();
                OTAUpdateImageFragment();
            } else if (action.equals(OTA_ACTION_UPDATE_REQUEST_RESPONSE)) {
                BLELog.d(TAG, " BroadcastReceiver OTA_ACTION_UPDATE_REQUEST_RESPONSE");
                if (mProccessedBytes < OTA_TotalLength) {
                    OTAUpdateRequest();
                    OTAUpdateImageFragment();
                } else {
                    intent.setAction(OTA_ACTION_UPDATE_UI);
                    intent.putExtra(OTA_PARAMETER_STATE_UPDATE, OTA_STATE_VALIDATION);
                    sendBroadcast(intent);
                    OTAValidateRequest();
                }
            } else if (action.equals(OTA_ACTION_VALIDATE_REQUEST_RESPONSE)) {
                BLELog.d(TAG, " BroadcastReceiver OTA_ACTION_VALIDATE_REQUEST_RESPONSE");
                intent.setAction(OTA_ACTION_UPDATE_UI);
                intent.putExtra(OTA_PARAMETER_STATE_UPDATE, OTA_STATE_VALIDATED);
                sendBroadcast(intent);

                byte status = intent.getByteExtra(OTA_ACTION_END_REQUEST_RESPONSE, (byte) 0);

                if (flashHeader.isDSPupdateRequired == true) {
                    mImageType = OTADFUActivity.DSP_IMAGE;
                    startNextUupdate();
                    flashHeader.isDSPupdateRequired = false;
                } else  if (flashHeader.isUICfgUpdateRequired == true) {

                    mImageType = OTADFUActivity.UI_CFG_IMAGE;
                    startNextUupdate();

                    flashHeader.isUICfgUpdateRequired = false;

                } else {
                    OTAEndRequest();
                }


            } else if (action.equals(OTA_ACTION_RESET_REQUEST)) {
                BLELog.d(TAG, " BroadcastReceiver OTA_ACTION_RESET_REQUEST");
                OTAResetRequest();


            } else if (action.equals(OTA_ACTION_END_REQUEST_RESPONSE)) {
                BLELog.d(TAG, " Received  OTA_ACTION_END_REQUEST_RESPONSE + isDSPupdateRequired =" +flashHeader.isDSPupdateRequired);
               // OTAResetRequest();

            }
        }
    };
    private void startNextUupdate () {
        if (flashHeader.dspVersionStr !=  null) {

            new Timer().schedule(
                    new TimerTask() {
                        @Override
                        public void run() {

                            BLELog.v(TAG, "Starting next update startNextUupdate");

                            Intent intent1 = new Intent();

                            mProccessedBytes = 0;
                            mUpdateRequestImageSize = 0;
                            boolean result = false;

                            if (mImageType == OTADFUActivity.DSP_IMAGE)
                             result = OpenDSPVPFile();
                            else if (mImageType == OTADFUActivity.UI_CFG_IMAGE)
                                result = openFileUiCfg();


                            if (result) {

                                intent1.setAction(OTA_ACTION_UPDATE_UI);
                                intent1.putExtra(OTA_PARAMETER_STATE_UPDATE, OTA_STATE_CONNECTED);
                                sendBroadcast(intent1);
                                OTAInitRequest();
                                OTASendImageInfo();
                            } else {
                                intent1.setAction(OTA_ACTION_UPDATE_FAILED);
                                intent1.putExtra(OTA_UPDATE_FAILED_RESPONSE, "Update Failed: Error in File open!!");
                                sendBroadcast(intent1);
                                return;
                            }

                        }
                    },
                    2000
            );
        }
    }

    private String OTAFile_AbsolutePath;

    private static IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();

        intentFilter.addAction(ACTION_CONNECT);
        intentFilter.addAction(ACTION_DISCONNECT);
        intentFilter.addAction(BLEService.OTA_ACTION_START_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_START_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_INFO_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_INFO_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_INIT_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_INIT_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_VALIDATE_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_VALIDATE_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_END_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_END_REQUEST_RESPONSE);
        intentFilter.addAction(BLEService.OTA_ACTION_RESET_REQUEST);
        intentFilter.addAction(BLEService.OTA_ACTION_OPEN_FILE);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_FAILED);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_PROGRESS);
        intentFilter.addAction(BLEService.OTA_ACTION_UPDATE_UI);
        intentFilter.addAction(BLEService.OTA_ACTION_CONFIRM_UPDATE_FILE_RESPONSE);

        return intentFilter;
    }

    public static boolean refreshDeviceCache(BluetoothGatt gatt) {
        try {
            Method localMethod = gatt.getClass().getMethod("refresh");
            if (localMethod != null) {
                return (Boolean) localMethod.invoke(gatt);
            }
        } catch (Exception localException) {
            BLELog.v(TAG, "Exeception occured while clearing cache");
        }
        return false;
    }

    public byte[] subArray(byte[] b, int offset, int length) {
        byte[] sub = new byte[length];
        for (int i = offset; i < offset + length; i++) {
            try {
                sub[i - offset] = b[i];
            } catch (Exception e) {

            }
        }
        return sub;
    }

    public void writeGattDescriptor(BluetoothGattDescriptor d) {
        //put the descriptor into the write queue
        descriptorWriteQueue.add(d);
        //if there is only 1 item in the queue, then write it.  If more than 1, we handle asynchronously in the callback above
        if (descriptorWriteQueue.size() == 1) {
            mBluetoothGatt.writeDescriptor(d);
        }
    }

    public void writeGattCharacteristic(BluetoothGattCharacteristic ch,
                                        byte[] data) {
        BLELog.d(TAG, "writeGattCharacteristic " + ch.getUuid().toString() + "  Value =" + HexTool.byteArrayToHexString(data));
        characteristicWriteQueue.add(new TempQueueObject(ch, data));
        if (characteristicWriteQueue.size() == 1
                && descriptorWriteQueue.size() == 0) {
            TempQueueObject temp = characteristicWriteQueue.peek();
            temp.write();
        }

    }

    public void checkCharacteristicQueue() {
        if (characteristicWriteQueue.size() > 0) {
            TempQueueObject temp = characteristicWriteQueue.peek();
            temp.write();
        }
    }

    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        sendBroadcast(intent);
    }

    private void broadcastUpdate(final String action, final String object) {
        final Intent intent = new Intent(action);
        intent.putExtra("DATA", object);
        sendBroadcast(intent);
    }

    private void broadcastUpdate(final String action,
                                 final BluetoothGattCharacteristic characteristic) {
        broadcastUpdate(ACTION_LOG, "IN: " + HexTool.byteArrayToHexString(characteristic.getValue()));

        byte status;
        byte commandID;

        final Intent intent = new Intent();

        if (characteristic.getService().getUuid().equals(SERVICE_UUID_ISSC_AIR_PATCH_16)) {
            if (characteristic.getUuid().equals(CHAR_UUID_ISSC_AIR_PATCH_CTRL_PT)) {
                BLELog.d(TAG, "Response/Notification from Server: " + HexTool.byteArrayToHexString(characteristic.getValue()));
                ByteBuffer bb = ByteBuffer.wrap(characteristic.getValue());
                bb.order(ByteOrder.LITTLE_ENDIAN);
                status = bb.get();
                commandID = bb.get();

                if (status == OTA_OPCODE_RESPONSE) {
                    byte value = bb.get();
                    if (value != OPCODE_RESPONSE_SUCCESS) {
                        intent.setAction(OTA_ACTION_UPDATE_FAILED);
                        intent.putExtra(OTA_UPDATE_FAILED_RESPONSE, HexTool.byteArrayToHexString(characteristic.getValue()));
                        sendBroadcast(intent);
                        return;
                    }
                    switch (commandID) {
                        case OTA_OPCODE_START_REQUEST:
                            intent.setAction(OTA_ACTION_INFO_REQUEST);
                            intent.putExtra(BLEService.OTA_PARAMETER_IS_APP_INFO_REQUEST, false);
                            sendBroadcast(intent);
                            break;
                        case OTA_OPCODE_INFO_REQUEST:
                            intent.setAction(OTA_ACTION_INFO_REQUEST_RESPONSE);
                            intent.putExtra(OTA_ACTION_INFO_REQUEST_RESPONSE, value);
                            byte[] version = new byte[2];
                            version[0] = bb.get();
                            version[1] = bb.get();
                            int data_value;
                            String mcu_version;
                            String mcu_sub_version;
                            //String mcu_versionStr;
                            //String mcu_sub_versionStr;
                            String dsp_version;
                            String dsp_sub_version;
                            data_value = version[0];
                            data_value = data_value << 8;
                            data_value = data_value | version[1];
                            BLELog.d(TAG, "Receiver Buffer size =" + data_value);
                            UPDATE_IMAGE_MAX_SIZE = data_value;
                            version[0] = bb.get();
                            version[1] = bb.get();
                            data_value = version[0];
                            data_value = data_value << 8;
                            data_value = data_value | version[1];
                            mcu_version = HexTool.byteArrayToHexString(version);
                            BLELog.d(TAG, "MCU version =" + mcu_version);

                            version[0] = bb.get();
                            version[1] = bb.get();
                            mcu_sub_version = HexTool.byteArrayToHexString(version);
                            BLELog.d(TAG, "MCU sub Version =" + mcu_sub_version);
                            version[0] = bb.get();
                            version[1] = bb.get();
                            dsp_version = HexTool.byteArrayToHexString(version);
                            BLELog.d(TAG, "DSP Version =" + dsp_version);
                            version[0] = bb.get();
                            version[1] = bb.get();
                            dsp_sub_version = HexTool.byteArrayToHexString(version);
                            BLELog.d(TAG, "DSP sub =" + dsp_sub_version);
                            intent.putExtra(OTA_PARAMETER_MCU_VERSION, mcu_version);
                            intent.putExtra(OTA_PARAMETER_MCU_SUB_VERSION, mcu_sub_version);
                            intent.putExtra(OTA_PARAMETER_DSP_VERSION, dsp_version);
                            intent.putExtra(OTA_PARAMETER_DSP_SUB_VERSION, dsp_sub_version);
                            if ((null != flashHeader) && (null != flashHeader.mcuVersionStr)) {
                                intent.putExtra(OTA_PARAMETER_UPDATE_VERSION, flashHeader.mcuVersionStr);
                                intent.putExtra(OTA_PARAMETER_UPDATE_SUB_VERSION, flashHeader.mcuSubVersionStr);
                            }
                            if ((null != flashHeader) && (null != flashHeader.dspVersionStr)) {
                                intent.putExtra(OTA_PARAMETER_DSP_UPDATE_VERSION, flashHeader.dspVersionStr);
                                intent.putExtra(OTA_PARAMETER_DSP_UPDATE_SUB_VERSION, flashHeader.dspSubVersionStr);
                            }
                            sendBroadcast(intent);

                            break;
                        case OTA_OPCODE_INIT_REQUEST:
                            intent.setAction(OTA_ACTION_INIT_REQUEST_RESPONSE);
                            intent.putExtra(OTA_ACTION_INIT_REQUEST_RESPONSE, value);
                            sendBroadcast(intent);
                            break;
                        case OTA_OPCODE_UPDATE_REQUEST:
                            if ((mProccessedBytes % 5120) == 0 || mProccessedBytes == OTA_TotalLength) {
                                int progressValue;
                                if (mProccessedBytes != OTA_TotalLength)
                                    progressValue = (int) (mProccessedBytes * 100) / OTA_TotalLength;
                                else
                                    progressValue = 100;
                                intent.setAction(OTA_ACTION_UPDATE_PROGRESS);
                                intent.putExtra(OTA_PROGRESS_VALUE, progressValue);
                                sendBroadcast(intent);
                            }
                            intent.setAction(OTA_ACTION_UPDATE_REQUEST_RESPONSE);
                            intent.putExtra(OTA_ACTION_UPDATE_REQUEST_RESPONSE, value);
                            sendBroadcast(intent);
                            break;
                        case OTA_OPCODE_VALIDATE_REQUEST:
                            intent.setAction(OTA_ACTION_VALIDATE_REQUEST_RESPONSE);
                            intent.putExtra(OTA_ACTION_VALIDATE_REQUEST_RESPONSE, value);
                            sendBroadcast(intent);
                            break;
                        case OTA_OPCODE_END_REQUEST:
                            intent.setAction(OTA_ACTION_END_REQUEST_RESPONSE);
                            intent.putExtra(OTA_ACTION_END_REQUEST_RESPONSE, value);
                            sendBroadcast(intent);
                            break;
                        default:
                            BLELog.d(TAG, "Default opcode " + commandID);
                            break;
                    }
                }
            }
        }
        if (characteristic.getUuid().equals(CHAR_UUID_SERIAL_NUMBER)) {
            serialNumber = characteristic.getValue();
            intent.putExtra("SN", new String(serialNumber));
            sendBroadcast(intent);
        }
    }

    public boolean initialize() {
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                BLELog.d(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            BLELog.d(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        return true;
    }

    public boolean connect(final String address) {
        if (mBluetoothAdapter == null || address == null) {
            return false;
        }
        BluetoothDevice mDevice = mBluetoothAdapter
                .getRemoteDevice(address);

        if (getConnectionState(mDevice) == BluetoothProfile.STATE_CONNECTED) {
            BLELog.d(TAG, "Its Already Connected");
            if (mBluetoothGatt != null) {
                mBluetoothGatt.connect();
                return true;
            }
        }
        if (mBluetoothGatt != null)
            mBluetoothGatt.close();
        mBluetoothGatt = mDevice.connectGatt(OTADFUActivity.getInstance(), true, mGattCallback, BluetoothDevice.TRANSPORT_LE);
        refreshDeviceCache(mBluetoothGatt);
        mBluetoothDeviceAddress = address;

        mConnectionState = STATE_CONNECTING;
        return true;
    }

    public int getConnectionState(BluetoothDevice device) {
        BluetoothManager mgr = (BluetoothManager) OTADFUActivity.getInstance().getSystemService(Context.BLUETOOTH_SERVICE);
        return mgr.getConnectionState(device, BluetoothProfile.GATT);
    }

    /**
     * Disconnects an existing connection or cancel a pending connection. The
     * disconnection result is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public void disconnect() {
        try {
            if (mBluetoothAdapter == null || mBluetoothGatt == null) {
                return;
            }
            mBluetoothGatt.disconnect();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    try {
                        if (mBluetoothGatt != null) {
                            mBluetoothGatt.close();
                            mBluetoothGatt = null;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // mBluetoothGatt = null;
    }

    /**
     * After using a given BLE device, the app must call this method to ensure resources are
     * released properly.
     */
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        close();
        return super.onUnbind(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        registerReceiver(mGattUpdateReceiver, makeIntentFilter());

    }
    @Override
    public void onDestroy() {
        if (mConnectionState != STATE_DISCONNECTED) {
            disconnect();
        }
        close();
        unregisterReceiver(mGattUpdateReceiver);
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    private void setNotification(BluetoothGattCharacteristic characteristic,
                                 Boolean b) {
        BLELog.d(TAG, "setNotification  b: " + b);
        mBluetoothGatt.setCharacteristicNotification(characteristic, b);
        BluetoothGattDescriptor descriptor = characteristic
                .getDescriptor(BTUUID.uuidFromString("2902"));
        if (descriptor != null) {
            if (b) {
                if ((characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                } else {
                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                }
            } else {
                descriptor.setValue(BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
            }
            writeGattDescriptor(descriptor);
        }

    }

    private ByteBuffer prepareOutputBuffer(byte commend) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(20);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        tempBuffer.put(commend);
        return tempBuffer;
    }

    private ByteBuffer prepareOutputBuffer(byte commend, int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        tempBuffer.put(commend);
        return tempBuffer;
    }

    private ByteBuffer prepareOutputBuffer(int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        return tempBuffer;
    }


    private void OTAStartRequest() {
        if (isscOTACtrlPtChar == null) {
            BLELog.d(TAG, " OTAStartRequest Fail isscOTACtrlPtChar is null");
            return;
        }
        BLELog.d(TAG, "OTAStartRequest");
        ByteBuffer buffer = prepareOutputBuffer(OTA_OPCODE_START_REQUEST, 1);
        writeGattCharacteristic(isscOTACtrlPtChar, buffer.array());
    }

    private void OTASendImageSize(int mcu_ota_len, int dsp_ota_len, int uicfg_ola_len) {
        if (isscOTAPacketChar == null) {
            BLELog.d(TAG, " OTASendImageSize Fail isscOTAPacketChar is null");
            return;
        }

        BLELog.d(TAG, "OTASendImageSize"+ "mcu_ota_len="+ mcu_ota_len+ "dsp_ota_len="+dsp_ota_len+
                        "uicfg_ola_len="+ uicfg_ola_len);

        int sizeindex = 0;
        //if (mImageType == OTADFUActivity.DSP_IMAGE)
         //   sizeindex = 4;

        ByteBuffer buffer = prepareOutputBuffer(13);
        buffer.put(sizeindex++, (byte) ((mcu_ota_len >> 24) & 0XFF));
        buffer.put(sizeindex++, (byte) ((mcu_ota_len >> 16) & 0xFF));
        buffer.put(sizeindex++, (byte) ((mcu_ota_len >> 8) & 0xFF));
        buffer.put(sizeindex, (byte) (mcu_ota_len & 0xFF));

        sizeindex = 4;
        //OpenDSPVPFile();
        //OTA_TotalLength = 273024;
        buffer.put(sizeindex++, (byte) ((dsp_ota_len >> 24) & 0XFF));
        buffer.put(sizeindex++, (byte) ((dsp_ota_len >> 16) & 0xFF));
        buffer.put(sizeindex++, (byte) ((dsp_ota_len >> 8) & 0xFF));
        buffer.put(sizeindex, (byte) (dsp_ota_len & 0xFF));

        sizeindex = 8;
       // OTA_TotalLength = 8192;
        buffer.put(sizeindex++, (byte) ((uicfg_ola_len >> 24) & 0XFF));
        buffer.put(sizeindex++, (byte) ((uicfg_ola_len >> 16) & 0xFF));
        buffer.put(sizeindex++, (byte) ((uicfg_ola_len >> 8) & 0xFF));
        buffer.put(sizeindex, (byte) (uicfg_ola_len & 0xFF));

       // OTA_TotalLength = 524288;

        writeGattCharacteristic(isscOTAPacketChar, buffer.array());
    }

    private void OTASendImageInfo() {
        if (isscOTAPacketChar == null)
            return;

        if (mImageType == OTADFUActivity.DSP_IMAGE) {
            int size = 0;
            size = 2 + 2 + dspFlashHeaderLen;


            int startIndex = 0; // first time CRC and Lentth takesh 4 bytes
            int totalDataSizeRemaining = dspFlashHeaderLen ;

            int SEND_IMAGE_INFO_MTU = MAX_MTU_DATA_SIZE - 4;
            boolean isFirstPacketWrite =  true;

            if (size > MAX_MTU_DATA_SIZE)
                size = MAX_MTU_DATA_SIZE;

            BLELog.d(TAG, "OTASendImageInfo DSP " + "size =" + size);
            ByteBuffer buffer = prepareOutputBuffer(size);
            buffer.put((byte) (mCRCValue >> 8));//CRC
            buffer.put((byte) (mCRCValue & 0xff));//CRC
            buffer.put((byte) (dspFlashHeaderLen >> 8));//Header len
            buffer.put((byte) (dspFlashHeaderLen & 0xff));//Header len

            BLELog.d(TAG, "OTASendImageInfo" + "SEND_IMAGE_INFO_MTU =" + SEND_IMAGE_INFO_MTU);

             while (startIndex < dspFlashHeaderLen  ) {
                  //chunkSize = dspFlashHeaderLen - startIndex;

                 if (totalDataSizeRemaining >= (SEND_IMAGE_INFO_MTU)) {
                     buffer.put(mDspFlashHeader, startIndex , SEND_IMAGE_INFO_MTU);
                     byte[] charData = buffer.array().clone();
                     writeGattCharacteristic(isscOTAPacketChar, charData);
                     BLELog.d(TAG, "DSP header flash header write size =" + charData.length);
                     startIndex += (SEND_IMAGE_INFO_MTU);
                     buffer.clear();
                     totalDataSizeRemaining -=  SEND_IMAGE_INFO_MTU;
                     size = totalDataSizeRemaining;
                     if (size > MAX_MTU_DATA_SIZE)
                         size = MAX_MTU_DATA_SIZE;
                     buffer = prepareOutputBuffer(size);
                     BLELog.d(TAG, "OTASendImageInfo DSP " + "Next buffer size =" + size);
                     BLELog.d(TAG, "OTASendImageInfo DSP " + "totalDataSizeRemaining =" + totalDataSizeRemaining);

                 } else {
                     buffer.put(mDspFlashHeader, startIndex , totalDataSizeRemaining);
                     writeGattCharacteristic(isscOTAPacketChar, buffer.array());
                     BLELog.d(TAG, "DSP header flash header Final Chunk write size =" + buffer.array().length);
                     break;
                 }

                 if (isFirstPacketWrite) {
                     SEND_IMAGE_INFO_MTU = SEND_IMAGE_INFO_MTU + 4;
                     isFirstPacketWrite = false;
                 }
             }

        } else {

            BLELog.d(TAG, "OTASendImageInfo MCU " + "size =" + "2");
            ByteBuffer buffer = prepareOutputBuffer(2);
            buffer.put((byte) (mCRCValue >> 8));//MCU
            buffer.put((byte) (mCRCValue & 0xff));//MCU

            writeGattCharacteristic(isscOTAPacketChar, buffer.array());
        }

    }

    private void OTAUpdateImageFragment() {
        BLELog.d(TAG, "OTAUpdateImageFragment");
        mUpdateRequestImageSize = 0;
        while (mUpdateRequestImageSize < UPDATE_IMAGE_MAX_SIZE) {
            if ((OTA_TotalLength - mProccessedBytes) > (MAX_MTU_DATA_SIZE)) {
                if ((UPDATE_IMAGE_MAX_SIZE - mUpdateRequestImageSize) > MAX_MTU_DATA_SIZE)
                    updateImage(MAX_MTU_DATA_SIZE);
                else
                    updateImage(UPDATE_IMAGE_MAX_SIZE - mUpdateRequestImageSize);
            } else {
                updateImage(OTA_TotalLength - mProccessedBytes);
                mUpdateRequestImageSize = UPDATE_IMAGE_MAX_SIZE; //update total length as 512
            }

        }
    }

    private void updateImage(int size) {
        BLELog.d(TAG, "updateImage size=" + size + " And ProcessedBytes=" + mProccessedBytes);
        if (isscOTAPacketChar == null)
            return;
        ByteBuffer buffer = prepareOutputBuffer(size); //put fragment length
        for (int i = mProccessedBytes; i < mProccessedBytes + size; i++) {
            buffer.put(mRehexData[i]);
        }
        mProccessedBytes = mProccessedBytes + size;
        mUpdateRequestImageSize = mUpdateRequestImageSize + size;
        writeGattCharacteristic(isscOTAPacketChar, buffer.array());
    }

    private void OTAInfoRequest() {
        if (isscOTACtrlPtChar == null)
            return;
        BLELog.d(TAG, "OTAInfoRequest");
        ByteBuffer buffer = prepareOutputBuffer(OTA_OPCODE_INFO_REQUEST, 1);
        writeGattCharacteristic(isscOTACtrlPtChar, buffer.array());
    }

    private void OTAInitRequest() {
        if (isscOTACtrlPtChar == null)
            return;
        BLELog.d(TAG, "OTAInitRequest");
        ByteBuffer buffer = prepareOutputBuffer(OTA_OPCODE_INIT_REQUEST, 2);
        if (mImageType == OTADFUActivity.MCU_IMAGE)
            buffer.put((byte) 0x01);
        else if (mImageType == OTADFUActivity.DSP_IMAGE)
            buffer.put((byte) 0x02);
        else if (mImageType == OTADFUActivity.UI_CFG_IMAGE)
            buffer.put((byte) 0x03);

        writeGattCharacteristic(isscOTACtrlPtChar, buffer.array());
    }

    private void OTAUpdateRequest() {
        if (isscOTACtrlPtChar == null)
            return;
        BLELog.d(TAG, "OTAUpdateRequest");
        ByteBuffer buffer = prepareOutputBuffer(OTA_OPCODE_UPDATE_REQUEST, 1);
        writeGattCharacteristic(isscOTACtrlPtChar, buffer.array());
    }

    private void OTAValidateRequest() {
        if (isscOTACtrlPtChar == null)
            return;
        BLELog.d(TAG, "OTAValidateRequest");
        ByteBuffer buffer = prepareOutputBuffer(OTA_OPCODE_VALIDATE_REQUEST, 1);
        writeGattCharacteristic(isscOTACtrlPtChar, buffer.array());
    }

    private void OTAEndRequest() {
        if (isscOTACtrlPtChar == null)
            return;
        BLELog.d(TAG, "OTAEndRequest");
        ByteBuffer buffer = prepareOutputBuffer(OTA_OPCODE_END_REQUEST, 1);
        writeGattCharacteristic(isscOTACtrlPtChar, buffer.array());
    }

    private void OTAResetRequest() {
        if (isscOTACtrlPtChar == null)
            return;
        BLELog.d(TAG, "OTAResetRequest");
        mResetRequest = true;
        ByteBuffer buffer = prepareOutputBuffer(OTA_OPCODE_RESET_REQUEST, 1);
        writeGattCharacteristic(isscOTACtrlPtChar, buffer.array());
    }

    //private int OTA_Update_CRC(byte data)
    private void OTA_Update_CRC(byte data) {
        int CRC_table[] = {0x0000, 0x1081, 0x2102, 0x3183,
                0x4204, 0x5285, 0x6306, 0x7387,
                0x8408, 0x9489, 0xa50a, 0xb58b,
                0xc60c, 0xd68d, 0xe70e, 0xf78f
        };

        CRC_Value = (CRC_Value >> 4) ^ CRC_table[(CRC_Value ^ data) & 0x0f];
        CRC_Value = (CRC_Value >> 4) ^ CRC_table[(CRC_Value ^ (data >> 4)) & 0x0f];
    }

    private int OTA_Finish_CRC() {
        int tmp = CRC_Value;
        tmp = ((tmp & 0xFF00) >> 8) | ((tmp & 0x00FF) << 8);
        tmp = ((tmp & 0xF0F0) >> 4) | ((tmp & 0x0F0F) << 4);
        tmp = ((tmp & 0xCCCC) >> 2) | ((tmp & 0x3333) << 2);
        tmp = ((tmp & 0xAAAA) >> 1) | ((tmp & 0x5555) << 1);
        return tmp;
    }


    private int CRC_CalculateFinish() {
        int tmp = OTA_Finish_CRC();
        CRC_Value = 0xffff;
        return tmp;
    }

    private String getEncryptionKey () {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("ENCRYPT_PREF", 0); // 0 - for private mode
        return pref.getString("encrypt_key", OTADFUActivity.DEFAULT_KEY); // getting String

    }

    private boolean OpenFile() {

        File file = new File(OTAFile_AbsolutePath);

        BLELog.d("BLEService.java", "OpenFile OTAFile_AbsolutePath " + OTAFile_AbsolutePath);
        BLELog.d(TAG, "***Open File : " + OTAFile_AbsolutePath);

        if ((OTAFile_AbsolutePath.length() == 0) || (OTAFile_AbsolutePath.equals(""))) {
            BLELog.d(TAG, "File Path Error!");
            return false;
        }

        int fileDataLen = (int) file.length();
        if (!file.exists()) {
            BLELog.d(TAG, "OpenFile fail, file not exist!");
            return false;
        }

        byte[] fileData = new byte[fileDataLen];
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            DataInputStream dis = new DataInputStream(fis);
            dis.readFully(fileData);        //Read all
            dis.close();

            BLELog.d(TAG, "RAW Rehex file size = " + fileDataLen);

        } catch (IOException e) {
            e.printStackTrace();
        }


        int cnt = 0;
        int m = 0;
        /*while (cnt < 5) {
            if (fileData[m++] == '\n')
                cnt++;
        }*/

        int index = 0;
        int z =0;
        boolean isVersionFound = false;
        Arrays.fill( mRehexData, (byte) 0 );
        OTA_TotalLength = 0;
        int extendedAddress = 0;

        for (; m < fileData.length; m++) {
            if (fileData[m] == ':') {
                byte byetCount;
                byte recordType;
                int address;

                m = m + 1;
                //parse byte Count
                if (z < 10)
                    BLELog.d(TAG, "Parse line = " + HexTool.byteArrayToHexString(subArray(fileData, m, 42)));

                byetCount = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                byetCount = (byte) ((byetCount) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                address = 0;


                address = (((int) getCharFromASCII(fileData[m++]))) << 12;
                address |= (((int) getCharFromASCII(fileData[m++])) << 8);
                address |= (((int) getCharFromASCII(fileData[m++])) << 4);
                address |= ((int) getCharFromASCII(fileData[m++]));


                if (z++ < 10)
                    BLELog.d(TAG, "Balaji Shift char address  = " + address);



                /*BLELog.d(TAG, "3 address  = " + address);
                BLELog.d(TAG, "3 Hex address  = " + Long.toHexString(address));

                BLELog.d(TAG, "4 address  = " + address);
                BLELog.d(TAG, "4 Hex address  = " + Long.toHexString(address));

                BLELog.d(TAG, "5 address  = " + address);
                BLELog.d(TAG, "5 Hex address  = " + Long.toHexString(address));*/

                //parse record type
                recordType = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                recordType = (byte) ((recordType) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                if (recordType == 0x04) {
                    extendedAddress = (((int) (getCharFromASCII(fileData[m++]))) << 12);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 8);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 4);
                    extendedAddress |= (int) getCharFromASCII(fileData[m++]);
                    BLELog.d(TAG, "MCU  record extendedAddress  = " + extendedAddress);
                    continue;
                } else {
                    address |= (extendedAddress << 16);
                }

                if (recordType != 0x00){//non data {
                    BLELog.d(TAG, "MCU  recordType != 0x00 " );
                    continue;
                }
                int endRowIndex = 0;

                // BLELog.d(TAG, "address  = " + address);

                // BLELog.d(TAG, "Hex address  = " + Long.toHexString(address));

                if (byetCount == 0x10) {


                    if ((0x000021F0 == (address & 0x000021F0)/*8688*/) && (isVersionFound == false)) {

                        int versionInd = m + 24;
                        mVersionStr = null;
                        //byte[] parseByteArr =  new byte[2];
                        /*mVersion = (((int)getCharFromASCII(fileData[versionInd++]))) << 12;
                        mVersion += (((int)getCharFromASCII(fileData[versionInd++])) << 8);
                        mVersion += (((int)getCharFromASCII(fileData[versionInd++])) << 4);
                        mVersion +=  ((int) getCharFromASCII(fileData[versionInd++]));

                        //int versionSubInd = m + 28;
                        mSubVersion = 0;

                        mSubVersion = (((int)getCharFromASCII(fileData[versionInd++]))) << 12;
                        mSubVersion += (((int)getCharFromASCII(fileData[versionInd++])) << 8);
                        mSubVersion += (((int)getCharFromASCII(fileData[versionInd++])) << 4);
                        mSubVersion +=  ((int) getCharFromASCII(fileData[versionInd++]));*/

                        byte[] versionBytes = new byte[2];
                        versionBytes[0] = (byte) ((getCharFromASCII(fileData[versionInd++])) << 4);
                        versionBytes[0] = (byte) ((versionBytes[0]) | ((getCharFromASCII(fileData[versionInd++])) & 0X0F));

                        versionBytes[1] = (byte) ((getCharFromASCII(fileData[versionInd++])) << 4);
                        versionBytes[1] = (byte) ((versionBytes[1]) | ((getCharFromASCII(fileData[versionInd++])) & 0X0F));

                        byte[] versionSubBytes = new byte[2];
                        versionSubBytes[0] = (byte) ((getCharFromASCII(fileData[versionInd++])) << 4);
                        versionSubBytes[0] = (byte) ((versionSubBytes[0]) | ((getCharFromASCII(fileData[versionInd++])) & 0X0F));

                        versionSubBytes[1] = (byte) ((getCharFromASCII(fileData[versionInd++])) << 4);
                        versionSubBytes[1] = (byte) ((versionSubBytes[1]) | ((getCharFromASCII(fileData[versionInd++])) & 0X0F));

                        mVersionStr = HexTool.byteArrayToHexString(versionBytes);
                        mSubVersionStr = HexTool.byteArrayToHexString(versionSubBytes);

                        BLELog.d(TAG, "MCU xVersionString = " + mVersionStr);
                        BLELog.d(TAG, "MCU mSubVersionStr  = " + mSubVersionStr);


                        if(!mVersionStr.contains("FF") && !mVersionStr.contains("ff")) {
                            isVersionFound = true;
                        } else
                            isVersionFound = false;

                        // BLELog.d(TAG, " Version = " + mVersion);
                        // BLELog.d(TAG, " Sub Version = " + mSubVersion);

                    }

                    endRowIndex = m + 32; //32 bytes data (16 bytes)


                } else if (byetCount == 0x02)
                    endRowIndex = m + 4; //4 bytes data (2 bytes)

                if(address >= 0x00010000 && address < 0x0008FFFF) {

                    while (m < endRowIndex) {
                       /* mRehexData[index] = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        mRehexData[index] = (byte) ((mRehexData[index]) | ((getCharFromASCII(fileData[m++])) & 0X0F));
                        */

                        byte rawData ;

                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        rawData = (byte) ((rawData) |
                                ((getCharFromASCII(fileData[m++])) & 0X0F));


                        //if ((rawData & 0xFF)  != 0xFF ) {
                        mRehexData[index] = rawData;
                        index++;
                        //}
                    }
                }

            }
        }

        OTA_TotalLength = index;
        BLELog.d(TAG, "ReHexed data length = " + OTA_TotalLength);

        Thread thread = new Thread(new Runnable(){
            @Override
            public void run(){



                // DO encryption
                //byte[] keyHex = {  0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, };
                byte[] keyHex = HexTool.hexStringToByteArray(getEncryptionKey());
                byte[] ivHex = HexTool.hexStringToByteArray(getEncryptionIV());

                //  BLELog.d(TAG, "Image Data Before encyption = " + HexTool.byteArrayToHexString(dataSample));
                // IV internally used for encryption byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, };

                mEncryptedRehexData = new byte[OTA_TotalLength];

                try {
                    mEncryptedRehexData = OTAEncrypt.AESCryptEX(subArray(mRehexData, 0 , OTA_TotalLength ), keyHex, ivHex);
                } catch (Exception e) {
                    e.printStackTrace();

                }

                BLELog.d(TAG, "Sample Data after encyption = " + HexTool.byteArrayToHexString( mEncryptedRehexData));

            }
        });
        thread.start();


        for (int k = 0; k < OTA_TotalLength; k++) {
            OTA_Update_CRC(mRehexData[k]);
        }
        mCRCValue = CRC_CalculateFinish();
        BLELog.d(TAG, String.format("CRC = 0x%x", mCRCValue));

        return true;
    }


    private String getEncryptionIV () {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("ENCRYPT_PREF", 0); // 0 - for private mode
         return pref.getString("encrypt_iv", OTADFUActivity.DEFAULT_IV); // getting String

    }

    private boolean OpenDSPFile() {

        File file = new File(OTAFile_AbsolutePath);

        BLELog.d("BLEService.java", "DSP OpenFile OTAFile_AbsolutePath " + OTAFile_AbsolutePath);
        BLELog.d(TAG, "*** DSP Open File : " + OTAFile_AbsolutePath);

        if ((OTAFile_AbsolutePath.length() == 0) || (OTAFile_AbsolutePath.equals(""))) {
            BLELog.d(TAG, "File Path Error!");
            return false;
        }

        int fileDataLen = (int) file.length();
        if (!file.exists()) {
            BLELog.d(TAG, "DSP OpenFile fail, file not exist!");
            return false;
        }

        byte[] fileData = new byte[fileDataLen];
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            DataInputStream dis = new DataInputStream(fis);
            dis.readFully(fileData);        //Read all
            dis.close();

            BLELog.d(TAG, " DSP RAW Rehex file size = " + fileDataLen);

        } catch (IOException e) {
            e.printStackTrace();
        }


        int m = 0;

        //int index = 0;
        int z =0;
        boolean isVersionFound = false;
        int extendedAddress = 0;
        int  headerStartAddress = 0;
        int  headerEndAddress = 0;
        int flashHeaderParseState = -1; // -1(Not parsed),0,parse started, 1 parse ended


        Arrays.fill( mDspHeaderParseData, (byte) 0 );
        Arrays.fill( mDspHeaderParseData, (byte) 0 );
        Arrays.fill( mDspFlashHeader, (byte) 0 );

        dspHeaderParseDataLen = 0;
        dspFlashHeaderLen = 0;
        OTA_TotalLength = 0;
        dspCodeLen = 0;
        voiceDataLen = 0;

        Arrays.fill(mRehexData, 0, 262144 , (byte)0xff);

        for (; m < fileData.length; m++) {
            if (fileData[m] == ':') {
                byte byetCount;
                byte recordType;
                int address;
                byte parseByte;

                m = m + 1;
                //parse byte Count
                if (z < 10)
                    BLELog.d(TAG, "DSP Parse line = " + HexTool.byteArrayToHexString(subArray(fileData, m, 42)));

                byetCount = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                byetCount = (byte) ((byetCount) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                address = 0;


                address = (((int) getCharFromASCII(fileData[m++]))) << 12;
                address |= (((int) getCharFromASCII(fileData[m++])) << 8);
                address |= (((int) getCharFromASCII(fileData[m++])) << 4);
                address |= ((int) getCharFromASCII(fileData[m++]));


                if (z++ < 50)
                    BLELog.d(TAG, "DSP  address  = " + address);


                //parse record type
                recordType = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                recordType = (byte) ((recordType) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                if (recordType == 0x04) {
                    extendedAddress = (((int) (getCharFromASCII(fileData[m++]))) << 12);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 8);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 4);
                    extendedAddress |= (int) getCharFromASCII(fileData[m++]);
                    BLELog.d(TAG, "DSP  record extendedAddress  = " + extendedAddress);
                    continue;
                } else {
                    address |= (extendedAddress << 16);
                }


                if (recordType != 0x00) {//non data {
                    BLELog.d(TAG, "DSP  recordType != 0x00 " );
                    continue;
                }
                int endRowIndex = 0;

                // BLELog.d(TAG, "address  = " + address);

                // BLELog.d(TAG, "Hex address  = " + Long.toHexString(address));
                   /*m = m + 2;

                headerStartAddress = address;

                headerEndAddress = (((int) getCharFromASCII(fileData[m++]))) << 12;
                headerEndAddress |= (((int) getCharFromASCII(fileData[m++])) << 8);
                headerEndAddress |= (((int) getCharFromASCII(fileData[m++])) << 4);
                headerEndAddress |= ((int) getCharFromASCII(fileData[m++]));

                headerEndAddress |= (extendedAddress << 16);*/


                if (byetCount == 0x10) {

                   endRowIndex = m + 32; //32 bytes data (16 bytes)

                } else if (byetCount == 0x02)
                    endRowIndex = m + 4; //4 bytes data (2 bytes)



                if  (flashHeaderParseState != 1) { // Flash header
                    while ((m < endRowIndex) ) {

                        parseByte = 0;

                        parseByte = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        parseByte = (byte) ((parseByte) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                        if ((parseByte & 0xFF)  == 0x80) {
                            BLELog.d(TAG, "DSP  if ((parseByte & 0xFF) == 0x80) {  = " );
                            flashHeaderParseState = 0;
                        } else  if ((parseByte & 0xFF) == 0x81) {
                            BLELog.d(TAG, "DSP  if ((parseByte & 0xFF) == 0x81){  = " );
                            flashHeaderParseState = 1;
                        }

                        if (flashHeaderParseState == 0){
                            mDspHeaderParseData[dspHeaderParseDataLen] = (byte) parseByte;
                            dspHeaderParseDataLen++;
                        }

                    }

                } else if (address >= 0x00110000 && address < 0x00150000) { //DSP code

                    while (m < endRowIndex) {
                        mRehexData[dspCodeLen] = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        mRehexData[dspCodeLen] = (byte) ((mRehexData[dspCodeLen]) | ((getCharFromASCII(fileData[m++])) & 0X0F));
                       // index++;
                        OTA_TotalLength++;
                        dspCodeLen++;
                    }
                } else if (address >= 0x00150000){ // Voice data
                    //BLELog.d(TAG, "DSP Voice  address  = " + address);
                    if (address >= 0x00160000  && address <  0x001FFFFF) {
                        BLELog.d(TAG, "DSP  address >= 0x00160000  && address <=  0x001FFFFF address =  " + address);
                        //m = m + (endRowIndex - m);
                        //m = endRowIndex ;//- 1;
                        continue;
                    }
                    while (m < endRowIndex) {
                        byte rawData ;
                        //mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen] = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                       // mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen] = (byte) ((mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen]) |
                              //  ((getCharFromASCII(fileData[m++])) & 0X0F));

                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        rawData = (byte) ((rawData) |
                                ((getCharFromASCII(fileData[m++])) & 0X0F));


                        if ((rawData & 0xFF)  != 0xFF ) {
                            //index++;
                            mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen] = rawData;
                            OTA_TotalLength++;
                            voiceDataLen++;
                        }
                    }
                } /*else {
                    BLELog.d(TAG, "Else ignore data  " + address);
                    m = m + endRowIndex ;
                }*/


            }
        }
        BLELog.d(TAG, "DSP dspHeaderParseDataLen  = " + dspHeaderParseDataLen);
        BLELog.d(TAG, "DSP Parse line = " + HexTool.byteArrayToHexString(mDspHeaderParseData));

        int flashHeaderIndex = 0;
        for (int k = 0; k < dspHeaderParseDataLen ;/* k++*/) {
            if(k<20)
            BLELog.d(TAG,k+"="+ mDspHeaderParseData[k]);
            if (((mDspHeaderParseData[k] & 0xFF) ==  0x90) || ((mDspHeaderParseData[k]& 0xFF) ==  0x91)
                    || ((mDspHeaderParseData[k]& 0xFF) == 0xD0) || ((mDspHeaderParseData[k]& 0xFF) == 0x92) ){

                //boolean isVersionData = false;

                if ((mDspHeaderParseData[k]& 0xFF) == 0x92) {
                    //isVersionData = true;

                    byte[] versionBytes = new byte[2];
                    versionBytes[0] = mDspHeaderParseData[k+2];
                    versionBytes[1] = mDspHeaderParseData[k+3];

                    byte[] versionSubBytes = new byte[2];
                    versionSubBytes[0] = mDspHeaderParseData[k+4];
                    versionSubBytes[1] = mDspHeaderParseData[k+5];

                    mVersionStr = HexTool.byteArrayToHexString(versionBytes);
                    mSubVersionStr = HexTool.byteArrayToHexString(versionSubBytes);

                    BLELog.d(TAG, "DSP xVersionString = " + mVersionStr);
                    BLELog.d(TAG, "DSP mSubVersionStr  = " + mSubVersionStr);

                    //String decVersionString  = String.format("%04d", ByteBuffer.wrap(versionBytes).getShort());;
                    //String decSubVersionString = String.format("%04d", ByteBuffer.wrap(versionSubBytes).getShort());;

                    //BLELog.d(TAG, "DSP decVersionString = " + decVersionString);
                    //BLELog.d(TAG, "DSP decSubVersionString  = " + decSubVersionString);

                    //mVersion = HexTool.hex2decimal(xVersionString);

                    //mSubVersion = HexTool.hex2decimal(xSubVersionString);

                    //mSubVersion = mSubVersion + 9;

                    //BLELog.d(TAG, "DSP Version = " + mVersion);
                    //BLELog.d(TAG, "DSP Sub Version = " + mSubVersion);

                   // BLELog.d(TAG, "DSP version bytes  = " + HexTool.byteArrayToHexString(versionBytes));


                }
                mDspFlashHeader[flashHeaderIndex++] = mDspHeaderParseData[k++]; // Index
                int size = mDspHeaderParseData[k];
                mDspFlashHeader[flashHeaderIndex++] = mDspHeaderParseData[k++]; // length
                size = size + k;
                for (; k <  size; k++) {
                    mDspFlashHeader[flashHeaderIndex++] = mDspHeaderParseData[k];
                }
            } else
                k++;

        }
        dspFlashHeaderLen = flashHeaderIndex;

        BLELog.d(TAG, "DSP dspFlashHeaderLen = " + dspFlashHeaderLen);
        BLELog.d(TAG, "DSP mDspFlashHeader  = " + HexTool.byteArrayToHexString(mDspFlashHeader));
        BLELog.d(TAG, "DSP Code  data leng = " + dspCodeLen);
        BLELog.d(TAG, "DSP Voice  data length = " + voiceDataLen);

        OTA_TotalLength = DSP_CODE_SEGMENT_LEN + voiceDataLen;
        //OTA_TotalLength = index;
        BLELog.d(TAG, "DSP image  data length = " + OTA_TotalLength);

        Thread thread = new Thread(new Runnable(){
            @Override
            public void run(){

                // DO encryption
                //byte[] keyHex = {  0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, };
                byte[] keyHex = HexTool.hexStringToByteArray(getEncryptionKey());
                byte[] ivHex = HexTool.hexStringToByteArray(getEncryptionIV());



                //  BLELog.d(TAG, "Image Data Before encyption = " + HexTool.byteArrayToHexString(dataSample));
                // IV internally used for encryption byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, };

                mEncryptedRehexData = new byte[OTA_TotalLength];

                try {
                    mEncryptedRehexData = OTAEncrypt.AESCryptEX(subArray(mRehexData, 0 , OTA_TotalLength ), keyHex,ivHex);
                } catch (Exception e) {
                    e.printStackTrace();

                }

                BLELog.d(TAG, "DSP  Data after encyption = " + HexTool.byteArrayToHexString( mEncryptedRehexData));

            }
        });
       thread.start();


        for (int k = 0; k < OTA_TotalLength; k++) {
            OTA_Update_CRC(mRehexData[k]);
        }
        mCRCValue = CRC_CalculateFinish();
        BLELog.d(TAG, String.format("DSP CRC = 0x%x", mCRCValue));

        return true;
    }

    private boolean openFileMCU (){

        File file = new File(OTAFile_AbsolutePath);

        BLELog.d("BLEService.java", "OpenFile OTAFile_AbsolutePath " + OTAFile_AbsolutePath);
        BLELog.d(TAG, "***Open File : " + OTAFile_AbsolutePath);

        if ((OTAFile_AbsolutePath.length() == 0) || (OTAFile_AbsolutePath.equals(""))) {
            BLELog.d(TAG, "File Path Error!");
            return false;
        }

        int fileDataLen = (int) file.length();
        if (!file.exists()) {
            BLELog.d(TAG, "OpenFile fail, file not exist!");
            return false;
        }

        byte[] fileData = new byte[fileDataLen];
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            DataInputStream dis = new DataInputStream(fis);
            dis.readFully(fileData);        //Read all
            dis.close();

            BLELog.d(TAG, "RAW Rehex file size = " + fileDataLen);

        } catch (IOException e) {
            e.printStackTrace();
        }


        int cnt = 0;
        int m = 0;
        /*while (cnt < 5) {
            if (fileData[m++] == '\n')
                cnt++;
        }*/

        Arrays.fill( mRehexData, (byte) 0 );

        Arrays.fill( mDspHeaderParseData, (byte) 0 );
        Arrays.fill( mDspFlashHeader, (byte) 0 );
        flashHeader = new FlashHeader();


        int index = 0;
        int z =0;
        boolean isVersionFound = false;
        OTA_TotalLength = 0;
        dspHeaderParseDataLen = 0 ;

        int extendedAddress = 0;
        int flashHeaderParseState = -1; // -1(Not parsed),0,parse started, 1 parse ended
        int accHederBytesBeforeStopping = -1;


        for (; m < fileData.length; m++) {
            if (fileData[m] == ':') {
                byte byetCount;
                byte recordType;
                int address;
                byte parseByte;
                byte parseByteNext;

                m = m + 1;
                //parse byte Count
                if (z < 10)
                    BLELog.d(TAG, "Parse line = " + HexTool.byteArrayToHexString(subArray(fileData, m, 42)));

                byetCount = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                byetCount = (byte) ((byetCount) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                address = 0;


                address = (((int) getCharFromASCII(fileData[m++]))) << 12;
                address |= (((int) getCharFromASCII(fileData[m++])) << 8);
                address |= (((int) getCharFromASCII(fileData[m++])) << 4);
                address |= ((int) getCharFromASCII(fileData[m++]));


                if (z++ < 10)
                    BLELog.d(TAG, "Balaji Shift char address  = " + address);




                //parse record type
                recordType = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                recordType = (byte) ((recordType) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                if (recordType == 0x04) {
                    extendedAddress = (((int) (getCharFromASCII(fileData[m++]))) << 12);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 8);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 4);
                    extendedAddress |= (int) getCharFromASCII(fileData[m++]);
                    BLELog.d(TAG, "MCU  record extendedAddress  = " + extendedAddress);
                    continue;
                } else {
                    address |= (extendedAddress << 16);
                }

                if (recordType != 0x00){//non data {
                    BLELog.d(TAG, "MCU  recordType != 0x00 " );
                    continue;
                }
                int endRowIndex = 0;

                // BLELog.d(TAG, "address  = " + address);

                // BLELog.d(TAG, "Hex address  = " + Long.toHexString(address));

                if (byetCount == 0x10) {

                    endRowIndex = m + 32; //32 bytes data (16 bytes)

                } else if (byetCount == 0x02)
                    endRowIndex = m + 4; //4 bytes data (2 bytes)

                if  (flashHeaderParseState != 1) { // Flash header
                    while ((m < endRowIndex) ) {

                        parseByte = 0;
                        parseByteNext = 0;

                        parseByte = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        parseByte = (byte) ((parseByte) | ((getCharFromASCII(fileData[m++])) & 0X0F));

                        parseByteNext = (byte) ((getCharFromASCII(fileData[m])) << 4);
                        parseByteNext = (byte) ((parseByteNext) | ((getCharFromASCII(fileData[m+1])) & 0X0F));


                        if (((parseByte & 0xFF)  == 0x80) && ((parseByteNext & 0xFF)  == 0x04)) {
                            BLELog.d(TAG, "OTA DFU if ((parseByte & 0xFF) == 0x80) && ((parseByteNext & 0xFF)  == 0x04)) {  = " );
                            flashHeaderParseState = 0;
                        } else  if ((parseByte & 0xFF) == 0x81) {
                            BLELog.d(TAG, "OTA DFU  if ((parseByte & 0xFF) == 0x81){  = " );
                            //flashHeaderParseState = 1; // TODO shift inside bracket

                        }else if ((parseByte & 0xFF)  == 0xFB) {

                            BLELog.d(TAG, "OTA DFU  if ((parseByte & 0xFF) == 0xFB){  = " );
                            BLELog.d(TAG, "OTA DFU Parse line = " + HexTool.byteArrayToHexString(mDspHeaderParseData));
                            // Now handle  for header data
                            //flashHeader.parseData();

                            //flashHeaderParseState = 1;

                            //if(flashHeader.dspVersionStr ==  null)

                            accHederBytesBeforeStopping = 26;
                            flashHeaderParseState = 3;


                        }else if ((parseByte & 0xFF)  == 0xFC) {
                            BLELog.d(TAG, "OTA DFU  if ((parseByte & 0xFF) == 0xFC){  = " );

                             //flashHeader.parseData();
                             //flashHeaderParseState = 1;

                        }else if ((parseByte & 0xFF)  == 0xFD) {
                            BLELog.d(TAG, "OTA DFU  if ((parseByte & 0xFF) == 0xFD){  = " );

                            //flashHeader.parseData();
                            //flashHeaderParseState = 1;

                        }




                        if ((flashHeaderParseState == 0) || (flashHeaderParseState == 3)){
                            mDspHeaderParseData[dspHeaderParseDataLen] = (byte) parseByte;
                            dspHeaderParseDataLen++;

                            if (flashHeaderParseState == 3) {
                                accHederBytesBeforeStopping--;
                                if (accHederBytesBeforeStopping == 0) {
                                    flashHeaderParseState = 1;
                                    BLELog.d(TAG, "balaji OTA DFU Parse line = " + HexTool.byteArrayToHexString(mDspHeaderParseData));
                                    flashHeader.parseData();

                                }
                            }

                        }

                    }

                }



                if(address >= 0x00010000 && address < 0x0008FFFF) {

                    while (m < endRowIndex) {
                       /* mRehexData[index] = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        mRehexData[index] = (byte) ((mRehexData[index]) | ((getCharFromASCII(fileData[m++])) & 0X0F));
                        */

                        byte rawData ;

                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        rawData = (byte) ((rawData) |
                                ((getCharFromASCII(fileData[m++])) & 0X0F));


                        //if ((rawData & 0xFF)  != 0xFF ) {
                        mRehexData[index] = rawData;
                        index++;
                        //}
                    }
                }

            }
        }

        OTA_TotalLength = index;
        BLELog.d(TAG, "ReHexed OTA MCU data length = " + OTA_TotalLength);


        mCRCValue = ByteBuffer.wrap(flashHeader.mcuCheckSumBytes).getInt();

        BLELog.d(TAG, String.format("MCU CRC = 0x%x", mCRCValue));


       // OpenDSPVPFile();

      //  openFileUiCfg();

        return true;
    }

    private boolean OpenDSPVPFile() {

        File file = new File(OTAFile_AbsolutePath);

        BLELog.d("BLEService.java", "DSP OpenFile OTAFile_AbsolutePath " + OTAFile_AbsolutePath);
        BLELog.d(TAG, "*** DSP Open File : " + OTAFile_AbsolutePath);

        if ((OTAFile_AbsolutePath.length() == 0) || (OTAFile_AbsolutePath.equals(""))) {
            BLELog.d(TAG, "File Path Error!");
            return false;
        }

        int fileDataLen = (int) file.length();
        if (!file.exists()) {
            BLELog.d(TAG, "DSP OpenFile fail, file not exist!");
            return false;
        }

        byte[] fileData = new byte[fileDataLen];
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            DataInputStream dis = new DataInputStream(fis);
            dis.readFully(fileData);        //Read all
            dis.close();

            BLELog.d(TAG, " DSP RAW Rehex file size = " + fileDataLen);

        } catch (IOException e) {
            e.printStackTrace();
        }


        int m = 0;

        //int index = 0;
        int z =0;
        boolean isVersionFound = false;
        int extendedAddress = 0;
        int  headerStartAddress = 0;
        int  headerEndAddress = 0;
        int flashHeaderParseState = -1; // -1(Not parsed),0,parse started, 1 parse ended



        Arrays.fill( mDspHeaderParseData, (byte) 0 );
        Arrays.fill( mDspHeaderParseData, (byte) 0 );
        Arrays.fill( mDspFlashHeader, (byte) 0 );
        mRawVoiceData = new byte[917504];
        Arrays.fill( mRawVoiceData, (byte) 0 );

        dspHeaderParseDataLen = 0;
        dspFlashHeaderLen = 0;
        OTA_TotalLength = 0;
        dspCodeLen = 0;
        voiceDataLen = 0;
        rawVoiceDataLen = 0;

        Arrays.fill(mRehexData, 0, 262144 , (byte)0xff);

        for (; m < fileData.length; m++) {
            if (fileData[m] == ':') {
                byte byetCount;
                byte recordType;
                int address;
                byte parseByte;

                m = m + 1;
                //parse byte Count
                if (z < 10)
                    BLELog.d(TAG, "DSP Parse line = " + HexTool.byteArrayToHexString(subArray(fileData, m, 42)));

                byetCount = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                byetCount = (byte) ((byetCount) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                address = 0;


                address = (((int) getCharFromASCII(fileData[m++]))) << 12;
                address |= (((int) getCharFromASCII(fileData[m++])) << 8);
                address |= (((int) getCharFromASCII(fileData[m++])) << 4);
                address |= ((int) getCharFromASCII(fileData[m++]));


                if (z++ < 50)
                    BLELog.d(TAG, "DSP  address  = " + address);


                //parse record type
                recordType = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                recordType = (byte) ((recordType) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                if (recordType == 0x04) {
                    extendedAddress = (((int) (getCharFromASCII(fileData[m++]))) << 12);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 8);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 4);
                    extendedAddress |= (int) getCharFromASCII(fileData[m++]);
                    BLELog.d(TAG, "DSP  record extendedAddress  = " + extendedAddress);
                    continue;
                } else {
                    address |= (extendedAddress << 16);
                }


                if (recordType != 0x00) {//non data {
                    BLELog.d(TAG, "DSP  recordType != 0x00 " );
                    continue;
                }
                int endRowIndex = 0;



                if (byetCount == 0x10) {

                    endRowIndex = m + 32; //32 bytes data (16 bytes)

                } else if (byetCount == 0x02)
                    endRowIndex = m + 4; //4 bytes data (2 bytes)



                if  (flashHeaderParseState != 1) { // Flash header
                    while ((m < endRowIndex) ) {

                        parseByte = 0;

                        parseByte = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        parseByte = (byte) ((parseByte) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                        if ((parseByte & 0xFF)  == 0x80) {
                            BLELog.d(TAG, "DSP  if ((parseByte & 0xFF) == 0x80) {  = " );
                            flashHeaderParseState = 0;
                        } else  if ((parseByte & 0xFF) == 0x81) {
                            BLELog.d(TAG, "DSP  if ((parseByte & 0xFF) == 0x81){  = " );
                            flashHeaderParseState = 1;
                        }

                        if (flashHeaderParseState == 0){
                            mDspHeaderParseData[dspHeaderParseDataLen] = (byte) parseByte;
                            dspHeaderParseDataLen++;
                        }

                    }

                } else if (address >= 0x00110000 && address < 0x00150000) { //DSP code

                    while (m < endRowIndex) {
                        mRehexData[dspCodeLen] = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        mRehexData[dspCodeLen] = (byte) ((mRehexData[dspCodeLen]) | ((getCharFromASCII(fileData[m++])) & 0X0F));
                        // index++;
                        OTA_TotalLength++;
                        dspCodeLen++;
                    }
                } else if (address >= 0x00150000){ // Voice data
                    //BLELog.d(TAG, "DSP Voice  address  = " + address);
                   /* if (address >= 0x00160000  && address <  0x001FFFFF) {
                       // BLELog.d(TAG, "DSP  address >= 0x00160000  && address <=  0x001FFFFF address =  " + address);
                        //m = m + (endRowIndex - m);
                        //m = endRowIndex ;//- 1;
                        continue;
                    }*/
                    while (m < endRowIndex) {
                        byte rawData ;
                        //mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen] = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        // mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen] = (byte) ((mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen]) |
                        //  ((getCharFromASCII(fileData[m++])) & 0X0F));

                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        rawData = (byte) ((rawData) |
                                ((getCharFromASCII(fileData[m++])) & 0X0F));


                       // int prevIndex  =  voiceDataLen - 1;

                        //if (prevIndex < 0)
                            //prevIndex = 0;
                        //if ((rawData & 0xFF)  != 0xFF/* &&  ((mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen]& 0xFF) != 0xFF)*/) {

                                                //index++;
                            //mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen] = rawData;
                            mRawVoiceData[ rawVoiceDataLen] = rawData;
                            OTA_TotalLength++;
                             voiceDataLen++;
                            rawVoiceDataLen++;
                       //}
                    }
                } /*else {
                    BLELog.d(TAG, "Else ignore data  " + address);
                    m = m + endRowIndex ;
                }*/


            }
        }


        BLELog.d(TAG, "DSP dspHeaderParseDataLen  = " + dspHeaderParseDataLen);
        BLELog.d(TAG, "DSP Parse line = " + HexTool.byteArrayToHexString(mDspHeaderParseData));
        //voiceDataLen++;
        int flashHeaderIndex = 0;
        for (int k = 0; k < dspHeaderParseDataLen ;/* k++*/) {
            //if(k<20)
               // BLELog.d(TAG,k+"="+ mDspHeaderParseData[k]);
            if (((mDspHeaderParseData[k]& 0xFF) == 0x80) && ((mDspHeaderParseData[k+1]& 0xFF) == 0x04)) {
                BLELog.d(TAG, "DSP balaji if (((mDspHeaderParseData[k]& 0xFF) == 0x80) && ((mDspHeaderParseData[k+1]& 0xFF) == 0x04)) " );
                k= k+4;
                k++;
                continue;
            }

            if (((mDspHeaderParseData[k]& 0xFF) == 0x82) && ((mDspHeaderParseData[k+1]& 0xFF) == 0x04)) {
                BLELog.d(TAG, "DSP balaji if (((mDspHeaderParseData[k]& 0xFF) == 0x82) && ((mDspHeaderParseData[k+1]& 0xFF) == 0x04)) " );
                k= k+4;
                k++;
                continue;
            }

            if (((mDspHeaderParseData[k]& 0xFF) == 0x83)) {
                BLELog.d(TAG, "DSP balaji if (((mDspHeaderParseData[k]& 0xFF) == 0x83) " );
                int tempK = k+1;

                int length = mDspHeaderParseData[tempK++];
                byte[] fwHdrdata = new byte[length];

                length = length + tempK;
                for (int i=0; tempK <  length; tempK++) {
                    fwHdrdata[i++] = mDspHeaderParseData[tempK];
                }
                //k++;
                //k = k + length;
                k = tempK;
                BLELog.d(TAG, "DSP balaji fwHdrdata = " + HexTool.byteArrayToHexString(fwHdrdata));
                continue;
            }



            if (((mDspHeaderParseData[k] & 0xFF) ==  0x90) || ((mDspHeaderParseData[k]& 0xFF) ==  0x91)
                    || ((mDspHeaderParseData[k]& 0xFF) == 0xD0) || ((mDspHeaderParseData[k]& 0xFF) == 0x92) ){

                //boolean isVersionData = false;

                if ((mDspHeaderParseData[k]& 0xFF) == 0x92) {
                    //isVersionData = true;

                    byte[] versionBytes = new byte[2];
                    versionBytes[0] = mDspHeaderParseData[k+2];
                    versionBytes[1] = mDspHeaderParseData[k+3];

                    byte[] versionSubBytes = new byte[2];
                    versionSubBytes[0] = mDspHeaderParseData[k+4];
                    versionSubBytes[1] = mDspHeaderParseData[k+5];

                    mVersionStr = HexTool.byteArrayToHexString(versionBytes);
                    mSubVersionStr = HexTool.byteArrayToHexString(versionSubBytes);

                    BLELog.d(TAG, "DSP xVersionString = " + mVersionStr);
                    BLELog.d(TAG, "DSP mSubVersionStr  = " + mSubVersionStr);

                } else if ((mDspHeaderParseData[k]& 0xFF) == 0xD0 ) {

                    int tempK = k+1;

                    int length = mDspHeaderParseData[tempK++];
                    byte[] vpHdrdata = new byte[length];

                    length = length + tempK;
                    for (int i=0; tempK <  length; tempK++) {
                        vpHdrdata[i++] = mDspHeaderParseData[tempK];
                    }

                    BLELog.d(TAG, "DSP vpHdrdata = " + HexTool.byteArrayToHexString(vpHdrdata));

                }
                mDspFlashHeader[flashHeaderIndex++] = mDspHeaderParseData[k++]; // Index
                int size = mDspHeaderParseData[k];
                mDspFlashHeader[flashHeaderIndex++] = mDspHeaderParseData[k++]; // length
                size = size + k;
                for (; k <  size; k++) {
                    mDspFlashHeader[flashHeaderIndex++] = mDspHeaderParseData[k];
                }
            } else
                k++;

        }
        dspFlashHeaderLen = flashHeaderIndex;

        processVpData();

        BLELog.d(TAG, "DSP Voice raw  data length = " + rawVoiceDataLen);
        BLELog.d(TAG, "DSP dspFlashHeaderLen = " + dspFlashHeaderLen);
        BLELog.d(TAG, "DSP mDspFlashHeader  = " + HexTool.byteArrayToHexString(mDspFlashHeader));
        BLELog.d(TAG, "DSP Code  data leng = " + dspCodeLen);
        BLELog.d(TAG, "DSP Voice  data length = " + voiceDataLen);

        OTA_TotalLength = DSP_CODE_SEGMENT_LEN + voiceDataLen;
        //OTA_TotalLength = index;
        BLELog.d(TAG, "DSP image  data length = " + OTA_TotalLength);


        if ((null !=flashHeader) && (null != flashHeader.dspCheckSumBytes))
        mCRCValue = ByteBuffer.wrap(flashHeader.dspCheckSumBytes).getInt();

        BLELog.d(TAG, String.format("DSP CRC = 0x%x", mCRCValue));

        return true;
    }

    private void processVpData() {
       /* for (int k = DSP_CODE_SEGMENT_LEN; k < DSP_CODE_SEGMENT_LEN + voiceDataLen ;k++) {





            if ((mRehexData[k]& 0xFF) == 0xFF) {

            }
        }

        int modAlign = (voiceDataLen % 16);

        if (modAlign != 0) {
            //mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen] = 0;
            voiceDataLen = voiceDataLen + (16 - modAlign);
        }*/


        /*int modAlign = (rawVoiceDataLen % 16);

        if (rawVoiceDataLen != 0) {
            //mRehexData[DSP_CODE_SEGMENT_LEN + voiceDataLen] = 0;
            rawVoiceDataLen = rawVoiceDataLen + (16 - modAlign);

        }*/
        BLELog.d(TAG, "rawVoiceDataLen "+ rawVoiceDataLen);

        byte[] dst = Arrays.copyOf(mRawVoiceData, rawVoiceDataLen);



       String vpDataHexStr =  HexTool.byteArrayToHexString(dst);
       vpDataHexStr = vpDataHexStr.replaceAll("FFFFFFFF","");
        vpDataHexStr = vpDataHexStr.replaceAll("ffffffff","");
        vpDataHexStr = vpDataHexStr.replaceAll("FFFFffff","");
        vpDataHexStr = vpDataHexStr.replaceAll("ffffFFFF","");
       mRawVoiceData =  HexTool.hexStringToByteArray(vpDataHexStr);
        BLELog.d(TAG, "processVpData byte lenght "+ mRawVoiceData.length);
        BLELog.d(TAG, "processVpData hex str "+ HexTool.byteArrayToHexString(mRawVoiceData));
        voiceDataLen = mRawVoiceData.length;
        System.arraycopy(mRawVoiceData,
                0,
                mRehexData,
                DSP_CODE_SEGMENT_LEN,
                voiceDataLen);


    }

    private boolean openFileUiCfg (){

        File file = new File(OTAFile_AbsolutePath);

        BLELog.d("BLEService.java", "OpenFile OTAFile_AbsolutePath " + OTAFile_AbsolutePath);
        BLELog.d(TAG, "***Open File : " + OTAFile_AbsolutePath);

        if ((OTAFile_AbsolutePath.length() == 0) || (OTAFile_AbsolutePath.equals(""))) {
            BLELog.d(TAG, "File Path Error!");
            return false;
        }

        int fileDataLen = (int) file.length();
        if (!file.exists()) {
            BLELog.d(TAG, "OpenFile fail, file not exist!");
            return false;
        }

        byte[] fileData = new byte[fileDataLen];
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            DataInputStream dis = new DataInputStream(fis);
            dis.readFully(fileData);        //Read all
            dis.close();

            BLELog.d(TAG, "RAW Rehex file size = " + fileDataLen);

        } catch (IOException e) {
            e.printStackTrace();
        }


        int cnt = 0;
        int m = 0;
        /*while (cnt < 5) {
            if (fileData[m++] == '\n')
                cnt++;
        }*/

        Arrays.fill( mRehexData, (byte) 0 );

        Arrays.fill( mDspHeaderParseData, (byte) 0 );
        Arrays.fill( mDspFlashHeader, (byte) 0 );


        int index = 0;
        int z =0;
        OTA_TotalLength = 0;
        dspHeaderParseDataLen = 0 ;
        userConfigLen = 0;

        int extendedAddress = 0;


        for (; m < fileData.length; m++) {
            if (fileData[m] == ':') {
                byte byetCount;
                byte recordType;
                int address;
                byte parseByte;

                m = m + 1;
                //parse byte Count
                if (z < 10)
                    BLELog.d(TAG, "UI CFG Parse line = " + HexTool.byteArrayToHexString(subArray(fileData, m, 42)));

                byetCount = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                byetCount = (byte) ((byetCount) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                address = 0;


                address = (((int) getCharFromASCII(fileData[m++]))) << 12;
                address |= (((int) getCharFromASCII(fileData[m++])) << 8);
                address |= (((int) getCharFromASCII(fileData[m++])) << 4);
                address |= ((int) getCharFromASCII(fileData[m++]));


                if (z++ < 10)
                    BLELog.d(TAG, "Balaji Shift char address  = " + address);




                //parse record type
                recordType = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                recordType = (byte) ((recordType) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                if (recordType == 0x04) {
                    extendedAddress = (((int) (getCharFromASCII(fileData[m++]))) << 12);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 8);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 4);
                    extendedAddress |= (int) getCharFromASCII(fileData[m++]);
                    BLELog.d(TAG, "Ui Cfg   record extendedAddress  = " + extendedAddress);
                    continue;
                } else {
                    address |= (extendedAddress << 16);
                }

                if (recordType != 0x00){//non data {
                    BLELog.d(TAG, "UI CFG recordType != 0x00 " );
                    continue;
                }
                int endRowIndex = 0;

                // BLELog.d(TAG, "address  = " + address);

                // BLELog.d(TAG, "Hex address  = " + Long.toHexString(address));

                if (byetCount == 0x10) {

                    endRowIndex = m + 32; //32 bytes data (16 bytes)

                } else if (byetCount == 0x02)
                    endRowIndex = m + 4; //4 bytes data (2 bytes)


                if(address >= 0x00006000 && address < 0x00007FFF )  { //User Config data

                    // BLELog.d(TAG, "OTA DFU CONFIG data  address  = " + address);

                    while (m < endRowIndex) {
                        byte rawData ;

                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        rawData = (byte) ((rawData) |
                                ((getCharFromASCII(fileData[m++])) & 0X0F));

                        // if ((rawData & 0xFF)  != 0xFF ) {
                        mRehexData[OTA_TotalLength] = rawData;
                        OTA_TotalLength++;
                        userConfigLen++;
                        //}
                    }


                }

            }
        }

        BLELog.d(TAG, "ReHexed OTA UI CFG data length = " + userConfigLen);
        BLELog.d(TAG, "ReHexed OTA UI CFG OTA_TotalLength = " + OTA_TotalLength);

        if ((null !=flashHeader) && (null != flashHeader.dspCheckSumBytes))
        mCRCValue = ByteBuffer.wrap(flashHeader.uiCfgCheckSumBytes).getInt();

        BLELog.d(TAG, String.format("MCU CRC = 0x%x", mCRCValue));


        return true;
    }

   /* private boolean OpenOTADFUFile() {

        File file = new File(OTAFile_AbsolutePath);

        BLELog.d("BLEService.java", "OTA DFU OpenFile OTAFile_AbsolutePath " + OTAFile_AbsolutePath);
        BLELog.d(TAG, "*** OTA DFU Open File : " + OTAFile_AbsolutePath);

        if ((OTAFile_AbsolutePath.length() == 0) || (OTAFile_AbsolutePath.equals(""))) {
            BLELog.d(TAG, "OTA DFU File Path Error!");
            return false;
        }

        int fileDataLen = (int) file.length();
        if (!file.exists()) {
            BLELog.d(TAG, "OTA DFU OpenFile fail, file not exist!");
            return false;
        }

        byte[] fileData = new byte[fileDataLen];
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            DataInputStream dis = new DataInputStream(fis);
            dis.readFully(fileData);        //Read all
            dis.close();

            BLELog.d(TAG, " OTA DFU RAW Rehex file size = " + fileDataLen);

        } catch (IOException e) {
            e.printStackTrace();
        }


        int m = 0;

        //int index = 0;
        int z =0;
        boolean isVersionFound = false;
        int extendedAddress = 0;
        int  headerStartAddress = 0;
        int  headerEndAddress = 0;
        int flashHeaderParseState = -1; // -1(Not parsed),0,parse started, 1 parse ended



        Arrays.fill( mDspHeaderParseData, (byte) 0 );
        Arrays.fill( mDspFlashHeader, (byte) 0 );


        dspHeaderParseDataLen = 0;
        dspFlashHeaderLen = 0;
        OTA_TotalLength = 0;
        fwCodeLen = 0;
        userConfigLen = 0;
        dspCodeLen = 0;
        voiceDataLen = 0;


        Arrays.fill(mRehexData, 0, 262144 , (byte)0xff);

        for (; m < fileData.length; m++) {
            if (fileData[m] == ':') {
                byte byetCount;
                byte recordType;
                int address;
                byte parseByte;

                m = m + 1;
                //parse byte Count
                if (z < 10)
                    BLELog.d(TAG, "OTA DFU Parse line = " + HexTool.byteArrayToHexString(subArray(fileData, m, 42)));

                byetCount = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                byetCount = (byte) ((byetCount) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                address = 0;


                address = (((int) getCharFromASCII(fileData[m++]))) << 12;
                address |= (((int) getCharFromASCII(fileData[m++])) << 8);
                address |= (((int) getCharFromASCII(fileData[m++])) << 4);
                address |= ((int) getCharFromASCII(fileData[m++]));


                if (z++ < 50)
                    BLELog.d(TAG, "OTA DFU address  = " + address);


                //parse record type
                recordType = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                recordType = (byte) ((recordType) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                if (recordType == 0x04) {
                    extendedAddress = (((int) (getCharFromASCII(fileData[m++]))) << 12);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 8);
                    extendedAddress |= (((int) (getCharFromASCII(fileData[m++]))) << 4);
                    extendedAddress |= (int) getCharFromASCII(fileData[m++]);
                    BLELog.d(TAG, "OTA DFU record extendedAddress  = " + extendedAddress);
                    continue;
                } else {
                    address |= (extendedAddress << 16);
                }


                if (recordType != 0x00) {//non data {
                    BLELog.d(TAG, "OTA DFU recordType != 0x00 " );
                    continue;
                }
                int endRowIndex = 0;


                if (byetCount == 0x10) {

                    endRowIndex = m + 32; //32 bytes data (16 bytes)

                } else if (byetCount == 0x02)
                    endRowIndex = m + 4; //4 bytes data (2 bytes)



                if  (flashHeaderParseState != 1) { // Flash header
                    while ((m < endRowIndex) ) {

                        parseByte = 0;

                        parseByte = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        parseByte = (byte) ((parseByte) | ((getCharFromASCII(fileData[m++])) & 0X0F));


                        if ((parseByte & 0xFF)  == 0x80) {
                            BLELog.d(TAG, "OTA DFU if ((parseByte & 0xFF) == 0x80) {  = " );
                            flashHeaderParseState = 0;
                        } else  if ((parseByte & 0xFF) == 0x81) {
                            BLELog.d(TAG, "OTA DFU  if ((parseByte & 0xFF) == 0x81){  = " );
                            flashHeaderParseState = 1; // TODO shift inside bracket
                            {

                                parseByte = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                                parseByte = (byte) ((parseByte) | ((getCharFromASCII(fileData[m++])) & 0X0F));
                                mDspHeaderParseData[dspHeaderParseDataLen] = (byte) parseByte;
                                dspHeaderParseDataLen++;

                                parseByte = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                                parseByte = (byte) ((parseByte) | ((getCharFromASCII(fileData[m++])) & 0X0F));
                                mDspHeaderParseData[dspHeaderParseDataLen] = (byte) parseByte;
                                dspHeaderParseDataLen++;

                                parseByte = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                                parseByte = (byte) ((parseByte) | ((getCharFromASCII(fileData[m++])) & 0X0F));
                                mDspHeaderParseData[dspHeaderParseDataLen] = (byte) parseByte;
                                dspHeaderParseDataLen++;

                                parseByte = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                                parseByte = (byte) ((parseByte) | ((getCharFromASCII(fileData[m++])) & 0X0F));
                                mDspHeaderParseData[dspHeaderParseDataLen] = (byte) parseByte;
                                dspHeaderParseDataLen++;

                                BLELog.d(TAG, "OTA DFU Parse line = " + HexTool.byteArrayToHexString(mDspHeaderParseData));


                                {
                                   // int i = dspHeaderParseDataLen;
                                    int i = 0;
                                  //  int n = m;
                                    while (i < 20){
                                    byte rawData;


                                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                                        rawData = (byte) ((rawData) |
                                                ((getCharFromASCII(fileData[m++])) & 0X0F));

                                            mDspHeaderParseData[dspHeaderParseDataLen] = rawData;
                                            dspHeaderParseDataLen++;
                                            i++;

                                    }
                                }

                                // Now handle  for header data
                                flashHeader.parseData();


                                if (null == flashHeader.dspVersionStr) // No dsp CRC
                                    dspHeaderParseDataLen =  dspHeaderParseDataLen -4;

                                if (null == flashHeader.uiCfgCheckSumBytes)// No Ui cfg CRC
                                    dspHeaderParseDataLen =  dspHeaderParseDataLen -4;


                            }
                        }

                        if (flashHeaderParseState == 0){
                            mDspHeaderParseData[dspHeaderParseDataLen] = (byte) parseByte;
                            dspHeaderParseDataLen++;
                        }

                    }

                }

                if(address >= 0x00006000 && address < 0x00007FFF &&  (null != flashHeader.dspVersionStr))  { //User Config data

                   // BLELog.d(TAG, "OTA DFU CONFIG data  address  = " + address);

                    while (m < endRowIndex) {
                        byte rawData ;

                        rawData = (byte) ((rawData) |
                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                                ((getCharFromASCII(fileData[m++])) & 0X0F));

                        // if ((rawData & 0xFF)  != 0xFF ) {
                        mRehexData[OTA_TotalLength] = rawData;
                        OTA_TotalLength++;
                        userConfigLen++;
                        //}
                    }


                }else if(address >= 0x00010000 && address < 0x0008FFFF)  { //MCU data

                    //BLELog.d(TAG, "OTA DFU MCU FW  address  = " + address);

                    while (m < endRowIndex) {
                        byte rawData ;

                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        rawData = (byte) ((rawData) |
                                ((getCharFromASCII(fileData[m++])) & 0X0F));

                       // if ((rawData & 0xFF)  != 0xFF ) {
                            mRehexData[OTA_TotalLength] = rawData;
                            OTA_TotalLength++;
                            fwCodeLen++;
                       //}
                    }


                } else if ((address >= 0x00110000) && (address < 0x00150000) && (null != flashHeader.dspVersionStr)) { //DSP code

                    while (m < endRowIndex) {

                        byte rawData ;

                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        rawData = (byte) ((rawData) |
                                ((getCharFromASCII(fileData[m++])) & 0X0F));
                       // if ((rawData & 0xFF)  != 0xFF ) {
                            mRehexData[OTA_TotalLength] = (byte) rawData;
                            // index++;
                            OTA_TotalLength++;
                            dspCodeLen++;
                        //}
                    }
                } else if ((address >= 0x00150000) && (null != flashHeader.dspVersionStr)){ // Voice data
                    //BLELog.d(TAG, "DSP Voice  address  = " + address);
                   if (address >= 0x00160000  && address <  0x001FFFFF) {
                       // BLELog.d(TAG, "OTA DFU DSP  address >= 0x00160000  && address <=  0x001FFFFF address =  " + address);
                        //m = m + (endRowIndex - m);
                        //m = endRowIndex ;//- 1;
                        continue;
                    }
                    while (m < endRowIndex) {
                        byte rawData ;

                        rawData = (byte) ((getCharFromASCII(fileData[m++])) << 4);
                        rawData = (byte) ((rawData) |
                                ((getCharFromASCII(fileData[m++])) & 0X0F));


                        if ((rawData & 0xFF)  != 0xFF ) {
                            mRehexData[OTA_TotalLength] = rawData;
                            OTA_TotalLength++;
                            voiceDataLen++;
                        }
                    }
                }

            }
        }
        BLELog.d(TAG, "OTA DFU dspHeaderParseDataLen  = " + dspHeaderParseDataLen);
        BLELog.d(TAG, "OTA DFU Parse line = " + HexTool.byteArrayToHexString(mDspHeaderParseData));

        dspFlashHeaderLen = dspHeaderParseDataLen;
        mDspFlashHeader = mDspHeaderParseData;

        BLELog.d(TAG, "OTA DFU FlashHeaderLen = " + dspFlashHeaderLen);
        BLELog.d(TAG, "OTA DFU FlashHeader  = " + HexTool.byteArrayToHexString(mDspFlashHeader));

        BLELog.d(TAG, "OTA DFU User Config data leng = " + userConfigLen);
        BLELog.d(TAG, "OTA DFU MCU FW  data leng = " + fwCodeLen);
        BLELog.d(TAG, "OTA DFU DSP Code  data leng = " + dspCodeLen);
        BLELog.d(TAG, "OTA DFU DSP Voice  data length = " + voiceDataLen);

        BLELog.d(TAG, "OTA DFU  image  data length BEFORE CALC = " + OTA_TotalLength);

       // TODO OTA_TotalLength = userConfigLen + DSP_CODE_SEGMENT_LEN + voiceDataLen +fwCodeLen;
        OTA_TotalLength = userConfigLen +  voiceDataLen + fwCodeLen + dspCodeLen;

        BLELog.d(TAG, "OTA DFU  image  data length = " + OTA_TotalLength);




        return true;
    } */

    // Simple nested inner class
    class FlashHeader {

        boolean isMCUupdateRequired = false;
        boolean isDSPupdateRequired = false;
        boolean isUICfgUpdateRequired = false;

        String dspVersionStr = null;
        String dspSubVersionStr = null;
        boolean isDspVersionFound = false;

        String mcuVersionStr = null;
        String mcuSubVersionStr = null;
        boolean isMCUVersionFound = false;

        byte[] mcuCheckSumBytes = null;
        boolean isMCUCRCound = false;

        byte[] dspCheckSumBytes = null;
        boolean isDSPCRCound = false;

        byte[] uiCfgCheckSumBytes = null;
        boolean isUICfgCRCFound = false;

        int  headerStartAddress = 0;
        int  headerEndAddress = 0;
        int  programRAMAddress = 0;

        // FWFlashHeader fwFlashHeader = new FWFlashHeader();
        //DSPImageHeader dspFlashHeader =  new DSPImageHeader();
        //VPFlashHeader vpFlashHeader = new VPFlashHeader();

        void parseData() {
            int flashHeaderIndex = 0;

            for (int k = 0; k < dspHeaderParseDataLen  ; k++) {
                if(k<20)
                    BLELog.d(TAG,k+"="+ mDspHeaderParseData[k]);
                /*if (((mDspHeaderParseData[k] & 0xFF) ==  0x90) || ((mDspHeaderParseData[k]& 0xFF) ==  0x91)
                        || ((mDspHeaderParseData[k]& 0xFF) == 0xD0) || ((mDspHeaderParseData[k]& 0xFF) == 0x92) ) {*/


                    if (((mDspHeaderParseData[k] & 0xFF) == 0x92) && (isDspVersionFound == false)) {
                        //isVersionData = true;

                        byte[] versionBytes = new byte[2];
                        versionBytes[0] = mDspHeaderParseData[k + 2];
                        versionBytes[1] = mDspHeaderParseData[k + 3];

                        byte[] versionSubBytes = new byte[2];
                        versionSubBytes[0] = mDspHeaderParseData[k + 4];
                        versionSubBytes[1] = mDspHeaderParseData[k + 5];

                        dspVersionStr = HexTool.byteArrayToHexString(versionBytes);
                        dspSubVersionStr = HexTool.byteArrayToHexString(versionSubBytes);

                        if(!dspVersionStr.contains("FF") && !dspVersionStr.contains("ff")) {
                            isDspVersionFound = true;
                            isDSPupdateRequired = true;
                        } else {

                            isDspVersionFound = false;
                            isDSPupdateRequired = false;
                            dspVersionStr = null;
                        }


                        BLELog.d(TAG, "OTA DFU DSP dspVersionStr = " + dspVersionStr);
                        BLELog.d(TAG, "OTA DFU DSP dspSubVersionStr  = " + dspSubVersionStr);

                    } else if (((mDspHeaderParseData[k] & 0xFF) == 0xFB) && ((mDspHeaderParseData[k+1] & 0xFF) == 0x0C) && (isMCUVersionFound == false)) {

                        byte[] checkSumBytes = new byte[4];
                        checkSumBytes[0] = mDspHeaderParseData[k + 2];
                        checkSumBytes[1] = mDspHeaderParseData[k + 3];
                        checkSumBytes[2] = mDspHeaderParseData[k + 4];
                        checkSumBytes[3] = mDspHeaderParseData[k + 5];
                        mcuCheckSumBytes =  checkSumBytes;


                        byte[] versionBytes = new byte[4];
                        versionBytes[0] = mDspHeaderParseData[k + 6];
                        versionBytes[1] = mDspHeaderParseData[k + 7];
                        versionBytes[2] = mDspHeaderParseData[k + 8];
                        versionBytes[3] = mDspHeaderParseData[k + 9];

                        byte[] versionSubBytes = new byte[4];
                        versionSubBytes[0] = mDspHeaderParseData[k + 10];
                        versionSubBytes[1] = mDspHeaderParseData[k + 11];
                        versionSubBytes[2] = mDspHeaderParseData[k + 12];
                        versionSubBytes[3] = mDspHeaderParseData[k + 13];

                        mcuVersionStr = HexTool.byteArrayToHexString(versionBytes);
                        mcuSubVersionStr = HexTool.byteArrayToHexString(versionSubBytes);

                        if(!mcuVersionStr.contains("FF") && !mcuVersionStr.contains("ff")) {
                            isMCUVersionFound = true;
                            isMCUupdateRequired = true;
                        } else {
                           isMCUVersionFound = false;
                            isMCUupdateRequired = false;
                            mcuVersionStr = null;
                        }
                        isMCUVersionFound = true;
                        isMCUupdateRequired = true;

                        BLELog.d(TAG, "OTA DFU  mcuVersionStr = " + mcuVersionStr);
                        BLELog.d(TAG, "OTA DFU  mcuSubVersionStr  = " + mcuSubVersionStr);
                        BLELog.d(TAG, "OTA DFU  mcuCheckSumBytes = " + HexTool.byteArrayToHexString(mcuCheckSumBytes));


                    } else if (((mDspHeaderParseData[k] & 0xFF) == 0xFC) && ((mDspHeaderParseData[k+1] & 0xFF) == 0x04) && (isDSPCRCound == false)) {

                        byte[] checkSumBytes = new byte[4];
                        checkSumBytes[0] = mDspHeaderParseData[k + 2];
                        checkSumBytes[1] = mDspHeaderParseData[k + 3];
                        checkSumBytes[2] = mDspHeaderParseData[k + 4];
                        checkSumBytes[3] = mDspHeaderParseData[k + 5];
                        dspCheckSumBytes =  checkSumBytes;
                        isDSPCRCound = true;

                        BLELog.d(TAG, "OTA DFU  dspCheckSumBytes = " + HexTool.byteArrayToHexString(dspCheckSumBytes));

                    } else if (((mDspHeaderParseData[k] & 0xFF) == 0xFD) && ((mDspHeaderParseData[k+1] & 0xFF) == 0x04)/* && (isUICfgCRCFound = false)*/){
                        byte[] checkSumBytes = new byte[4];
                        checkSumBytes[0] = mDspHeaderParseData[k + 2];
                        checkSumBytes[1] = mDspHeaderParseData[k + 3];
                        checkSumBytes[2] = mDspHeaderParseData[k + 4];
                        checkSumBytes[3] = mDspHeaderParseData[k + 5];
                        uiCfgCheckSumBytes =  checkSumBytes;
                        isUICfgCRCFound = true;
                        isUICfgUpdateRequired = true;

                        BLELog.d(TAG, "OTA DFU  uiCfgCheckSumBytes = " + HexTool.byteArrayToHexString(uiCfgCheckSumBytes));
                    }
                }


            //}

        }


    }

    class FWFlashHeader {
         byte bankIndexFw = 0;
         int usedSizeFw = 0;
         int maxSizeFw = 0;
         byte numOfBanksFw = 0;
         int[] bankAdressFwArr = new int[1];
    }

    class DSPImageHeader {
        byte bankIndexDsp = 0;
        int usedSizeDsp = 0;
        int maxSizeDsp = 0;
        byte numOfBanksDsp = 0;
        int[] bankAdressDspArr = new int[1];
    }

    class VPFlashHeader {
        byte bankIndexVp = 0;
        int usedSizeVp = 0;
        int maxSizeVp = 0;
        byte numOfBanksVp = 0;
        int[] bankAdressVpArr = new int[1];
    }


    private byte getCharFromASCII(byte b) {
        byte ret;
        switch (b) {
            case 0x30:
                ret = 0;
                break;
            case 0x31:
                ret = 1;
                break;
            case 0x32:
                ret = 2;
                break;
            case 0x33:
                ret = 3;
                break;
            case 0x34:
                ret = 4;
                break;
            case 0x35:
                ret = 5;
                break;
            case 0x36:
                ret = 6;
                break;
            case 0x37:
                ret = 7;
                break;
            case 0x38:
                ret = 8;
                break;
            case 0x39:
                ret = 9;
                break;
            case 0x41:
                ret = 10;
                break;
            case 0x42:
                ret = 11;
                break;
            case 0x43:
                ret = 12;
                break;
            case 0x44:
                ret = 13;
                break;
            case 0x45:
                ret = 14;
                break;
            case 0x46:
                ret = 15;
                break;
            default:
                ret = 0;
        }
        return ret;
    }

    private class TempQueueObject extends Object {
        public BluetoothGattCharacteristic chr;
        public byte[] value;
        private boolean isRead = false;

        public TempQueueObject(BluetoothGattCharacteristic characteristic,
                               byte[] data, boolean read) {
            chr = characteristic;
            value = data;
            isRead = read;
        }

        public TempQueueObject(BluetoothGattCharacteristic characteristic,
                               byte[] data) {
            chr = characteristic;
            value = data;
            isRead = false;
        }

        public void write() {
            if (isRead) {
                mBluetoothGatt.readCharacteristic(chr);
            } else {
                if (chr.getWriteType() == BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) {
                    ;
                    BLELog.d(TAG, "WRITE_TYPE_NO_RESPONSE");
                    chr.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                    chr.setValue(value);
                    mBluetoothGatt.writeCharacteristic(chr);
                } else {
                    chr.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                    chr.setValue(value);
                    mBluetoothGatt.writeCharacteristic(chr);
                }
            }
        }
    }

    public class LocalBinder extends Binder {
        public BLEService getService() {
            return BLEService.this;
        }
    }


}
