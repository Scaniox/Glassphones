package com.app.microchip.dsptunning.pagerFrag;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;
import com.app.microchip.dsptunning.ui.DspTuningVoicePagerActivity;

import java.util.Arrays;

/**
 * Created by I17163 on 12/12/2019.
 */

public class NoiseReductionVoiceFragment extends Fragment implements DSPTuningDelegate{

    private static final String TAG = NoiseReductionVoiceFragment.class.getSimpleName();

    private Spinner SPK_NR;
    private Spinner MIC_NR;
    private Button TuneDSP;
    TextView DSPState;
    private DspTuningVoicePagerActivity mActivity;
    private DspOTATunningBLEService mService;

    byte[] SPK_NoiseReduction_Data;
    byte[] MIC_NoiseReduction_Data;

    private long fragFocusStartTime = 0;

    byte[] SPK_Prev_Data;
    byte[] MIC_Prev_Data;

   byte  Modified_Parameters = 0x00;

    String[] NR_table1 = {"6dB Noise Suppression", "9dB", "12dB", "15dB -Default",
            "18dB", "21dB", "24dB", "27dB", "30dB"};

    byte[] NR_Low_ids = {64, 45, 32, 22, 16, 11, 8, 6, 4};
    byte[] NR_High_ids = {90, 64, 45, 32, 22, 16, 11, 8, 6};

    public NoiseReductionVoiceFragment() {
        Log.d(TAG, "Constructor");
    }

    DspTuningVoicePagerActivity activity;




    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.noise_reduction_voice_fragment, container, false);

        BLELog.d(TAG, "onCreateView");

        SPK_NR = (Spinner)view.findViewById(R.id.Spinner3);
        MIC_NR = (Spinner)view.findViewById(R.id.Spinner4);
        DSPState =(TextView) view.findViewById(R.id.deviceStatus);
        TuneDSP = (Button) view.findViewById(R.id.tuneDspButton);

        initUI();

        return view;

    }


    private void initUI () {

        if (DSPState!= null & (mService!=null))
            DSPState.setText(mService.DSP_DUT_State);




            ArrayAdapter<String> adapter;
            adapter = new ArrayAdapter<String>(getActivity(),
                    android.R.layout.simple_spinner_item, NR_table1);

            SPK_NR.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    long fragFocusEndTime =  System.currentTimeMillis();

                    long fragAutoEventTimeElapsed = fragFocusEndTime - fragFocusStartTime ;

                    Log.d(TAG,"SPK_NR fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

                    if (fragAutoEventTimeElapsed > 2000) {
                        enableTuneDspButton();
                    }

                    if (SPK_NoiseReduction_Data != null) {
                        Log.d(TAG, "Before MOD SPK_NoiseReduction_Data =" +
                                HexTool.byteArrayToHexString(SPK_NoiseReduction_Data));

                        SPK_NoiseReduction_Data[0] = NR_Low_ids[pos];
                        SPK_NoiseReduction_Data[1] = NR_High_ids[pos];
                        Modified_Parameters = 0x01;

                        Log.d(TAG, "After MOD SPK_NoiseReduction_Data =" +
                                HexTool.byteArrayToHexString(SPK_NoiseReduction_Data));
                    }


                }

                @Override
                public void onNothingSelected(AdapterView<?> arg0) {
                    // TODO Auto-generated method stub
                }
            });

            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            SPK_NR.setAdapter(adapter);
            //LineIn_Threshold.setSelection(0);



            ArrayAdapter<String> adapter1;
            adapter1 = new ArrayAdapter<String>(getActivity(),
                    android.R.layout.simple_spinner_item, NR_table1);

            MIC_NR.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    long fragFocusEndTime =  System.currentTimeMillis();

                    long fragAutoEventTimeElapsed = fragFocusEndTime - fragFocusStartTime ;

                    Log.d(TAG,"MIC_NR fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

                    if (fragAutoEventTimeElapsed > 2000) {
                        enableTuneDspButton();
                    }

                    if (MIC_NoiseReduction_Data != null) {

                        Log.d(TAG, "Before MOD MIC_NoiseReduction_Data =" +
                                HexTool.byteArrayToHexString(MIC_NoiseReduction_Data));

                        MIC_NoiseReduction_Data[0] = NR_Low_ids[pos];
                        MIC_NoiseReduction_Data[1] = NR_High_ids[pos];
                        Modified_Parameters = 0x02;

                        Log.d(TAG, "After MOD MIC_NoiseReduction_Data =" +
                                HexTool.byteArrayToHexString(MIC_NoiseReduction_Data));


                    }

                }

                @Override
                public void onNothingSelected(AdapterView<?> arg0) {
                    // TODO Auto-generated method stub
                }
            });

            adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            MIC_NR.setAdapter(adapter1);



        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(Modified_Parameters != 0x00) {
                    BLELog.d(TAG,"Modified_Parameters ="+ Modified_Parameters);

                    if(Modified_Parameters == 0x01){
                        BLELog.d(TAG,"DSPTuning:SPK");
                        mService.DSPTuning( (byte)0x0D, (byte)0x06, (byte) SPK_NoiseReduction_Data.length, SPK_NoiseReduction_Data);
                    }else if(Modified_Parameters == 0x02){
                        BLELog.d(TAG,"DSPTuning:MIC");
                        mService.DSPTuning( (byte)0x0D,  (byte)0x07, (byte) MIC_NoiseReduction_Data.length,  MIC_NoiseReduction_Data);
                    } else{
                      // QueueModifiedParameters();
                       // DSPManager?.DSPTuning3()
                    }

                    mActivity.showSpinnerDialog(true);
                }
            }
        });

        NoiseReduction_Data_Init();

        disableTuneDspButton();
        updateFunctionButtonsState();

        BLELog.d(TAG, "initUI");
    }

    private void  enableTuneDspButton() {
        TuneDSP.setEnabled(true);
        TuneDSP.setTextColor(Color.WHITE);
    }

    private void  disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }

    private synchronized void updateFunctionButtonsState () {
        if ( (mService!=null)) {
            mActivity.runOnUiThread(new Thread(new Runnable() {
                @Override
                public void run() {
                    if (mService.dynamicToolMode == mService.TuneDSPMode_NotSupport || mService.dynamicToolMode == mService.TuneDSPMode_Audio) {
                        SPK_NR.setEnabled(false);
                        MIC_NR.setEnabled(false);
                        disableTuneDspButton();
                    } else if (mService.dynamicToolMode == mService.TuneDSPMode_Voice) {
                        SPK_NR.setEnabled(true);
                        MIC_NR.setEnabled(true);
                    }

                }

            }));
        }
    }

    private int SPK_NR_selectedIndex;
    private int MIC_NR_selectedIndex;

    void NoiseReduction_Data_Init() {
        BLELog.d(TAG, "NoiseReduction_Data_Init");

        if (SPK_NoiseReduction_Data == null)
            return;

        if (SPK_NoiseReduction_Data[0] > 45 && SPK_NoiseReduction_Data[0] <= 64) {
            SPK_NR_selectedIndex = 0;
        } else if (SPK_NoiseReduction_Data[0] > 32 && SPK_NoiseReduction_Data[0] <= 45) {
            SPK_NR_selectedIndex = 1;
        } else if (SPK_NoiseReduction_Data[0] > 22 && SPK_NoiseReduction_Data[0] <= 32) {
            SPK_NR_selectedIndex = 2;
        } else if (SPK_NoiseReduction_Data[0] > 16 && SPK_NoiseReduction_Data[0] <= 22) {
            SPK_NR_selectedIndex = 3;
        } else if (SPK_NoiseReduction_Data[0] > 11 && SPK_NoiseReduction_Data[0] <= 16) {
            SPK_NR_selectedIndex = 4;
        } else if (SPK_NoiseReduction_Data[0] > 8 && SPK_NoiseReduction_Data[0] <= 11) {
            SPK_NR_selectedIndex = 5;
        } else if (SPK_NoiseReduction_Data[0] > 6 && SPK_NoiseReduction_Data[0] <= 8) {
            SPK_NR_selectedIndex = 6;
        } else if (SPK_NoiseReduction_Data[0] > 4 && SPK_NoiseReduction_Data[0] <= 6) {
            SPK_NR_selectedIndex = 7;
        } else if (SPK_NoiseReduction_Data[0] <= 4) {
            SPK_NR_selectedIndex = 8;
        }


        if (MIC_NoiseReduction_Data[0] > 45 && MIC_NoiseReduction_Data[0] <= 64) {
            MIC_NR_selectedIndex = 0;
        } else if (MIC_NoiseReduction_Data[0] > 32 && MIC_NoiseReduction_Data[0] <= 45) {
            MIC_NR_selectedIndex = 1;
        } else if (MIC_NoiseReduction_Data[0] > 22 && MIC_NoiseReduction_Data[0] <= 32) {
            MIC_NR_selectedIndex = 2;
        } else if (MIC_NoiseReduction_Data[0] > 16 && MIC_NoiseReduction_Data[0] <= 22) {
            MIC_NR_selectedIndex = 3;
        } else if (MIC_NoiseReduction_Data[0] > 11 && MIC_NoiseReduction_Data[0] <= 16) {
            MIC_NR_selectedIndex = 4;
        } else if (MIC_NoiseReduction_Data[0] > 8 && MIC_NoiseReduction_Data[0] <= 11) {
            MIC_NR_selectedIndex = 5;
        } else if (MIC_NoiseReduction_Data[0] > 6 && MIC_NoiseReduction_Data[0] <= 8) {
            MIC_NR_selectedIndex = 6;
        } else if (MIC_NoiseReduction_Data[0] > 4 && MIC_NoiseReduction_Data[0] <= 6) {
            MIC_NR_selectedIndex = 7;
        } else if (MIC_NoiseReduction_Data[0] <= 4) {
            MIC_NR_selectedIndex = 8;
        }

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                SPK_NR.setSelection(SPK_NR_selectedIndex);
                Log.d(TAG,"SPK_NR SPK_NR_selectedIndex="+ SPK_NR_selectedIndex);

                MIC_NR.setSelection(MIC_NR_selectedIndex);
                Log.d(TAG,"MIC_NR SPK_NR_selectedIndex="+ MIC_NR_selectedIndex);

            }
        }));


    }

    void QueueModifiedParameters() {
        if ((Modified_Parameters & 0x01) == 0x01) {
            Log.d(TAG, "DSPTuning:SPK");
            mService.DSPQueueData((byte) 0x0D, (byte) 0x06, (byte) SPK_NoiseReduction_Data.length, SPK_NoiseReduction_Data);

        } else if ((Modified_Parameters  & 0x02) == 0x02){
            Log.d(TAG, "DSPTuning:MIC");
            mService.DSPQueueData((byte)0x0D, (byte)0x07, (byte) MIC_NoiseReduction_Data.length, MIC_NoiseReduction_Data);

        }
    }

    public void initModule(DspTuningVoicePagerActivity act) {
        mActivity = act;

        mService = DspOTATunningMainActivity.getINSTANCE().getmBLEService();


        mService.setListener(NoiseReductionVoiceFragment.this);


        initUI();

        mService.Get_Voice_DSP_Setting_NR();


        fragFocusStartTime = System.currentTimeMillis();

        
    }

    public void cleanModule() {

    }


    @Override
    public void onAttach(Context context) {
        Log.d(TAG, "EQAudioFragment onAttach");
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        Log.d(TAG, "EQAudioFragment onDetach");
        super.onDetach();
    }

    @Override
    public void BLE_ServiceReady() {

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] Data) {
        int k = 0;
        byte[] buffer = Data;

        //(dat as NSData).getBytes(&buffer, length: (dat as NSData).length)

        Log.d(TAG,"Parsing configuration data");

        while(k < buffer.length){
            byte len = buffer[k+2];
            //let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))

            byte[] param_dat = Arrays.copyOfRange(buffer, k+3, k+3+ len);;

            Log.d(TAG,"Offset = "+k+" module_id ="+buffer[k]+ "cfg_id ="+buffer[k+1]+
                    "data len = "+len+" dat = "+ HexTool.byteArrayToHexString(param_dat));

           /* if(buffer[k] == 13 && buffer[k+1] == 6){
                for index in 0..<3 {
                    SPK_NoiseReduction_Data.append(buffer[k+3+index])
                }
                print("SPK_NoiseReduction_Data (FENR)= \(SPK_NoiseReduction_Data)")
            }
            else if(buffer[k] == 13 && buffer[k+1] == 7) {
                for index in 0..< 3 {
                    MIC_NoiseReduction_Data.append(buffer[k + 3 + index])
                }
            }*/

                if(buffer[k] == 13 && buffer[k+1] == 6){

                    SPK_NoiseReduction_Data = Arrays.copyOfRange(buffer, k+3 , k+3+ 3);

                    Log.d(TAG,"SPK_NoiseReduction_Data len = "+SPK_NoiseReduction_Data.length +  "data ="+
                            HexTool.byteArrayToHexString(SPK_NoiseReduction_Data));


                }else if(buffer[k] == 13 && buffer[k+1] == 7) {
                    MIC_NoiseReduction_Data = Arrays.copyOfRange(buffer, k+3 , k+3+ 3);

                    Log.d(TAG,"SPK_NoiseReduction_Data len = "+MIC_NoiseReduction_Data.length +  "data ="+
                            HexTool.byteArrayToHexString(MIC_NoiseReduction_Data));

                }

            k += (int)(3+len);
        }

        NoiseReduction_Data_Init();

    }

    private String  dspStatusMsgDialog= "";
    private void showTuneDspDialog(String message) {

        dspStatusMsgDialog = message;

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder ad = new AlertDialog.Builder(getActivity() , R.style.MyDialogTheme);
                ad.setMessage(dspStatusMsgDialog);

                ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
                sendBroadcast(i);
                  mOtaState.setText("Completed");*/
                    }
                });

                final AlertDialog  alert = ad.create();
                alert.setTitle("Tune DSP Status!!");
                alert.show();



                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {

                    }
                });

            }
        }));


    }

    @Override
    public void DSPTuningComplete(byte result) {
        String  status = "";

        mActivity.dismissSpinnerDialog();

        if(result == 0x01){
            status = "Success";
        }
        else{
            status = "Failed " + result;
        }

        showTuneDspDialog(status);

        if(result != 0x01){
            //LineIn_Config_Init(null, true);
        }

        getActivity().runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                disableTuneDspButton();

            }
        }));
    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {
        Log.d(TAG, " DSPTuningState" + state);
        if (DSPState!= null)
            DSPState.setText(state);

        updateFunctionButtonsState();

    }

    @Override
    public void ExportDSPTuningResult() {

    }
}
