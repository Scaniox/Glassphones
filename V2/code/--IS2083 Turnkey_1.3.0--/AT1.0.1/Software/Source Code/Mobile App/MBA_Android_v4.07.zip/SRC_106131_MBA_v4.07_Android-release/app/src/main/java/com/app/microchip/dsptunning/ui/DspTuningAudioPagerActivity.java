package com.app.microchip.dsptunning.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.pagerAdap.MyPagerAdapter;
import com.app.microchip.dsptunning.pagerFrag.EQAudioFragment;
import com.app.microchip.dsptunning.pagerFrag.LineInAudioFragment;
import com.app.microchip.dsptunning.pagerFrag.SoundEffectAudioFragment;

/**
 * Created by I17163 on 12/12/2019.
 */

public class DspTuningAudioPagerActivity extends AppCompatActivity implements ViewPager.OnPageChangeListener {
    private static final String TAG = DspTuningAudioPagerActivity.class.getSimpleName();


    private MyPagerAdapter pagerAdapterView;

    private ImageView firstDotImageView;
    private ImageView secondDotImageView;
    private ImageView thirdDotImageView;

    private LineInAudioFragment lineInAudioFrag;
    private SoundEffectAudioFragment SoundEffectAudioFrag;
    private EQAudioFragment EQAudioFrag;


    ViewPager myViewPager;


    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        Log.d(TAG, "onPageSelected=" + position);
        if (position == 0) {
            firstDotImageView.setImageResource(R.drawable.current_position_icon);
            secondDotImageView.setImageResource(R.drawable.disable_position_icon);
            thirdDotImageView.setImageResource(R.drawable.disable_position_icon);

            SoundEffectAudioFrag.cleanModule();
            lineInAudioFrag.initModule(DspTuningAudioPagerActivity.this);
            setTitle(" LineIn");
        } else if (position == 1) {

            lineInAudioFrag.cleanModule();
            SoundEffectAudioFrag.initModule(DspTuningAudioPagerActivity.this);
            setTitle(" Sound Effect  ");

            firstDotImageView.setImageResource(R.drawable.disable_position_icon);
            secondDotImageView.setImageResource(R.drawable.current_position_icon);
            thirdDotImageView.setImageResource(R.drawable.disable_position_icon);

        } else if (position == 2) {

            EQAudioFrag.initModule(DspTuningAudioPagerActivity.this);

            setTitle(" Audio EQ");
            firstDotImageView.setImageResource(R.drawable.disable_position_icon);
            secondDotImageView.setImageResource(R.drawable.disable_position_icon);
            thirdDotImageView.setImageResource(R.drawable.current_position_icon);

        }
    }


    @Override
    public void onPageScrollStateChanged(int state) {

    }



    /*private void onPageSelected(int position) {
        if  (position == 0) {
                firstDotImageView.setImageResource(R.drawable.current_position_icon);
                secondDotImageView.setImageResource(R.drawable.disable_position_icon);
                thirdDotImageView.setImageResource(R.drawable.disable_position_icon);
        } else if  (position == 1)  {

                firstDotImageView.setImageResource(R.drawable.disable_position_icon);
                secondDotImageView.setImageResource(R.drawable.current_position_icon);
                thirdDotImageView.setImageResource(R.drawable.disable_position_icon);

        } else if  (position == 2)  {

                firstDotImageView.setImageResource(R.drawable.disable_position_icon);
                secondDotImageView.setImageResource(R.drawable.disable_position_icon);
                thirdDotImageView.setImageResource(R.drawable.current_position_icon);

        }
    }*/

    private void addPagerFragments() {
        lineInAudioFrag = new LineInAudioFragment();
        SoundEffectAudioFrag = new SoundEffectAudioFragment();
        EQAudioFrag = new EQAudioFragment();

        pagerAdapterView.addFragments(lineInAudioFrag);
        pagerAdapterView.addFragments(SoundEffectAudioFrag);
        pagerAdapterView.addFragments(EQAudioFrag);

        setTitle("LineIn");
        //DspOTATunningMainActivity.getINSTANCE().getmBLEService().DSP_Init();
        lineInAudioFrag.initModule(DspTuningAudioPagerActivity.this);
    }

   /*() private void  zoomOutTransformation(page:View, position: Float) {
        when {
            position < -1 ->
            page.alpha = 0f
            position <= 1 -> {
                page.scaleX = Math.max(MIN_SCALE, 1 - Math.abs(position))
                page.scaleY = Math.max(MIN_SCALE, 1 - Math.abs(position))
                page.alpha = Math.max(MIN_ALPHA, 1 - Math.abs(position))
            }
            else -> page.alpha = 0f
        }
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


        //  WindowManager wm = (WindowManager) getApplicationContext()
        //.getSystemService(Context.WINDOW_SERVICE);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activty_pager_audio);

        firstDotImageView = (ImageView) findViewById(R.id.firstDotImageView);
        secondDotImageView = (ImageView) findViewById(R.id.secondDotImageView);
        thirdDotImageView = (ImageView) findViewById(R.id.thirdDotImageView);

        myViewPager = (ViewPager) findViewById(R.id.myViewPager);

        pagerAdapterView = new MyPagerAdapter(getSupportFragmentManager());
        isReadModuleData = true;
        addPagerFragments();
        myViewPager.setAdapter(pagerAdapterView);
        myViewPager.addOnPageChangeListener(this);

        registerReceiver(mGattUpdateReceiver, makeIntentFilter());

    }

    private boolean isFragmentWithoutPager = false;
    private boolean isReadModuleData;

    public void loadFragmentWithoutPager(Fragment fragment) {

        isFragmentWithoutPager = true;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //  setContentView(R.layout.activity_);

        myViewPager = (ViewPager) findViewById(R.id.myViewPager);

        pagerAdapterView = new MyPagerAdapter(getSupportFragmentManager());
        addPagerFragments();
        myViewPager.setAdapter(pagerAdapterView);
        myViewPager.addOnPageChangeListener(this);


    }

    public void removeFragmentWithoutPager() {
        isFragmentWithoutPager = false;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activty_pager_audio);

        firstDotImageView = (ImageView) findViewById(R.id.firstDotImageView);
        secondDotImageView = (ImageView) findViewById(R.id.secondDotImageView);
        thirdDotImageView = (ImageView) findViewById(R.id.thirdDotImageView);

        myViewPager = (ViewPager) findViewById(R.id.myViewPager);

        pagerAdapterView = new MyPagerAdapter(getSupportFragmentManager());
        isReadModuleData = false;
        addPagerFragments();
        myViewPager.setAdapter(pagerAdapterView);
        myViewPager.addOnPageChangeListener(this);


    }
    private ProgressDialog mSpinnerDialog;

    public void showSpinnerDialog(boolean isTunning) {

        mSpinnerDialog = new ProgressDialog(DspTuningAudioPagerActivity.this);
        mSpinnerDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        if(isTunning)
            mSpinnerDialog.setMessage("Please wait..Tunning Params.. ");
        else
            mSpinnerDialog.setMessage("Please wait..Reading Params.. ");
        mSpinnerDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mSpinnerDialog.setIndeterminate(true);
        mSpinnerDialog.setCancelable(false);
        mSpinnerDialog.setCanceledOnTouchOutside(false);
        mSpinnerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                               @Override
                                               public void onCancel(DialogInterface dialog) {
                                                   BLELog.d(TAG, "Cancelling during validation");

                                               }
                                           }
        );

        mSpinnerDialog.show();
    }

    public void dismissSpinnerDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSpinnerDialog != null && mSpinnerDialog.isShowing()) {
                    mSpinnerDialog.dismiss();
                }
            }
        });
    }





    public void onBackPressed() {
        if (isFragmentWithoutPager) {
            removeFragmentWithoutPager();
            return;
        }

        super.onBackPressed();


    }

    protected void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        unregisterReceiver(mGattUpdateReceiver);
        super.onDestroy();
    }
    //End Pager code


    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            BLELog.d(TAG, "BroadcastReceiver action: " + action);
            if (action.equals(DspOTATunningBLEService.ACTION_GATT_DISCONNECTED)) {
                finish();
            }

        }
    };

    private static IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(DspOTATunningBLEService.ACTION_GATT_DISCONNECTED);

        return intentFilter;
    }



}
