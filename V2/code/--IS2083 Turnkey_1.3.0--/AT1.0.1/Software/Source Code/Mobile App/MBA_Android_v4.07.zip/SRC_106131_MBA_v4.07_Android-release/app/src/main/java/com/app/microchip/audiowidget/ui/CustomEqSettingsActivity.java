package com.app.microchip.audiowidget.ui;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.managers.TransparentServiceManager;
import com.app.microchip.audiowidget.util.BLELog;


public class CustomEqSettingsActivity extends AppCompatActivity {
    // ALL EQ SETTINGS HERE !!!
    public static final int MAX_FREQUENCY_BANDS = 5;
    public static final int Max_dB = 12;
    public static final int Min_dB = 40;
    public static final int Quanti_LSB = 30;
    public static final int Quanti_MSB = 14;
    public static final int Sim_Bit_Drop = 0;  //Use full 32 bits
    public static final int Slider_step_size = 10;
    public static final int Max_Eq_Calculated_Bytes = 84;
    public static final int Frequency_default[] = {1000, 2000, 5000, 10000, 16000};
    public static final int Q_default[] = {1, 1, 1, 1, 1};
    public static final int Gain_default[] = {0, 0, 0, 0, 0};
    static final int MAX_SLIDERS = MAX_FREQUENCY_BANDS; // Must match the XML layout
    static final int EQ_SEND_DELAY = 1100;
    // Debugging
    private static final String TAG = CustomEqSettingsActivity.class.getSimpleName();
    int min_level = 0;
    int max_level = 100;
    int eqCalByteIndex = 0;
    int m_StageNum = MAX_FREQUENCY_BANDS;
    SeekBar sliders[] = new SeekBar[MAX_SLIDERS];
    int freqBands[] = new int[MAX_FREQUENCY_BANDS];
    int QValues[] = new int[MAX_FREQUENCY_BANDS];
    TextView gainValues[] = new TextView[MAX_FREQUENCY_BANDS];
    int eqCalculatedBytes[] = new int[Max_Eq_Calculated_Bytes];
    FilterCoeff pFilter[] = new FilterCoeff[MAX_FREQUENCY_BANDS];
    double pGain[] = new double[MAX_FREQUENCY_BANDS];
    double pFreq[] = new double[MAX_FREQUENCY_BANDS];
    double pQ[] = new double[MAX_FREQUENCY_BANDS];
    double m_SampleFreq = 48000;
    int m_AccuracyNum = 16384;
    double m_GlobalGain = 0;
    private TransparentServiceManager mainActivity;
    private Handler mSendHandler = new Handler();
    private int eqSendPressed = 0;
    private Runnable eqSendRunObj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_eq_settings);
        setTitle("Equalizer Settings");
        mainActivity = TransparentServiceManager.getInstance();

        int i;
        SeekBar.OnSeekBarChangeListener sliderBarListener = new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progresValue, boolean fromUser) {
                BLELog.d(TAG, "onProgressChanged progresValue=" + progresValue);
                int i;
                for (i = 0; i < MAX_SLIDERS; i++)
                    if (seekBar == sliders[i])
                        break;

                pGain[i] = (progresValue / 10) - 5;
                BLELog.d(TAG, "onProgressChanged pGain=" + pGain[i]);
                sliders[i].setProgress(((int) Math.round(progresValue / Slider_step_size)) * Slider_step_size);
                gainValues[i].setText(Double.toString(pGain[i]));
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        };

        int sliderID[] = {R.id.slider_1, R.id.slider_2, R.id.slider_3, R.id.slider_4, R.id.slider_5};
        int gaintext[] = {R.id.gain1, R.id.gain2, R.id.gain3, R.id.gain4, R.id.gain5};

        for (i = 0; i < MAX_FREQUENCY_BANDS; i++) {
            sliders[i] = (SeekBar) findViewById(sliderID[i]);
            sliders[i].setOnSeekBarChangeListener(sliderBarListener);
            gainValues[i] = (TextView) findViewById(gaintext[i]);
            freqBands[i] = Frequency_default[i];
            QValues[i] = Q_default[i];
            pGain[i] = Gain_default[i];
            gainValues[i].setText(Double.toString(pGain[i]));
        }
        Button buttonSend = (Button) findViewById(R.id.applyEq);
        buttonSend.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (eqSendPressed++ == 0) {
                    mSendHandler.postDelayed(eqSendRunObj, EQ_SEND_DELAY);
                    eqCalculateAndSend();
                }
            }
        });

        Button resetButton = (Button) findViewById(R.id.eqresetbtn);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < MAX_SLIDERS; i++) {
                    sliders[i].setProgress(50);
                }
                if (eqSendPressed++ == 0) {
                    mSendHandler.postDelayed(eqSendRunObj, EQ_SEND_DELAY);
                    eqCalculateAndSend();
                }
            }
        });

        for (i = 0; i < MAX_FREQUENCY_BANDS; i++)
            pFilter[i] = new FilterCoeff();

        eqSendPressed = 0;
        eqSendRunObj = new Runnable() {
            @Override
            public void run() {
                BLELog.d(TAG, "EQ Timer Expire");
                if (eqSendPressed > 1)
                    eqCalculateAndSend();
                eqSendPressed = 0;

            }
        };
    }

    public void eqCalculateAndSend() {
        int i;
        double tmpFreq, tmpQ;
        for (i = 0; i < MAX_FREQUENCY_BANDS; i++) {
            tmpFreq = freqBands[i];
            if (tmpFreq < 1)
                tmpFreq = 1;
            else if (tmpFreq > 23999)
                tmpFreq = 23999;
            pFreq[i] = tmpFreq;
            pQ[i] = QValues[i];
            BLELog.d(TAG, "Index-" + i + " Freq:" + pFreq[i] + " Q:" + pQ[i] + " Gain:" + pGain[i]);
        }
        eqCalculate();
        eqSendBytes();
    }

    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
    }

    public void onProgressChanged(SeekBar seekBar, int level,
                                  boolean fromTouch) {

    }

    public void onCheckedChanged(CompoundButton view, boolean isChecked) {

    }

    public int boost(FilterCoeff in, double gain, double fc, double Q, double fs) {
        double PI = 3.1415926535898, wcT, K, V;
        V = fs / 2 - fc;
        if (V <= 0)
            return 0;

        in.Stage = 2;
        if (gain == 1) {
            in.Stage = 0;
            in.Gain = 1;
            in.Den[0] = 1;
            in.Num[0] = 1;
            in.Den[1] = 0;
            in.Num[1] = 0;
            in.Den[2] = 0;
            in.Num[2] = 0;
            return 1;
        }
        wcT = 2 * PI * fc / fs;

        K = Math.tan(wcT / 2);
        V = gain;


        in.Num[0] = 1 + V * K / Q + K * K;
        in.Num[1] = 2 * (K * K - 1);
        in.Num[2] = 1 - V * K / Q + K * K;
        in.Den[0] = 1 + K / Q + K * K;
        in.Den[1] = 2 * (K * K - 1);
        in.Den[2] = 1 - K / Q + K * K;

        V = in.Num[0];
        K = in.Den[0];
        for (int i = 0; i < 3; i++) {
            in.Num[i] = in.Num[i] / V;
            in.Den[i] = in.Den[i] / K;
        }
        in.Gain = V / K;
        return 1;
    }

    public double GTodB(double in) {
        double out;
        out = 20.0 * Math.log10(in);
        return out;
    }

    double dBToG(double in) {
        double out;
        out = Math.pow(10.0, in / (20.0));
        return out;
    }

    double round(double in) {
        double tmp;
        tmp = Math.floor(in);
        in = in - tmp;
        in = in * 2;
        if (in >= 1)
            tmp++;
        return tmp;
    }

    ;

    void FilterFixQuantize(FilterCoeff In, int Bits) {
        int i;
        double tmp;

        for (i = 1; i <= In.Stage; i++) {
            tmp = In.Den[i] * Math.pow(2.0, Bits);
            tmp = round(tmp);
            In.Den[i] = tmp / Math.pow(2.0, Bits);

            tmp = In.Num[i] * Math.pow(2.0, Bits);
            tmp = round(tmp);
            In.Num[i] = tmp / Math.pow(2.0, Bits);


        }
    }

    ;

    void FreqResponse(FilterCoeff In, int N, Response result) {
        double realNum = 0, imagNum = 0, realDen = 0, imagDen = 0, realRes, imagRes, tmpDen;
        double PI = 3.1415926535898, wcT, NwcT;
        int i, j;
        for (i = 0; i < N; i++) {
            realNum = 1;
            imagNum = 0;
            realDen = 1;
            imagDen = 0;
            wcT = PI / (double) N * (double) i;


            for (j = 1; j <= In.Stage; j++) {
                NwcT = (-1) * wcT * (double) j;
                realNum = realNum + In.Num[j] * Math.cos(NwcT);
                imagNum = imagNum + In.Num[j] * Math.sin(NwcT);
                realDen = realDen + In.Den[j] * Math.cos(NwcT);
                imagDen = imagDen + In.Den[j] * Math.sin(NwcT);

            }
            tmpDen = realDen * realDen + imagDen * imagDen;
            realRes = realNum * realDen + imagNum * imagDen;
            imagRes = realDen * imagNum - imagDen * realNum;
            realRes = realRes / tmpDen;
            imagRes = imagRes / tmpDen;
            tmpDen = realRes * realRes + imagRes * imagRes;
            result.value[i] = In.Gain * Math.sqrt(tmpDen);
        }
    }

    public void eqSendFragmemtBytes() {
        // 0xaa 0x01 0x11 0x30 0x1c 15bytes-DATA
        // 0xaa 0x02 0x11 17bytes-DATA
        // 0xaa 0x02 0x11 17bytes-DATA
        // 0xaa 0x02 0x11 17bytes-DATA
        // 0xaa 0x02 0x11 17bytes-DATA
        // 0xaa 0x03 0x02 2bytes-DATA
        char eqCmd[] = new char[1 + 4 + Max_Eq_Calculated_Bytes + 1];
        char eqFragData[] = new char[20];
        char eqFragEnd[] = new char[5];

        String message;
        int index = 0;
        int i, src, dst, frag2Idx;

        eqCmd[index++] = 0xaa;
        eqCmd[index++] = 0x00;
        eqCmd[index++] = 2 + Max_Eq_Calculated_Bytes;
        eqCmd[index++] = 0x30;
        eqCmd[index++] = 0x13;

        for (i = 0; i < Max_Eq_Calculated_Bytes; i++)
            eqCmd[index + i] = (char) eqCalculatedBytes[i];

        eqCmd[index + Max_Eq_Calculated_Bytes] = 0;
        for (i = 0; i < Max_Eq_Calculated_Bytes + 4; i++)
            eqCmd[index + Max_Eq_Calculated_Bytes] += eqCmd[i + 1];
        eqCmd[index + Max_Eq_Calculated_Bytes] &= 0xff;
        eqCmd[index + Max_Eq_Calculated_Bytes] = (char) (256 - eqCmd[index + Max_Eq_Calculated_Bytes]);

        BLELog.d(TAG, String.format("EQ Fragment Checksum value = %d", (int) eqCmd[index + Max_Eq_Calculated_Bytes]));

        String uartString = "";
        for (i = 0; i < 84; i++) {
            uartString += String.format("%02X", (int) (eqCmd[i + 5]) & 0xff) + " ";
        }
        BLELog.d(TAG, uartString);


        // First Fragment
        dst = 0;
        eqFragData[dst++] = 0xaa;
        eqFragData[dst++] = 0x01;
        eqFragData[dst++] = 0x11;
        eqFragData[dst++] = 0x30;
        eqFragData[dst++] = 0x13;
        src = dst;
        for (i = 0; i < 15; i++)
            eqFragData[dst++] = eqCmd[src++];
        mainActivity.sendCommand(eqFragData);

        // 2-5 Fragment
        for (frag2Idx = 0; frag2Idx < 4; frag2Idx++) {
            dst = 0;
            eqFragData[dst++] = 0xaa;
            eqFragData[dst++] = 0x02;
            eqFragData[dst++] = 0x11;
            for (i = 0; i < 17; i++)
                eqFragData[dst++] = eqCmd[src++];
            mainActivity.sendCommand(eqFragData);
        }

        // 6 Fragment
        dst = 0;
        eqFragEnd[dst++] = 0xaa;
        eqFragEnd[dst++] = 0x03;
        eqFragEnd[dst++] = 0x02;
        for (i = 0; i < 2; i++)
            eqFragEnd[dst++] = eqCmd[src++];
        mainActivity.sendCommand(eqFragEnd);
    }

    public void eqSendBytes() {
        // 0xaa 0x00 Count 0x30 0x1c 84bytes Checksum
        char eqCmd[] = new char[1 + 4 + Max_Eq_Calculated_Bytes + 1];
        String message;
        int index = 0;
        int i;

        eqCmd[index++] = 0xaa;
        eqCmd[index++] = 0x00;
        eqCmd[index++] = 2 + Max_Eq_Calculated_Bytes;
        eqCmd[index++] = 0x30;
        eqCmd[index++] = 0x13;

        for (i = 0; i < Max_Eq_Calculated_Bytes; i++)
            eqCmd[index + i] = (char) eqCalculatedBytes[i];

        eqCmd[index + Max_Eq_Calculated_Bytes] = 0;
        for (i = 0; i < Max_Eq_Calculated_Bytes + 4; i++)
            eqCmd[index + Max_Eq_Calculated_Bytes] += eqCmd[i + 1];
        eqCmd[index + Max_Eq_Calculated_Bytes] &= 0xff;
        eqCmd[index + Max_Eq_Calculated_Bytes] = (char) (256 - eqCmd[index + Max_Eq_Calculated_Bytes]);

        message = String.copyValueOf(eqCmd);

        BLELog.d(TAG, "msg length =" + message.length());


        for (i = 0; i < eqCmd.length; i++)
            BLELog.d(TAG, String.format("value = %d", (int) eqCmd[i]));

        if (message.length() == 0) {
            return;
        }
        mainActivity.sendCommand(eqCmd);
    }

    public void eqCalculate() {
        int i;
        eqCalByteIndex = 0;
        for (i = 0; i < m_StageNum; i++) {
            if (boost(pFilter[i], dBToG(pGain[i]), pFreq[i], pQ[i], m_SampleFreq) == 0) {
                return;
            }
            FilterFixQuantize(pFilter[i], Quanti_LSB - Sim_Bit_Drop);
        }

        //Calculate response for each separate filters then combine the response
        Response ResponseResult = new Response();
        Response ResponseTemp = new Response();

        FreqResponse(pFilter[0], m_AccuracyNum, ResponseResult);

        for (i = 1; i < m_StageNum; i++) {
            FreqResponse(pFilter[i], m_AccuracyNum, ResponseTemp);
            for (int j = 0; j < m_AccuracyNum; j++) {
                ResponseResult.value[j] = ResponseResult.value[j] * ResponseTemp.value[j];
            }
        }
        for (int j = 0; j < m_AccuracyNum; j++) {
            ResponseResult.value[j] = ResponseResult.value[j] * dBToG(m_GlobalGain);
        }
//==================================================================================================
        double GGain, tmp;
        double tmpG[] = new double[MAX_FREQUENCY_BANDS];
        FilterCoeff tmpFilter[] = new FilterCoeff[MAX_FREQUENCY_BANDS];

        long MSB, LSB;
        GGain = dBToG(m_GlobalGain);
        int j;

        for (i = 0; i < m_StageNum; i++) {
            tmpFilter[i] = pFilter[i];
            tmpG[i] = dBToG(pGain[i]);
        }

        //Bubble minmax sort
        //drop gain=1 filtet to buttom to remove redundant filter
        FilterCoeff tmpFilterCoeff = new FilterCoeff();
        for (i = 0; i < m_StageNum - 1; i++) {
            for (j = 0; j < m_StageNum - 1; j++) {

                if (((tmpG[j] > tmpG[j + 1]) || (tmpG[j] == 1)) && (tmpG[j + 1] != 1)) {
                    tmp = tmpG[j];
                    tmpG[j] = tmpG[j + 1];
                    tmpG[j + 1] = tmp;

                    tmpFilterCoeff = tmpFilter[j];
                    tmpFilter[j] = tmpFilter[j + 1];
                    tmpFilter[j + 1] = tmpFilterCoeff;
                }
            }
        }
        int count = 0;

        //Need to sort the output sequence of filters by the value of gains
        //Output all coefficients as unsigned mode
        for (i = 0; i < m_StageNum; i++) {
            for (j = 2; j > 0; j--) {
                //tmp=pow(2.0,Quanti_MSB)*pFilter[i]->Num[j];
                tmp = Math.pow(2.0, Quanti_MSB) * tmpFilter[i].Num[j];
                MSB = (long) Math.floor(tmp);
                LSB = (long) ((tmp - (double) MSB) * Math.pow(2.0, 16));
                if (MSB < 0)
                    MSB = (long) (MSB + Math.pow(2.0, 16));

                //LSB=(tmp-(double)MSB)*pow(2.0,16);

                //if (LSB>=32768)
                //  LSB=LSB-65536;
                BLELog.d(TAG, " " + MSB);
                BLELog.d(TAG, " " + LSB);
                eqCalculatedBytes[eqCalByteIndex++] = (char) (MSB & 0xff00) >> 8;
                eqCalculatedBytes[eqCalByteIndex++] = (char) (MSB & 0xff);
                eqCalculatedBytes[eqCalByteIndex++] = (char) (LSB & 0xff00) >> 8;
                eqCalculatedBytes[eqCalByteIndex++] = (char) (LSB & 0xff);
                //out<<MSB<<endl;
                //out<<LSB<<endl;

                //IIR_Coeff_Buff[count++]=MSB;
                //IIR_Coeff_Buff[count++]=LSB;
            }

            for (j = 2; j > 0; j--) {
                //tmp=pow(2.0,Quanti_MSB)*pFilter[i]->Den[j];
                tmp = Math.pow(2.0, Quanti_MSB) * tmpFilter[i].Den[j];
                MSB = (long) (Math.floor(tmp));
                LSB = (long) ((tmp - (double) MSB) * Math.pow(2.0, 16));
                if (MSB < 0)
                    MSB = (long) (MSB + Math.pow(2.0, 16));

                //LSB=(tmp-(double)MSB)*pow(2.0,16);
                //if (LSB>=32768)
                //  LSB=LSB-65536;
                BLELog.d(TAG, " " + MSB);
                BLELog.d(TAG, " " + LSB);
                eqCalculatedBytes[eqCalByteIndex++] = (char) (MSB & 0xff00) >> 8;
                eqCalculatedBytes[eqCalByteIndex++] = (char) (MSB & 0xff);
                eqCalculatedBytes[eqCalByteIndex++] = (char) (LSB & 0xff00) >> 8;
                eqCalculatedBytes[eqCalByteIndex++] = (char) (LSB & 0xff);
                //out<<MSB<<endl;
                //out<<LSB<<endl;
                //IIR_Coeff_Buff[count++]=MSB;
                //IIR_Coeff_Buff[count++]=LSB;
            }
            GGain = GGain * pFilter[i].Gain;
        }
/*
        for (i=m_StageNum;i<Max_Stage;i++)
		{
			out<<"0"<<endl<<"0"<<endl<<"0"<<endl<<"0"<<endl;
			out<<"0"<<endl<<"0"<<endl<<"0"<<endl<<"0"<<endl;
			IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;
			IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;
		}
*/
        GGain = Math.pow(2.0, Quanti_LSB) * GGain;
        GGain = round(GGain);
        GGain = GGain / Math.pow(2.0, Quanti_LSB);
        tmp = Math.pow(2.0, Quanti_MSB) * GGain;
        MSB = (long) (Math.floor(tmp));
        LSB = (long) ((tmp - (double) MSB) * Math.pow(2.0, 16));
        if (MSB < 0)
            MSB = (long) (MSB + Math.pow(2.0, 16));

        //LSB=(tmp-(double)MSB)*pow(2.0,16);
        //if (LSB>=32768)
        //  LSB=LSB-65536;

        //out<<MSB<<endl;
        //out<<LSB<<endl;
        BLELog.d(TAG, " " + MSB);
        BLELog.d(TAG, " " + LSB);
        eqCalculatedBytes[eqCalByteIndex++] = (char) (MSB & 0xff00) >> 8;
        eqCalculatedBytes[eqCalByteIndex++] = (char) (MSB & 0xff);
        eqCalculatedBytes[eqCalByteIndex++] = (char) (LSB & 0xff00) >> 8;
        eqCalculatedBytes[eqCalByteIndex++] = (char) (LSB & 0xff);

        BLELog.d(TAG, "Calculated bytes Array");
        for (i = 0; i < Max_Eq_Calculated_Bytes; i++)
            BLELog.d(TAG, " " + eqCalculatedBytes[i]);


//		IIR_Coeff_Buff[count++]=MSB;
//		IIR_Coeff_Buff[count++]=LSB;

        //Output Filter Original Settings here
        //CString outstring;
    }

    @Override
    public void onStop() {
        BLELog.d(TAG, "Device Choose onpause");
        super.onPause();
        mSendHandler.removeCallbacks(eqSendRunObj);
    }

    public class Response {
        double value[] = new double[m_AccuracyNum];

        Response() {
            int i = 0;
            for (i = 0; i < m_AccuracyNum; i++)
                value[i] = 0;
        }
    }

    public class FilterCoeff {
        int Stage;
        double Gain;
        double Num[] = new double[100];
        double Den[] = new double[100];

        FilterCoeff() {
            Stage = 0;
            Gain = 0;
            int i = 0;
            for (i = 0; i < 100; i++) {
                Num[i] = 0;
                Den[i] = 0;
            }
        }
    }
}



