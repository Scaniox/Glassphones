package com.app.microchip.audiowidget.managers;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ListView;

import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.ui.HomeScreenActivity;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;
import com.app.microchip.audiowidget.util.GattTransaction;
import com.app.microchip.audiowidget.util.TransactionQueue;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;

public class TransparentServiceManager implements
        TransactionQueue.Consumer<GattTransaction> {

    public final static String BLE_TRANS_DATA = "ble_transparent_data";
    public final static String BLE_RX_BYTES = "ble_receive_bytes";
    public final static String BLE_TRANS_READY = "ble_transparent_ready";
    public final static String BLE_DISCONNECTED = "ble_disconnected";
    private final static int PAYLOAD_MAX = 90;      // Multi-speaker support 93bytes MTU
    private final static int TRANS_RX_MESSAGE = 0x1000;
    private final static String TRANS_RX_BYTES = "trans_rx_bytes";
    private final static String RCV_ENABLED = "could_receive_data_if_enabled";
    private static final String TAG = TransparentServiceManager.class.getSimpleName();
    private static TransparentServiceManager sInstance = null;
    protected TransparentServiceManager.transparentRxHandler msgTransHandler;
    private int mSuccess = 0;
    private int mFail = 0;
    private BluetoothGattCharacteristic mTransTx;
    private BluetoothGattCharacteristic mTransRx;
    private boolean transSupported = false;
    private BLESpeaker mSpeaker;
    private BLEManager mBleManager;
    private TransactionQueue mQueue;
    private ListView list;
    private String mDevId = "";
    private Context m_context;
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (!mSpeaker.getBtDevice().getAddress().equals(gatt.getDevice().getAddress())) {
                BLELog.d(TAG, " balaji mSpeaker.getBtDevice().getAddress().equals(gatt.getDevice().getAddress())");
               return;
            }
            BLELog.d(TAG, "balaji onConnectionStateChange=" + mDoNothandleGattClose);

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                onConnected();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {

                if (mDoNothandleGattClose == false) {

                    mBleManager.removeListener(mGattCallback);

                    mBleManager.closeGatt(mSpeaker.getBtDevice());
                }

                onDisconnected();
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            onDiscovered();
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            BLELog.d(TAG, "onMtuChanged called mtu=" + mtu);
            onMTUChange();
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            BLELog.d(TAG, "read char, uuid=" + characteristic.getUuid().toString());
            byte[] value = characteristic.getValue();
            BLELog.d(TAG, "get value, byte length:" + value.length);
            for (int i = 0; i < value.length; i++) {
                BLELog.d(TAG, "[" + i + "]" + Byte.toString(value[i]));
            }
            mQueue.onConsumed();
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic chrc) {
            BLELog.d(TAG, "on chr changed");
            if (chrc.getUuid().equals(Constants.CHR_ISSC_TRANS_TX)) {
                onReceived(chrc.getValue());
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mSuccess += characteristic.getValue().length;
            } else {
                mFail += characteristic.getValue().length;
            }
            BLELog.d(TAG, " onCharacteristicWrite " + status);
            mQueue.onConsumed();
        }

        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor dsc, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                byte[] value = dsc.getValue();
                if (Arrays.equals(value, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)) {
                    Bundle state = new Bundle();
                    state.putBoolean(RCV_ENABLED, true);
                    if (transSupported == false) {
                        BLELog.d(TAG, "Transparent READY --------------");
                        transSupported = true;
                        Intent intent = new Intent(BLE_TRANS_READY);
                        m_context.sendBroadcast(intent);
                        //packAndSendCommand(UART_CMD_READ_LINK_STATUS);
                    }
                }
            }
        }
    };
    private File mTempFile;

    private static boolean mDoNothandleGattClose = false;

    public void setDoNothandleGattClose(boolean doNothandleGattClose) {
        mDoNothandleGattClose = doNothandleGattClose;

    }



    public TransparentServiceManager(Context context, String devId, File tempFile) {
        m_context = context;
        mDevId = devId;
        mTempFile = tempFile;
        mSpeaker = HomeScreenActivity.getInstance().getSpeaker(mDevId);
        mQueue = new TransactionQueue(this);
        connectService();
        msgTransHandler = new transparentRxHandler();
        sInstance = this;
    }

    // Getter to access Singleton instance
    public static TransparentServiceManager getInstance() {
        return sInstance;
    }


    public void forceDisconnect(String message) {
        BLELog.d(TAG, message);
        mBleManager.disconnect(mSpeaker.getBtDevice());

    }

    public void cleanupTransparentService() {
        BLELog.d(TAG, " balaji cleanupTransparentService called mDoNothandleGattClose"+ mDoNothandleGattClose);
        if (mDoNothandleGattClose == true)
            mBleManager.removeListener(mGattCallback);

        forceDisconnect("Delete");
        if (mDoNothandleGattClose == true)
            sInstance = null;
    }

    private void enableNotification() {
        boolean set = mBleManager.setCharacteristicNotification(mTransTx, true);
        BLELog.d(TAG, "set notification:" + set);
        BluetoothGattDescriptor dsc = mTransTx.getDescriptor(Constants.DES_CLIENT_CHR_CONFIG);
        dsc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        boolean success = mBleManager.writeDescriptor(dsc);
        BLELog.d(TAG, "writing enable descriptor:" + success);
    }

    private void onReceived(byte[] data) {
        if (data == null) {
            return;
        }
       /* int i = 0;
        for (i = 0; i < data.length; i++)
            BLELog.d(TAG, "Transparent Rx:" + data[i]);*/

        Bundle msg = new Bundle();
        msg.putByteArray(TRANS_RX_BYTES, data);
        processTransRxMsg(TRANS_RX_MESSAGE, msg);
    }

    public void processTransRxMsg(int tag, Bundle info) {
        if (info == null) {
            info = new Bundle();
        }
        Message msg = msgTransHandler.obtainMessage(tag);
        msg.what = tag;
        msg.setData(info);
        msgTransHandler.sendMessage(msg);
    }

    public void registerFragReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        m_context.registerReceiver(receiver, filter);
    }

    public void unregisterFragReceiver(BroadcastReceiver receiver) {
        try {
            m_context.unregisterReceiver(receiver);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    /**
     * Write 5506 command to remote device.
     */
    public void sendCommand(char[] data) {
        BLELog.d(TAG, "====>  sendCommand : " + data);
        sendDataByTransparent(data);
    }

    public char[] packAndSendCommand(String message) {
        BLELog.d(TAG, "====>  packAndSendCommand : " + message);


        char inCmd[] = new char[message.length()];
        int curIndex = message.indexOf(' ');
        int inCmdCount = 0;
        String inMessage = message;
        String tmpString1 = null;
        String tmpString2 = null;
        while (curIndex > 0) {
            tmpString1 = inMessage.substring(0, curIndex);
            tmpString2 = inMessage.substring(curIndex + 1, inMessage.length());
            inCmd[inCmdCount++] = (char) Integer.parseInt(tmpString1, 16);
            inMessage = tmpString2;
            curIndex = inMessage.indexOf(' ');
            if (curIndex == -1)
                inCmd[inCmdCount++] = (char) Integer.parseInt(tmpString2, 16);
        }

        char cmds[] = new char[1 + 2 + inCmdCount + 1];
        int index = 0;
        cmds[index++] = 0xaa;
        cmds[index++] = 0x00;
        cmds[index++] = (char) (inCmdCount);

        int i;
        for (i = 0; i < inCmdCount; i++)
            cmds[index + i] = inCmd[i];
        cmds[index + inCmdCount] = 0;
        for (i = 0; i < inCmdCount + 2; i++)
            cmds[index + inCmdCount] += cmds[i + 1];
        cmds[index + inCmdCount] &= 0xff;
        cmds[index + inCmdCount] = (char) (256 - cmds[index + inCmdCount]);

        String showMessage = "";
        for (i = 0; i < 1 + 2 + inCmdCount + 1; i++) {
            // android.util.Log.d(getClass().getName(), String.format("value = %d", (int) cmds[i]));
            // showMessage += String.format("0x%02X", (int) cmds[i]) + " ";
        }
        sendDataByTransparent(cmds);

        String packedMessage = "";
        char[] packedCmds = cmds;
        for (i = 0; i < packedCmds.length; i++) {
            android.util.Log.d(getClass().getName(), String.format("value = %d", (int) packedCmds[i]));
            packedMessage += String.format("0x%02X", (int) packedCmds[i]) + " ";
        }
        packedMessage += "\n";
        appendMsg(packedMessage, true);
        return cmds;
    }

    public BluetoothDevice getDevice() {
        return mSpeaker.getBtDevice();
    }

    private void sendDataByTransparent(char[] data) {
        if (transSupported == false) {
            BLELog.d(TAG, "sendDataByTransparent : MCHP Transparent service have NOT started");
            return;
        }
        int i;
        ByteBuffer buf = ByteBuffer.allocate(data.length);
        byte commandBytes[] = new byte[data.length];
        for (i = 0; i < data.length; i++)
            commandBytes[i] = (byte) data[i];
        buf.put(commandBytes);
        buf.position(0);
        while (buf.remaining() != 0) {
            int size = (buf.remaining() > PAYLOAD_MAX) ? PAYLOAD_MAX : buf.remaining();
            byte[] dst = new byte[size];
            buf.get(dst, 0, size);
            // mTransRx.setValue(dst);
            //  mBleManager.writeCharacteristic(mTransRx);
            GattTransaction t = new GattTransaction(mTransRx, dst);
            mQueue.add(t);
        }
    }

    private void onConnected() {
        List<BluetoothGattService> list = mBleManager.getServices(mSpeaker.getBtDevice());
        if ((list == null) || (list.size() == 0)) {
            BLELog.d(TAG, "no services, do discovery");
            mBleManager.discoverServices(mSpeaker.getBtDevice());
            //mBleManager.setMtuSize();
        } else {
            onDiscovered();
        }
    }

    private void onDisconnected() {
        BLELog.d(TAG, "transparent activity disconnected, closing");
        Intent intent = new Intent(BLE_DISCONNECTED);
        m_context.sendBroadcast(intent);
        if (!transSupported)
            return;
        mQueue.clear();
    }


    private void onDiscovered() {
        BLELog.d(TAG, "ActivityTransparent ------> Service On Discovered");
        BluetoothGattService proprietary = mBleManager.getService(mSpeaker.getBtDevice(), Constants.SERVICE_ISSC_PROPRIETARY);
        if (proprietary == null) {
            BLELog.d(TAG, "ActivityTransparent ------> Service On Discovered proprietary == null Disconnecteing" );
            mBleManager.disconnect(mSpeaker.getBtDevice());
            //mBleManager.closeGatt(mSpeaker.getBtDevice());
            transSupported = false;
        } else {
            mTransTx = proprietary.getCharacteristic(Constants.CHR_ISSC_TRANS_TX);
            mTransRx = proprietary.getCharacteristic(Constants.CHR_ISSC_TRANS_RX);
            if (mDoNothandleGattClose == true) {
                mBleManager.setMtuSize();
                BLELog.d(TAG, "Setting  MTU Now !");
            }
            else {
                enableNotification();
                BLELog.d(TAG, "Enabling notification MTU Now !");
            }
        }
    }

    private void onMTUChange() {
        if (mDoNothandleGattClose == true) {
            enableNotification();
        }
        BLELog.d(TAG, "Transparent onMTUChange service ready");

    }

    @Override
    public void onTransact(GattTransaction t) {
        t.chr.setValue(t.value);
        int i = 0;
        for (i = 0; i < t.value.length; i++) {
            t.value[i] &= 0xff;
            //  BLELog.d(TAG, "send" + i + " :" + t.value[i]);
        }

        if (t.isWrite) {
            t.chr.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            mBleManager.writeCharacteristic(t.chr);
        } else {
            mBleManager.readCharacteristic(t.chr);
        }
    }

    public void finalize() {
        BLELog.d(TAG, "Finalize called");
    }

    public void connectService() {

        mBleManager = BLEManager.getBLEManager(HomeScreenActivity.getInstance());
        mBleManager.addListener(mGattCallback);

        int conn = mBleManager.getConnectionState(mSpeaker.getBtDevice());
        if (conn == BluetoothProfile.STATE_DISCONNECTED) {
            onDisconnected();
        } else {
            BLELog.d(TAG, "already connected");
            onConnected();
        }
    }

    public boolean isConnected() {
        int conn = mBleManager.getConnectionState(mSpeaker.getBtDevice());
        if (conn == BluetoothProfile.STATE_DISCONNECTED)
            return false;
        if (conn == BluetoothProfile.STATE_CONNECTED)
            return true;
        else return false;
    }

    private void appendMsg(String msg, boolean isTx) {
        if (mTempFile != null) {
            try {
                if (isTx)
                    msg = "->" + msg;
                else
                    msg = "<-" + msg;
                FileWriter writer = new FileWriter(mTempFile, true);
                BufferedWriter bw = new BufferedWriter(writer);
                bw.write(msg);
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void logCommand(byte rxBytes[]) {
        if (mTempFile != null) {
            if (rxBytes != null) {
                int k;
                String replyString = "";
                char rxDataHex[] = new char[rxBytes.length];
                for (k = 0; k < rxDataHex.length; k++) {
                    rxDataHex[k] = (char) rxBytes[k];
                    replyString += String.format("0x%02X", (int) (rxDataHex[k]) & 0xff) + " ";
                    BLELog.d(TAG, "Commands Fragment Rx data : " + rxBytes[k]);
                }
                replyString += "\n";
                appendMsg(replyString, false);

            }
        }
    }

    class transparentRxHandler extends Handler {
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            if (bundle == null) {
                BLELog.d(TAG, "transparentRxHandler handled a message without information");
                return;
            }
            int tag = msg.what;
            if (tag == TRANS_RX_MESSAGE) {
                logCommand(bundle.getByteArray(TRANS_RX_BYTES));
                Intent intent = new Intent(BLE_TRANS_DATA);
                intent.putExtra(BLE_RX_BYTES, bundle.getByteArray(TRANS_RX_BYTES));
                m_context.sendBroadcast(intent);
            }
        }
    }
}
