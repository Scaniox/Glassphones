package com.app.microchip.dsptunning.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.pagerAdap.MyPagerAdapter;
import com.app.microchip.dsptunning.pagerFrag.AECVoiceFragment;
import com.app.microchip.dsptunning.pagerFrag.EQVoiceFragment;
import com.app.microchip.dsptunning.pagerFrag.FilerVoiceFragment;
import com.app.microchip.dsptunning.pagerFrag.MICGainVoiceFragment;
import com.app.microchip.dsptunning.pagerFrag.NoiseReductionVoiceFragment;

/**
 * Created by I17163 on 12/12/2019.
 */

public class DspTuningVoicePagerActivity extends AppCompatActivity implements ViewPager.OnPageChangeListener {
    private static final String TAG = DspTuningVoicePagerActivity.class.getSimpleName();


    private MyPagerAdapter pagerAdapterView;

    private ImageView firstDotImageView;
    private ImageView secondDotImageView;
    private ImageView thirdDotImageView;
    private ImageView fourthDotImageView;
    private ImageView fifthDotImageView;

    private FilerVoiceFragment filerVoiceFragment1;
    private NoiseReductionVoiceFragment noiseReductionVoiceFragment2;
    private EQVoiceFragment eQVoiceFragment3;
    private MICGainVoiceFragment mICGainVoiceFragment4;
    private AECVoiceFragment aECVoiceFragment5;

    ViewPager myViewPager;




    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }
    private int prevPagePosition = 0;

    @Override
    public void onPageSelected(int position) {
        Log.d(TAG,"onPageSelected="+position);
        if (position == 0) {
            firstDotImageView.setImageResource(R.drawable.current_position_icon);
            secondDotImageView.setImageResource(R.drawable.disable_position_icon);
            thirdDotImageView.setImageResource(R.drawable.disable_position_icon);
            fourthDotImageView.setImageResource(R.drawable.disable_position_icon);
            fifthDotImageView.setImageResource(R.drawable.disable_position_icon);


            noiseReductionVoiceFragment2.cleanModule();
            filerVoiceFragment1.initModule(DspTuningVoicePagerActivity.this);
            setTitle(" Filter");
            prevPagePosition = 0;
        } else if (position == 1) {


            filerVoiceFragment1.cleanModule();
            noiseReductionVoiceFragment2.initModule(DspTuningVoicePagerActivity.this);
            setTitle(" Noise Reduction ");
            prevPagePosition = 1;

            firstDotImageView.setImageResource(R.drawable.disable_position_icon);
            secondDotImageView.setImageResource(R.drawable.current_position_icon);
            thirdDotImageView.setImageResource(R.drawable.disable_position_icon);
            fourthDotImageView.setImageResource(R.drawable.disable_position_icon);
            fifthDotImageView.setImageResource(R.drawable.disable_position_icon);



        } else if (position == 2) {


            setTitle(" EQ");
            prevPagePosition = 2;

            eQVoiceFragment3.initModule(DspTuningVoicePagerActivity.this);

            firstDotImageView.setImageResource(R.drawable.disable_position_icon);
            secondDotImageView.setImageResource(R.drawable.disable_position_icon);
            thirdDotImageView.setImageResource(R.drawable.current_position_icon);
            fourthDotImageView.setImageResource(R.drawable.disable_position_icon);
            fifthDotImageView.setImageResource(R.drawable.disable_position_icon);

        } else if (position == 3) {
            setTitle(" MIC Gain/ComfortNoise");
            prevPagePosition = 3;

            mICGainVoiceFragment4.initModule(DspTuningVoicePagerActivity.this);

            firstDotImageView.setImageResource(R.drawable.disable_position_icon);
            secondDotImageView.setImageResource(R.drawable.disable_position_icon);
            thirdDotImageView.setImageResource(R.drawable.disable_position_icon);
            fourthDotImageView.setImageResource(R.drawable.current_position_icon);
            fifthDotImageView.setImageResource(R.drawable.disable_position_icon);

        } else if (position == 4) {

            setTitle(" AEC/AES");
            prevPagePosition = 4;

            aECVoiceFragment5.initModule(DspTuningVoicePagerActivity.this);

            firstDotImageView.setImageResource(R.drawable.disable_position_icon);
            secondDotImageView.setImageResource(R.drawable.disable_position_icon);
            thirdDotImageView.setImageResource(R.drawable.disable_position_icon);
            fourthDotImageView.setImageResource(R.drawable.disable_position_icon);
            fifthDotImageView.setImageResource(R.drawable.current_position_icon);

        }
    }


    @Override
    public void onPageScrollStateChanged(int state) {

    }



    /*private void onPageSelected(int position) {
        if  (position == 0) {
                firstDotImageView.setImageResource(R.drawable.current_position_icon);
                secondDotImageView.setImageResource(R.drawable.disable_position_icon);
                thirdDotImageView.setImageResource(R.drawable.disable_position_icon);
        } else if  (position == 1)  {

                firstDotImageView.setImageResource(R.drawable.disable_position_icon);
                secondDotImageView.setImageResource(R.drawable.current_position_icon);
                thirdDotImageView.setImageResource(R.drawable.disable_position_icon);

        } else if  (position == 2)  {

                firstDotImageView.setImageResource(R.drawable.disable_position_icon);
                secondDotImageView.setImageResource(R.drawable.disable_position_icon);
                thirdDotImageView.setImageResource(R.drawable.current_position_icon);

        }
    }*/

    private void addPagerFragments() {
        filerVoiceFragment1 = new FilerVoiceFragment();
         noiseReductionVoiceFragment2 = new NoiseReductionVoiceFragment();
          eQVoiceFragment3 = new EQVoiceFragment();
          mICGainVoiceFragment4 = new MICGainVoiceFragment();
          aECVoiceFragment5 = new AECVoiceFragment();

            pagerAdapterView.addFragments(filerVoiceFragment1);
            pagerAdapterView.addFragments(noiseReductionVoiceFragment2);
            pagerAdapterView.addFragments(eQVoiceFragment3);
            pagerAdapterView.addFragments(mICGainVoiceFragment4);
            pagerAdapterView.addFragments(aECVoiceFragment5);

        setTitle(" Filter");
        //DspOTATunningMainActivity.getINSTANCE().getmBLEService().DSP_Init();
        filerVoiceFragment1.initModule(DspTuningVoicePagerActivity.this);
    }

   /*() private void  zoomOutTransformation(page:View, position: Float) {
        when {
            position < -1 ->
            page.alpha = 0f
            position <= 1 -> {
                page.scaleX = Math.max(MIN_SCALE, 1 - Math.abs(position))
                page.scaleY = Math.max(MIN_SCALE, 1 - Math.abs(position))
                page.alpha = Math.max(MIN_ALPHA, 1 - Math.abs(position))
            }
            else -> page.alpha = 0f
        }
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);



        //  WindowManager wm = (WindowManager) getApplicationContext()
        //.getSystemService(Context.WINDOW_SERVICE);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activty_pager_voice);

        firstDotImageView = (ImageView) findViewById(R.id.firstDotImageView);
        secondDotImageView = (ImageView) findViewById(R.id.secondDotImageView);
        thirdDotImageView = (ImageView) findViewById(R.id.thirdDotImageView);
          fourthDotImageView = (ImageView) findViewById(R.id.fourthDotImageView);
          fifthDotImageView = (ImageView) findViewById(R.id.fifthDotImageView);

       myViewPager = (ViewPager) findViewById(R.id.myViewPager);

        pagerAdapterView = new MyPagerAdapter(getSupportFragmentManager());
        isReadModuleData = true;
        addPagerFragments();
        myViewPager.setAdapter(pagerAdapterView);
        myViewPager.addOnPageChangeListener(this);

        registerReceiver(mGattUpdateReceiver, makeIntentFilter());

    }
    private  boolean isFragmentWithoutPager = false;
    private boolean isReadModuleData ;

    public void loadFragmentWithoutPager (Fragment fragment){

        isFragmentWithoutPager = true;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

      //  setContentView(R.layout.activity_);

        myViewPager = (ViewPager) findViewById(R.id.myViewPager);

        pagerAdapterView = new MyPagerAdapter(getSupportFragmentManager());
        addPagerFragments();
        myViewPager.setAdapter(pagerAdapterView);
        myViewPager.addOnPageChangeListener(this);


    }

    public void removeFragmentWithoutPager (){
        isFragmentWithoutPager = false;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activty_pager_audio);

        firstDotImageView = (ImageView) findViewById(R.id.firstDotImageView);
        secondDotImageView = (ImageView) findViewById(R.id.secondDotImageView);
        thirdDotImageView = (ImageView) findViewById(R.id.thirdDotImageView);

        myViewPager = (ViewPager) findViewById(R.id.myViewPager);

        pagerAdapterView = new MyPagerAdapter(getSupportFragmentManager());
        isReadModuleData = false;
        addPagerFragments();
        myViewPager.setAdapter(pagerAdapterView);
        myViewPager.addOnPageChangeListener(this);

        registerReceiver(mGattUpdateReceiver, makeIntentFilter());

    }


    public void onBackPressed() {
        if (isFragmentWithoutPager) {
            removeFragmentWithoutPager();
            return;
        }

        super.onBackPressed();


    }
    //End Pager code

    private ProgressDialog mSpinnerDialog;

    public void showSpinnerDialog(boolean isTunning) {

        mSpinnerDialog = new ProgressDialog(DspTuningVoicePagerActivity.this);
        mSpinnerDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        if(isTunning)
            mSpinnerDialog.setMessage("Please wait..Tunning Params.. ");
        else
            mSpinnerDialog.setMessage("Please wait..Reading Params.. ");
        mSpinnerDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mSpinnerDialog.setIndeterminate(true);
        mSpinnerDialog.setCancelable(false);
        mSpinnerDialog.setCanceledOnTouchOutside(false);
        mSpinnerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                               @Override
                                               public void onCancel(DialogInterface dialog) {
                                                   BLELog.d(TAG, "Cancelling during validation");

                                               }
                                           }
        );

        mSpinnerDialog.show();
    }

    public void dismissSpinnerDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSpinnerDialog != null && mSpinnerDialog.isShowing()) {
                    mSpinnerDialog.dismiss();
                }
            }
        });
    }

    protected void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        unregisterReceiver(mGattUpdateReceiver);
        super.onDestroy();
    }


    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            BLELog.d(TAG, "BroadcastReceiver action: " + action);
            if (action.equals(DspOTATunningBLEService.ACTION_GATT_DISCONNECTED)) {
                finish();
            }

        }
    };

    private static IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(DspOTATunningBLEService.ACTION_GATT_DISCONNECTED);

        return intentFilter;
    }




}
