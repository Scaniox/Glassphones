package com.app.microchip.dsptunning.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;


public class DspOTATunningMainActivity extends AppCompatActivity  implements DSPTuningDelegate {

    private static final String TAG = DspOTATunningMainActivity.class.getSimpleName();

    public static DspOTATunningMainActivity getINSTANCE() {
        return INSTANCE;
    }

    private static DspOTATunningMainActivity INSTANCE;

    public DspOTATunningBLEService getmBLEService() {
        return mBLEService;
    }

    private DspOTATunningBLEService mBLEService;
    private ProgressDialog mSpinnerDialog;

    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            BLELog.d(TAG, "BroadcastReceiver action: " + action);
            if (action.equals(DspOTATunningBLEService.ACTION_GATT_SERVICES_DISCOVERED)) {
                dismissSpinnerDialog();
                Toast.makeText(DspOTATunningMainActivity.this, "Connected", Toast.LENGTH_SHORT).show();



            } else if (action.equals(DspOTATunningBLEService.ACTION_GATT_DISCONNECTED)) {
                Toast.makeText(DspOTATunningMainActivity.this, "Disconnected", Toast.LENGTH_SHORT).show();
                finish();


            } else if (action.equals(DspOTATunningBLEService.ACTION_DATA_AVAILABLE)) {


                BLELog.d(TAG, " ACTION_DATA_AVAILABLE ");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                    }
                });
            }


        }
    };

    private String address;
    private String deviceName;

    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            BLELog.d(TAG, "onServiceConnected");
            displaySpinnerDialog();
            Intent i = new Intent(DspOTATunningBLEService.ACTION_CONNECT);
            i.putExtra("ADDRESS", address);
            sendBroadcast(i);

            mBLEService = ((DspOTATunningBLEService.LocalBinder) service).getService();
            mBLEService.setListener(DspOTATunningMainActivity.this);
            mBLEService.DSP_Init();
            //mBLEService.DSPTuningCommand((byte) (0x02));
            BLELog.d(TAG, " mBLEService onServiceConnected");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };
    private void dismissSpinnerDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSpinnerDialog != null && mSpinnerDialog.isShowing()) {
                    mSpinnerDialog.dismiss();
                }
            }
        });
    }

    private void displaySpinnerDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSpinnerDialog != null)
                    mSpinnerDialog.show();
            }
        });
    }
    private void stopConnect() {
        if (mBLEService != null) {
            mBLEService.disconnect();
        }
        finish();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dsp_controller);
        INSTANCE = this;

        address = getIntent().getStringExtra("Address");
        deviceName = getIntent().getStringExtra("Name");

        InitializeUI();

        mSpinnerDialog = new ProgressDialog(this);
        mSpinnerDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mSpinnerDialog.setMessage("Connecting. Please wait...");
        mSpinnerDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mSpinnerDialog.setIndeterminate(true);
        mSpinnerDialog.setCancelable(true);
        mSpinnerDialog.setCanceledOnTouchOutside(false);
        mSpinnerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                               @Override
                                               public void onCancel(DialogInterface dialog) {
                                                   BLELog.d(TAG, "Cancelling Connection");
                                                   stopConnect();
                                               }
                                           }
        );

        Intent gattServiceIntent = new Intent(this, DspOTATunningBLEService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
        registerReceiver(mGattUpdateReceiver, makeIntentFilter());

    }

    private static IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(DspOTATunningBLEService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(DspOTATunningBLEService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(DspOTATunningBLEService.ACTION_GATT_SERVICES_DISCOVERED);

        return intentFilter;
    }

    private void commandError(final String message) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), message,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onPause() {
        BLELog.d(TAG, "onPause called");

        super.onPause();
    }

    @Override
    protected void onResume() {
        BLELog.d(TAG, "onResume called");
        super.onResume();

        InitializeUI();
    }

    @Override
    protected void onStart() {
        BLELog.d(TAG, "onStart called");
        super.onStart();
    }

    @Override
    protected void onStop() {
        BLELog.d(TAG, "onStop called");
        super.onStop();
    }

    protected void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        unregisterReceiver(mGattUpdateReceiver);
        unbindService(mServiceConnection);
        // TODO disconnect TSP tunning
        INSTANCE = null;
        super.onDestroy();

    }

    public void onBackPressed(){

        if (mBLEService != null)
            mBLEService.disconnect();
        super.onBackPressed();

    }




    public void InitializeUI() {

        setTitle("Dynamic OTA DSP Tuning");


        RelativeLayout audioFunction = (RelativeLayout) findViewById(R.id.audioFunction);
        audioFunction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DspTuningAudioPagerActivity.class);
                startActivity(intent);
            }
        });

        RelativeLayout groupsettings = (RelativeLayout) findViewById(R.id.dspVoiceFunction);
        groupsettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DspTuningVoicePagerActivity.class);
                startActivity(intent);
            }
        });

        RelativeLayout dspCommandOptions = (RelativeLayout) findViewById(R.id.DspTunningCmds);
        dspCommandOptions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initializeCommands();
            }
        });


        RelativeLayout exportDspdata = (RelativeLayout) findViewById(R.id.dspTuneExportData);
        exportDspdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }

    public void initializeCommands () {

// setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Dynamic Tunning Commands");

// add a list
        String[] animals = {"Factory Reset", "Reset DSP", "Reset DUT", "Save to Flash", "Reset Parameters", "Cancel"};
        builder.setItems(animals, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // Factory Reset
                        mBLEService.DSPTuningCommand((byte)0x07);
                        break;
                    case 1: // Reset DSP
                        mBLEService.DSPTuningCommand((byte)0x05);
                        break;
                    case 2: // Reset DUT
                        mBLEService.DSPTuningCommand((byte)0x06);
                        break;
                    case 3: // Save to Flash
                        mBLEService.DSPTuningCommand((byte)0x08);
                        break;
                    case 4: // Reset Parameters
                        mBLEService.DSPTuningCommand((byte)0x04);
                        break;
                }
            }
        });

// create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void sendCommand(String cmd) {

    }


    @Override
    public void BLE_ServiceReady() {

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] Data) {

    }

    private void showTuneDspDialog(String message) {


            final android.app.AlertDialog.Builder ad = new android.app.AlertDialog.Builder(DspOTATunningMainActivity.this , R.style.MyDialogTheme);
            ad.setMessage(message);

            ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
            /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
            sendBroadcast(i);
              mOtaState.setText("Completed");*/
                }
            });

            final android.app.AlertDialog alert = ad.create();
            alert.setTitle("Tune DSP Status!!");
            alert.show();



            alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {

                }
            });



    }
String dialogMessage = "";
    @Override
    public void DSPTuningComplete(byte result) {
       /* if(result != 0x01){
            var str:String = ""

            str = "Failed " + String(result)

            let alertController = UIAlertController(
                    title: "DynamicTuningCommand",
                    message: str,
                    preferredStyle: .alert)

            let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
                print("okAction")
            }

            alertController.addAction(okAction)

            self.present(alertController, animated: true, completion: nil)
        }*/

        String  status = "";

        if(result == 0x01){
            status = "Success";
        }
        else{
            status = "Failed " + result;
        }
        dialogMessage = status;

        runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                showTuneDspDialog(dialogMessage);

            }
        }));



    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {

    }

    @Override
    public void ExportDSPTuningResult() {

    }
}
