package com.app.microchip.audiowidget.ota;

import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class OTAEncrypt {

	public static byte[] encrypt(byte[] plainText, byte[] customerKey) {
		if (plainText == null || customerKey == null) {
			return null;
		}

		if(customerKey.length != 16)
			return null;

		byte[] password = new byte[16];

		for (int i = 0; i < password.length; i++) {
			password[i] = customerKey[i];
		}

		for (int i = 0; i < 8; i++) {
			byte temp;
			temp = plainText[i];
			plainText[i] = plainText[plainText.length-1-i];
			plainText[plainText.length-1-i] = temp;

			temp = password[i];
			password[i] = password[password.length-1-i];
			password[password.length-1-i] = temp;
		}
		try {
			AESCrypt(password);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] encrypted = cipher.doFinal(plainText);
			for (int i = 0; i < 8; i++) {
				byte temp;
				temp = encrypted[i];
				encrypted[i] = encrypted[encrypted.length-1-i];
				encrypted[encrypted.length-1-i] = temp;
			}
			return encrypted;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 *  @method                                 encrypt
	 *
	 *  @param plainText                        The data to encrypt. The data is from the challenge data of Login Request
	 *  @param customerKey                      The key setting in UI table
	 *  @param sn                               The serial number in DIS service
	 *
	 *  @return                                 The encrypted data.
	 *
	 *
	 */
	public static byte[] encrypt(byte[] plainText, byte[] customerKey, byte[] sn) {
		if (plainText == null || customerKey == null || sn == null) {
			return null;
		}
		byte[] password = new byte[16];
		for (int i = 0; i < password.length; i++) {
			if (i < 10) {
				if (i< sn.length) {
					password[i] = sn[i];
				}
				else {
					password[i] = 0;
				}
			}
			else {
				if ((i-10)< customerKey.length) {
					password[i] = customerKey[i-10];
				}
				else {
					password[i] = 0;
				}
			}
		}
		for (int i = 0; i < 8; i++) {
			byte temp;
			temp = plainText[i];
			plainText[i] = plainText[plainText.length-1-i];
			plainText[plainText.length-1-i] = temp;

			temp = password[i];
			password[i] = password[password.length-1-i];
			password[password.length-1-i] = temp;
		}
		try {
            AESCrypt(password);
		    cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] encrypted = cipher.doFinal(plainText);
			for (int i = 0; i < 8; i++) {
				byte temp;
				temp = encrypted[i];
				encrypted[i] = encrypted[encrypted.length-1-i];
				encrypted[encrypted.length-1-i] = temp;
			}
			return encrypted;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 *  @method                                 libVersion
	 *
	 *  @return                                 Version of this library.
	 *
	 *
	 */
	public static String libVersion() {
		return _libVersion;
	}

	private static void AESCrypt(byte[] password) throws Exception {
		cipher = Cipher.getInstance("AES/ECB/NoPadding");
		key = new SecretKeySpec(password, "AES");
		spec = getIV();
	}

	public  static byte[]  AESCryptEX(byte[] data,byte[] aesKey, byte[] IV) throws Exception {

		cipher = Cipher.getInstance("AES/CFB/NoPadding");
		key = new SecretKeySpec(aesKey, "AES");
		spec = getIVEx(IV);

		cipher.init(Cipher.ENCRYPT_MODE, key,spec);
		byte[] encrypted = cipher.doFinal(data);

		return  encrypted;

	}

	private static AlgorithmParameterSpec getIVEx(byte[] IV) {
		IvParameterSpec ivParameterSpec;
		ivParameterSpec = new IvParameterSpec(IV);

		return ivParameterSpec;
	}


	private static AlgorithmParameterSpec getIV() {
		byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, };
		IvParameterSpec ivParameterSpec;
		ivParameterSpec = new IvParameterSpec(iv);

		return ivParameterSpec;
	}

	//private static final String _libVersion = "1.0";
	private static final String _libVersion = "1.1";
	private static Cipher cipher;
	private static SecretKeySpec key;
	private static AlgorithmParameterSpec spec;

}
