package com.app.microchip.wstearbuds.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.util.Constants;

import java.util.ArrayList;

/**
 * Created by I21309 on 2/20/2017.
 */


public class EarbudsSpeakerControlAdapter extends BaseAdapter {

    private static LayoutInflater inflater = null;
    private Activity activity;
    private ArrayList<BLESpeaker> data;

    public EarbudsSpeakerControlAdapter(Activity a, ArrayList<BLESpeaker> d) {
        activity = a;
        data = d;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    public int getCount() {
        return data.size();
    }


    public Object getItem(int position) {
        return position;
    }


    public long getItemId(int position) {
        return position;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null)
            vi = inflater.inflate(R.layout.groupinfo_list_row, null);

        TextView deviceName = (TextView) vi.findViewById(R.id.textView1);
        TextView deviceStatus = (TextView) vi.findViewById(R.id.textView2);

        BLESpeaker spk = new BLESpeaker();
        
        spk = data.get(position);

        // Setting all values in listview
        deviceName.setText(spk.getName());
        deviceStatus.setText(Constants.getSpeakerTypeString(spk.getGroupStatus()));
        return vi;
    }

}