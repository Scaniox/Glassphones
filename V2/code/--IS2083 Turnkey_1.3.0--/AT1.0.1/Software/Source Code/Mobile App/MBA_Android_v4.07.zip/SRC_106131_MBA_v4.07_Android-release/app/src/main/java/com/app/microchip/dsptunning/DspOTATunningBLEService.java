package com.app.microchip.dsptunning;

import android.annotation.SuppressLint;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import com.app.microchip.audiowidget.ota.BTUUID;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;

import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.UUID;

@SuppressLint("SimpleDateFormat")
public class DspOTATunningBLEService extends Service {


    public final static String UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE = "49535343-87E0-4C24-83CD-A9AF7933EAC2";
    public final static String UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR = "49535343-B75C-4470-9621-16B7F26C1045";
    public final static String UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR = "49535343-4BB6-4977-B521-F04466776A3F";
    public final static String UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR = "49535343-2DD1-45A3-94DE-8810F6436D78";
    public final static UUID UUID_MCHP_OTA_CFG_UPD_SERVICE = BTUUID
            .uuidFromString(UUIDSTR_MCHP_OTA_CFG_UPD_SERVICE);
    public final static UUID UUID_MCHP_OTA_CFG_UPD_PARAMETER_CHAR = BTUUID
            .uuidFromString(UUIDSTR_MCHP_OTA_CFG_UPD_PARAMETER_CHAR);
    public final static UUID UUID_MCHP_OTA_CFG_UPD_CTRL_CHAR = BTUUID
            .uuidFromString(UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR);
    public final static UUID UUID_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR = BTUUID
            .uuidFromString(UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR);



    private final static String TAG = DspOTATunningBLEService.class.getSimpleName();
    private final static String PACKAGE = DspOTATunningBLEService.class.getName();
    public final static String ACTION_GATT_CONNECTED = PACKAGE
            + "bluetooth.le.ACTION_GATT_CONNECTED";
    //AirPatch Control point
    public final static String ACTION_GATT_DISCONNECTED = PACKAGE
            + "bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED = PACKAGE
            + "bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE = PACKAGE
            + "bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String ACTION_CONNECT = PACKAGE
            + "bluetooth.le.ACTION_CONNECT";
    public final static String ACTION_DISCONNECT = PACKAGE
            + "bluetooth.le.ACTION_DISCONNECT";
    public final static String ACTION_LOG = PACKAGE + "bluetooth.le.ACTION_LOG";


    //command set
    private final static byte DSP_CMD_ = 0x01;


    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;
    private final IBinder mBinder = new LocalBinder();
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private String mBluetoothDeviceAddress;
    private BluetoothGatt mBluetoothGatt;
    private int mConnectionState = STATE_DISCONNECTED;

    private BluetoothGattCharacteristic otaDspControlPtChr;
    private BluetoothGattCharacteristic otaDspParamUpdateChr;
    private BluetoothGattCharacteristic otaDsplogChr;
    private BluetoothGatt mGatt;


    private Queue<BluetoothGattDescriptor> descriptorWriteQueue = new LinkedList<BluetoothGattDescriptor>();
    private Queue<TempQueueObject> characteristicWriteQueue = new LinkedList<TempQueueObject>();


    private int MAX_MTU_DATA_SIZE = 0;
    private int OTA_MTU_SIZE = 0;


    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status,
                                            int newState) {
            String intentAction;
            BLELog.d(TAG, "onConnectionStateChange");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    intentAction = ACTION_GATT_CONNECTED;
                    mConnectionState = STATE_CONNECTED;
                    broadcastUpdate(intentAction);
                    BLELog.d(TAG, "Connected to GATT server.");

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        BLELog.d(TAG, "Attempting Exchange MTU:" + mBluetoothGatt.requestMtu(247));
                    }

                    DSP_Init();
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    intentAction = ACTION_GATT_DISCONNECTED;
                    mConnectionState = STATE_DISCONNECTED;
                    BLELog.d(TAG, "Disconnected from GATT server.");
                    broadcastUpdate(intentAction);
                    otaDspParamUpdateChr = null;
                    otaDspControlPtChr = null;
                    otaDsplogChr = null;
                    DSP_Disconnect_Reset();
                }
            } else {
                BLELog.d(TAG, "GATT error code = " + status);
                broadcastUpdate(ACTION_GATT_DISCONNECTED);
            }
        }

        public void onMtuChanged(BluetoothGatt Gatt, int mtu, int status) {
            BLELog.d("onMtuChanged", "MTU: " + mtu + "status: " + status);
            BLELog.d(TAG, "Attempting to start service discovery:"
                    + mBluetoothGatt.discoverServices());
            OTA_MTU_SIZE = mtu;
            MAX_MTU_DATA_SIZE = OTA_MTU_SIZE - 3;
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            BLELog.d(TAG, "onServicesDiscovered status=" + status);
            List<BluetoothGattService> list = gatt.getServices();
            for (BluetoothGattService service : list) {
                BLELog.d(TAG, "Service:" + service.getUuid().toString());
            }
            if (status == BluetoothGatt.GATT_SUCCESS) {
                //  broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                BluetoothGattService service = gatt
                        .getService(UUID_MCHP_OTA_CFG_UPD_SERVICE);


                service = gatt.getService(UUID_MCHP_OTA_CFG_UPD_SERVICE);
                mGatt = gatt;
                if (service != null) {
                    for (BluetoothGattCharacteristic ch : service.getCharacteristics()) {
                        if (ch.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_CTRL_CHAR)) {
                            otaDspControlPtChr = ch;
                            setNotification(ch, true);
                            BLELog.d(TAG, "UUID_MCHP_OTA_CFG_UPD_CTRL_CHAR : SetNotification");
                        }
                        if (ch.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_PARAMETER_CHAR)) {
                            otaDspParamUpdateChr = ch;
                            setNotification(ch, true);
                            BLELog.d(TAG, "UUIDSTR_MCHP_OTA_CFG_UPD_CTRL_CHAR : SetNotification");
                        }
                        if (ch.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR)) {
                            otaDsplogChr = ch;
                            setNotification(ch, true);
                            BLELog.d(TAG, "UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR : SetNotification");
                        }

                    }

                    broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                    //DSPTuningCommand(())0x02;

                }

            } else {
                BLELog.d(TAG, "onServicesDiscovered received: " + status);
                mBluetoothGatt.discoverServices();
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic, int status) {
            characteristicWriteQueue.remove();
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (characteristic.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_CTRL_CHAR)) {
                    // Parse in DSP handler characteristic.getValue()
                    BLELog.d(TAG, "on CTRL PT chr READ=" + HexTool.byteArrayToHexString(characteristic.getValue()));
                    //broadcastUpdate(ACTION_DATA_AVAILABLE);
                    checkCharacteristicQueue();
                } else if (characteristic.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_PARAMETER_CHAR)) {
                    // Parse in DSP handler characteristic.getValue()
                    BLELog.d(TAG, "on _OTA_CFG_UPD_PARAMETER chr READ=" + HexTool.byteArrayToHexString(characteristic.getValue()));
                    DSPTuningResponse_Read(characteristic.getValue());
                    //broadcastUpdate(ACTION_DATA_AVAILABLE);
                    checkCharacteristicQueue();
                }
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            //BLELog.d(TAG,"onCharacteristicChanged calling broadcastUpdate");
            BLELog.d(TAG, "onCharacteristicChanged");
                    // Parse in DSP handler
            if (characteristic.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_CTRL_CHAR)) {
                // Parse in DSP handler characteristic.getValue()
                BLELog.d(TAG, "on CTRL PT chr changed=" + HexTool.byteArrayToHexString(characteristic.getValue()));
                DSPTuningCommandComplete(characteristic.getValue());
                broadcastUpdate(ACTION_DATA_AVAILABLE);
            } else if (characteristic.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_PARAMETER_CHAR)) {
                // Parse in DSP handler characteristic.getValue()
                BLELog.d(TAG, "on _OTA_CFG_UPD_PARAMETER chr changed=" + HexTool.byteArrayToHexString(characteristic.getValue()));
                DSPTuningResponse(characteristic.getValue());
                broadcastUpdate(ACTION_DATA_AVAILABLE);
            } else if (characteristic.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR)) {
                // Parse in DSP handler characteristic.getValue()
                BLELog.d(TAG, "on UUID_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR chr changed=" + HexTool.byteArrayToHexString(characteristic.getValue()));
                DSPTuningLogs(characteristic.getValue());
                broadcastUpdate(ACTION_DATA_AVAILABLE);
            }
            checkCharacteristicQueue();
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt,
                                      BluetoothGattDescriptor descriptor, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                BLELog.d(TAG, "Callback: Wrote GATT Descriptor successfully.");
            } else {
                BLELog.d(TAG, "Callback: Error writing GATT Descriptor: " + status);
            }
            descriptorWriteQueue.remove(); //pop the item that we just finishing writing
            //if there is more to write, do it!
            if (descriptorWriteQueue.size() > 0)
                mBluetoothGatt.writeDescriptor(descriptorWriteQueue.element());
            else
                checkCharacteristicQueue();
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt,
                                          BluetoothGattCharacteristic characteristic, int status) {
            BLELog.d("onCharacteristicWrite", "onCharacteristicWrite");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                BLELog.d(TAG, "GattWrite callback: SUCCESS");
            } else {
                BLELog.d(TAG, "Callback: Error writing GATT Characteristic: "
                        + status);
            }
            if (characteristicWriteQueue.size() > 0) {
                characteristicWriteQueue.remove();
                checkCharacteristicQueue();
            }
        }
    };


    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            BLELog.d(TAG, "BroadcastReceiver action: " + action);

            if (action.equals(ACTION_CONNECT)) {
                if (initialize()) {
                    String address = intent.getStringExtra("ADDRESS");
                    if (address != null) {
                        connect(address);
                    }
                }
            } else if (action.equals(ACTION_DISCONNECT)) {
                disconnect();
            }

        }
    };


    private static IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();

        intentFilter.addAction(ACTION_CONNECT);
        intentFilter.addAction(ACTION_DISCONNECT);


        return intentFilter;
    }

    public static boolean refreshDeviceCache(BluetoothGatt gatt) {
        try {
            Method localMethod = gatt.getClass().getMethod("refresh");
            if (localMethod != null) {
                return (Boolean) localMethod.invoke(gatt);
            }
        } catch (Exception localException) {
            BLELog.v(TAG, "Exeception occured while clearing cache");
        }
        return false;
    }

    public byte[] subArray(byte[] b, int offset, int length) {
        byte[] sub = new byte[length];
        for (int i = offset; i < offset + length; i++) {
            try {
                sub[i - offset] = b[i];
            } catch (Exception e) {

            }
        }
        return sub;
    }

    public void writeGattDescriptor(BluetoothGattDescriptor d) {
        //put the descriptor into the write queue
        descriptorWriteQueue.add(d);
        //if there is only 1 item in the queue, then write it.  If more than 1, we handle asynchronously in the callback above
        if (descriptorWriteQueue.size() == 1) {
            mBluetoothGatt.writeDescriptor(d);
        }
    }

    public void writeGattCharacteristic(BluetoothGattCharacteristic ch,
                                        byte[] data) {
        BLELog.d(TAG, "writeGattCharacteristic " + ch.getUuid().toString() + "  Value =" + HexTool.byteArrayToHexString(data));
        characteristicWriteQueue.add(new TempQueueObject(ch, data));
        if (characteristicWriteQueue.size() == 1
                && descriptorWriteQueue.size() == 0) {
            TempQueueObject temp = characteristicWriteQueue.peek();
            temp.write();
        }

    }

    public void checkCharacteristicQueue() {
        if (characteristicWriteQueue.size() > 0) {
            TempQueueObject temp = characteristicWriteQueue.peek();
            temp.write();
        }
    }

    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        sendBroadcast(intent);
    }


    public boolean initialize() {
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                BLELog.d(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            BLELog.d(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        return true;
    }

    public boolean connect(final String address) {
        if (mBluetoothAdapter == null || address == null) {
            return false;
        }
        BluetoothDevice mDevice = mBluetoothAdapter
                .getRemoteDevice(address);

        if (getConnectionState(mDevice) == BluetoothProfile.STATE_CONNECTED) {
            BLELog.d(TAG, "Its Already Connected");
            if (mBluetoothGatt != null) {
                mBluetoothGatt.connect();
                return true;
            }
        }
        if (mBluetoothGatt != null)
            mBluetoothGatt.close();
        mBluetoothGatt = mDevice.connectGatt(DspOTATunningMainActivity.getINSTANCE(), true, mGattCallback, BluetoothDevice.TRANSPORT_LE);
        refreshDeviceCache(mBluetoothGatt);
        mBluetoothDeviceAddress = address;

        mConnectionState = STATE_CONNECTING;
        return true;
    }

    public int getConnectionState(BluetoothDevice device) {
        BluetoothManager mgr = (BluetoothManager) DspOTATunningMainActivity.getINSTANCE().getSystemService(Context.BLUETOOTH_SERVICE);
        return mgr.getConnectionState(device, BluetoothProfile.GATT);
    }

    /**
     * Disconnects an existing connection or cancel a pending connection. The
     * disconnection result is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public void disconnect() {
        try {
            if (mBluetoothAdapter == null || mBluetoothGatt == null) {
                return;
            }
            mBluetoothGatt.disconnect();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    try {
                        if (mBluetoothGatt != null) {
                            mBluetoothGatt.close();
                            mBluetoothGatt = null;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, 1200);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // mBluetoothGatt = null;
    }

    /**
     * After using a given BLE device, the app must call this method to ensure resources are
     * released properly.
     */
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        close();
        return super.onUnbind(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        registerReceiver(mGattUpdateReceiver, makeIntentFilter());

    }

    @Override
    public void onDestroy() {
        if (mConnectionState != STATE_DISCONNECTED) {
            disconnect();
        }
        close();
        unregisterReceiver(mGattUpdateReceiver);
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    private void setNotification(BluetoothGattCharacteristic characteristic,
                                 Boolean b) {
        BLELog.d(TAG, "setNotification  b: " + b);
        mBluetoothGatt.setCharacteristicNotification(characteristic, b);
        BluetoothGattDescriptor descriptor = characteristic
                .getDescriptor(BTUUID.uuidFromString("2902"));
        if (descriptor != null) {
            if (b) {
                if ((characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                } else {
                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                }
            } else {
                descriptor.setValue(BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
            }
            writeGattDescriptor(descriptor);
        }

    }

    private ByteBuffer prepareOutputBuffer(byte commend) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(20);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        tempBuffer.put(commend);
        return tempBuffer;
    }

    private ByteBuffer prepareOutputBuffer(byte commend, int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        tempBuffer.put(commend);
        return tempBuffer;
    }


    private ByteBuffer prepareOutputBuffer(int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        return tempBuffer;
    }

    static byte[] getByteArrayUsed(ByteBuffer bb) {
        byte[] ba = Arrays.copyOfRange(bb.array(), 0, bb.position() );
        return ba;
    }

    private ByteBuffer prepareOutputBufferBigEND(int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.BIG_ENDIAN);
        return tempBuffer;
    }


    private class TempQueueObject extends Object {
        public BluetoothGattCharacteristic chr;
        public byte[] value;
        private boolean isRead = false;

        public TempQueueObject(BluetoothGattCharacteristic characteristic,
                               byte[] data, boolean read) {
            chr = characteristic;
            value = data;
            isRead = read;
        }

        public TempQueueObject(BluetoothGattCharacteristic characteristic,
                               byte[] data) {
            chr = characteristic;
            value = data;
            isRead = false;
        }

        public void write() {
            if (isRead) {
                mBluetoothGatt.readCharacteristic(chr);
            } else {
                if (chr.getWriteType() == BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) {

                    BLELog.d(TAG, "WRITE_TYPE_NO_RESPONSE");
                    chr.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                    chr.setValue(value);
                    mBluetoothGatt.writeCharacteristic(chr);
                } else {
                    BLELog.d(TAG, "WRITE_TYPE_DEFAULT");
                    chr.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                    chr.setValue(value);
                    mBluetoothGatt.writeCharacteristic(chr);
                }
            }
        }
    }


    public void DSPConfigParameterUpdate(byte[] data) {

       BluetoothGattService service = mGatt.getService(UUID_MCHP_OTA_CFG_UPD_SERVICE);
       if (service != null) {
            for (BluetoothGattCharacteristic ch : service.getCharacteristics()) {

                //if (null == otaDspParamUpdateChr) &&ch.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_CTRL_CHAR)) {
                /*if ( ch.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_PARAMETER_CHAR)) {
                    otaDspParamUpdateChr = ch;
                    setNotification(ch, true);
                    BLELog.d(TAG, " DSPConfigParameterUpdate UUID_MCHP_OTA_CFG_UPD_PARAMETER_CHAR : SetNotification");
                }*/

            }
        }

        if (otaDspParamUpdateChr == null) {
            BLELog.d(TAG, " DSPConfigParameterUpdate otaDspParamUpdateChr   is null");
            return;
        }

        if (DspOTATunningMainActivity.getINSTANCE() == null) {
            BLELog.d(TAG, " DspOTATunningMainActivity.getINSTANCE() == null");
            return;
        }
        BLELog.d(TAG, "DSPConfigParameterUpdate" + HexTool.byteArrayToHexString(data));

        ByteBuffer buffer = prepareOutputBuffer(data.length);
        buffer.put(data);
        writeGattCharacteristic(otaDspParamUpdateChr, buffer.array());
    }

    public void DSPConfigParameterUpdate_Read(byte[] data) {



        if (otaDspParamUpdateChr == null) {
            BLELog.d(TAG, " DSPConfigParameterUpdate otaDspParamUpdateChr   is null");
            return;
        }

        if (DspOTATunningMainActivity.getINSTANCE() == null) {
            BLELog.d(TAG, " DspOTATunningMainActivity.getINSTANCE() == null");
            return;
        }
        BLELog.d(TAG, "DSPConfigParameterUpdate_Read" + HexTool.byteArrayToHexString(data));

        characteristicWriteQueue.add(new TempQueueObject(otaDspParamUpdateChr, null, true));
    }


    public void DSPTuningCommand(byte cmd) {
        if (otaDspControlPtChr == null) {
            BLELog.d(TAG, " DSPTuningCommand sendCtrlPointCommand   is null");
            return;
        }

        if (DspOTATunningMainActivity.getINSTANCE() == null) {
            BLELog.d(TAG, " DspOTATunningMainActivity.getINSTANCE() == null");
            return;
        }

        //cmd = 0x02;

        BLELog.d(TAG, "sendCtrlPointCommand" + cmd);

        ByteBuffer buffer = prepareOutputBuffer(cmd, 1);
        writeGattCharacteristic(otaDspControlPtChr, buffer.array());
    }


    public void EnableDSPTuningLogs() {

        BluetoothGattService service = mGatt.getService(UUID_MCHP_OTA_CFG_UPD_SERVICE);
        if (service != null) {
            for (BluetoothGattCharacteristic ch : service.getCharacteristics()) {

                /*if ( (ch.getUuid().equals(UUID_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR))) {
                    otaDsplogChr = ch;
                    setNotification(ch, true);
                    BLELog.d(TAG, "UUIDSTR_MCHP_OTA_CFG_UPD_DSP_TUNE_LOG_CHAR : SetNotification");
                }*/

            }
        }


            if (otaDsplogChr == null) {
                BLELog.d(TAG, " EnableDSPTuningLogs  Fail otaDsplogChr is null");
                return;
            }

            if (DspOTATunningMainActivity.getINSTANCE() == null) {
                BLELog.d(TAG, " DspOTATunningMainActivity.getINSTANCE() == null");
                return;
            }
            //byte cmd  = DspOTATunningMainActivity.getINSTANCE().getDspTunningManager();


            BLELog.d(TAG, "EnableDSPTuningLogs" + "");

            ByteBuffer buffer = prepareOutputBuffer(2);
            buffer.put((byte) 0x01);
            buffer.put((byte) 0x01);
            writeGattCharacteristic(otaDsplogChr, buffer.array());



    }


    public boolean ConnectService = false;
    public boolean Capability_DSPTuning = false;

    public boolean GetCapability() {

        if (null != otaDspControlPtChr)
            Capability_DSPTuning = true;

        if (Capability_DSPTuning)
            ChkConnectService();

        return Capability_DSPTuning;
    }

    public boolean ChkConnectService() {
        BLELog.d(TAG, "*ConnectService = " + ConnectService);
        if (ConnectService == false) {
            BLELog.d(TAG, "[DSPTuning]Connect Service");
            byte connect_command = (byte) 0x02;
            DSPTuningCommand(connect_command);
        }

        return ConnectService;
    }

    private DSPTuningDelegate listnerDspActiveClient;

    public synchronized void setListener(DSPTuningDelegate dspNewClient) {

        listnerDspActiveClient = dspNewClient;

    }

    public synchronized void removeListener(DSPTuningDelegate client) {
        listnerDspActiveClient = null;

    }


    public class LocalBinder extends Binder {
        public DspOTATunningBLEService getService() {
            return DspOTATunningBLEService.this;
        }
    }


/* End LE serive code */





/*/////////////////////////////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////////////////////////////*/
/* OTA DSP tunning Code  */


    public static final byte TuneDSPMode_NotSupport = 0x00;
    public static final byte TuneDSPMode_Audio = 0x01;
    public static final byte TuneDSPMode_Voice = 0x02;
;


    public  byte[] Audio_Config = null;//  MODULE_AUDIO_MCU

    boolean DSPTuningInProgress = false;

    //var EQMode: UInt8?
    public byte[] MBDRC_Data = null;
    public byte[] EQ_Data=  null;

    public byte[] AEC_AES_Data;
    int BLE_MTU;

    byte DSP_State = 0x10;
    byte DUT_State = 0x10;
    public String DSP_DUT_State = "";

    public byte dynamicToolMode;
    ArrayList<DSP_Parameter> QueueParameters = new ArrayList();

    public  ByteBuffer Module_Config_data;
    byte Config_data_flag = 0x00;

    boolean TuneDSPParametersComplete = false;

    // DSP tunning
    public void DSP_Init() {

        Module_Config_data = null;
        MBDRC_Data = null;
        DSPTuningInProgress = false;
        dynamicToolMode = TuneDSPMode_NotSupport;
        //GetMTUSize()  //Disable for test
    }
    public void DSP_Disconnect_Reset() {
        BLELog.d(TAG,"DSP Disconnect reset params");
        //BLE_MTU = nil
        Audio_Config = null;
        DSPTuningInProgress = false;
        MBDRC_Data= null;
        AEC_AES_Data= null;
        //EQ_Data.removeAll();
       // EQMode = 0x00;
        DSP_State = 0x10;
        DUT_State = 0x10;
        DSP_DUT_State = "";
        QueueParameters.clear();
        dynamicToolMode = TuneDSPMode_NotSupport;
        Module_Config_data = null;
        Config_data_flag = 0x00;
        TuneDSPParametersComplete = false;
    }


    class DSP_Parameter {
        byte Module_id;
        byte Config_id;
        byte len;
        byte[] dat;

        DSP_Parameter(byte module_id, byte cfg_id, byte length, byte[] data) {
            Module_id = module_id;
            Config_id = cfg_id;
            len = length;
            dat = data;
        }
    }


    public void DSP_End_Read_Session(){
        BLELog.d(TAG, "End Read Session" );
        DSPTuningCommand((byte)0x09);
    }

    public void Read_Module_Audio_MCU(){
        BLELog.d(TAG,"Read_Module_Audio_MCU");

        if(Audio_Config == null){

            byte[] Command = {(byte) 0x05,(byte) 0x03};//Read Module:MODULE_AUDIO_MCU

            DSPConfigParameterUpdate(Command);
        }
        else {
            listnerDspActiveClient.RefreshModuleData();
        }
    }

    public void Read_Module_Voice_DSP(){
        BLELog.d(TAG,"Read_Module_Voice_DSP");

        byte[] modData = {(byte) 0x0D,(byte) 0x12};//MODULE_VOICE_DSP, num_cfg_ids = 0x12
        byte[] modLen = {(byte) 0x01,(byte) 0xC0}; //Config_data length = 448

        //Module_Config_data.put(modData); //MODULE_VOICE_DSP, num_cfg_ids = 0x12
       // Module_Config_data.put(modData);  //Config_data length = 448


        byte[] Command = {(byte) 0x05,(byte) 0x0D};//Read Module:MODULE_VOICE_DSP

        DSPConfigParameterUpdate(Command);

    }

    public void Get_Voice_DSP_Setting_NR(){
        BLELog.d(TAG,"Get_Voice_DSP_Setting_NR");


        //Read Parameters:
        //Module_id = 0x0D
        //Cfg_id = 0x06, VOICE_DSP_CFG_KEY_TUNING_FENR
        //Cfg_id = 0x07, VOICE_DSP_CFG_KEY_TUNING_NENR
        //Cfg_id = 0x01 , VOICE_DSP_CFG_KEY_CONFIG_WORD

        //Module_id = 0x03
        //Cfg_id = 0x0D , AUD_MCU_CFG_KEY_NR_EQ_MODE

        byte[] Command = { 0x04,0x04,0x0D,0x06,0x0D,0x07,0x03,0x0D,0x0D,0x0C};


        DSPConfigParameterUpdate(Command);
    }

    public void  Get_Voice_DSP_Setting_AEC_AES(){
        BLELog.d(TAG,"Get_Voice_DSP_Setting_AEC_AES");

        //Read Parameters:
        //Module_id = 0x0D
        //Cfg_id = 0x05 , VOICE_DSP_CFG_KEY_TUNING_AEC_AES
        //Cfg_id = 0x01 , VOICE_DSP_CFG_KEY_CONFIG_WORD

        //let Command = Data(bytes: [0x04,0x01,0x0D,0x05])
        byte[] Command = { 0x04,0x02,0x0D,0x05,0x0D,0x01};

        DSPConfigParameterUpdate(Command);
    }


    public void Get_Voice_MIC_Gain(){
        BLELog.d(TAG,"Get_Voice_MIC_Gain");


        //Read Parameters:
        //Module_id = 0x0D
        //Cfg_id = 0x03, VOICE_DSP_CFG_KEY_TUNING_WNG
        //Cfg_id = 0x04, VOICE_DSP_CFG_KEY_TUNING_DIGITAL_AND_CODEC_GAIN


        byte[] Command = { 0x04,0x02,0x0D,0x03,0x0D,0x04};


        DSPConfigParameterUpdate(Command);
    }




    public void Get_Voice_DSP_Setting_Filter(){
        BLELog.d(TAG,"Get_Voice_DSP_Setting_Filter");

        byte[] Command = {(byte) 0x04,(byte) 0x01,(byte) 0x0D,(byte) 0x09};

        ////byte[] Command = Data(bytes: [0x04,0x01,0x0C,0x01])//Read Parameters:AUD_DSP_CFG_KEY_LINEIN

        DSPConfigParameterUpdate(Command);
    }



    public void Get_Audio_DSP_Setting_LineIn(){
        BLELog.d(TAG,"Get_Audio_DSP_Setting_LineIn");

        byte[] Command = {(byte) 0x04,(byte) 0x01,(byte) 0x0C,(byte) 0x01};

        ////byte[] Command = Data(bytes: [0x04,0x01,0x0C,0x01])//Read Parameters:AUD_DSP_CFG_KEY_LINEIN

        DSPConfigParameterUpdate(Command);
    }

    public void Get_Audio_DSP_Setting_MBDRC(){
        BLELog.d(TAG,"Get_Audio_DSP_Setting_MBDRC");

        byte[] Command = {(byte)0x04,(byte)0x01,(byte)0x0C,(byte)0x02};//Read Parameters:AUD_DSP_CFG_KEY_MBDRC

        DSPConfigParameterUpdate(Command);

        //DSPTuningResponse = <01040100 000b0c02 08a06935 028ff915 c3>, length = 17
    }
    public  byte[] GetDefaultEqualizerMode() {
        if(Audio_Config == null)
            return null;

        BLELog.d(TAG,"GetDefaultEqualizerMode");

        byte[] bytes = Audio_Config ;
        byte[] buf = Audio_Config;
        int k = 0;

        byte EQ_OnOff = 0;
        byte Default_EQ= 0;

        while(k < bytes.length) {
            byte cfg_id = buf[k];
            byte len = buf[k+1];
            //let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)));
            byte[] dat = Arrays.copyOfRange(bytes, k+2, k+2+len );

            if(cfg_id == 0x0F){     //AUD_MCU_CFG_KEY_AUDIO_RPU_STATUS
                //Default_EQ = buf[k+2]
                EQ_OnOff = buf[k+2];
            }
            else if(cfg_id == 0x04){     //AUD_MCU_CFG_KEY_TX_EQ_MODE
                Default_EQ = buf[k+2];
            }

            k += (int) (2+buf[k+1]);
        }

        byte[] aud_eq_default = new byte[2];
        aud_eq_default[0] = (byte) (EQ_OnOff & 0x20);
        aud_eq_default[1] = Default_EQ;

        return aud_eq_default;
    }



    public  byte[] GetAudioEQMask() {
        if(Audio_Config == null)
            return null;

        BLELog.d(TAG,"GetAudioEQMask");

        byte[] bytes = Audio_Config ;
        byte[] buf = Audio_Config;
        int k = 0;

        byte EQ_Mask_byte1 = 0;
        byte EQ_Mask_byte2= 0;

        while(k < bytes.length) {
            byte cfg_id = buf[k];
            byte len = buf[k+1];
            //let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)));
            byte[] dat = Arrays.copyOfRange(bytes, k+2, k+2+len );

            if(cfg_id == 0x0C){     //AUD_MCU_CFG_KEY_EQ_MASK
                EQ_Mask_byte1 = buf[k+2];
                EQ_Mask_byte2 = buf[k+3];
            }

            k += (int) (2+buf[k+1]);
        }

        byte[] aud_eq_mask = new byte[2];
        aud_eq_mask[0] = EQ_Mask_byte1;
        aud_eq_mask[1] = EQ_Mask_byte2;

        return aud_eq_mask;
    }

    public  byte[] GetAudioEffect() {
        if(Audio_Config == null)
            return null;

        BLELog.d(TAG,"GetAudioEffect");

        byte[] bytes = Audio_Config ;
        byte[] buf = Audio_Config;
        int k = 0;

        byte Audio_Effect_Mask = 0;
        byte Audio_Effect= 0;

        while(k < bytes.length) {
            byte cfg_id = buf[k];
            byte len = buf[k+1];
            //let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)));
            byte[] dat = Arrays.copyOfRange(bytes, k+2, k+2+len );

            if(cfg_id == 0x20){     //AUD_MCU_CFG_KEY_EFFECT_MASK
                Audio_Effect_Mask = buf[k+2];
            }
            else if(cfg_id == 0x21){    //AUD_MCU_CFG_KEY_EFFECT
                Audio_Effect = buf[k+2];
            }

            k += (int) (2+buf[k+1]);
        }

        byte[] aud_eff_data = new byte[2];
        aud_eff_data[0] = Audio_Effect_Mask;
        aud_eff_data[1] = Audio_Effect;

        return aud_eff_data;
    }

    public  byte[] GetVoiceEQMode() {
            if(Audio_Config == null)
                return null;

            BLELog.d(TAG,"GetVoiceEQMode");

            byte[] bytes = Audio_Config ;
            byte[] buf = Audio_Config;
            int k = 0;

            byte EQMode1 = 0x0f;
            byte EQMode2 = 0x0f;
            byte EQMode3 = 0x0f;
            byte EQMode4 = 0x0f;


            while(k < bytes.length) {
                byte cfg_id = buf[k];
                byte len = buf[k+1];
                //let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)));
                byte[] dat = Arrays.copyOfRange(bytes, k+2, k+2+len );

                if(cfg_id == 0x12){         //AUD_MCU_CFG_KEY_CVSD_RX_EQ_MODE
                    EQMode1 = buf[k+2];
                }
                else if(cfg_id == 0x13){    //AUD_MCU_CFG_KEY_CVSD_TX_EQ_MODE
                    EQMode2 = buf[k+2];
                }
                if(cfg_id == 0x14){         //AUD_MCU_CFG_KEY_MSBC_RX_EQ_MODE
                    EQMode3 = buf[k+2];
                }
                else if(cfg_id == 0x15){    //AUD_MCU_CFG_KEY_MSBC_TX_EQ_MODE
                    EQMode4 = buf[k+2];
                }

                k += (int) (2+buf[k+1]);
            }

            byte[] voice_eq_mode_data = new byte[4];
            voice_eq_mode_data[0] = EQMode1;
            voice_eq_mode_data[1] = EQMode2;
            voice_eq_mode_data[2] = EQMode3;
            voice_eq_mode_data[3] = EQMode4;

            return voice_eq_mode_data;
        }


    public boolean[] CheckAudioMBDRC_AW() {
        if(Audio_Config == null)
            return null;

        BLELog.d(TAG,"CheckAudioMBDRC_AW");


        byte[] bytes = Audio_Config ;
        byte[] buf = Audio_Config;
        int k = 0;

        byte Audio_RPU_Status = 0;
        byte Audio_Effect= 0;

        while(k < bytes.length) {
            byte cfg_id = buf[k];
            byte len = buf[k+1];
            //let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            byte[] dat = Arrays.copyOfRange(bytes, k+2, k+2+len );
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")

            if(cfg_id == 0x0F){     //AUD_MCU_CFG_KEY_AUDIO_RPU_STATUS
                Audio_RPU_Status = buf[k+2];
            }
            else if(cfg_id == 0x20){    //AUD_MCU_CFG_KEY_EFFECT_MASK
                Audio_Effect = buf[k+2];
            }

            k += (int)(2+buf[k+1]);
        }

        boolean MBDRC_onoff = false;
        boolean AW_onoff = false;

        if(((Audio_RPU_Status & 0x80) == 0x80) && ((Audio_Effect & 0x06) != 0)){
            MBDRC_onoff = true;
        }

        if(((Audio_RPU_Status & 0x80) == 0x80) && ((Audio_Effect & 0x0C) != 0)){
            AW_onoff = true;
        }

        boolean[] aud_mb_aw = new boolean[2];
        aud_mb_aw[0] = MBDRC_onoff;
        aud_mb_aw[1] = AW_onoff;

        return aud_mb_aw;
    }

    public void DSPQueueData(byte module,byte cfg, byte len, byte[] data) {

        BLELog.d(TAG,"DSPQueueData module= "+ module+"cfg="+cfg+"len="+len+"data="+HexTool.byteArrayToHexString(data));

        int count = 0;
        for (int index = 0; index < QueueParameters.size(); index++ ) {
            DSP_Parameter obj = QueueParameters.get(index);
            if(obj.Module_id == module && obj.Config_id == cfg){
                BLELog.d(TAG,"DSP parameter exist! Update data");
                //obj.dat = data
                DSP_Parameter new_obj = new DSP_Parameter(obj.Module_id,  obj.Config_id, obj.len, data);
                QueueParameters.add(index, new_obj);
                BLELog.d(TAG,"index ="+ index);
                BLELog.d(TAG,("new_obj = "+new_obj.Module_id + "new_obj.Config_id"+new_obj.Config_id + (new_obj.len) +""+new_obj.dat));
                break;
            }
            count += 1;
        }

        if(count == QueueParameters.size()){
            QueueParameters.add(new DSP_Parameter( module,  cfg,  len,  data));
        }

        BLELog.d(TAG,"========  QueueParameters ======== ");
        for (int index = 0; index < QueueParameters.size(); index ++) {
            DSP_Parameter  obj = QueueParameters.get( index);
            BLELog.d(TAG,"index = "+index);
            BLELog.d(TAG,("obj ="+ "Module_id"+obj.Module_id+"Config_id"+obj.Config_id+"len"+obj.len));
            BLELog.d(TAG, "data =" + HexTool.byteArrayToHexString(data));
        }

    }

    public byte GetVoiceAECMode() {
        if(Audio_Config == null)
            return 0;

        BLELog.d(TAG,"GetVoiceAECMode");


        byte[] bytes = Audio_Config ;
        byte[] buf = Audio_Config;
        int k = 0;

        byte AEC_Mode = 0;
        byte Voice_RPU_Status= 0;

        while(k < bytes.length) {
            byte cfg_id = buf[k];
            byte len = buf[k+1];
            //let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            byte[] dat = Arrays.copyOfRange(bytes, k+2, k+2+len );
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")

            if(cfg_id == 0x10){   //AUD_MCU_CFG_KEY_AEC_MODE
                AEC_Mode = buf[k+2];
            }
            else if(cfg_id == 0x17){     //AUD_MCU_CFG_KEY_VOICE_RPU_STATUS
                Voice_RPU_Status = buf[k+2];
            }

            k += (int)(2+buf[k+1]);
        }


        Log.d(TAG, "  AEC_Mode =" +
                String.format("%02x", AEC_Mode));

        Log.d(TAG, " Voice_RPU_Status =" +
                String.format("%02x", Voice_RPU_Status));

        Log.d(TAG, " return GetVoiceAECMode =" +
                String.format("%02x", (byte) (AEC_Mode & (Voice_RPU_Status & ( 0x01)))));

        return (byte) (AEC_Mode & (Voice_RPU_Status & ( 0x01)));
    }

    public void  DSPTuning(byte module,byte cfg , byte len,byte[] data){
        if(!DSPTuningInProgress){
            DSPTuningInProgress = true;
            BLELog.d(TAG,"Tune DSP parameters");

            ByteBuffer dd =  ByteBuffer.allocate(243);

            byte total_len = 0;

            DSPQueueData( module,  cfg,  len,  data);

            dd.put((byte) 0x06); //Tune DSP
            dd.put((byte) (QueueParameters.size()));     //Number of parameters
            for (int index = 0; index <QueueParameters.size();index++) {   //Calculate total length
                DSP_Parameter obj = QueueParameters.get(index);
                total_len += obj.len;
                total_len += 3;
            }
            dd.put((byte)0x00); //Totoal_length_H
            dd.put(total_len); //Total_length_L
            for (int index = 0; index < QueueParameters.size();index++) {   //Calculate total length
                DSP_Parameter obj = QueueParameters.get(index);
                dd.put(obj.Module_id);
                dd.put(obj.Config_id);
                dd.put(obj.len);
                dd.put(obj.dat);
            }

            byte[] dsp_data = getByteArrayUsed(dd);
            BLELog.d(TAG,"[DSPTuning] dsp_data ="+ HexTool.byteArrayToHexString(dsp_data));

            /*if(BLE_MTU != 0 && dd.count > BLE_MTU!){
                BLELog.d(TAG,("[DSPTuning] Data length > MTU size");
                BLELog.d(TAG,("BLE_MTU = \(BLE_MTU!)");
                BLELog.d(TAG,("Send data, len = \(dd.count)")
                return;
            }*/
            DSPConfigParameterUpdate(dsp_data);
            QueueParameters.clear();
        }
    }




    public void DSPTuningResponse(byte[] dataIn) {

        BLELog.d(TAG,"DSPTuningResponse ="+ HexTool.byteArrayToHexString(dataIn));

        byte[] buf = dataIn;
        byte[] bytes = dataIn;
        int data_len = 0;


        if(buf[0] == 0x01 && buf[1] == 0x05) {    //Response = 0x01,Request op-code = 0x05(Read Module) {


            if (buf[2] != 0x01) {//Operation result = 0x01(Success)
                BLELog.d(TAG, "Operation result is fail !,module_id = " + (buf[4]));
                return;
            }


            if (buf[4] == 0x03){//module_id = MODULE_AUDIO_MCU

                //byte[] config = bytes.subdata(with: NSMakeRange(8, bytes.length-8))
                byte[] config = Arrays.copyOfRange(bytes, 8, bytes.length );
                BLELog.d(TAG,"Audio config ="+HexTool.byteArrayToHexString(config));
                Audio_Config = config;
                ParsingAudioConfigData();


            }else {
                if(buf[3] == 0x00)
                {
                    //Type = 0x00-The configuration data is sent in notification

                    byte[] new_config_data = Arrays.copyOfRange(bytes, 8, bytes.length );
                    BLELog.d(TAG,"Notification]Module configuration data = "+ HexTool.byteArrayToHexString(new_config_data));

                    if(Module_Config_data != null){
                        BLELog.d(TAG,"[Notification]Append Module_Config_data");
                        //Module_Config_data?.append(config_data)
                        Module_Config_data.put(new_config_data);

                        if(Config_data_flag != 0 && Config_data_flag == 0x80){
                           /* DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                            {
                                Read_Module_Voice_DSP();
                                Config_data_flag = (byte) 0x81;
                            }*/
                        }
                        else if(Config_data_flag != 0 && Config_data_flag == 0x81){
                            /*DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                            {
                                self.Read_Module_I2S_DSP()
                                self.Config_data_flag = 0x82
                            }*/
                        }
                        else if(Config_data_flag != 0 && Config_data_flag == 0x82){
                            /*self.Config_data_flag = NULL;

                            if((Module_Config_data!.count % 16) != 0){
                                let new_size = ((Module_Config_data!.count/16)+1) * 16
                                BLELog.d(TAG,"Adjust the Data size = \(new_size)")

                                let padding_len = new_size - Module_Config_data!.count
                                for _ in 0..<padding_len {
                                    Module_Config_data?.append(Data(bytes: [0xff]))
                                }
                            }

                            //Module_Config_data
                            BLELog.d(TAG,"Module_Config_data,len = \(Module_Config_data?.count)")
                            BLELog.d(TAG,"data = \(Module_Config_data as! NSData)");
                            ExportDSPTuningResult();*/
                        }
                    }
                }
                else{
                    //Type = 0x01-The configuration data should be read using read characteristic method
                    BLELog.d(TAG,"Read module, Response data byte 3(Type) = 0x01");
                    byte[] cmdArr = new byte[2];
                    cmdArr[0] = (byte)0x05;//Read Module
                    cmdArr[1] = buf[4]; // module info
                    BLELog.d(TAG,"Command = "+ HexTool.byteArrayToHexString( cmdArr));
                    DSPConfigParameterUpdate_Read(cmdArr);
                }

            }

        } else if (buf[0] == 0x01 && buf[1] == 0x04) {     //Response = 0x01,Request op-code = 0x04(Read Parameter)

           // byte[] slice = Arrays.copyOfRange(myArray, 5, 10);

            data_len = (((int)(buf[4]) << 8) + ((int)(buf[5])));
            BLELog.d(TAG, "Length of the configuration data = "+data_len);

            byte[] config_data = Arrays.copyOfRange(buf, 6, buf.length );;
            //bytes.subdata(with: NSMakeRange(6, (bytes.length-6)))
            listnerDspActiveClient.RefreshParametersData(config_data);



        } else if (buf[0] == 0x01 && buf[1] == 0x06) { //Response = 0x01,Request op-code = 0x06(Tune DSP parameters)
            DSPTuningInProgress = false;
            listnerDspActiveClient.DSPTuningComplete( buf[2]);
        }
    }

    public void DSPTuningResponse_Read(byte[] dataIn) {
        BLELog.d(TAG,"Characteristic Read]Module configuration data = "+
                HexTool.byteArrayToHexString(dataIn) + "length = "+ dataIn.length);

        BLELog.d(TAG,"Append data");
        //Module_Config_data?.append(dataIn)
        //let new_config_data = ClearModifiedBit(data: dataIn)
        Module_Config_data.put(dataIn);

        DSP_End_Read_Session();
    }
    private Handler mHandler = new Handler();

    public void DSPTuningCommandComplete(byte[] dataIn) {

        byte[] bytes = dataIn;
        byte[] buf = dataIn;


        BLELog.d(TAG,"DSPTuningCommandComplete ="+HexTool.byteArrayToHexString(dataIn)+ "length = "+ dataIn.length);

        if(buf[0] != 0x01) {    //Response
            BLELog.d(TAG,"Invalid data");
            return;
        }

        if((buf[2] != 0x01) || (dataIn.length < 3) ) {   //Success = 0x01
            BLELog.d(TAG,"Execute command failed!");
            if(buf[1] >= 0x04 && buf[1] <= 0x09){
                //Dynamic Tuning Commands
                BLELog.d(TAG,"Dynamic Tuning Commands : response");
                // balaji
               // DSPTuningComplete(result: buf[2])
            }
            return;
        }

        /// balaji more case
        byte[] successResult  = new byte[3];
        successResult[0]= 0x01; successResult[1]= 0x02;successResult[2]= 0x01;
        //let connect_success = Data(bytes: [0x01,0x02,0x01]) //Response,Request op-code,Result
        if (0 == (HexTool.byteArrayToHexString(dataIn).compareTo( HexTool.byteArrayToHexString(successResult)))){
            BLELog.d(TAG,"Connect Success");
            //byte[] GetMTUCommand = Data(bytes:[0x0a])
            //DSPControlCommmand(GetMTUCommand)
            EnableDSPTuningLogs();
            ConnectService =true;
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    listnerDspActiveClient.BLE_ServiceReady();
                }
            }, 3000);

        }
        else {
            /*let mtu = bytes.subdata(with: NSMakeRange(3, bytes.length-3));
            //Arrays.copyOfRange(bytes, 8, bytes.length )
            print("MTU = \(mtu as NSData)")
            Get_BT_Device_Name()

           // EnableDSPTuningLogs();

            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                if(self.Audio_Config == nil){
                    //self.DSPTuningDelegate?.BLE_ServiceReady()
                    let view = self.GetCurrentView()
                    if(view == 2){
                        self.VoiceFilter_Delegate?.BLE_ServiceReady()
                    }
                    else if(view == 6){
                        self.AudioLineIn_Delegate?.BLE_ServiceReady()
                    }
                    else if(view == 9){
                        self.HiddenAVC_Delegate?.BLE_ServiceReady()
                    }
                }
            }*/
        }

    }

    void ParsingAudioConfigData() {

        BLELog.d(TAG,"ParsingAudioConfigData");

        //Paramter format : [cfg_id,len,data]
        byte[] bytes = Audio_Config;
        byte[]  buf = bytes;
        int k = 0;

        while(k < bytes.length) {
            int len = (int)buf[k+1];
            //let dat = bytes.subdata(with: NSMakeRange(k+2, Int(len)))
            byte[] dat = Arrays.copyOfRange(bytes, k+2, k+2+len);
            //print("Offset = \(k), cfg_id = \(buf[k]), data len = \(buf[k+1]), dat = \(dat as NSData)")
            BLELog.d(TAG, "Offset ="+k+ "cfg_id ="+ (buf[k] & 0x7F)+" data len ="+
                    (buf[k+1])+" dat ="+ HexTool.byteArrayToHexString(dat));
            k += (int)(2+buf[k+1]);
        }

        listnerDspActiveClient.RefreshModuleData();

        /*
         Offset = 0, cfg_id = 1, data len = 1, dat = <f0>
         Offset = 3, cfg_id = 2, data len = 1, dat = <03>
         Offset = 6, cfg_id = 3, data len = 1, dat = <01>
         Offset = 9, cfg_id = 4, data len = 1, dat = <02>
         Offset = 12, cfg_id = 5, data len = 1, dat = <00>
         Offset = 15, cfg_id = 6, data len = 1, dat = <ff>
         Offset = 18, cfg_id = 135, data len = 8, dat = <20222222 22222222>
         Offset = 28, cfg_id = 136, data len = 1, dat = <0a>
         Offset = 31, cfg_id = 9, data len = 1, dat = <f0>
         Offset = 34, cfg_id = 10, data len = 16, dat = <00a2a5c2 c5e2e5e8 ebeef1f4 f7fafbfc>
         Offset = 52, cfg_id = 139, data len = 1, dat = <22>
         Offset = 55, cfg_id = 12, data len = 2, dat = <03fe>
         Offset = 59, cfg_id = 13, data len = 1, dat = <11>
         Offset = 62, cfg_id = 14, data len = 16, dat = <00a2a5c2 c5e2e5e8 ebeef1f4 f7fafbfc>
         Offset = 80, cfg_id = 23, data len = 1, dat = <67>
         Offset = 83, cfg_id = 16, data len = 1, dat = <01>
         Offset = 86, cfg_id = 17, data len = 1, dat = <67>
         Offset = 89, cfg_id = 18, data len = 1, dat = <0a>
         Offset = 92, cfg_id = 19, data len = 1, dat = <0a>
         Offset = 95, cfg_id = 20, data len = 1, dat = <0a>
         Offset = 98, cfg_id = 21, data len = 1, dat = <0a>
         Offset = 101, cfg_id = 22, data len = 1, dat = <00>
         Offset = 104, cfg_id = 15, data len = 1, dat = <a0>
         Offset = 107, cfg_id = 24, data len = 1, dat = <59>
         Offset = 110, cfg_id = 25, data len = 1, dat = <2e>
         Offset = 113, cfg_id = 26, data len = 1, dat = <00>
         Offset = 116, cfg_id = 27, data len = 1, dat = <22>
         Offset = 119, cfg_id = 28, data len = 1, dat = <00>
         Offset = 122, cfg_id = 29, data len = 1, dat = <93>
         Offset = 125, cfg_id = 30, data len = 1, dat = <05>
         Offset = 128, cfg_id = 31, data len = 1, dat = <00>
         Offset = 131, cfg_id = 32, data len = 1, dat = <0e>
         Offset = 134, cfg_id = 33, data len = 1, dat = <02>
         Offset = 137, cfg_id = 34, data len = 1, dat = <f0>
         Offset = 140, cfg_id = 35, data len = 1, dat = <08>
         Offset = 143, cfg_id = 36, data len = 11, dat = <01c00000 00000007 000100>
         Offset = 156, cfg_id = 37, data len = 1, dat = <05>
         Offset = 159, cfg_id = 38, data len = 1, dat = <04>
         Offset = 162, cfg_id = 39, data len = 1, dat = <0c>
         Offset = 165, cfg_id = 40, data len = 1, dat = <00>
         */
    }

    public void  DSPTuningLogs(byte[] buf) {
        //print("DSP Tuning Logs =  \(state as NSData)")


        DSP_DUT_State = "";

        if (buf[0] < 8) {
            //DSP Current State
            DSP_State = buf[2];
        } else if (buf[0] <= 15 && buf[0] >= 8) {
            //DUT Current State
            DUT_State = buf[2];
        } else {
            BLELog.d(TAG, "*Unknown State " );
        }

        switch (DSP_State) {
            case 0:
                //print("DSP State:STANDBY")
                //print("DSP:STANDBY")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:STANDBY");
                break;
            case 1:
                //print("DSP:WAIT CODEC PD")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:WAIT CODEC PD");
                break;
            case 2:
                //print("DSP:WAIT DSP PD")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:WAIT DSP PD");
                break;
            case 3:
                //print("DSP:WAIT REACTIVE")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:WAIT REACTIVE");
                break;
            case 4:
                //print("DSP:WAIT ACTIVE")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:WAIT ACTIVE");
                break;
            case 5:
                //print("DSP:PREPARE READY")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:PREPARE READY");
                break;
            case 6:
                //print("DSP:RESTART DSP")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:RESTART DSP");
                break;
            case 7:
                //print("DSP:TEST MODE")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:TEST MODE");
                break;
            case 8:
                //print("DSP:LINE IN READY")
                dynamicToolMode = TuneDSPMode_Audio;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:LINE IN READY");
                break;
            case 9:
                //print("DSP:PCM READY")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:PCM READY");
                break;
            case 10:
                //print("DSP:RINGTONE READY")
                dynamicToolMode = TuneDSPMode_Audio;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:RINGTONE READY");
                break;
            case 11:
                //print("DSP:AUX RINGTONE READY")
                dynamicToolMode = TuneDSPMode_Audio;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:AUX RINGTONE READY");
                break;
            case 12:
                //print("DSP:SCO READY")
                dynamicToolMode = TuneDSPMode_Voice;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:SCO READY");
                break;
            case 13:
                //print("DSP:SBC DECODE READY")
                dynamicToolMode = TuneDSPMode_Audio;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:SBC DECODE READY");
                break;
            case 14:
                //print("DSP:SBC ENCODE READY")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:SBC ENCODE READY");
                break;
            case 15:
                //print("DSP:VOICE RECOGNITION READY")
                dynamicToolMode = TuneDSPMode_NotSupport;
                DSP_DUT_State = DSP_DUT_State.concat("DSP:VOICE RECOGNITION READY");
                break;
            default:
                //print("DSP:Unknown")
                DSP_DUT_State = DSP_DUT_State.concat("DSP:Unknown");
                break;
        }

        DSP_DUT_State = DSP_DUT_State.concat(" / ");

        switch (DUT_State) {
            case 0:
                //print("DUT:OFF")
                DSP_DUT_State = DSP_DUT_State.concat("DUT:OFF");
                break;
            case 1:
                //print("DUT:STANDBY")
                DSP_DUT_State = DSP_DUT_State.concat("DUT:STANDBY");
                break;
            case 2:
                //print("DUT:PAIRING")
                DSP_DUT_State = DSP_DUT_State.concat("DUT:PAIRING");
                break;
            case 3:
                //print("DUT:PAGING")
                DSP_DUT_State = DSP_DUT_State.concat("DUT:PAGING");
                break;
            case 4:
                //print("DUT:ACTIVE")
                DSP_DUT_State = DSP_DUT_State.concat("DUT:ACTIVE");
                break;
            case 5:
                //print("DUT:SHUTDOWN")
                DSP_DUT_State = DSP_DUT_State.concat("DUT:SHUTDOWN");
                break;
            default:
                //print("DUT:Unknown")
                DSP_DUT_State = DSP_DUT_State.concat("DUT:Unknown");
                break;
        }

        listnerDspActiveClient.DSPTuningState(DSP_DUT_State);
    }
}




;
