package com.app.microchip.audiowidget.ui;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.managers.BLEManager;
import com.app.microchip.audiowidget.managers.PersonalGroupService;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;

import java.util.ArrayList;
import java.util.HashMap;


public class PersonalGroupCreationActivity extends AppCompatActivity {
    public static final String TAG = PersonalGroupCreationActivity.class.getSimpleName();

    public final static int CONCERT_MODE = 0;
    public final static int STEREO_MODE = 1;
    ArrayList<String> MasterspeakerNames = new ArrayList<>();
    ArrayList<String> SlavespeakerNames = new ArrayList<>();
    private ListView masterSpeakersListView;
    private ListView slaveSpeakersListView;
    private ArrayAdapter<String> MasterArrayAdapter;
    private ArrayAdapter<String> SlaveArrayAdapter;
    private ArrayList<BLESpeaker> allSpeakers;
    private BLEManager mBleManager;
    private boolean concertMode = true;
    private BLESpeaker selectedmasterspeaker;
    private int selectedMode = -1;
    private String groupName;
    private ArrayList<BLESpeaker> selectedslaveSpeakers = new ArrayList<>();
    private Context ctxt;
    private ProgressDialog mUpdateProgressDialog;
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            BLELog.d(TAG, "onConnectionStateChange Status: " + status);
            switch (newState) {
                case BluetoothProfile.STATE_CONNECTED:
                    BLELog.d(TAG, "STATE_CONNECTED");
                    BluetoothDevice dev = gatt.getDevice();
                    onConnect(dev);
                    break;
                case BluetoothProfile.STATE_DISCONNECTED:

                    BLELog.d(TAG, "STATE_DISCONNECTED");

                   mBleManager.removeListener(gattCallback);

                    mBleManager.closeGatt(null);

                    mBleManager.addListener(gattCallback);

                    onDisconnect();

                    break;
                default:
                    BLELog.d(TAG, "STATE_OTHER");
            }

        }
    };
    private int selectedMasterSpeakerPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_group_creation);

        mUpdateProgressDialog = new ProgressDialog(this);
        mUpdateProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mUpdateProgressDialog.setMessage(getString(R.string.creating_message));
        mUpdateProgressDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mUpdateProgressDialog.setIndeterminate(true);
        mUpdateProgressDialog.setCanceledOnTouchOutside(false);
        mUpdateProgressDialog.setCancelable(false);

        mBleManager = BLEManager.getBLEManager(this);
        if (mBleManager != null) {
            mBleManager.addListener(gattCallback);
        }
        Intent intent = getIntent();
        String groupName = intent.getStringExtra("groupName");
        BLELog.d(TAG, "GroupNAme here= " + intent.getStringExtra("groupName"));
        HashMap<String, String> entry = new HashMap<>();
        entry = (HashMap<String, String>) intent.getSerializableExtra("groupObject");
        if (groupName != null) {
            String mode = entry.get("mode");
            if (mode.equals("concert")) {
                selectedMode = CONCERT_MODE;
                concertMode = true;
            } else {
                selectedMode = STEREO_MODE;
                concertMode = false;
            }
            //   initializeUI();
            selectedmasterspeaker = HomeScreenActivity.getInstance().getSpeaker(entry.get("master"));
            BLELog.d(TAG, "Master:" + HomeScreenActivity.getInstance().getSpeaker(entry.get("master")));
            BLELog.d(TAG, "Entry contents:" + entry.toString());
            if (selectedmasterspeaker == null) {
                showEmptyDialog();
                return;
            }
            for (int i = 3; i < entry.size(); i++) {
                BLELog.d(TAG, "Slave:" + HomeScreenActivity.getInstance().getSpeaker(entry.get("slave" + i)));
                selectedslaveSpeakers.add(HomeScreenActivity.getInstance().getSpeaker(entry.get("slave" + i)));
            }
            createConnection();
        } else {
            selectmultiSPKMode();
        }
        ctxt = this;
    }


    private void onConnect(BluetoothDevice device) {
        ArrayList<BLESpeaker> speaker = HomeScreenActivity.getInstance().getSpeakers();
        String deviceID = "";
        for (BLESpeaker spk : speaker) {
            if (spk.getBtDevice().getAddress().equals(device.getAddress())) {
                deviceID = spk.getDeviceId();
                break;
            }
        }
        final String devId = deviceID;

        //  Intent intent = new Intent(PersonalGroupCreationActivity.this, GroupCreationProgress.class);
        Intent intent = new Intent(ctxt, PersonalGroupService.class);
        intent.putExtra(Constants.DEVICE_ID, devId);
        String masterid = "";
        if (selectedmasterspeaker == null)
            masterid = devId;
        else masterid = selectedmasterspeaker.getDeviceId();
        intent.putExtra(Constants.MASTER_ID, masterid);
        if (concertMode)
            intent.putExtra(Constants.CONCERT_MODE, true);
        else
            intent.putExtra(Constants.CONCERT_MODE, false);
        //  startActivity(intent);
        ctxt.startService(intent);
    }

    private void onDisconnect() {
        BLELog.d(TAG, "OnDisconnect called");
        createConnection();
    }


    private void selectmultiSPKMode() {
        CharSequence[] modes = {"Stereo", "Concert"};
        AlertDialog.Builder ad = new AlertDialog.Builder(PersonalGroupCreationActivity.this, R.style.MyDialogTheme);
        ad.setTitle(R.string.select_mode);
        ad.setSingleChoiceItems(modes, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                if (arg1 == 0) selectedMode = STEREO_MODE;
                else if (arg1 == 1) selectedMode = CONCERT_MODE;
            }
        });
        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (selectedMode != -1)
                    initializeUI();
                else
                    launchHomeScreen();
            }
        });
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        ad.setCancelable(false);
        AlertDialog alert = ad.create();
        alert.show();

    }


    public void createConnection() {
        BLELog.d(TAG, "Create slave called");
        mUpdateProgressDialog.show();
        if (selectedslaveSpeakers.size() != 0) {
            BLESpeaker speaker = selectedslaveSpeakers.get(selectedslaveSpeakers.size() - 1);
            BLELog.d(TAG, "Selected slave speakers size is not 0\n Calling ConnectGat for slave :" + speaker.getName());
            selectedslaveSpeakers.remove(selectedslaveSpeakers.size() - 1);
            mBleManager.connectGatt(getApplicationContext(), false, speaker.getBtDevice(), Constants.TRANSPORT_LE);
        } else {
            if (selectedmasterspeaker != null) {
                BLELog.d(TAG, "selectedmasterspeaker is not null\n Calling ConnectGat for master :" + selectedmasterspeaker.getName());
                mBleManager.connectGatt(getApplicationContext(), false, selectedmasterspeaker.getBtDevice(), Constants.TRANSPORT_LE);
                selectedmasterspeaker = null;
            } else {
                mBleManager.removeListener(gattCallback);
                launchHomeScreen();
            }
        }
    }

    public void showEmptyDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("More than One Ungrouped speakers Needed for Grouping!!")
                .setCancelable(false)
                .setPositiveButton("BACK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        mBleManager.removeListener(gattCallback);
                        launchHomeScreen();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void showSelectMasterDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Select Master and Minimun One slave for Grouping")
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void onStart() {
        super.onStart();
        BLELog.d(TAG, "On onStart");
    }

    public void onResume() {
        super.onResume();
        BLELog.d(TAG, "On Resume");
    }

    public void onStop() {
        BLELog.d(TAG, "onStop called");
        super.onStop();
    }

    public void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        super.onDestroy();
        mBleManager.removeListener(gattCallback);
    }

    private void launchHomeScreen() {

        runOnUiThread(new Runnable() {
            public void run() {
                if (mUpdateProgressDialog != null && mUpdateProgressDialog.isShowing()) {
                    mUpdateProgressDialog.dismiss();
                }
                mBleManager.removeListener(gattCallback);
                Intent home = new Intent(getApplicationContext(), HomeScreenActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }

    private void initializeUI() {
        setTitle("Personal Audio group");

        masterSpeakersListView = (ListView) findViewById(R.id.selectmasterlist);
        slaveSpeakersListView = (ListView) findViewById(R.id.selectslaveslist);


        allSpeakers = HomeScreenActivity.getInstance().getSpeakers();
        //   final ArrayList<String> speakerNames = new ArrayList<>();

        for (BLESpeaker speaker : allSpeakers) {
            if (speaker.getGroupStatus() == Constants.UNGROUPED_VALUE) {
                if (selectedMode == STEREO_MODE && speaker.isStereoSuppported() == 1) {
                    MasterspeakerNames.add(speaker.getName());
                    SlavespeakerNames.add(speaker.getName());
                }
                if (selectedMode == CONCERT_MODE && speaker.isConcertSuppported() == 1) {
                    MasterspeakerNames.add(speaker.getName());
                    SlavespeakerNames.add(speaker.getName());
                }
            }
        }

        if (MasterspeakerNames.size() <= 1) {
            showEmptyDialog();
        }


        for (int i = 0; i < MasterspeakerNames.size(); i++) {
            BLELog.d(TAG, "SpeakersNames=" + MasterspeakerNames.get(i));
        }
        MasterArrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_multiple_choice, MasterspeakerNames);

        SlaveArrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_multiple_choice, SlavespeakerNames);

        if (selectedMode == STEREO_MODE) {
            slaveSpeakersListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
            concertMode = false;
        } else {
            concertMode = true;
            slaveSpeakersListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        }
        masterSpeakersListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        masterSpeakersListView.setAdapter(MasterArrayAdapter);
        slaveSpeakersListView.setAdapter(SlaveArrayAdapter);

        masterSpeakersListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BLELog.d(TAG, "Clicked on item position=" + position);
                selectedMasterSpeakerPosition = position;
                SlavespeakerNames.clear();
                for (String name : MasterspeakerNames) {
                    SlavespeakerNames.add(name);
                }
                SlavespeakerNames.remove(position);
                SlaveArrayAdapter.notifyDataSetChanged();
            }
        });
    }

    public BLESpeaker getSlaveSpeakerFromName(String name) {
        for (BLESpeaker spk : allSpeakers) {
            if (spk.getName().equals(name)) {
                if (selectedmasterspeaker != null && spk.getDeviceId() != selectedmasterspeaker.getDeviceId())
                    return spk;
            }
        }
        return null;
    }

    public BLESpeaker getMasterSpeakerFromName(String name) {
        for (BLESpeaker spk : allSpeakers) {
            if (spk.getName().equals(name))
                return spk;
        }
        return null;
    }

    public boolean createGroup() {

        selectedmasterspeaker = null;
        selectedslaveSpeakers.clear();
        int masterPosition = masterSpeakersListView.getCheckedItemPosition();
        SparseBooleanArray checked = slaveSpeakersListView.getCheckedItemPositions();

        ArrayList<String> selectedItems = new ArrayList<String>();
        for (int i = 0; i < checked.size(); i++) {
            int position = checked.keyAt(i);
            if (checked.valueAt(i))
                // if (SlaveArrayAdapter.getItem(position).equals(MasterArrayAdapter.getItem(masterPosition)) == false)
                selectedItems.add(SlaveArrayAdapter.getItem(position));
        }

        if (masterPosition >= 0) {
            selectedmasterspeaker = getMasterSpeakerFromName(MasterArrayAdapter.getItem(masterPosition));
        }
        for (int i = 0; i < selectedItems.size(); i++) {
            BLELog.d(TAG, "Selected Slave Item:" + selectedItems.get(i));
            selectedslaveSpeakers.add(getSlaveSpeakerFromName(selectedItems.get(i)));
        }

        if (masterPosition < 0 || selectedslaveSpeakers.size() < 1) {
            showSelectMasterDialog();
            return false;
        }

        BLELog.d(TAG, "Selected Master Item:" + MasterArrayAdapter.getItem(masterPosition));
        EditText name = (EditText) findViewById(R.id.groupName);
        groupName = name.getText().toString();
        cacheGroup(groupName);
        createConnection();
        return true;
    }

    public void cacheGroup(String name) {
        StringBuilder value = new StringBuilder(name);
        value.append(":");
        if (selectedMode == CONCERT_MODE)
            value.append("concert");
        else
            value.append("stereo");
        value.append(":");
        value.append(selectedmasterspeaker.getDeviceId());
        for (BLESpeaker spk : selectedslaveSpeakers) {
            value.append(":");
            value.append(spk.getDeviceId());
        }
        HomeScreenActivity.getInstance().saveArray(name, value);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.personal_group_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.done_option:
                createGroup();
                return (true);
        }
        return (super.onOptionsItemSelected(item));
    }
}
