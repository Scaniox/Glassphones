package com.app.microchip.audiowidget.managers;

import android.app.ProgressDialog;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.os.Message;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.ui.HomeScreenActivity;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;

public class PersonalGroupService extends Service {

    public final static int MULTISPK_STATUS_UNKNOWN = -1;
    public final static int MULTISPK_STATUS_STANDALONE = 0;
    public final static int MULTISPK_STATUS_GROUPING = 1;
    public final static int MULTISPK_STATUS_nSPK_MASTER = 2;
    public final static int MULTISPK_STATUS_BROADCAST_MASTER = 3;
    public final static int MULTISPK_STATUS_BROADCAST_WAITING_NEW_SLAVE = 6;
    /* 5506 Reply event*/
    public final static int READ_MULTISPK_STATUS_REPLY_EVENT = 51;

    private static final String TAG = PersonalGroupService.class.getSimpleName();
    private static final int UngroupedRole = 0;
    private static final int StereoMasterRole = 1;
    private static final int StereoSlaveRole = 2;
    private static final int ConcertMasterRole = 3;
    private static final int ConcertSlaveRole = 4;
    private static final int AddNewSlave = 5;

    /*5506 Command*/
    private final static String UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_MASTER = "2 0 E0";
    private final static String UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_SLAVE = "2 0 E1";
    private final static String UART_CMD_MMI_ACTION_MULTISPK_ADD_MORE_SLAVE = "2 0 F6";
    private final static String UART_CMD_MMI_ACTION_MULTISPK_TERMINATE = "2 0 E4";
    private final static String UART_CMD_MMI_ACTION_MULTISPK_CANCEL_GROUPING = "2 0 E5";
    private final static String UART_CMD_ENTER_NSPK = "2 0 F4";
    private final static String UART_CMD_ENTER_BROADCAST = "2 0 F5";
    private final static String UART_CMD_READ_NSPK_LINK_STATUS = "2B 0";
    private final static String UART_CMD_MMI_ACTION_POWER_ON_PRESSED = "2 0 51";
    private final static String UART_CMD_MMI_ACTION_POWER_ON_RELEASED = "2 0 52";


    private final static int COMMAND_ACK_EVENT = 0;//0x00


    private String mDevId = "";
    private String mMasterId = "";

    private TransparentServiceManager mTraspService;
    private BroadcastReceiver speakerInfoReceiver;
    private BLESpeaker selectedMasterSpeaker;


    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;

    private int settingRole = -1;
    private BLESpeaker mSpeaker;
    private ProgressDialog mUpdateStateDialog;
    private boolean concertMode;

    @Override
    public void onCreate() {
        BLELog.d(TAG, "Oncreate called");
    }

    public void updateSpeakerCtrl(int status) {
        BLELog.d(TAG, "updateSpeakerCtrl to" + status);
        settingRole = -1;
        switch (status) {
            case MULTISPK_STATUS_STANDALONE:
                mSpeaker.setGroupStatus(Constants.UNGROUPED_VALUE);
                break;
            case MULTISPK_STATUS_BROADCAST_MASTER:
                mSpeaker.setGroupStatus(Constants.CONCERT_MASTER_VALUE);
                break;
            case MULTISPK_STATUS_GROUPING:
                mSpeaker.setGroupStatus(Constants.GROUPING_PROGRESS_VALUE);
                stopService();
                break;
            case MULTISPK_STATUS_nSPK_MASTER:
                mSpeaker.setGroupStatus(Constants.STEREO_MASTER_VALUE);
                break;
            case MULTISPK_STATUS_UNKNOWN:
                mSpeaker.setGroupStatus(Constants.UNKNOWN_VALUE);
                break;
            case MULTISPK_STATUS_BROADCAST_WAITING_NEW_SLAVE:
                mSpeaker.setGroupStatus(Constants.CONCERT_MASTER_TRANSITION_VALUE);
                break;
        }
    }

    public void setSpeakerRole(int role) {
        settingRole = role;
        switch (settingRole) {
            case ConcertMasterRole:
            case ConcertSlaveRole:
                sendCommand(UART_CMD_ENTER_BROADCAST);
                break;
            case StereoMasterRole:
                if (mSpeaker.isConcertSuppported() == 1)
                    sendCommand(UART_CMD_ENTER_NSPK);
                else
                    sendCommand(UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_MASTER);
                break;
            case StereoSlaveRole:
                if (mSpeaker.isConcertSuppported() == 1)
                    sendCommand(UART_CMD_ENTER_NSPK);
                else
                    sendCommand(UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_SLAVE);
                break;
            case UngroupedRole:
                sendCommand(UART_CMD_MMI_ACTION_MULTISPK_TERMINATE);
                settingRole = -1;
                break;
            case AddNewSlave:
                sendCommand(UART_CMD_MMI_ACTION_MULTISPK_ADD_MORE_SLAVE);
                settingRole = -1;
                break;
        }

    }

    private void stopService() {
        BLELog.d(TAG, "stopService called");
        stopSelf();
    }

    public void sendInitCommands() {
        BLELog.d(TAG, "Calling sendInit Commands here");
        sendCommand(UART_CMD_MMI_ACTION_POWER_ON_PRESSED);
        sendCommand(UART_CMD_MMI_ACTION_POWER_ON_RELEASED);
        if (mDevId.equals(mMasterId)) {
            if (concertMode)
                setSpeakerRole(ConcertMasterRole);
            else
                setSpeakerRole(StereoMasterRole);
        } else {
            String cmd = "3A 01";
            byte[] addr = selectedMasterSpeaker.getmAddress();
            for (int k = 5; k >= 0; k--) {
                cmd = cmd + ' ';
                cmd += String.format("%02X", addr[k]);
            }
            sendCommand(cmd);
        }
    }

    public void sendCommand(String cmd) {
        if (mTraspService.isConnected() == false) {
            BLELog.d(TAG, "Send command Transp Servcie disconnected cmd=" + cmd);
        }
        if (mTraspService != null) {
            mTraspService.packAndSendCommand(cmd);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Let it continue running until it is stopped.
        //   Toast.makeText(this, "Service Started", Toast.LENGTH_LONG).show();
        String deviceId = intent.getStringExtra(Constants.DEVICE_ID);
        BLELog.d(TAG, "Device ID of selected speaker =" + deviceId);
        mDevId = deviceId;
        mMasterId = intent.getStringExtra(Constants.MASTER_ID);
        concertMode = intent.getBooleanExtra(Constants.CONCERT_MODE, true);

        mSpeaker = HomeScreenActivity.getInstance().getSpeaker(mDevId);
        selectedMasterSpeaker = HomeScreenActivity.getInstance().getSpeaker(mMasterId);
        mTraspService = new TransparentServiceManager(getApplicationContext(), mDevId,null);
        mTraspService.setDoNothandleGattClose(true);

        mUpdateStateDialog = new ProgressDialog(this);
        mUpdateStateDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mUpdateStateDialog.setMessage(getString(R.string.creating_message));
        mUpdateStateDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mUpdateStateDialog.setIndeterminate(true);
        mUpdateStateDialog.setCanceledOnTouchOutside(false);

        transRxIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_READY);
        speakerInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                Message msg = Message.obtain();
                String action = intent.getAction();
                if (TransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (TransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(TransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i, byte_cnt;
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Speaker Info get data : " + rxBytes[i]);

                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            byte_cnt = rxBytes[2] & 0xff;
                            switch (rxBytes[3] & 0xff) {
                                case COMMAND_ACK_EVENT:
                                    String returnValue = "";
                                    switch (rxBytes[5] & 0xff) {
                                        case 0:
                                            returnValue = "Command complete";
                                            if ((rxBytes[4] & 0xff) == 0x3A) {
                                                if (concertMode)
                                                    setSpeakerRole(ConcertSlaveRole);
                                                else
                                                    setSpeakerRole(StereoSlaveRole);
                                            }
                                            break;
                                        case 1:
                                            returnValue = "Command dissallow";
                                            break;
                                        case 2:
                                            returnValue = "Unknown command";
                                            break;
                                        case 3:
                                            returnValue = "Parameters error";
                                            break;
                                        case 4:
                                            returnValue = "BTM is busy";
                                            break;
                                        case 5:
                                            returnValue = "BTM memory is full";
                                            break;
                                        default:
                                            returnValue = "unknown return value";
                                    }
                                    BLELog.d(TAG, "ACK for Command = " + (rxBytes[4] & 0xff) + "  ACK Return value =" + returnValue);
                                    if ((rxBytes[5] & 0xff) != 0) {
                                        BLELog.d("Service", " For Command:" + (rxBytes[4] & 0xff));
                                    }

                                    break;
                                case READ_MULTISPK_STATUS_REPLY_EVENT:
                                    BLELog.d(TAG, "READ_MULTISPK_STATUS_REPLY_EVENT : " + rxBytes[4]);
                                    if (rxBytes[5] == 0x02) {
                                        if (settingRole == 2 || settingRole == 4) {
                                            // launchHomeScreen();
                                        } else
                                            updateSpeakerCtrl(MULTISPK_STATUS_GROUPING);
                                        break;
                                    } else if (rxBytes[5] == 0x01) {
                                        updateSpeakerCtrl(MULTISPK_STATUS_STANDALONE);
                                    }

                                    if (rxBytes[4] > 0 && rxBytes[4] <= 3) {
                                        updateSpeakerCtrl(MULTISPK_STATUS_nSPK_MASTER);
                                    } else if (rxBytes[4] == 5) {
                                        if (rxBytes[5] == 9)
                                            updateSpeakerCtrl(MULTISPK_STATUS_BROADCAST_WAITING_NEW_SLAVE);
                                        else
                                            updateSpeakerCtrl(MULTISPK_STATUS_BROADCAST_MASTER);
                                    } else if (rxBytes[4] == 4 || rxBytes[4] == 6) {
                                        // launchHomeScreen();
                                    }
                                    if (rxBytes[4] == 0 && rxBytes[5] == 0) {
                                        if (settingRole != -1) {
                                            switch (settingRole) {
                                                case StereoMasterRole:
                                                case ConcertMasterRole:
                                                    sendCommand(UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_MASTER);
                                                    settingRole = -1;
                                                    break;
                                                case StereoSlaveRole:
                                                case ConcertSlaveRole:
                                                    sendCommand(UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_SLAVE);
                                                    settingRole = -1;
                                                    break;
                                            }
                                        } else
                                            updateSpeakerCtrl(MULTISPK_STATUS_STANDALONE);
                                    }
                                    if (rxBytes[4] == 7 && rxBytes[5] == 3) {
                                        updateSpeakerCtrl(MULTISPK_STATUS_BROADCAST_MASTER);
                                    }
                                    break;

                            }
                        }
                    }
                }
            }

        };
        settingRole = -1;
        mTraspService.registerFragReceiver(speakerInfoReceiver, transRxIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, transReadyIntentFilter);
        return START_STICKY;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        mTraspService.unregisterFragReceiver(speakerInfoReceiver);
        mTraspService.cleanupTransparentService();
        //   Toast.makeText(this, "Service Destroyed", Toast.LENGTH_LONG).show();
        BLELog.d(TAG, "OnDestry called");
    }
}
