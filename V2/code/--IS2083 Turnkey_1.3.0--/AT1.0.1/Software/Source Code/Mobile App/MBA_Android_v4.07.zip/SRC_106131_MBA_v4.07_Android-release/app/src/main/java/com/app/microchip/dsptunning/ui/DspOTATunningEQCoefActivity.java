package com.app.microchip.dsptunning.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.example.mynatapplication.EqualizerCalculate;

import java.util.Arrays;

public class DspOTATunningEQCoefActivity extends AppCompatActivity {

    private static final String TAG = DspOTATunningEQCoefActivity.class.getSimpleName();

    private DspOTATunningBLEService mService;

    EditText Frequency_1;
    EditText Frequency_2;
    EditText Frequency_3;
    EditText Frequency_4;
    EditText Frequency_5;
    EditText  Gain_1;
    EditText Gain_2;
    EditText Gain_3;
    EditText Gain_4;
    EditText Gain_5;
    EditText  Q_1;
    EditText  Q_2;
    EditText  Q_3;
    EditText Q_4;
    EditText Q_5;

    EditText global_gain;
    EditText sample_frequency;
    Spinner stage;
    Spinner defaultCoeff;
    Button calcGain;
    ImageView QR_ImageView;

    public static  byte EQMode = 00;
    byte Audio_MCU_Option3;

    double Sample_Freq;

    private static String[]  stage_table = {"1", "2", "3", "4", "5"};
    private static byte[] stage_table_ids= {1, 2, 3, 4, 5};

    private static String[]   defaultCoeff_table = {"Flat", "Boost", "Treble", "Pop", "Rock", "Classic", "Jazz", "Dance", "R&B"};
    private static byte[] defaultCoeff_table_ids = {1, 2, 3, 4, 5, 6, 7, 8, 9};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dsp_eq_activity);

        mService = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        InitializeUI();

    }

    public void InitializeUI() {


        QR_ImageView = (ImageView) findViewById(R.id.functionalImage);

        stage= (Spinner)findViewById(R.id.Spinner1);
        defaultCoeff = (Spinner)findViewById(R.id.Spinner2);
        calcGain = (Button) findViewById(R.id.calculateGain);

        global_gain = (EditText)findViewById(R.id.editTexgg);
        sample_frequency=  (EditText)findViewById(R.id.editTextSampleFreq);



        Frequency_1 = (EditText) findViewById(R.id.editTextf1);
        Frequency_2 = (EditText) findViewById(R.id.editTextf2);
        Frequency_3 = (EditText) findViewById(R.id.editTextf3);
        Frequency_4 = (EditText) findViewById(R.id.editTextf4);
        Frequency_5 = (EditText) findViewById(R.id.editTextf5);

        Gain_1 = (EditText) findViewById(R.id.editTextg1);
        Gain_2 = (EditText) findViewById(R.id.editTextg2);
        Gain_3 = (EditText) findViewById(R.id.editTextg3);
        Gain_4 = (EditText) findViewById(R.id.editTextg4);
        Gain_5 = (EditText) findViewById(R.id.edittextg5);

        Q_1 = (EditText) findViewById(R.id.editTextq1);
        Q_2= (EditText) findViewById(R.id.editTextq2);
        Q_3 = (EditText) findViewById(R.id.editTextq3);
        Q_4 = (EditText) findViewById(R.id.editTextq4);
        Q_5 = (EditText) findViewById(R.id.editTextq5);

        if(EQMode == 0x01) {
            setTitle("Audio EQ");
            QR_ImageView.setImageResource(R.drawable.audioeq_new);

            global_gain.setText("0");
            sample_frequency.setText("48000");
            Sample_Freq = 48000;

        } else {
            sample_frequency.setText("48000");

            if(EQMode == 0x02){
                setTitle("SPK EQ");
            } else if(EQMode == 0x03) {
                setTitle("MIC EQ");
            }else if(EQMode == 0x04){
                    setTitle("SPK_mSBC EQ");
            }else if(EQMode == 0x05){
                setTitle("MIC_mSBC EQ");
            }
            QR_ImageView.setImageResource(R.drawable.voice_eq);
        }


        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, stage_table);

        stage.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                UpdateStage(pos+1);


            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stage.setAdapter(adapter);


        ArrayAdapter<String> adapter1;
        adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, defaultCoeff_table);

        defaultCoeff.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();
                defaultCoeffDidSelect();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        defaultCoeff.setAdapter(adapter1);

        //defaultCoeff.setEnabled(false);
        stage.setSelection(4);
        defaultCoeff.setSelection(0);

        calcGain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                {
                    double[] GainArr = new double[5];
                    double[] FreqArr = new double[5];
                    double[] QArr = new double[5];

                    double m_global_gain = 0.0;

                    int stage_num = stage.getSelectedItemPosition()+1;


                    String m_global_Str =  global_gain.getText().toString();
                    if (m_global_Str.equals("") ) {
                        BLELog.d(TAG, "m_global_Str == null");
                        return;
                    }
                    m_global_gain = Double.parseDouble(m_global_Str);


                    String sample_frequency_Str =  sample_frequency.getText().toString();
                    if (sample_frequency_Str.equals("")  ) {
                        BLELog.d(TAG, "sample_frequency_Str == null");
                        return;
                    }
                    Sample_Freq = Double.parseDouble(sample_frequency_Str);


                    String freq1_Str =  Frequency_1.getText().toString();
                    if (freq1_Str.equals("")  ) {
                        BLELog.d(TAG, "freq1_Str == null");
                        return;
                    }
                    FreqArr[0] = Double.parseDouble(freq1_Str);


                    String freq2_Str =  Frequency_2.getText().toString();
                    if (freq2_Str.equals("")  ) {
                        BLELog.d(TAG, "freq2_Str == null");
                        return;
                    }
                    FreqArr[1] = Double.parseDouble(freq2_Str);


                    String freq3_Str =  Frequency_3.getText().toString();
                    if (freq3_Str.equals("")  ) {
                        BLELog.d(TAG, "freq3_Str == null");
                        return;
                    }
                    FreqArr[2] = Double.parseDouble(freq3_Str);

                    String freq4_Str =  Frequency_4.getText().toString();
                    if (freq4_Str.equals("")  ) {
                        BLELog.d(TAG, "freq4_Str == null");
                        return;
                    }
                    FreqArr[3] = Double.parseDouble(freq4_Str);

                    String freq5_Str =  Frequency_5.getText().toString();
                    if (freq5_Str.equals("")  ) {
                        BLELog.d(TAG, "freq5_Str == null");
                        return;
                    }
                    FreqArr[4] = Double.parseDouble(freq5_Str);



                    String gain1_Str =  Gain_1.getText().toString();
                    if (gain1_Str.equals("")  ) {
                        BLELog.d(TAG, "gain1_Str == null");
                        return;
                    }
                    GainArr[0] = Double.parseDouble(gain1_Str);

                    String gain2_Str =  Gain_2.getText().toString();
                    if (gain2_Str.equals("")  ) {
                        BLELog.d(TAG, "gain2_Str == null");
                        return;
                    }
                    GainArr[1] = Double.parseDouble(gain2_Str);

                    String gain3_Str =  Gain_3.getText().toString();
                    if (gain3_Str.equals("")  ) {
                        BLELog.d(TAG, "gain3_Str == null");
                        return;
                    }
                    GainArr[2] = Double.parseDouble(gain3_Str);

                    String gain4_Str =  Gain_4.getText().toString();
                    if (gain4_Str .equals("")  ) {
                        BLELog.d(TAG, "gain4_Str == null");
                        return;
                    }
                    GainArr[3] = Double.parseDouble(gain4_Str);

                    String gain5_Str =  Gain_5.getText().toString();
                    if (gain5_Str.equals("") ) {
                        BLELog.d(TAG, "gain5_Str == null");
                        return;
                    }
                    GainArr[4] = Double.parseDouble(gain5_Str);


                    String q1_Str =  Q_1.getText().toString();
                    if (q1_Str.equals("") ) {
                        BLELog.d(TAG, "q1_Str == null");
                        return;
                    }
                    QArr[0] = Double.parseDouble(q1_Str);

                    String q2_Str =  Q_2.getText().toString();
                    if (q2_Str .equals("")  ) {
                        BLELog.d(TAG, "q2_Str == null");
                        return;
                    }
                    QArr[1] = Double.parseDouble(q2_Str);


                    String q3_Str =  Q_3.getText().toString();
                    if (q3_Str.equals("")  ) {
                        BLELog.d(TAG, "q3_Str == null");
                        return;
                    }
                    QArr[2] = Double.parseDouble(q3_Str);


                    String q4_Str =  Q_4.getText().toString();
                    if (q4_Str.equals("") ) {
                        BLELog.d(TAG, "q4_Str == null");
                        return;
                    }
                    QArr[3] = Double.parseDouble(q4_Str);

                    String q5_Str =  Q_5.getText().toString();
                    if (q5_Str.equals("")  ) {
                        BLELog.d(TAG, "q5_Str == null");
                        return;
                    }
                    QArr[4] = Double.parseDouble(q5_Str);


                    Log.d(TAG, "GainArr="+Arrays.toString(GainArr));
                    Log.d(TAG, "FreqArr="+Arrays.toString(FreqArr));
                    Log.d(TAG, "QArr="+ Arrays.toString(QArr));
                    Log.d(TAG, "m_global_gain="+m_global_gain);
                    Log.d(TAG, "stage_num="+stage_num);
                    Log.d(TAG, "Sample_Freq="+Sample_Freq);

                    EqualizerCalculate eqCalHelper = new EqualizerCalculate();
                    int[] intEqData = eqCalHelper.bm83getEqualizerParameters(GainArr,FreqArr,QArr,
                            m_global_gain, stage_num,Sample_Freq);

                    Log.d(TAG, "intEqData="+Arrays.toString(intEqData));

                    mService.EQ_Data = new byte[84];
                    for(int i=0;i< 84;i++)  {
                        mService.EQ_Data[i] = (byte) intEqData[i];
                    }

                    Log.d(TAG, "mService.EQ_Data="+Arrays.toString(mService.EQ_Data));

                    showcalCulateDialog("Save Calculated gain ?");


                }




            }
        });


    }

    public void showcalCulateDialog(String message) {
        final AlertDialog.Builder ad = new AlertDialog.Builder(this, R.style.MyDialogTheme);
        ad.setMessage(message);

        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });


        final AlertDialog  alert = ad.create();
        alert.setTitle("Calculate Gain!!");
        alert.show();



        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {

            }
        });

    }


    void UpdateStage(int stage){
        if(stage == 1){
            Frequency_1.setEnabled(true) ;
            Gain_1.setEnabled(true);
            Q_1.setEnabled(true) ;
            Frequency_2.setEnabled(false);
            Gain_2.setEnabled(false);
            Q_2.setEnabled(false);
            Frequency_3.setEnabled(false) ;
            Gain_3.setEnabled(false);
            Q_3.setEnabled(false) ;
            Frequency_4.setEnabled(false);
            Gain_4.setEnabled(false) ;
            Q_4.setEnabled(false);
            Frequency_5.setEnabled(false) ;
            Gain_5.setEnabled(false) ;
            Q_5.setEnabled(false);
        }
        else if(stage == 2){
            Frequency_1.setEnabled(true) ;
            Gain_1.setEnabled(true) ;
            Q_1.setEnabled(true) ;
            Frequency_2.setEnabled(true) ;
            Gain_2.setEnabled(true);
            Q_2.setEnabled(true) ;
            Frequency_3.setEnabled(false);
            Gain_3.setEnabled(false) ;
            Q_3.setEnabled(false) ;
            Frequency_4.setEnabled(false);
            Gain_4.setEnabled(false) ;
            Q_4.setEnabled(false) ;
            Frequency_5.setEnabled(false);
            Gain_5.setEnabled(false);
            Q_5.setEnabled(false) ;
        }
        else if(stage == 3){
            Frequency_1.setEnabled(true);
            Gain_1.setEnabled(true) ;
            Q_1.setEnabled(true);
            Frequency_2.setEnabled(true);
            Gain_2.setEnabled(true);
            Q_2.setEnabled(true);
            Frequency_3.setEnabled(true);
            Gain_3.setEnabled(true) ;
            Q_3.setEnabled(true);
            Frequency_4.setEnabled(false);
            Gain_4.setEnabled(false);
            Q_4.setEnabled(false) ;
            Frequency_5.setEnabled(false);
            Gain_5.setEnabled(false);
            Q_5.setEnabled(false) ;
        }
        else if(stage == 4){
            Frequency_1.setEnabled(true);
            Gain_1.setEnabled(true) ;
            Q_1.setEnabled(true);
            Frequency_2.setEnabled(true);
            Gain_2.setEnabled(true);
            Q_2.setEnabled(true);
            Frequency_3.setEnabled(true);
            Gain_3.setEnabled(true) ;
            Q_3.setEnabled(true);
            Frequency_4.setEnabled(true);
            Gain_4.setEnabled(true);
            Q_4.setEnabled(true);
            Frequency_5.setEnabled(false);
            Gain_5.setEnabled(false);
            Q_5.setEnabled(false) ;
        }
        else if(stage == 5){
            Frequency_1.setEnabled(true);
            Gain_1.setEnabled(true) ;
            Q_1.setEnabled(true);
            Frequency_2.setEnabled(true);
            Gain_2.setEnabled(true);
            Q_2.setEnabled(true);
            Frequency_3.setEnabled(true);
            Gain_3.setEnabled(true) ;
            Q_3.setEnabled(true);
            Frequency_4.setEnabled(true);
            Gain_4.setEnabled(true);
            Q_4.setEnabled(true);
            Frequency_5.setEnabled(true);
            Gain_5.setEnabled(true);
            Q_5.setEnabled(true) ;
        }
    }

    void defaultCoeffDidSelect() {

        String defaultCoeff_Name = defaultCoeff_table[defaultCoeff.getSelectedItemPosition()];

        if (EQMode == (byte) 0x01) {
            //Audio EQ
            if (defaultCoeff_Name.equalsIgnoreCase("Flat")) {
                Frequency_1.setText("1000");
                Frequency_2.setText("2000");
                Frequency_3.setText( "4000");
                Frequency_4.setText("8000") ;
                Frequency_5.setText("16000") ;
                Gain_1.setText(Double.toString(GTodB(1.0)));
                Gain_2.setText(Double.toString(GTodB(1.0)));
                Gain_3.setText(Double.toString(GTodB(1.0)));
                Gain_4.setText(Double.toString(GTodB(1.0)));
                Gain_5.setText(Double.toString(GTodB(1.0)));
                Q_1.setText("1.0");
                Q_2.setText("1.0");
                Q_3.setText("1.0") ;
                Q_4.setText("1.0") ;
                Q_5.setText("1.0") ;
                int selectedIndex = 4;
                stage.setSelection(selectedIndex) ;
                global_gain.setText( Double.toString(GTodB(1.0)));
                sample_frequency.setText( "48000");
                Sample_Freq = 48000;
                UpdateStage(5);

            } else {

            }

        } else{
            int multiFactor = 1;
            if((EQMode == (byte) 0x04) || (EQMode == (byte) 0x05)){
                multiFactor = 2;
            }

            if (Audio_MCU_Option3 != 0) {
                if ((Audio_MCU_Option3  & 0x02) == 0x02){
                    multiFactor = 6;
                }
            }

            //TODOD
            multiFactor = 1;

            if ((EQMode == 0x02) || (EQMode == 0x03)) {

                if (defaultCoeff_Name == "Flat") {
                    Frequency_1.setText(Integer.toString(100 * multiFactor));
                    Frequency_2.setText(Integer.toString(200 * multiFactor));
                    Frequency_3.setText(Integer.toString(500 * multiFactor));
                    Frequency_4.setText(Integer.toString(1000 * multiFactor));
                    Frequency_5.setText(Integer.toString(2000 * multiFactor));
                    Gain_1.setText(Double.toString(GTodB(1.0)));
                    Gain_2.setText(Double.toString(GTodB(1.0)));
                    Gain_3.setText(Double.toString(GTodB(1.0)));
                    Gain_4.setText(Double.toString(GTodB(1.0)));
                    Gain_5.setText(Double.toString(GTodB(1.0)));
                    Q_1.setText("1.0");
                    Q_2.setText("1.0");
                    Q_3.setText("1.0");
                    Q_4.setText("1.0");
                    Q_5.setText("1.0");
                    int selectedIndex = 4;
                    stage.setSelection(selectedIndex);
                    global_gain.setText(Double.toString(GTodB(1.0)));
                    UpdateStage(5);
                    sample_frequency.setText("8000");
                    //SampleFreq = 8000 * multiFactor
                } else {

                }
            }else if ((EQMode == 0x04) || (EQMode == 0x05)) {

                if (defaultCoeff_Name == "Flat") {
                    Frequency_1.setText(Integer.toString(100 * multiFactor));
                    Frequency_2.setText(Integer.toString(200 * multiFactor));
                    Frequency_3.setText(Integer.toString(500 * multiFactor));
                    Frequency_4.setText(Integer.toString(1000 * multiFactor));
                    Frequency_5.setText(Integer.toString(2000 * multiFactor));
                    Gain_1.setText(Double.toString(GTodB(1.0)));
                    Gain_2.setText(Double.toString(GTodB(1.0)));
                    Gain_3.setText(Double.toString(GTodB(1.0)));
                    Gain_4.setText(Double.toString(GTodB(1.0)));
                    Gain_5.setText(Double.toString(GTodB(1.0)));
                    Q_1.setText("1.0");
                    Q_2.setText("1.0");
                    Q_3.setText("1.0");
                    Q_4.setText("1.0");
                    Q_5.setText("1.0");
                    int selectedIndex = 4;
                    stage.setSelection(selectedIndex);
                    global_gain.setText(Double.toString(GTodB(1.0)));
                    UpdateStage(5);
                    sample_frequency.setText("16000");
                    //SampleFreq = 8000 * multiFactor
                } else {

                }
            }

        }
    }

    @Override
    protected void onStop() {
        BLELog.d(TAG, "onStop called");
        super.onStop();
    }

    protected void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        super.onDestroy();
        //EQMode =  0x01;

    }


    //// Cust eq file

    public double GTodB(double in) {
        double out;
        out = 20.0 * Math.log10(in);
        return out;
    }

    double dBToG(double in) {
        double out;
        out = Math.pow(10.0, in / (20.0));
        return out;
    }


}
