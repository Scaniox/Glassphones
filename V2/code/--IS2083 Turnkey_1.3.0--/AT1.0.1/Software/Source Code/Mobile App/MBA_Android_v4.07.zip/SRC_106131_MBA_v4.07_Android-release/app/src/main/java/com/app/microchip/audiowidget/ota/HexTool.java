package com.app.microchip.audiowidget.ota;

public class HexTool {
	final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();

	public static String byteArrayToHexString(byte in[]) {
		char[] hexChars = new char[in.length * 2];
		int v;
		for (int j = 0; j < in.length; j++) {
			v = in[j] & 0xFF;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 0x0F];
		}
		return new String(hexChars);
	}

	public static byte[] hexStringToByteArray(String s) {
	    int len = s.length();
	    byte[] data = new byte[len / 2];
	    for (int i = 0; i < len; i += 2) {
	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
	                             + Character.digit(s.charAt(i+1), 16));
	    }
	    return data;
	}

	public static int hex2decimal(String s) {
		String digits = "0123456789ABCDEF";
		s = s.toUpperCase();
		int val = 0;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			int d = digits.indexOf(c);
			val = 16*val + d;
		}
		return val;
	}

	public static byte[] xorOprArr(byte[] array_1,byte[] array_2) {

		byte[] array_3 = new byte[array_1.length];

		int i = 0;
		for (byte b : array_1)
			array_3[i] = (byte)(b ^ array_2[i++]);

		return array_3;

	}

	public static byte[] toByteArray(int value) {
		return new byte[] {
				(byte)(value >> 24),
				(byte)(value >> 16),
				(byte)(value >> 8),
				(byte)value};
	}
}
