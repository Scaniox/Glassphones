package com.app.microchip.wstearbuds.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;
import com.app.microchip.wstearbuds.adapters.EarbudsHomeScreenAdapter;
import com.app.microchip.wstearbuds.adapters.EarbudsRecentsGroupsAdapter;
import com.app.microchip.wstearbuds.managers.EarbudsBLEManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;




public class EarbudsHomeScreenActivity extends AppCompatActivity {

    public static final String TAG = EarbudsHomeScreenActivity.class.getSimpleName();
    private static final long SCAN_PERIOD = 30000;
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    private static EarbudsHomeScreenActivity INSTANCE;
    private static boolean isFirstTimeApplaunch = true;
    public Map<String, BLESpeaker> mSpeakers = new ConcurrentHashMap<String, BLESpeaker>();
    ArrayList<String> speakerList;
    HashMap<String, List<String>> childList;
    ExpandableListView expListView;
    EarbudsHomeScreenAdapter mHomeAdapter;
    int delay = 40000; //40 seconds
    private boolean isBluetoothEnabled = false;
   // private Timer timer;
    private boolean isScanning = false;

    private BluetoothAdapter mBluetoothAdapter;
    //  private ArrayAdapter<String> cachedGroupsAdapter;
    private EarbudsRecentsGroupsAdapter cachedGroupsAdapter;
    private int REQUEST_ENABLE_BT = 1;
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                        BluetoothAdapter.ERROR);
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:
                        BLELog.d(TAG, "Bluetooth off");
                        isBluetoothEnabled = false;
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        BLELog.d(TAG, "Turning Bluetooth off...");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        BLELog.d(TAG, "Bluetooth on");
                        isBluetoothEnabled = true;
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        BLELog.d(TAG, "Turning Bluetooth on...");
                        break;
                }
            }
        }
    };
    private ArrayList<HashMap<String, String>> cachedGroupList;
    private Handler mHandler;
    private BluetoothLeScanner mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter> filters;
    private Button scanBtn;
    private EarbudsBLEManager mBleManager;
    private String mSelectedSpeakerId;
    private SharedPreferences mSharedPreference;

    private int mRssiFilterVal = -90;
    private boolean isFilterEnabled = false;
    private ProgressDialog mConnectDialog;
    private ProgressDialog mScanDialog;
    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, final ScanResult result) {
            BLELog.d(TAG, "onScanResult: callbackType = " + callbackType + " result=" + result.toString());
           //addSpeaker(result.getDevice(), result.getScanRecord(), result.getRssi());
            runOnUiThread(new Thread(new Runnable() {
                @Override
                public void run() {
                    addEarbuds(result.getDevice(), result.getScanRecord(), result.getRssi());
                    prepareListData();
                    mHomeAdapter.notifyDataSetChanged();

                }
            }));

        };


        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            BLELog.d(TAG, "onBatchScanResults:" + results.toString());
            for (ScanResult sr : results) {
                System.out.println("ScanResult - Results" + sr.toString());
                //addSpeaker(sr.getDevice(), sr.getScanRecord(), sr.getRssi());
               addEarbuds(sr.getDevice(), sr.getScanRecord(), sr.getRssi());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            BLELog.d(TAG, "Scan Failed Error Code: " + errorCode);
        }
    };

    public static synchronized EarbudsHomeScreenActivity getInstance() {
        return INSTANCE;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earbuds_home_screen);

        getSupportActionBar().setTitle(" Add New Earbuds");

        mSharedPreference = PreferenceManager.getDefaultSharedPreferences(this);
        INSTANCE = this;
        cachedGroupList = new ArrayList<>();
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(mReceiver, filter);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("This app needs location access");
                builder.setMessage("Please grant location access so this app can detect beacons.");
                builder.setPositiveButton(android.R.string.ok, null);
                builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                    public void onDismiss(DialogInterface dialog) {
                        requestPermissions(new String[]{
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        }, PERMISSION_REQUEST_COARSE_LOCATION);
                    }
                });
                builder.show();
            }

        }

        isCallReadPermissionGranted();

       // isStoragePermissionGranted();



        initializeUI();
        mHandler = new Handler();
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "BLE Not Supported",
                    Toast.LENGTH_SHORT).show();
            finish();
        }
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();


        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            mBleManager = EarbudsBLEManager.getBLEManager(this);
            mLEScanner = mBluetoothAdapter.getBluetoothLeScanner();
            settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            filters = new ArrayList<ScanFilter>();

            BLELog.d(TAG, "Scan LE device is calling here");
            isBluetoothEnabled = true;

            foregroundScan(true);

        }
    }

    private void dismissScanning() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mScanDialog != null && mScanDialog.isShowing()) {
                    mScanDialog.setMessage(getString(R.string.scanning_dialog_message));
                    mScanDialog.dismiss();
                }
            }
        });
    }

    public  boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                BLELog.d(TAG,"Permission is granted");
                return true;
            } else {

                BLELog.d(TAG,"Permission is revoked");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        }
        else { //permission is automatically granted on sdk<23 upon installation
            BLELog.d(TAG,"Permission is granted");
            return true;
        }
    }

    public  boolean isCallReadPermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE)
                    == PackageManager.PERMISSION_GRANTED) {
                BLELog.d(TAG,"Permission is granted");
                return true;
            } else {

                BLELog.d(TAG,"Permission is revoked");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 1);
                return false;
            }
        }
        else { //permission is automatically granted on sdk<23 upon installation
            BLELog.d(TAG,"Permission is granted");
            return true;
        }
    }

    private void dismissConnect() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mConnectDialog != null && mConnectDialog.isShowing()) {
                    mConnectDialog.dismiss();
                }
            }
        });
    }

    private void displayConnecting() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mConnectDialog != null)
                    mConnectDialog.show();
            }
        });
    }

    private void displayScanning() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mScanDialog != null)
                    mScanDialog.show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[],
                                           int[] grantResults) {
        BLELog.d(TAG, "onRequestPermissionsResult");
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    System.out.println("coarse location permission granted");
                } else {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Functionality limited");
                    builder.setMessage("Since location access has not been granted, this app will not be able to discover beacons when in the background.");
                    builder.setPositiveButton(android.R.string.ok, null);
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                        }
                    });
                    builder.show();
                }
                return;
            }
        }
    }

    @Override
    protected void onResume() {
        BLELog.d(TAG, "On resume called");

        mRssiFilterVal = mSharedPreference.getInt("rssiFilter", -90);
        isFilterEnabled = mSharedPreference.getBoolean("filterEnabled", false);
        mHomeAdapter.notifyDataSetChanged();
       /* timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                BLELog.d(TAG, "Calling backgroundscan here");
                backgroundScan(true);
            }
        }, 0, delay);*/


        setmIsWstAppForegroud(true);
        super.onResume();
    }

    @Override
    protected void onPause() {
        BLELog.d(TAG, "On Pause Called");

        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled() && isScanning) {
            BLELog.d(TAG, "Scan LE device is calling here2");
            scanLeDevice(false);
        }

        isScanning = false;
        //timer.cancel();
        mHandler.removeCallbacksAndMessages(null);

        setmIsWstAppForegroud(false);
        super.onPause();
    }

    private void  handleMTUAfterConnect() {
        mBleManager.setMtuSize();
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();


        unregisterReceiver(mReceiver);

        INSTANCE = null;
    }



    public void updateSpeaker(BLESpeaker speaker) {
        String deviceId = speaker.getDeviceId();
        BLESpeaker BLESpeaker = mSpeakers.get(deviceId);
        if (null == BLESpeaker) {
            mSpeakers.put(deviceId, speaker);
            BLELog.d(TAG, "new Speaker1:" + speaker.getName());
        } else {
            mSpeakers.put(deviceId, speaker);
            BLELog.d(TAG, "Updating Speaker Info For " + speaker.getName());
        }
    }


    public ArrayList<BLESpeaker> getSpeakers() {
        BLELog.d(TAG, "getSpeakers");
        ArrayList<BLESpeaker> speakersList = new ArrayList<BLESpeaker>();
        Iterator<String> keyIterator = mSpeakers.keySet().iterator();
        while (keyIterator.hasNext()) {
            String key = (String) keyIterator.next();
            BLESpeaker speaker = mSpeakers.get(key);
            if (null != speaker) {
                speakersList.add(speaker);
            }
        }
        return speakersList;
    }

    public synchronized void clearSpeakerList() {
        BLELog.d(TAG, "clearSpeakerList");
        Iterator<String> keyIterator = mSpeakers.keySet().iterator();
        while (keyIterator.hasNext()) {
            String key = (String) keyIterator.next();
            mSpeakers.remove(key);
        }
    }

    public BLESpeaker getSpeaker(String key) {
        BLELog.d(TAG, "getSpeaker:" + key);
        return null == mSpeakers ? null : mSpeakers.get(key);
    }

    public void prepareListData() {
        speakerList.clear();
        childList.clear();

        BLELog.d(TAG, "prepareListData");
        Iterator<String> keyIterator = mSpeakers.keySet().iterator();
        while (keyIterator.hasNext()) {
            String key = (String) keyIterator.next();
            BLESpeaker speaker = mSpeakers.get(key);
            BLELog.d(TAG, speaker.getName() + " status=" + Constants.getSpeakerTypeString(speaker.getGroupStatus()));
           // if (speaker.getGroupStatus() == Constants.UNKNOWN_VALUE || speaker.getGroupStatus() == Constants.UNGROUPED_VALUE || speaker.getGroupStatus() == Constants.GROUPING_PROGRESS_VALUE || speaker.getGroupStatus() == Constants.CONCERT_MASTER_TRANSITION_VALUE || speaker.getGroupStatus() == Constants.STEREO_MASTER_VALUE || speaker.getGroupStatus() == Constants.CONCERT_MASTER_VALUE) {
                speakerList.add(speaker.getDeviceId());
           // }
        }

        BLELog.d(TAG, "Sizeof headers =" + speakerList.size());
        for (int i = 0; i < speakerList.size(); i++) {
            List<String> header = new ArrayList<>();
            Iterator<String> childkeyIterator = mSpeakers.keySet().iterator();
            while (childkeyIterator.hasNext()) {
                String key = (String) childkeyIterator.next();
                BLESpeaker speaker = mSpeakers.get(key);
                if ((speaker.getGroupAddress().equals(speakerList.get(i))) && !(speaker.getDeviceId().equals(speakerList.get(i)))) {
                    header.add(speaker.getDeviceId());
                }
            }
            childList.put(speakerList.get(i), header);
        }


        Iterator<String> keyIterator1 = mSpeakers.keySet().iterator();
        while (keyIterator1.hasNext()) {
            String key = (String) keyIterator1.next();
            BLESpeaker speaker = mSpeakers.get(key);
            if (speaker.getGroupStatus() == Constants.UNGROUPED_VALUE) {
                BLELog.d(TAG, "Updating groupInfo here for " + speaker.getName());
                speaker.updateGroupInfo(speaker);
                updateSpeaker(speaker);
            } else {
                BLESpeaker masterSpeaker = mSpeakers.get(speaker.getGroupAddress());
                if (masterSpeaker != null) {
                    masterSpeaker.updateGroupInfo(speaker);
                    updateSpeaker(masterSpeaker);
                }
            }
        }
    }


    private void initializeUI() {
        BLELog.d(TAG, "initializeUI");
        //  scanBtn = (Button) findViewById(R.id.scan);
        expListView = (ExpandableListView) findViewById(R.id.speakerlist);

        //Connect Dialog
        mConnectDialog = new ProgressDialog(this);
        mConnectDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mConnectDialog.setMessage("Connecting. Please wait...");
        mConnectDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mConnectDialog.setIndeterminate(true);
        mConnectDialog.setCancelable(true);
        mConnectDialog.setCanceledOnTouchOutside(false);
        mConnectDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                               @Override
                                               public void onCancel(DialogInterface dialog) {
                                                   BLELog.d(TAG, "Cancelling Connection");
                                                 }
                                           }
        );


        //Scan dialog
        mScanDialog = new ProgressDialog(this);
        mScanDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);

            mScanDialog.setMessage(getString(R.string.scanning_dialog_message));

        mScanDialog.setIndeterminate(true);
        mScanDialog.setCancelable(true);
        mScanDialog.setCanceledOnTouchOutside(false);
        mScanDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mScanDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                scanLeDevice(false);
                prepareListData();
                mHomeAdapter.notifyDataSetChanged();
                mHandler.removeCallbacksAndMessages(null);

            }
        });
        speakerList = new ArrayList<>();
        childList = new HashMap<>();
        mHomeAdapter = new EarbudsHomeScreenAdapter(this, speakerList, childList);

        // setting list adapter
        expListView.setAdapter(mHomeAdapter);
        expListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView expandableListView, View view, int i, long l) {
                BLELog.d(TAG, "Clicked on list item");
                mSelectedSpeakerId = speakerList.get(i);
                BLESpeaker speaker = mSpeakers.get(mSelectedSpeakerId);

                /*if (mBleManager.getConnectionState(speaker.getBtDevice()) == BluetoothProfile.STATE_CONNECTED) {
                    BLELog.d(TAG, " Its already connected" +  speaker.getBtDevice().getAddress() + speaker.getDeviceId());
                    handleConnect();
                } else {
                    List<BluetoothDevice> connectedDevices = mBleManager.getConnectedDevices();
                    for (BluetoothDevice dev : connectedDevices) {
                        BLELog.d(TAG, "Disconnecting Already connected device" + dev.getName() + dev.getAddress());
                       // mBleManager.disconnect(dev);
                        mBleManager.closeGatt(dev);
                    }
                    displayConnecting();
                    scanLeDevice(false);
                   // timer.cancel();
                    BLELog.d(TAG, " Connnectiong  NEW  device" + speaker.getName() + speaker.getBtDevice().getAddress());
                    mBleManager.connectGatt(getApplicationContext(), false, speaker.getBtDevice(), Constants.TRANSPORT_LE);

                }*/
                scanLeDevice(false);

                try {
                    Thread.sleep(500);

                } catch (java.lang.InterruptedException e) {
                    e.printStackTrace();
                }

                EarbudsControllerActivity.getInstance().setSpeaker(speaker);
                finish();
                mSelectedSpeakerId = null;


                return true;
            }
        });

        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
                return false;
            }
        });


     /*   scanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BLELog.d(TAG, "scan Btn Clicked");
                BLELog.d(TAG, "Scan LE device is calling here1");
                foregroundScan(true);

            }
        });*/
        cachedGroupsAdapter = new EarbudsRecentsGroupsAdapter(EarbudsHomeScreenActivity.this, cachedGroupList);

        ListView v = (ListView) findViewById(R.id.recentgroupsList);
        v.setAdapter(cachedGroupsAdapter);
       /* v.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                scanLeDevice(false);//Stop scanning
                mSelectedSpeakerId = null;
                mBleManager.removeListener(gattCallback);
                Intent intent = new Intent(HomeScreenActivity.getInstance(), PersonalGroupCreationActivity.class);
                HashMap<String, String> entry = cachedGroupList.get(position);
                intent.putExtra("groupName", entry.get("name"));
                intent.putExtra("groupObject", entry);
                startActivity(intent);
            }
        });*/
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_CANCELED) {
                //Bluetooth not enabled.
                finish();
                return;
            }
            mBleManager = EarbudsBLEManager.getBLEManager(this);

            mLEScanner = mBluetoothAdapter.getBluetoothLeScanner();
            settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            filters = new ArrayList<ScanFilter>();

            foregroundScan(true);

            BLELog.d(TAG, "Scan LE device is calling here4");

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void foregroundScan(boolean enable) {
        displayScanning();
        speakerList.clear();
        childList.clear();
        clearSpeakerList();
        mHomeAdapter.notifyDataSetChanged();
        List<BluetoothDevice> devices = mBleManager.getConnectedDevices();
        for (BluetoothDevice device : devices) {

            BLELog.d(TAG, " Already connected device" + device.getAddress());
            //mBleManager.disconnect(device);
            //mBleManager.closeGatt(device);
        }
        scanLeDevice(enable);
    }

    private void backgroundScan(boolean enable) {
        scanLeDevice(enable);
    }

    private void scanLeDevice(final boolean enable) {
        BLELog.d(TAG, "scanLeDevice");
        if (isBluetoothEnabled == false) {
            BLELog.d(TAG, "Bluetooth not enabled, returning here");
            return;
        }
        if (enable) {
            if (isScanning)
                return;
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    BLELog.d(TAG, "Scan finished");
                    isScanning = false;
                    mBleManager.stopScan(mScanCallback);


                    dismissScanning();

                    prepareListData();

                    TextView tv = (TextView) findViewById(R.id.recentGroupsLabel);
                    tv.setVisibility(View.INVISIBLE);

                    mHomeAdapter.notifyDataSetChanged();
                    if (speakerList.isEmpty()) {
                        Toast.makeText(EarbudsHomeScreenActivity.this, "No Earbuds found, Please try scanning again",
                                Toast.LENGTH_SHORT).show();
                    }


                }
            }, SCAN_PERIOD);
            if (!isScanning) {
                isScanning = true;
                BLELog.d(TAG, "Scan Started");
                if(mBleManager!=null)
                {
                    List<BluetoothDevice> connectedDevices = mBleManager.getConnectedDevices();
                    for (BluetoothDevice dev : connectedDevices) {
                        BLELog.d(TAG, " Already connected device" + dev.getAddress());
                        //mBleManager.disconnect(dev);
                        mBleManager.closeGatt(dev);

                        try {
                            Thread.sleep(500);

                        } catch (java.lang.InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                ScanSettings scanSettings = new ScanSettings.Builder()
                        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                        .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
                        .setMatchMode(ScanSettings.MATCH_MODE_AGGRESSIVE)
                        .setNumOfMatches(ScanSettings.MATCH_NUM_ONE_ADVERTISEMENT)
                        .setReportDelay(0L)
                        .build();

                mBleManager.startScan(null, scanSettings, mScanCallback);
            }
        } else {
            isScanning = false;
            mBleManager.stopScan(mScanCallback);
        }

    }




    public boolean saveRecentBundleId(String bundleId, String  bundleGroupAddress) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor mEdit1 = sp.edit();

        mEdit1.putString("RecentBundleId" , bundleId);
        mEdit1.putString("RecentBundleGroupAddress" , bundleGroupAddress);

        BLELog.d(TAG, "saveRecentBundleId  " + bundleId+" bundleGroupAddress " + bundleGroupAddress);

        return mEdit1.commit();
    }

    public boolean saveRecentConnectedDevGroup(String deviceBtAddress, String  groupAddress,String btName) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor mEdit1 = sp.edit();

        mEdit1.putString("RecentBtAddress" , deviceBtAddress);
        mEdit1.putString("RecentGroupAddress" , groupAddress);
        mEdit1.putString("RecentBtName" , btName);

        return mEdit1.commit();
    }

    public String getRecentConnectedDeviceAddress() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String value = sp.getString("RecentBtAddress" , null);
        value = "";
        return value;
    }

    public String getRecentConnectedGroupAddress() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String value = sp.getString("RecentGroupAddress" , null);
        return value;
    }

    public String getRecentConnectedDeviceName() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String value = sp.getString("RecentBtName" , null);
        return value;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.scan_newdevicemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.find_new_device:
                foregroundScan(true);
                return (true);
            /*case R.id.personalgroup:
                scanLeDevice(false);//Stop scanning
                mSelectedSpeakerId = null;
                mBleManager.removeListener(gattCallback);
                Intent intent = new Intent(HomeScreenActivity.getInstance(), PersonalGroupCreationActivity.class);
                startActivity(intent);
                return (true);
            case R.id.AppSettings:
                Intent appSettings = new Intent(HomeScreenActivity.getInstance(), ApplicationSettings.class);
                startActivity(appSettings);
                break;
            case R.id.ota:
                scanLeDevice(false);//Stop scanning
                mSelectedSpeakerId = null;
                mBleManager.removeListener(gattCallback);
                Intent ota = new Intent(HomeScreenActivity.getInstance(), OTADeviceScanActivity.class);
                startActivity(ota);
                break;
            case R.id.earbuds:
                scanLeDevice(false);//Stop scanning
                mSelectedSpeakerId = null;
                mBleManager.removeListener(gattCallback);
                Intent earbuds = new Intent(HomeScreenActivity.getInstance(), EarbudsHomeScreenActivity.class);
                startActivity(earbuds);
                break;*/
        }
        return (super.onOptionsItemSelected(item));
    }





    public void addEarbuds(BluetoothDevice btDevice, ScanRecord record, int rssi) {
        {

            if (isFilterEnabled && rssi < mRssiFilterVal) {
                BLELog.d(TAG, "RSSI value Filter" + rssi + "<" + mRssiFilterVal + " Discard this");
                return;
            }
            byte[] beacon = new byte[20];
            BLELog.d(TAG, "SCAN RECORD:" + record.toString());
            Map<ParcelUuid, byte[]> data = new HashMap<>();
            data = record.getServiceData();
            boolean isMchpSpeaker = false;
            for (Map.Entry<ParcelUuid, byte[]> entry : data.entrySet()) {
                ParcelUuid uuid = entry.getKey();
                //compare to ISSC uuid and copy to beacon
                beacon = entry.getValue();
                System.out.println("key:" + uuid.toString());
                StringBuilder sb = new StringBuilder();
                for (byte b : beacon) {
                    sb.append(String.format("%02X ", b));
                }
                BLELog.d(TAG, "HEX VALUE " + sb.toString());
                String uuidStr = uuid.toString();
                if (uuidStr.startsWith("0000feda")) {
                    isMchpSpeaker = true;
                }
            }
            if (isMchpSpeaker == false) {
                BLELog.d(TAG, "Its not WST Earbud");
                return;
            }

            BLELog.d(TAG, "Becon Received Data Hex="+ HexTool.byteArrayToHexString(beacon));

            // BLELog.d(TAG, "Beacon Length=" + beacon.length);
            BLESpeaker speaker = new BLESpeaker();
            if (beacon.length == 2) {//category 2, 104/105 Embedded mode Generic Headset
                speaker.setDeviceId(btDevice.getAddress());
                speaker.setName(btDevice.getName());
                speaker.setBtDevice(btDevice);
                speaker.setRssi(rssi);
                speaker.setGroupAddress("");
                speaker.setGroupStatus(Constants.UNGROUPED_VALUE);
                speaker.setFeatureValue((byte) 4);
                speaker.setBeaconCategory(2);
            } else if (beacon.length == 10) {
                BLELog.d(TAG, "WST Earbud device");
            /*  Example
            uuid: 0000feda-0000-1000-8000-00805f9b34fb
            value: 00 02 00 00 C4 2B AE ED 00 00 00 00

            New HEX value : HEX VALUE 1F 02 00 00 A8 01 0A F4 81 34 00 00 00 00 00 00 03

            00 battery level [0th byte]
            02 BTM Status     [1st byte]
            00 multispk role [2nd byte]
            00 multi spk state [3rd byte]
            C4 2B AE ED Device address [4th byte]
            00 00 00 00 group address [10th byte]
            00 supported feature [16th byte]
            */


                //Battery Level
                int batteryVal = Constants.UNKNOWN_VALUE;
                if (beacon[0] == 0x00) batteryVal = 0;
                else if (beacon[0] == 0x01 || beacon[0] == 0x02 || beacon[0] == 0x03)
                    batteryVal = 1;
                else if (beacon[0] == 0x04 || beacon[0] == 0x05 || beacon[0] == 0x06)
                    batteryVal = 2;
                else if (beacon[0] == 0x07 || beacon[0] == 0x08 || beacon[0] == 0x09)
                    batteryVal = 3;
                else if (beacon[0] == 0x0A || beacon[0] == 0x0B) batteryVal = 4;
                else if (beacon[0] == 0x0C) batteryVal = 5;
                BLELog.d(TAG, "battery Level=" + batteryVal);

                //BTM Status
                int btmStatus = Constants.UNKNOWN_VALUE;
                if (beacon[1] == 0x00) btmStatus = Constants.POWER_OFF_STATE;
                else if (beacon[1] == 0x01) btmStatus = Constants.PAIRING_STATE;
                else if (beacon[1] == 0x02) btmStatus = Constants.STANDBY_STATE;
                else if (beacon[1] == 0x03) btmStatus = Constants.HF_CONN_STATE;
                else if (beacon[1] == 0x04) btmStatus = Constants.A2DP_CONN_STATE;
                else if (beacon[1] == 0x05) btmStatus = Constants.SPP_CONN_STATE;
                else if (beacon[1] == 0x06) btmStatus = Constants.MULTIPLE_CONN_STATE;
                BLELog.d(TAG, "WST BTM Status=" + btmStatus);


                //WST Primary ear bud status
                int groupStatus = Constants.UNKNOWN_VALUE;
                if (beacon[2] == 0x00) groupStatus = Constants.UNGROUPED_VALUE;
                else if (beacon[2] == 0x01) groupStatus = Constants.STEREO_MASTER_VALUE;
                else if (beacon[2] == 0x04) groupStatus = Constants.STEREO_SLAVE_VALUE;
                else if (beacon[2] == 0x05) groupStatus = Constants.CONCERT_MASTER_VALUE;
                else if (beacon[2] == 0x06) groupStatus = Constants.CONCERT_SLAVE_VALUE;
                else if (beacon[2] == 0x07) groupStatus = Constants.CONCERT_MASTER_VALUE;
                BLELog.d(TAG, "Primary ear bud status=" + Constants.getSpeakerTypeString(groupStatus));


                //WST Secondary ear bud battery
                int multispkState = Constants.UNKNOWN_VALUE;
                if (beacon[3] == 0x00) multispkState = Constants.MULTISPK_STANDBY;
                else if (beacon[3] == 0x01) multispkState = Constants.MULTISPK_BTM_BUSY;
                else if (beacon[3] == 0x02) multispkState = Constants.MULTISPK_CONNECTING;
                else if (beacon[3] == 0x03) multispkState = Constants.MULTISPK_CONNECTED;
                else if (beacon[3] == 0x09) multispkState = Constants.MULTISPK_MORE_SLAVE_CONN;
                BLELog.d(TAG, "Multi-SPK state=" + Constants.getMultiSPKstate(multispkState));



                if (groupStatus == Constants.UNGROUPED_VALUE && multispkState == Constants.MULTISPK_CONNECTING) {
                    groupStatus = Constants.GROUPING_PROGRESS_VALUE;
                }
                if (groupStatus == Constants.CONCERT_MASTER_VALUE && multispkState == Constants.MULTISPK_MORE_SLAVE_CONN) {
                    groupStatus = Constants.CONCERT_MASTER_TRANSITION_VALUE;
                }
                StringBuilder devId = new StringBuilder();
                StringBuilder grpId = new StringBuilder();

                {
                    //Device ID
                    devId.append(String.format("%02X", beacon[4]));
                    devId.append(String.format("%02X", beacon[5]));
                    devId.append(String.format("%02X", beacon[6]));
                    devId.append(String.format("%02X", beacon[7]));
                    devId.append(String.format("%02X", beacon[8]));
                    devId.append(String.format("%02X", beacon[9]));

                    if (devId.toString().equals("000000000000")) {
                        devId.replace(0, devId.length(), "UNKNOWN_");
                        devId.append(btDevice.getAddress());
                    }
                    BLELog.d(TAG, "Device Id=" + devId.toString());

                    //Group ID
                    grpId.append(String.format("%02X", beacon[4]));
                    grpId.append(String.format("%02X", beacon[5]));
                    grpId.append(String.format("%02X", beacon[6]));
                    grpId.append(String.format("%02X", beacon[7]));
                    grpId.append(String.format("%02X", beacon[8]));
                    grpId.append(String.format("%02X", beacon[9]));
                    BLELog.d(TAG, "Group Id=" + grpId.toString());


                    byte[] addr = new byte[6];
                    addr[0] = beacon[4];
                    addr[1] = beacon[5];
                    addr[2] = beacon[6];
                    addr[3] = beacon[7];
                    addr[4] = beacon[8];
                    addr[5] = beacon[9];
                    speaker.setmAddress(addr);
                    speaker.setBeaconCategory(3);
                }

                speaker.setDeviceId(devId.toString());
                speaker.setName(btDevice.getName());
                speaker.setBtDevice(btDevice);
                speaker.setRssi(rssi);
                speaker.setGroupAddress(grpId.toString());
                speaker.setBatteryValue(batteryVal);
                speaker.setGroupStatus(groupStatus);

            } else {
                BLELog.d(TAG, "WST BEACON length mismatch device");
                return;
            }

            if (btDevice.getName() == null)
                speaker.setName("unknown");

            String deviceId = speaker.getDeviceId();
            BLESpeaker BLESpeaker = mSpeakers.get(deviceId);
            if (null == BLESpeaker) {
                mSpeakers.put(deviceId, speaker);
                BLELog.d(TAG, "new Speaker:" + speaker.getName());
            } else {
                mSpeakers.put(deviceId, speaker);
                BLELog.d(TAG, "Speaker Object Existing: update RSSI for " + speaker.getName()+ "WST list size="+mSpeakers.size());
            }
        }
    }


    public boolean isWstAppForegroud() {
        return mIsWstAppForegroud;
    }

    public void setmIsWstAppForegroud(boolean mIsWstAppForegroud) {
        this.mIsWstAppForegroud = mIsWstAppForegroud;
    }

    private boolean mIsWstAppForegroud = false;
}