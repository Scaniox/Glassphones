package com.app.microchip.audiowidget.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ota.OTADeviceScanActivity;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.ui.DspOTATunningDeviceScanActivity;
import com.app.microchip.wstearbuds.ui.EarbudsControllerActivity;

public class HomeLaunchDashboard  extends AppCompatActivity {
    private LinearLayout bm83Button;
    private LinearLayout wstEarbudsButton;
    private LinearLayout dspbutton;
    private LinearLayout otabutton;

    private int REQUEST_ENABLE_BT = 1;

    private BluetoothAdapter mBluetoothAdapter;

    public static final String TAG = HomeLaunchDashboard.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_ACTION_BAR);

        setContentView(R.layout.activity_home_launcher_board);

        //ActionBar ab = getActionBar();

        getSupportActionBar().setTitle("            Microchip Bluetooth Audio");

        //getSupportActionBar().setTitle("            Microchip Bluetooth Audio");


        bm83Button = (LinearLayout) findViewById(R.id.mspklayout);
        wstEarbudsButton = (LinearLayout) findViewById(R.id.wstlayout);

        dspbutton = (LinearLayout) findViewById(R.id.dsptuningLayout);
        otabutton = (LinearLayout) findViewById(R.id.mspklayout2);

        bm83Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeLaunchDashboard.this, HomeScreenActivity.class);
                startActivity(intent);
            }
        });

        wstEarbudsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeLaunchDashboard.this, EarbudsControllerActivity.class);
                startActivity(intent);
            }
        });

        dspbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HomeLaunchDashboard.this, DspOTATunningDeviceScanActivity.class);
                //Intent intent = new Intent(HomeLaunchDashboard.this, DspTuningAudioPagerActivity.class);
                startActivity(intent);
            }
        });

        otabutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent = new Intent(HomeLaunchDashboard.this, OTADeviceScanActivity.class);
                startActivity(intent);
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("This app needs location access");
                builder.setMessage("Please grant location access so this app can BLE devices.");
                builder.setPositiveButton(android.R.string.ok, null);
                builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                    public void onDismiss(DialogInterface dialog) {
                        requestPermissions(new String[]{
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        }, PERMISSION_REQUEST_COARSE_LOCATION);
                    }
                });
                builder.show();
            }

        }

        isStoragePermissionGranted();


        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }



        }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_CANCELED) {
                //Bluetooth not enabled.
                finish();
                return;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;

    public  boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                BLELog.d(TAG,"Permission is granted");
                return true;
            } else {

                BLELog.d(TAG,"Permission is revoked");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        }
        else { //permission is automatically granted on sdk<23 upon installation
            BLELog.d(TAG,"Permission is granted");
            return true;
        }
    }
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[],
                                           int[] grantResults) {
        BLELog.d("HomeLaunchDashboard", "onRequestPermissionsResult");
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    System.out.println("coarse location permission granted");
                } else {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Functionality limited");
                    builder.setMessage("Since location access has not been granted, this app will not be able to discover beacons when in the background.");
                    builder.setPositiveButton(android.R.string.ok, null);
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                        }
                    });
                    builder.show();
                }
                return;
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();

    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
