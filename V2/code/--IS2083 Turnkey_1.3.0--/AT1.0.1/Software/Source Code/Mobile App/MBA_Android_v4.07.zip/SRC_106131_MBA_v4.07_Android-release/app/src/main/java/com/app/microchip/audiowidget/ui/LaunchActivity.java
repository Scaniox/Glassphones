package com.app.microchip.audiowidget.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

import com.app.microchip.audiowidget.BuildConfig;


public class LaunchActivity extends Activity {

    private static final int SPLASH_DELAY = 1 * 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Toast.makeText(getApplicationContext(), "Version:"+ BuildConfig.VERSION_NAME,
                Toast.LENGTH_LONG).show();

        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mSplashHandler.sendEmptyMessageDelayed(0, SPLASH_DELAY);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSplashHandler.removeMessages(0);
    }

    private Handler mSplashHandler = new Handler(new Handler.Callback() {

        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    startMainScreenActivity();
                    break;
            }
            return false;
        }
    });

    protected void startMainScreenActivity() {
        // Balaji
        //Intent intent = new Intent(this, HomeScreenActivity.class);
        Intent intent = new Intent(this, HomeLaunchDashboard.class);
        //Intent intent = new Intent(this, MainActivity.class);
         startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mSplashHandler = null;
    }
}
