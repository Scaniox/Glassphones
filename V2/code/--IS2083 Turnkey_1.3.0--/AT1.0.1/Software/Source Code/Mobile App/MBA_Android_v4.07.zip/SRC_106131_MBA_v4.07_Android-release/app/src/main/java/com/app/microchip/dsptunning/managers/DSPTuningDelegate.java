package com.app.microchip.dsptunning.managers;

/**
 * Created by I17163 on 1/30/2020.
 */

public interface DSPTuningDelegate  {

    public void  BLE_ServiceReady();
    public void  RefreshModuleData();
    public void  RefreshParametersData(byte[] Data);
    public void  DSPTuningComplete(byte result);
    public void  BLE_ConnectionStatus(boolean status);
    public void  DSPTuningState(String state);
    public void  ExportDSPTuningResult();
}
