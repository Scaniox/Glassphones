package com.app.microchip.audiowidget.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.managers.TransparentServiceManager;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;


public class GroupSettingsActivity extends AppCompatActivity {

    public final static int MULTISPK_STATUS_UNKNOWN = -1;
    public final static int MULTISPK_STATUS_STANDALONE = 0;
    public final static int MULTISPK_STATUS_GROUPING = 1;
    public final static int MULTISPK_STATUS_nSPK_MASTER = 2;
    public final static int MULTISPK_STATUS_BROADCAST_MASTER = 3;
    public final static int MULTISPK_STATUS_nSPK_SLAVE = 4;
    public final static int MULTISPK_STATUS_BROADCAST_SLAVE = 5;
    public final static int MULTISPK_STATUS_BROADCAST_WAITING_NEW_SLAVE = 6;
    /* 5506 Reply event*/
    public final static int READ_MULTISPK_STATUS_REPLY_EVENT = 51;
    private static final String TAG = GroupSettingsActivity.class.getSimpleName();
    private static final int UngroupedRole = 0;
    private static final int StereoMasterRole = 1;
    private static final int StereoSlaveRole = 2;
    private static final int ConcertMasterRole = 3;
    private static final int ConcertSlaveRole = 4;
    private static final int AddNewSlave = 5;
    private static final int cancelNewSlave = 6;
    private static final int ALERT_DIALOG_UNGROUPED = 1;
    private static final int ALERT_DIALOG_STEREOMASTER = 2;
    private static final int ALERT_DIALOG_CONCERTMASTER = 3;
    private static final int ALERT_DIALOG_GROUPING_PROGRESS = 4;
    private static final int ALERT_DIALOG_CONCERT_GROUPING_PROGRESS = 5;
    private static final int ALERT_DIALOG_STEREO_SLAVE = 6;
    private static final int ALERT_DIALOG_CONCERT_SLAVE = 7;
    private static final CharSequence[] ungroupedOptionsStereo = {"Stereo Master", "Stereo Slave"};
    private static final CharSequence[] ungroupedOptions = {"Stereo Master", "Stereo Slave", "Concert Master", "Concert Slave",};
    private static final CharSequence[] stereoMasteroptions = {"Ungrouped"};
    private static final CharSequence[] ConcertMasteroptions = {"Ungrouped", "Add new slave"};
    private static final CharSequence[] consrtmsterwatng4newslave = {"Ungrouped", "Disallow new slave"};
    /*5506 Command*/
    private final static String UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_MASTER = "2 0 E0";
    private final static String UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_SLAVE = "2 0 E1";
    private final static String UART_CMD_MMI_ACTION_MULTISPK_ADD_MORE_SLAVE = "2 0 F6";
    private final static String UART_CMD_MMI_ACTION_MULTISPK_TERMINATE = "2 0 E4";
    private final static String UART_CMD_MMI_ACTION_MULTISPK_CANCEL_GROUPING = "2 0 E5";
    private final static String UART_CMD_ENTER_NSPK = "2 0 F4";
    private final static String UART_CMD_ENTER_BROADCAST = "2 0 F5";
    private final static String UART_CMD_READ_NSPK_LINK_STATUS = "2B 0";
    private final static int COMMAND_ACK_EVENT = 0;//0x00
    private TextView speakerRole;
    private int selected = -1;
    private TransparentServiceManager mainActivity;
    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver groupInfoReceiver;
    private int settingRole = -1;
    private BLESpeaker mSpeaker;
    private RelativeLayout mGroupstatus;
    private ProgressDialog mUpdateStateDialog;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_settings);


        Intent intent = getIntent();
        String deviceId = intent.getStringExtra(Constants.DEVICE_ID);
        BLELog.d(TAG, "Device ID of selected speaker =" + deviceId);
        mSpeaker = HomeScreenActivity.getInstance().getSpeaker(deviceId);
        setTitle(mSpeaker.getName() + getString(R.string.group_settings));

        speakerRole = (TextView) findViewById(R.id.groupstatusvalue);
        speakerRole.setText(Constants.getSpeakerTypeString(mSpeaker.getGroupStatus()));

        mGroupstatus = (RelativeLayout) findViewById(R.id.groupstatus);
        mGroupstatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeSpeakerStatus();
            }
        });

        mUpdateStateDialog = new ProgressDialog(this);
        mUpdateStateDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mUpdateStateDialog.setMessage(getString(R.string.updating_message));
        mUpdateStateDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mUpdateStateDialog.setIndeterminate(true);
        mUpdateStateDialog.setCanceledOnTouchOutside(false);


        mainActivity = TransparentServiceManager.getInstance();
        transRxIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(TransparentServiceManager.BLE_DISCONNECTED);
        groupInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                Message msg = Message.obtain();
                String action = intent.getAction();
                if (TransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (TransparentServiceManager.BLE_DISCONNECTED.equals(action)) {
                    handleBLEDisconnection();
                }
                if (TransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(TransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i, byte_cnt;
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Speaker Info get data : " + rxBytes[i]);

                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            byte_cnt = rxBytes[2] & 0xff;
                            switch (rxBytes[3] & 0xff) {
                                case READ_MULTISPK_STATUS_REPLY_EVENT:
                                    BLELog.d(TAG, "READ_MULTISPK_STATUS_REPLY_EVENT : " + rxBytes[4]);
                                    if (rxBytes[5] == 0x02) {

                                        if (HomeScreenActivity.getInstance().isSlaveMode) {
                                            if (settingRole == 0 ) {
                                                launchHomeScreen();
                                            }

                                        }

                                        if (settingRole == 2 || settingRole == 4) {
                                            if (!HomeScreenActivity.getInstance().isSlaveMode) {
                                                launchHomeScreen();
                                            }
                                        } else
                                            updateSpeakerCtrl(MULTISPK_STATUS_GROUPING);
                                        break;
                                    } else if (rxBytes[5] == 0x01) {
                                        updateSpeakerCtrl(MULTISPK_STATUS_STANDALONE);
                                    }

                                    if (rxBytes[4] > 0 && rxBytes[4] <= 3) {
                                        updateSpeakerCtrl(MULTISPK_STATUS_nSPK_MASTER);
                                    } else if (rxBytes[4] == 5) {
                                        if (rxBytes[5] == 9)
                                            updateSpeakerCtrl(MULTISPK_STATUS_BROADCAST_WAITING_NEW_SLAVE);
                                        else
                                            updateSpeakerCtrl(MULTISPK_STATUS_BROADCAST_MASTER);
                                    } else if (rxBytes[4] == 4 || rxBytes[4] == 6) {
                                        if (!HomeScreenActivity.getInstance().isSlaveMode) {
                                            launchHomeScreen();
                                        }
                                    }
                                    if (rxBytes[4] == 0 && rxBytes[5] == 0) {
                                        if (settingRole != -1) {
                                            switch (settingRole) {
                                                case StereoMasterRole:
                                                case ConcertMasterRole:
                                                    sendCommand(UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_MASTER);
                                                    settingRole = -1;
                                                    break;
                                                case StereoSlaveRole:
                                                case ConcertSlaveRole:
                                                    sendCommand(UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_SLAVE);
                                                    settingRole = -1;
                                                    break;
                                            }
                                        } else
                                            updateSpeakerCtrl(MULTISPK_STATUS_STANDALONE);
                                    }
                                    if (rxBytes[4] == 7 && rxBytes[5] == 3) {
                                        updateSpeakerCtrl(MULTISPK_STATUS_BROADCAST_MASTER);
                                    }
                                    break;
                                case COMMAND_ACK_EVENT:
                                    String returnValue = "";
                                    switch (rxBytes[5] & 0xff) {
                                        case 0:
                                            returnValue = "Command complete";
                                            break;
                                        case 1:
                                            returnValue = "Command dissallow";
                                            break;
                                        case 2:
                                            returnValue = "Unknown command";
                                            break;
                                        case 3:
                                            returnValue = "Parameters error";
                                            break;
                                        case 4:
                                            returnValue = "BTM is busy";
                                            break;
                                        case 5:
                                            returnValue = "BTM memory is full";
                                            break;
                                        default:
                                            returnValue = "unknown return value";
                                    }
                                    BLELog.d(TAG, "ACK for Command = " + (rxBytes[4] & 0xff) + "  ACK Return value =" + returnValue);
                                    if ((rxBytes[5] & 0xff) != 0) {
                                        commandError(returnValue + " For Command:" + (rxBytes[4] & 0xff));
                                    }

                                    break;
                            }
                        }
                    }
                }
            }
        };
        settingRole = -1;
    }

    public void updateSpeakerCtrl(int status) {
        BLELog.d(TAG, "updateSpeakerCtrl to" + status);
        settingRole = -1;
        switch (status) {
            case MULTISPK_STATUS_STANDALONE:
                mSpeaker.setGroupStatus(Constants.UNGROUPED_VALUE);
                break;
            case MULTISPK_STATUS_BROADCAST_MASTER:
                mSpeaker.setGroupStatus(Constants.CONCERT_MASTER_VALUE);
                break;
            case MULTISPK_STATUS_GROUPING:
                mSpeaker.setGroupStatus(Constants.GROUPING_PROGRESS_VALUE);
                break;
            case MULTISPK_STATUS_nSPK_MASTER:
                mSpeaker.setGroupStatus(Constants.STEREO_MASTER_VALUE);
                break;
            case MULTISPK_STATUS_UNKNOWN:
                mSpeaker.setGroupStatus(Constants.UNKNOWN_VALUE);
                break;
            case MULTISPK_STATUS_BROADCAST_WAITING_NEW_SLAVE:
                mSpeaker.setGroupStatus(Constants.CONCERT_MASTER_TRANSITION_VALUE);
                break;
        }
        speakerRole.setText(Constants.getSpeakerTypeString(mSpeaker.getGroupStatus()));
        HomeScreenActivity.getInstance().updateSpeaker(mSpeaker);
        HomeScreenActivity.getInstance().prepareListData();
        runOnUiThread(new Runnable() {
            public void run() {
                if (mUpdateStateDialog != null && mUpdateStateDialog.isShowing()) {
                    mUpdateStateDialog.dismiss();
                }
            }
        });
    }

    private void commandError(final String message) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mUpdateStateDialog != null && mUpdateStateDialog.isShowing()) {
                    mUpdateStateDialog.dismiss();
                }
                Toast.makeText(getApplicationContext(), message + "\n Please check Speaker power",
                        Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mUpdateStateDialog != null && mUpdateStateDialog.isShowing()) {
                    mUpdateStateDialog.dismiss();
                }
                Intent home = new Intent(getApplicationContext(), HomeScreenActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }

    private void displayUpdateDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mUpdateStateDialog != null)
                    mUpdateStateDialog.show();
            }
        });
    }

    public void setSpeakerRole(int role) {
        settingRole = role;
        switch (settingRole) {
            case ConcertMasterRole:
            case ConcertSlaveRole:
                displayUpdateDialog();
                sendCommand(UART_CMD_ENTER_BROADCAST);
                break;
            case StereoMasterRole:
                displayUpdateDialog();
                if (mSpeaker.isConcertSuppported() == 1)
                    sendCommand(UART_CMD_ENTER_NSPK);
                else
                    sendCommand(UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_MASTER);
                break;
            case StereoSlaveRole:
                displayUpdateDialog();
                if (mSpeaker.isConcertSuppported() == 1)
                    sendCommand(UART_CMD_ENTER_NSPK);
                else
                    sendCommand(UART_CMD_MMI_ACTION_TRIGGER_MULTISPK_SLAVE);
                break;
            case UngroupedRole:
                displayUpdateDialog();
                sendCommand(UART_CMD_MMI_ACTION_MULTISPK_TERMINATE);
                settingRole = -1;
                launchHomeScreen();
                break;
            case AddNewSlave:
                displayUpdateDialog();
                sendCommand(UART_CMD_MMI_ACTION_MULTISPK_ADD_MORE_SLAVE);
                settingRole = -1;
                break;
        }

    }

    private void showAlertDialog(int dialog) {
        final int type = dialog;
        runOnUiThread(new Runnable() {
            public void run() {
                showDialog(type);
            }
        });
    }

    private void changeSpeakerStatus() {
        int value = mSpeaker.getGroupStatus();
        switch (value) {
            case Constants.UNGROUPED_VALUE:
                showAlertDialog(ALERT_DIALOG_UNGROUPED);
                break;
            case Constants.CONCERT_MASTER_VALUE:
                showAlertDialog(ALERT_DIALOG_CONCERTMASTER);
                break;
            case Constants.STEREO_MASTER_VALUE:
                showAlertDialog(ALERT_DIALOG_STEREOMASTER);
                break;
            case Constants.GROUPING_PROGRESS_VALUE:
                showAlertDialog(ALERT_DIALOG_GROUPING_PROGRESS);
                break;
            case Constants.CONCERT_MASTER_TRANSITION_VALUE:
                showAlertDialog(ALERT_DIALOG_GROUPING_PROGRESS);
                break;
            case Constants.STEREO_SLAVE_VALUE:
            case Constants.CONCERT_SLAVE_VALUE:
                showAlertDialog(ALERT_DIALOG_STEREO_SLAVE);
                break;

        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        AlertDialog dialog;

        switch (id) {
            case ALERT_DIALOG_UNGROUPED:

                final AlertDialog.Builder ad = new AlertDialog.Builder(GroupSettingsActivity.this, R.style.MyDialogTheme);
                ad.setTitle(R.string.set_speaker_as);
                if (mSpeaker.isConcertSuppported() == 1 && mSpeaker.isStereoSuppported() == 1) {
                    ad.setSingleChoiceItems(ungroupedOptions, -1, new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            selected = arg1;
                        }
                    });
                } else if (mSpeaker.isStereoSuppported() == 1) {
                    ad.setSingleChoiceItems(ungroupedOptionsStereo, -1, new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            selected = arg1;
                        }
                    });
                }
                ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                ad.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (selected == -1)
                            return;
                        BLELog.d(TAG, "selected =" + ungroupedOptions[selected]);
                        switch (selected) {
                            case 0:
                                setSpeakerRole(StereoMasterRole);
                                break;
                            case 1:
                                setSpeakerRole(StereoSlaveRole);
                                break;
                            case 2:
                                setSpeakerRole(ConcertMasterRole);
                                break;
                            case 3:
                                setSpeakerRole(ConcertSlaveRole);
                                break;
                        }

                    }
                });
                dialog = ad.create();
                break;
            case ALERT_DIALOG_STEREO_SLAVE:
            case ALERT_DIALOG_STEREOMASTER:

                final AlertDialog.Builder ad1 = new AlertDialog.Builder(GroupSettingsActivity.this, R.style.MyDialogTheme);
                ad1.setTitle(R.string.set_speaker_as);
                ad1.setSingleChoiceItems(stereoMasteroptions, -1, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        selected = arg1;
                    }
                });
                ad1.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                ad1.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (selected == -1)
                            return;
                        BLELog.d(TAG, "selected =" + stereoMasteroptions[selected]);
                        switch (selected) {
                            case 0:
                                setSpeakerRole(UngroupedRole);
                                break;
                            default:
                                BLELog.d(TAG, "Wrong value");
                                break;
                        }

                    }
                });
                dialog = ad1.create();
                break;
            case ALERT_DIALOG_CONCERTMASTER:

                final AlertDialog.Builder ad2 = new AlertDialog.Builder(GroupSettingsActivity.this, R.style.MyDialogTheme);
                ad2.setTitle(R.string.set_speaker_as);
                ad2.setSingleChoiceItems(ConcertMasteroptions, -1, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        selected = arg1;
                    }
                });
                ad2.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                ad2.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (selected == -1)
                            return;
                        BLELog.d(TAG, "selected =" + ConcertMasteroptions[selected]);
                        switch (selected) {
                            case 0:
                                setSpeakerRole(UngroupedRole);
                                break;
                            case 1:
                                setSpeakerRole(AddNewSlave);
                                break;
                            default:
                                BLELog.d(TAG, "Wrong value");
                                break;
                        }

                    }
                });
                dialog = ad2.create();
                break;
            case ALERT_DIALOG_GROUPING_PROGRESS:
                final AlertDialog.Builder ad3 = new AlertDialog.Builder(GroupSettingsActivity.this, R.style.MyDialogTheme);
                ad3.setMessage(R.string.cancel_grouping_message)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                displayUpdateDialog();
                                sendCommand(UART_CMD_MMI_ACTION_MULTISPK_CANCEL_GROUPING);
                                launchHomeScreen();
                            }
                        })
                        .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                dialog = ad3.create();
                break;
            case ALERT_DIALOG_CONCERT_GROUPING_PROGRESS:
                final AlertDialog.Builder ad4 = new AlertDialog.Builder(GroupSettingsActivity.this, R.style.MyDialogTheme);
                ad4.setTitle(R.string.set_speaker_as);
                ad4.setSingleChoiceItems(consrtmsterwatng4newslave, -1, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        selected = arg1;
                    }
                });
                ad4.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                ad4.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (selected == -1)
                            return;
                        BLELog.d(TAG, "selected =" + ConcertMasteroptions[selected]);
                        switch (selected) {
                            case 0:
                                setSpeakerRole(UngroupedRole);
                                break;
                            case 1:
                                displayUpdateDialog();
                                sendCommand(UART_CMD_MMI_ACTION_MULTISPK_CANCEL_GROUPING);
                                break;
                            default:
                                BLELog.d(TAG, "Wrong value");
                                break;
                        }

                    }
                });
                dialog = ad4.create();
                break;

            default:
                dialog = null;
        }
        return dialog;

    }

    public void sendCommand(String cmd) {
        if (mainActivity.isConnected() == false) {
            handleBLEDisconnection();
        }
        if (mainActivity != null) {
            mainActivity.packAndSendCommand(cmd);
        }
    }

    public void onStart() {
        super.onStart();
    }

    public void onResume() {
        super.onResume();
        BLELog.d(TAG, "onResume");
        sendInitCommands();
        mainActivity.registerFragReceiver(groupInfoReceiver, transRxIntentFilter);
        mainActivity.registerFragReceiver(groupInfoReceiver, transReadyIntentFilter);
        mainActivity.registerFragReceiver(groupInfoReceiver, disconnectionfilter);
    }

    public void onStop() {
        super.onStop();
        BLELog.d(TAG, "onStop");
        mainActivity.unregisterFragReceiver(groupInfoReceiver);
    }

    public void sendInitCommands() {
        BLELog.d(TAG, "SendInitCommands");
        sendCommand(UART_CMD_READ_NSPK_LINK_STATUS);
    }

    public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
            }
        });
        builder.show();
    }
}