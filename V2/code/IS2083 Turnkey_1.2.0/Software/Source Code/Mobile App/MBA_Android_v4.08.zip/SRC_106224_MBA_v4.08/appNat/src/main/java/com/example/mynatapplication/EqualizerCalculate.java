package com.example.mynatapplication;


import android.util.Log;

import java.util.Arrays;

public class EqualizerCalculate {


    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    int[] eqData = new int[84];

    public int[] getSampleData3() {

        {
            double[] GainArr = {1, 2.0, 5.0, 2.0, 3.0};
            double[] FreqArr = {1000.0, 2000.0, 4000.0, 8000.0, 16000.0};
            double[] QArr = {0.5, 0.5, 0.7, 0.6, 0.8};
            double gain = 1.0;
            double newFreq = 48000.0;
            int stage = 5;

            eqData =bm83getEqualizerParameters(GainArr, FreqArr, QArr,
                gain, stage, newFreq);

            Log.d("MainActivity  4", Arrays.toString(eqData));

            return eqData;
        }


    }


    public void test(){
        {
        double[] GainArr = {-5.0, 5.0, 5.0, 0.0, 0.0};
        double[] FreqArr = {5000.0, 20000.0, 10000.0, 15000.0, 23000.0};
        double[] QArr = {1.0, 1.0, 1.0, 1.0, 1.0};
        double gain = 0.0;
        double newFreq = 48000.0;
        int stage = 5;

        eqData = bm83getEqualizerParameters(GainArr, FreqArr, QArr,
                gain, stage, newFreq);

        Log.d("MainActivity eqData 1", Arrays.toString(eqData));
    }

    {
        // double[] GainArr = {1.0, 2.0, 5.0, 0.0, 0.0};
        //double[] FreqArr = {1000.0, 2000.0, 4000.0, 8000.0, 16000.0};
        // double[] QArr = {1.0, 1.0, 1.0, 1.0, 1.0};
        double[] GainArr = {1.0, 2.0, 5.0, 0.0, 0.0};
        double[] FreqArr = {1000.0, 2000.0, 4000.0, 0, 0.0};
        double[] QArr = {1.0, 1.0, 1.0, 0.0, 0.0};
        double gain = 1.0;
        double newFreq = 48000.0;
        int stage = 3;

        eqData = bm83getEqualizerParameters(GainArr, FreqArr, QArr,
                gain, stage, newFreq);

        Log.d("MainActivity eqData 2", Arrays.toString(eqData));
    }

    {
        double[] GainArr = {1.0, 2.0, 5.0, 0.0, 0.0};
        double[] FreqArr = {1000.0, 2000.0, 4000.0, 8000.0, 16000.0};
        double[] QArr = {0.5, 0.5, 1.0, 0.6, 1.0};
        double gain = 1.0;
        double newFreq = 48000.0;
        int stage = 5;

        eqData = bm83getEqualizerParameters(GainArr, FreqArr, QArr,
                gain, stage, newFreq);

        Log.d("MainActivity eqData 3", Arrays.toString(eqData));
    }

    {
        double[] GainArr = {1.0, 2.0, 5.0, 2.0, 3.0};
        double[] FreqArr = {1000.0, 2000.0, 4000.0, 8000.0, 16000.0};
        double[] QArr = {0.5, 0.5, 0.7, 0.6, 0.8};
        double gain = 1.0;
        double newFreq = 48000.0;
        int stage = 5;

        eqData = bm83getEqualizerParameters(GainArr, FreqArr, QArr,
                gain, stage, newFreq);

        Log.d("MainActivity eqData 4", Arrays.toString(eqData));
    }


}



    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();

    public native int[] bm83getEqualizerParameters( double[] jArrGain,double[] jArrFreq,double[] jArrQ,
                                                            double global_gain,int stage,double new_freq);
}
