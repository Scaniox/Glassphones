package com.app.microchip.audiowidget.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.managers.TransparentServiceManager;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;

import static android.R.id.empty;


public class SpeakerSettingsActivity extends AppCompatActivity {
    private static final String TAG = SpeakerSettingsActivity.class.getSimpleName();
    /*5506 Command*/
    private final static String UART_CMD_READ_SW_VERSION = "8 1";
    private final static String UART_CMD_CHANGE_DEVICE_NAME = "35 0 0 ";
    private final static String UART_CMD_READ_DEVICE_NAME = "10 0";
    private final static String UART_CMD_READ_IC_VERSION = "32 0";


    /* 5506 Reply event*/
    private final static int READ_BTM_VER_REPLY_EVENT = 24; //0x18
    private final static int READ_LOACL_DEVICE_NAME = 33; //0x21
    private final static int COMMAND_ACK_EVENT = 0;//0x00
    private final static int READ_IC_VERSION_REPLAY = 56; //0x38

    public String mDeviceName;
    TextView devName;
    private TransparentServiceManager mainActivity;
    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver speakerInfoReceiver;
    private String uartVer = "";
    private String swVer = "";
    private BLESpeaker mSpeaker;
    private ProgressDialog mUpdateNameDialog;
    private RelativeLayout devicename;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speaker_settings);
        Intent intent = getIntent();
        String deviceId = intent.getStringExtra(Constants.DEVICE_ID);
        BLELog.d(TAG, "Device ID of selected speaker =" + deviceId);
        mSpeaker = HomeScreenActivity.getInstance().getSpeaker(deviceId);
        setTitle(mSpeaker.getName() + getString(R.string.settings));
        mDeviceName = mSpeaker.getName();

        mUpdateNameDialog = new ProgressDialog(this);
        mUpdateNameDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mUpdateNameDialog.setMessage(getString(R.string.updating_message));
        mUpdateNameDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mUpdateNameDialog.setIndeterminate(true);
        mUpdateNameDialog.setCanceledOnTouchOutside(false);
        devName = (TextView) findViewById(R.id.devicenamevalue);
        devName.setText(mSpeaker.getName());
        devicename = (RelativeLayout) findViewById(R.id.devicename);
        devicename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editDeviceNameAlert();
            }
        });

        mainActivity = TransparentServiceManager.getInstance();
        transRxIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(TransparentServiceManager.BLE_DISCONNECTED);
        speakerInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {

                Message msg = Message.obtain();
                String action = intent.getAction();
                if (TransparentServiceManager.BLE_DISCONNECTED.equals(action)) {
                    handleBLEDisconnection();
                }
                if (TransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (TransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(TransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i, byte_cnt;
                        String displayString = "";
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Speaker Info get data : " + rxBytes[i]);

                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            byte_cnt = rxBytes[2] & 0xff;
                            BLELog.d(TAG, "3rd byte=" + (rxBytes[3] & 0xff));
                            switch (rxBytes[3] & 0xff) {
                                case COMMAND_ACK_EVENT:
                                    String returnValue = "";
                                    switch (rxBytes[5] & 0xff) {
                                        case 0:
                                            returnValue = "Command complete";
                                            break;
                                        case 1:
                                            returnValue = "Command dissallow";
                                            break;
                                        case 2:
                                            returnValue = "Unknown command";
                                            break;
                                        case 3:
                                            returnValue = "Parameters error";
                                            break;
                                        case 4:
                                            returnValue = "BTM is busy";
                                            break;
                                        case 5:
                                            returnValue = "BTM memory is full";
                                            break;
                                        default:
                                            returnValue = "unknown return value";
                                    }
                                    BLELog.d(TAG, "ACK for Command = " + (rxBytes[4] & 0xff) + "  ACK Return value =" + returnValue);
                                    if ((rxBytes[5] & 0xff) != 0) {
                                        commandError(returnValue + " For Command:" + (rxBytes[4] & 0xff));
                                    }
                                    break;
                                case READ_BTM_VER_REPLY_EVENT:
                                    if ((rxBytes[4] & 0xff) == 0x00) {
                                        displayString += String.format("%02X", (int) (rxBytes[5]) & 0xff) + ".";
                                        displayString += String.format("%02X", (int) (rxBytes[6]) & 0xff);
                                        uartVer = displayString;
                                        sendCommand(UART_CMD_READ_SW_VERSION);
                                    } else if ((rxBytes[4] & 0xff) == 0x01) {
                                        displayString += String.format("%02X", (int) (rxBytes[5]) & 0xff) + ".";
                                        displayString += String.format("%02X", (int) (rxBytes[6]) & 0xff);
                                        swVer = displayString;
                                    }
                                    break;
                                case READ_LOACL_DEVICE_NAME:
                                    int length = rxBytes[4] & 0xff;
                                    byte value[] = new byte[length];
                                    for (int i1 = 0; i1 < length; i1++) {
                                        value[i1] = rxBytes[5 + i1];
                                    }
                                    String name = new String(value);
                                    mUpdateNameDialog.dismiss();
                                    mDeviceName = name;
                                    mSpeaker.setName(mDeviceName);
                                    HomeScreenActivity.getInstance().updateSpeaker(mSpeaker);
                                    HomeScreenActivity.getInstance().prepareListData();
                                    break;
                                case READ_IC_VERSION_REPLAY:
                                    String s = new String(rxBytes);
                                    BLELog.d(TAG, "Reply for READ_IC_VERSION_REPLAY::" + s);
                                    if (s.contains("5506_ROM_104")) {
                                        BLELog.d(TAG, "ITS ROM Device, Hardcoded sw version");
                                        swVer = "04.00";
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                        updateUI();
                    }

                }
            }

        };
    }

    private void commandError(final String message) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mUpdateNameDialog != null && mUpdateNameDialog.isShowing()) {
                    mUpdateNameDialog.dismiss();
                }
                Toast.makeText(getApplicationContext(), message,
                        Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void editDeviceNameAlert() {
        // get prompts.xml view
        LayoutInflater li = LayoutInflater.from(SpeakerSettingsActivity.this);
        View promptsView = li.inflate(R.layout.editdevicename, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                SpeakerSettingsActivity.this);

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);

        final EditText userInput = (EditText) promptsView
                .findViewById(R.id.editTextDialogUserInput);
        userInput.setText("");
        userInput.append(mDeviceName);

        // set dialog message
        alertDialogBuilder
                .setCancelable(false);
        // create alert dialog
        final AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
        Button positiveBtn = (Button) promptsView.findViewById(R.id.editNameOK);
        positiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String deviceName = userInput.getText().toString();
                BLELog.d(TAG, "Device Name from UI=" + deviceName);
                alertDialog.dismiss();
                String cmd = UART_CMD_CHANGE_DEVICE_NAME;
                StringBuilder name = new StringBuilder();
                name.append(String.format("%02X", deviceName.length()));
                for (int i = 0; i < deviceName.length(); i++) {
                    name.append(String.format(" %02X", (int) deviceName.charAt(i)));
                }
                BLELog.d(TAG, "name is" + name.toString());
                cmd = cmd + name.toString();
                sendCommand(cmd);
                sendCommand(UART_CMD_READ_DEVICE_NAME);
                mUpdateNameDialog.show();

            }
        });
        Button negativeBtn = (Button) promptsView.findViewById(R.id.editNameCancel);
        negativeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }

    public void updateUI() {
        try {
            runOnUiThread(new Runnable() {

                @Override
                public void run() {

                    devName.setText(mDeviceName);
                    setTitle(mDeviceName + getString(R.string.settings));
                    TextView swVersion = (TextView) findViewById(R.id.versionvalue);
                    swVersion.setText(swVer);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void sendCommand(String cmd) {
        if (mainActivity.isConnected() == false) {
            handleBLEDisconnection();
        }
        if (mainActivity != null) {
            mainActivity.packAndSendCommand(cmd);
        }
    }

    public void onStart() {
        super.onStart();
        BLELog.d(TAG, "On Stop");
    }

    public void onResume() {
        super.onResume();
        BLELog.d(TAG, "On Resume");
        mainActivity.registerFragReceiver(speakerInfoReceiver, transRxIntentFilter);
        mainActivity.registerFragReceiver(speakerInfoReceiver, transReadyIntentFilter);
        mainActivity.registerFragReceiver(speakerInfoReceiver, disconnectionfilter);
        sendInitCommands();
    }

    public void onStop() {
        super.onStop();
        BLELog.d(TAG, "On Stop");
        mainActivity.unregisterFragReceiver(speakerInfoReceiver);
    }

    public void sendInitCommands() {
        BLELog.d(TAG, "SendInitCommands swVer=" + swVer);
        sendCommand(UART_CMD_READ_SW_VERSION);
        sendCommand(UART_CMD_READ_DEVICE_NAME);
        sendCommand(UART_CMD_READ_IC_VERSION);
    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                Intent home = new Intent(getApplicationContext(), HomeScreenActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }
    public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
            }
        });
        builder.show();
    }
}
