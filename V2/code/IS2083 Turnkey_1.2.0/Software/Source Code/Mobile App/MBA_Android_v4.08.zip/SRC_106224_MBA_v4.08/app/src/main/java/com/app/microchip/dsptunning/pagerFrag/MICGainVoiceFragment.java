package com.app.microchip.dsptunning.pagerFrag;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;
import com.app.microchip.dsptunning.ui.DspTuningVoicePagerActivity;

import java.util.Arrays;

/**
 * Created by I17163 on 12/12/2019.
 */

public class MICGainVoiceFragment extends Fragment implements DSPTuningDelegate{

    private static final String TAG = MICGainVoiceFragment.class.getSimpleName();


    private Spinner Mic_Gain;
    private Spinner ComfortNoise;
    private Button TuneDSP;
    TextView DSPState;
    private DspTuningVoicePagerActivity mActivity;
    private DspOTATunningBLEService mServie;

    byte[] MIC_Data;
    byte[] MIC_Prev_Data;
    byte[] ComfortNoise_Data;
    byte[] ComfortNoise_Prev_Data;

    String[] Mic_Gain_table = {"0x00: -19dB -Minimum", "0x03: -16dB", "0x05: -14dB", "0x07: -12dB",
            "0x09: -10dB", "0x0B: -8dB", "0x0D: -6dB", "0x0F: -4dB", "0x11: -2dB",
            "0x13: 0dB -Default", "0x15: 2dB", "0x17: 4dB", "0x19: 6dB", "0x1B: 8dB", "0x1D: 10dB",
            "0x1F: 12dB", "0x21: 14dB", "0x23: 16dB", "0x25: 18dB", "0x27: 20dB -Maximum"};
    byte[] Mic_Gain_ids = {0x00, 0x03, 0x05, 0x07, 0x09, 0x0B, 0x0D, 0x0F, 0x11, 0x13, 0x15, 0x17,
            0x19, 0x1B, 0x1D, 0x1F, 0x21, 0x23, 0x25, 0x27};
    String[] ComfortNoise_table = {"0x00: 0dB -Highest", "0x01: -6dB", "0x02: -12dB",
            "0x03: -18dB", "0x04: -24dB", "0x05: -30dB", "0x06: -36dB", "0x07: -42dB",
            "0x08: -48dB", "0x09: -54dB", "0x0A: -60dB", "0x0B: -66dB", "0x0C: -72dB",
            "0x0D: -78dB -Default", "0x0E: -84dB", "0x0F: -90dB -Lowest"};
    byte[] ComfortNoise_ids = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

    public MICGainVoiceFragment() {
        Log.d(TAG, "Constructor");
    }

    DspTuningVoicePagerActivity activity;

    public void init(DspTuningVoicePagerActivity act) {
        Log.d(TAG, "initialize");
        activity = act;
    }

    public void cleanup() {
        Log.d(TAG, "cleanup");
        activity = null;
    }

    private void initUI () {

        if (DSPState!= null & (mServie!=null))
            DSPState.setText(mServie.DSP_DUT_State);



        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, Mic_Gain_table);

        Mic_Gain.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                if (MIC_Data != null) {
                    Log.d(TAG, "Before MOD Mic_Gain_ids =" +
                            HexTool.byteArrayToHexString(Mic_Gain_ids));

                    MIC_Data[0] = Mic_Gain_ids[pos];

                    Log.d(TAG, "After MOD Mic_Gain_ids =" +
                            HexTool.byteArrayToHexString(Mic_Gain_ids));
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Mic_Gain.setAdapter(adapter);




        ArrayAdapter<String> adapter1;
        adapter1 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, ComfortNoise_table);

        ComfortNoise.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                if (ComfortNoise_Data != null) {

                    Log.d(TAG, "Before MOD ComfortNoise_Data =" +
                            HexTool.byteArrayToHexString(ComfortNoise_Data));

                    //int DSP_Byte =  ((0x8000 >> (pos))-1);
                    long DSP_Byte =  ((0x8000 >> (pos))-1);
                    ComfortNoise_Data[0] = (byte) (DSP_Byte >> 8);
                    ComfortNoise_Data[1] = (byte) (DSP_Byte & 0xFF);

                    Log.d(TAG, "After MOD MIC_NoiseReduction_Data =" +
                            HexTool.byteArrayToHexString(ComfortNoise_Data));

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ComfortNoise.setAdapter(adapter1);



        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });

        Voice_Data_Init();

        Mic_Gain.setEnabled(false);
        ComfortNoise.setEnabled(false);
        TuneDSP.setEnabled(false);


        BLELog.d(TAG, "initUI");
    }

    private int Mic_Gain_selectedIndex;
    private int CN_selectedIndex;


    void Voice_Data_Init() {
        BLELog.d(TAG,"Voice_Data_Init");

        if(MIC_Data!= null && MIC_Data.length != 0){
            for (int index=0; index < Mic_Gain_ids.length; index++)  {
                if(MIC_Data[0] == Mic_Gain_ids[index]){
                    Mic_Gain_selectedIndex = index;
                }
            }


        }

        if((ComfortNoise_Data != null) && (ComfortNoise_Data.length != 0) ){
            long noise = ((ComfortNoise_Data[0] << 8) + ComfortNoise_Data[1]);
            BLELog.d(TAG,"ComfortNoise ="+noise);
            int i = 0;
            long DSP_Byte = 1 << 15;
            while((noise+1) < DSP_Byte){
                i += 1;
                DSP_Byte = DSP_Byte >> 1;
            }
            CN_selectedIndex = i;

        }

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                Mic_Gain.setSelection(Mic_Gain_selectedIndex);
                Log.d(TAG,"SPK_NR SPK_NR_selectedIndex="+ Mic_Gain_selectedIndex);

                ComfortNoise.setSelection(CN_selectedIndex);
                Log.d(TAG,"MIC_NR SPK_NR_selectedIndex="+ CN_selectedIndex);

            }
        }));

    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.micgain_voice_fragment, container, false);

        Mic_Gain = (Spinner)view.findViewById(R.id.Spinner3);
        ComfortNoise = (Spinner)view.findViewById(R.id.Spinner4);
        DSPState =(TextView) view.findViewById(R.id.deviceStatus);
        TuneDSP = (Button) view.findViewById(R.id.tuneDspButton);

        Log.d(TAG, "onCreateView");

        disableTuneDspButton();


        return view;
                
    }

    private void  enableTuneDspButton() {
        TuneDSP.setEnabled(true);
        TuneDSP.setTextColor(Color.WHITE);
    }

    private void  disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }
    public void initModule(DspTuningVoicePagerActivity act) {
        mActivity = act;

        mServie = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        mServie.setListener(MICGainVoiceFragment.this);


        initUI();
        mServie.Get_Voice_MIC_Gain();

    }

    public void cleanModule() {

    }


    @Override
    public void onAttach(Context context) {
        Log.d(TAG, " onAttach");
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        Log.d(TAG, " onDetach");
        super.onDetach();
    }

    @Override
    public void BLE_ServiceReady() {

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] Data) {
        int k = 0;
        byte[] buffer = Data;

        //(dat as NSData).getBytes(&buffer, length: (dat as NSData).length)

        Log.d(TAG,"Parsing configuration data");

        while(k < buffer.length){
            byte len = buffer[k+2];
            //let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))

            byte[] param_dat = Arrays.copyOfRange(buffer, k+3, k+3+ len);;

            Log.d(TAG,"Offset = "+k+" module_id ="+buffer[k]+ "cfg_id ="+buffer[k+1]+
                    "data len = "+len+" dat = "+ HexTool.byteArrayToHexString(param_dat));



            if(buffer[k] == 13 && buffer[k+1] == 3){

                ComfortNoise_Data = Arrays.copyOfRange(buffer, k+3 , k+3+ 3);

                Log.d(TAG,"ComfortNoise_Data len = "+ComfortNoise_Data.length +  "data ="+
                        HexTool.byteArrayToHexString(ComfortNoise_Data));


            }else if(buffer[k] == 13 && buffer[k+1] == 4) {
                MIC_Data = Arrays.copyOfRange(buffer, k+3 , k+3+ 6);

                Log.d(TAG,"MIC_Data len = "+MIC_Data.length +  "data ="+
                        HexTool.byteArrayToHexString(MIC_Data));

            }

            k += (int)(3+len);
        }
        Voice_Data_Init();
    }

    @Override
    public void DSPTuningComplete(byte result) {

    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {

        Log.d(TAG, " DSPTuningState" + state);
        if (DSPState!= null)
            DSPState.setText(state);

    }

    @Override
    public void ExportDSPTuningResult() {

    }
}
