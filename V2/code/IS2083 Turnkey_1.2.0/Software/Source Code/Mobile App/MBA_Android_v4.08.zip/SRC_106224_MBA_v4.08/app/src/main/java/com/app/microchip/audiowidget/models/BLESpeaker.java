package com.app.microchip.audiowidget.models;

import android.bluetooth.BluetoothDevice;

import java.util.ArrayList;
import java.util.List;

import static android.os.Build.ID;

/**
 * Created by I21309 on 12/27/2016.
 */

public class BLESpeaker {

    private BluetoothDevice mbtDevice;
    private int mGroupStatus;
    private int mRssi;
    private String mName;
    private String mGroupAddress;
    private int mBatteryValue;
    private int mBTMStatus;
    private String mDeviceId;
    private ArrayList<BLESpeaker> groupInfo;

    public int getBeaconCategory() {
        return beaconCategory;
    }

    public void setBeaconCategory(int beaconCategory) {
        this.beaconCategory = beaconCategory;
    }

    private int beaconCategory = 0;

    public byte[] getmAddress() {
        return mAddress;
    }

    public void setmAddress(byte[] mAddress) {
        this.mAddress = mAddress;
    }

    private byte[] mAddress = new byte[6];

    public byte getFeatureValue() {
        return featureValue;
    }

    public int isStereoSuppported() {
        return (featureValue >> 0) & 1;
    }

    public int isConcertSuppported() {
        return (featureValue >> 1) & 1;
    }

    public int isembeddedSuppported() {
        return (featureValue >> 2) & 1;
    }

    public void setFeatureValue(byte featureValue) {
        this.featureValue = featureValue;
    }

    private byte featureValue;

    public BLESpeaker() {
        groupInfo = new ArrayList<BLESpeaker>();
    }

    public int getBTMStatus() {
        return mBTMStatus;
    }

    public void setBTMStatus(int mBTMStatus) {
        this.mBTMStatus = mBTMStatus;
    }

    public int getBatteryValue() {
        return mBatteryValue;
    }

    public void setBatteryValue(int mBatteryValue) {
        this.mBatteryValue = mBatteryValue;
    }

    public String getDeviceId() {
        return mDeviceId;
    }

    public void setDeviceId(String mDeviceId) {
        this.mDeviceId = mDeviceId;
    }

    public String getName() {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public BluetoothDevice getBtDevice() {
        return mbtDevice;
    }

    public void setBtDevice(BluetoothDevice mbtDevice) {
        this.mbtDevice = mbtDevice;
    }

    public int getGroupStatus() {
        return mGroupStatus;
    }

    public void setGroupStatus(int mGroupStatus) {
        this.mGroupStatus = mGroupStatus;
    }

    public String getGroupAddress() {
        return mGroupAddress;
    }

    public void setGroupAddress(String groupAddress) {
        this.mGroupAddress = groupAddress;
    }

    public int getRssi() {
        return mRssi;
    }

    public void setRssi(int mRssi) {
        this.mRssi = mRssi;
    }

    public List<BLESpeaker> getGroupInfo() {
        return groupInfo;
    }

    public void updateGroupInfo(BLESpeaker spk) {
        for (int i = 0; i < groupInfo.size(); i++) {
            if (groupInfo.get(i).getDeviceId().equals(spk.getDeviceId())) {
                groupInfo.set(i, spk);
                return;
            }
        }
        groupInfo.add(spk);
    }
}
