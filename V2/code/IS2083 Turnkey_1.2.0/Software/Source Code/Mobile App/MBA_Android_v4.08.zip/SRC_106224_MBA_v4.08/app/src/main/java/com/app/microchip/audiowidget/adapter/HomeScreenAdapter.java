package com.app.microchip.audiowidget.adapter;


/**
 * Created by I21309 on 1/2/2017.
 */

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.ui.HomeScreenActivity;
import com.app.microchip.audiowidget.util.Constants;

import java.util.HashMap;
import java.util.List;

public class HomeScreenAdapter extends BaseExpandableListAdapter {

    private Context _context;
    private List<String> _listDataHeader; // header titles
    // child data in format of header title, child title
    private HashMap<String, List<String>> _listDataChild;

    public HomeScreenAdapter(Context context, List<String> listDataHeader,
                             HashMap<String, List<String>> listChildData) {
        this._context = context;
        this._listDataHeader = listDataHeader;
        this._listDataChild = listChildData;
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return this._listDataChild.get(this._listDataHeader.get(groupPosition))
                .get(childPosititon);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        final String childText = (String) getChild(groupPosition, childPosition);

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.childitems, null);
        }

        BLESpeaker speaker = HomeScreenActivity.getInstance().getSpeaker(childText);

        TextView txtListChild = (TextView) convertView.findViewById(R.id.childname);
        TextView speakerType = (TextView) convertView.findViewById(R.id.speakertype);
        ImageView rssiImage = (ImageView) convertView.findViewById(R.id.childrssiImage);
        ImageView batteryImage = (ImageView) convertView.findViewById(R.id.childbatteryimage);


        int rssiValue = speaker.getRssi();
        int batteryValue = speaker.getBatteryValue();
        txtListChild.setText(speaker.getName());
        speakerType.setText(Constants.getSpeakerTypeString(speaker.getGroupStatus()));


        //Set RSSI image
        if (rssiValue <= -110)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal0));
        if (rssiValue <= -100 && rssiValue > -110)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal1));
        if (rssiValue <= -85 && rssiValue > -100)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal2));
        if (rssiValue <= -70 && rssiValue > -85)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal3));
        if (rssiValue <= -60 && rssiValue > -70)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal4));
        if (rssiValue > -60)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal5));

        //Set Battery image
        if (batteryValue == 0)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery0));
        if (batteryValue == 1)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery1));
        if (batteryValue == 2)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery2));
        if (batteryValue == 3)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery3));
        if (batteryValue == 4)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery4));
        if (batteryValue == 5)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery5));

        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return this._listDataChild.get(this._listDataHeader.get(groupPosition))
                .size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this._listDataHeader.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return this._listDataHeader.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.listitems, null);
        }

        //Get the speaker
        BLESpeaker speaker = HomeScreenActivity.getInstance().getSpeaker(headerTitle);

        //read from UI
        TextView lblListHeader = (TextView) convertView.findViewById(R.id.name);
        TextView groupType = (TextView) convertView.findViewById(R.id.grouptype);
        ImageView speakerImg = (ImageView) convertView.findViewById(R.id.speakerImage);
        ImageView rssiImage = (ImageView) convertView.findViewById(R.id.grouprssiImage);
        ImageView batteryImage = (ImageView) convertView.findViewById(R.id.groupbatteryimage);

        //get all values from speaker
        String name = speaker.getName();
        String type = Constants.getSpeakerTypeString(speaker.getGroupStatus());
        int rssiValue = speaker.getRssi();
        int batteryValue = speaker.getBatteryValue();

        //Set Name and type
        lblListHeader.setText(name);
        lblListHeader.setTextColor(Color.BLACK);
        groupType.setText(type);

        //Set RSSI image
        if (rssiValue <= -110)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal0));
        if (rssiValue <= -100 && rssiValue > -110)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal1));
        if (rssiValue <= -85 && rssiValue > -100)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal2));
        if (rssiValue <= -70 && rssiValue > -85)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal3));
        if (rssiValue <= -60 && rssiValue > -70)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal4));
        if (rssiValue > -60)
            rssiImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.signal5));

        //Set Battery image
        if (batteryValue == 0)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery0));
        if (batteryValue == 1)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery1));
        if (batteryValue == 2)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery2));
        if (batteryValue == 3)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery3));
        if (batteryValue == 4)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery4));
        if (batteryValue == 5)
            batteryImage.setImageDrawable(convertView.getResources().getDrawable(R.drawable.battery5));

        //Set Speaker image
        speakerImg.setImageDrawable(convertView.getResources().getDrawable(R.drawable.single_speaker));

        if (speaker.getGroupStatus() == Constants.CONCERT_MASTER_VALUE) {
            speakerImg.setImageDrawable(convertView.getResources().getDrawable(R.drawable.concert_group));
        } else if (speaker.getGroupStatus() == Constants.STEREO_MASTER_VALUE) {
            speakerImg.setImageDrawable(convertView.getResources().getDrawable(R.drawable.stereo_group));
        } else {
            speakerImg.setImageDrawable(convertView.getResources().getDrawable(R.drawable.single_speaker));
        }

        if(speaker.getBeaconCategory()==2){
            batteryImage.setVisibility(View.GONE);
            groupType.setVisibility(View.GONE);
        } else {
            batteryImage.setVisibility(View.VISIBLE);
            groupType.setVisibility(View.VISIBLE);
        }

        ExpandableListView view = (ExpandableListView) parent;
        view.expandGroup(groupPosition);

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
