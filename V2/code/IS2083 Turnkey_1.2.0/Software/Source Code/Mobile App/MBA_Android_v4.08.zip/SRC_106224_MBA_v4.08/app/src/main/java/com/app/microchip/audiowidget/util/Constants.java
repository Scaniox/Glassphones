package com.app.microchip.audiowidget.util;

import java.util.UUID;

/**
 * Created by I21309 on 12/27/2016.
 */

public class Constants {

    public static final int UNGROUPED_VALUE = 0;
    public static final int STEREO_MASTER_VALUE = 1;
    public static final int STEREO_SLAVE_VALUE = 4;
    public static final int CONCERT_MASTER_VALUE = 5;
    public static final int CONCERT_SLAVE_VALUE = 6;
    public static final int CONCERT_MASTER_TRANSITION_VALUE = 7;
    public static final int GROUPING_PROGRESS_VALUE = 8;
    public static final int UNKNOWN_VALUE = 99;

    // WST
    public static final int WST_NOTCONNECTED_VALUE = 0;
    public static final int WST_CONNECTED = 1;


    public static final String UNGROUPED = "Ungrouped";
    public static final String STEREO_MASTER = "Stereo Master";
    public static final String STEREO_SLAVE = "Stereo Slave";
    public static final String CONCERT_MASTER = "Concert Master";
    public static final String CONCERT_SLAVE = "Concert Slave";
    public static final String UNKNOWN_DEVICE = "Unknown";
    public static final String GROUPING= "Grouping...";
    public static final String WAITING_FOR_NEW_SLAVE= "Waiting for new slave...";

    public static final String DEVICE_ID = "com.microchip.audiowidget.speaker.DEVICE_ID";
    public static final String MASTER_ID = "com.microchip.audiowidget.speaker.MASTER_ID";
    public static final String CONCERT_MODE= "com.microchip.audiowidget.speaker.CONCERT_MODE";

    //BTM status
    public static final int POWER_OFF_STATE = 0;
    public static final int PAIRING_STATE = 1;
    public static final int STANDBY_STATE = 2;
    public static final int HF_CONN_STATE = 3;
    public static final int A2DP_CONN_STATE = 4;
    public static final int SPP_CONN_STATE = 5;
    public static final int MULTIPLE_CONN_STATE = 6;

    //Multi_SPK state
    public static final int MULTISPK_STANDBY = 0;
    public static final int MULTISPK_BTM_BUSY = 1;
    public static final int MULTISPK_CONNECTING = 2;
    public static final int MULTISPK_CONNECTED = 3;
    public static final int MULTISPK_MORE_SLAVE_CONN = 9;

    //Dual mode transport parameters
    public static final int TRANSPORT_AUTO = 0;
    public static final int TRANSPORT_BREDR = 1;
    public static final int TRANSPORT_LE = 2;

    //UUIDS
    public final static UUID CHR_ISSC_MP = UUID.fromString("49535343-ACA3-481C-91EC-D85E28A60318");
    private final static String ENCODE = "UTF-8";
    private final static String sPREFIX = "0000";
    private final static String sPOSTFIX = "-0000-1000-8000-00805f9b34fb";
    /* Device Info service */
    public final static UUID SERVICE_DEVICE_INFO = uuidFromStr("180A");
    public final static UUID CHR_MANUFACTURE_NAME = uuidFromStr("2A29");
    public final static UUID CHR_MODEL_NUMBER = uuidFromStr("2A24");
    public final static UUID CHR_SERIAL_NUMBER = uuidFromStr("2A25");
    public final static UUID CHR_HARDWARE_REVISION = uuidFromStr("2A27");
    public final static UUID CHR_FIRMWARE_REVISION = uuidFromStr("2A26");
    public final static UUID CHR_SOFTWARE_REVISION = uuidFromStr("2A28");
    public static UUID SERVICE_ISSC_PROPRIETARY = UUID.fromString("49535343-FE7D-4AE5-8FA9-9FAFD205E455");
    public static UUID CHR_CONNECTION_PARAMETER = UUID.fromString("49535343-6DAA-4D02-ABF6-19569ACA69FE");
    public static UUID CHR_ISSC_TRANS_TX = UUID.fromString("49535343-1E4D-4BD9-BA61-23C647249616");
    public static UUID CHR_ISSC_TRANS_RX = UUID.fromString("49535343-8841-43F4-A8D4-ECBE34729BB3");

    public static UUID CHR_WST_BUNDLE_CTL_POINT = UUID.fromString("49535343-4c8a-39b3-2f49-511cff073b7e");


    public  static boolean isBundleEnabled = true;

    public static UUID uuidFromStr(String str) {
        if (!str.matches(".{4}")) {
            return null;
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(sPREFIX);
            sb.append(str);
            sb.append(sPOSTFIX);
            return UUID.fromString(sb.toString());
        }
    }

    public static String getMultiSPKstate(int state) {
        if (state == Constants.MULTISPK_STANDBY)
            return "MultiSpeaker Standby";
        if (state == Constants.MULTISPK_BTM_BUSY)
            return "MultiSpeaker BTM Busy";
        if (state == Constants.MULTISPK_CONNECTING)
            return "MultiSpeaker Connecting";
        if (state == Constants.MULTISPK_CONNECTED)
            return "MultiSpeaker Connected";
        if (state == Constants.MULTISPK_MORE_SLAVE_CONN)
            return "MultiSpeaker More slave connection";
        return "Unknown state";
    }

    public static String getSpeakerTypeString(int type) {
        if (type == Constants.CONCERT_MASTER_VALUE)
            return Constants.CONCERT_MASTER;
        if (type == Constants.CONCERT_SLAVE_VALUE)
            return Constants.CONCERT_SLAVE;
        if (type == Constants.STEREO_MASTER_VALUE)
            return Constants.STEREO_MASTER;
        if (type == Constants.STEREO_SLAVE_VALUE)
            return Constants.STEREO_SLAVE;
        if (type == Constants.UNGROUPED_VALUE)
            return Constants.UNGROUPED;
        if (type == Constants.GROUPING_PROGRESS_VALUE)
            return Constants.GROUPING;
        if (type == Constants.CONCERT_MASTER_TRANSITION_VALUE)
            return Constants.WAITING_FOR_NEW_SLAVE;
        return Constants.UNKNOWN_DEVICE;
    }

    public static final UUID Device_Name_UUID = UUID.fromString("00002a00-0000-1000-8000-00805f9b34fb");
    public static final UUID Write_UUID = UUID.fromString("00001800-0000-1000-8000-00805f9b34fb");

    /* Client Characteristic Configuration Descriptor */
    public final static UUID DES_CLIENT_CHR_CONFIG = uuidFromStr("2902");
}
