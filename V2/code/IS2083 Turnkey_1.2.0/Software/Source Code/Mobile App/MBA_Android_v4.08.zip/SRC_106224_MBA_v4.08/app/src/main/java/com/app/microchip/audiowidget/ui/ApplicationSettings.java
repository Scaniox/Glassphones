package com.app.microchip.audiowidget.ui;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.BuildConfig;
import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.util.BLELog;

import static java.lang.Integer.parseInt;

public class ApplicationSettings extends AppCompatActivity {
    private static final String TAG = ApplicationSettings.class.getSimpleName();
    private SharedPreferences sp;
    private EditText rssiValue;
    private Switch rssiFilter;
    private RelativeLayout filterValuerow;
    int versionCode = BuildConfig.VERSION_CODE;
    String versionName = BuildConfig.VERSION_NAME;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application_settings);
        setTitle("Application Settings");

        TextView version = (TextView) findViewById(R.id.versionNumber);
        version.setText(versionName+"."+versionCode);

        rssiValue = (EditText) findViewById(R.id.rssiValue);
        sp = PreferenceManager.getDefaultSharedPreferences(HomeScreenActivity.getInstance());
        int iRssiValue = sp.getInt("rssiFilter", -90);
        rssiValue.setText(Integer.toString(iRssiValue));
        filterValuerow = (RelativeLayout) findViewById(R.id.filterValuerow);
        rssiFilter = (Switch) findViewById(R.id.rssifilterEnableSwitch);
        boolean isEnabled = sp.getBoolean("filterEnabled", false);
        if (isEnabled) {
            rssiFilter.setChecked(true);
            filterValuerow.setVisibility(View.VISIBLE);
        } else {
            rssiFilter.setChecked(false);
            filterValuerow.setVisibility(View.INVISIBLE);
        }
        rssiFilter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    SharedPreferences.Editor mEdit1 = sp.edit();
                    mEdit1.putBoolean("filterEnabled", true);
                    mEdit1.commit();
                    filterValuerow.setVisibility(View.VISIBLE);
                } else {
                    SharedPreferences.Editor mEdit1 = sp.edit();
                    mEdit1.putBoolean("filterEnabled", false);
                    mEdit1.commit();
                    filterValuerow.setVisibility(View.INVISIBLE);
                }
            }
        });


        Button rssiApply = (Button) findViewById(R.id.rssiApply);
        rssiApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sRssiVal = rssiValue.getText().toString();
                if (sRssiVal == null || sRssiVal.equals("")) {
                    Toast.makeText(ApplicationSettings.this, "RSSI value should be integer", Toast.LENGTH_SHORT).show();
                    return;
                }
                int iRssiVal = Integer.parseInt(sRssiVal);
                BLELog.d(TAG, "RSSIValue in int =" + iRssiVal);
                SharedPreferences.Editor mEdit1 = sp.edit();
                mEdit1.putInt("rssiFilter", iRssiVal);
                mEdit1.commit();
                Toast.makeText(ApplicationSettings.this, "Updated", Toast.LENGTH_SHORT).show();
            }
        });


    }
}
