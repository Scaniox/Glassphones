package com.app.microchip.audiowidget.ota;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.util.BLELog;

import java.util.ArrayList;
import java.util.List;


public class OTADeviceScanActivity extends AppCompatActivity {

    public static final String TAG = OTADeviceScanActivity.class.getSimpleName();
    private static final long SCAN_PERIOD = 320000;
    private ScanSettings settings;
    private List<ScanFilter> filters;
    private boolean isScanning = false;
    private Handler mHandler;
    private ArrayList<BluetoothDevice> mDevicelist;
    private BluetoothDevice mSelectedDevice;
    private OTADeviceListAdapter mAdapter;
    private ProgressDialog mScanDialog;
    private BluetoothAdapter mBTAdapter;
    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BLELog.d(TAG, "onScanResult: callbackType = " + callbackType + " result=" + result.toString());
            BluetoothDevice device = result.getDevice();
            for (BluetoothDevice dev : mDevicelist) {
                if (dev.getAddress().equals(device.getAddress()))
                    return;
            }
            mDevicelist.add(device);
            mAdapter.notifyDataSetChanged();
        }


        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            BLELog.d(TAG, "onBatchScanResults:" + results.toString());
            for (ScanResult sr : results) {
                System.out.println("ScanResult - Results" + sr.toString());
                BluetoothDevice device = sr.getDevice();
                for (BluetoothDevice dev : mDevicelist) {
                    if (dev.getAddress().equals(device.getAddress()))
                        return;
                }
                mDevicelist.add(device);
                mAdapter.notifyDataSetChanged();

            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            BLELog.d(TAG, "Scan Failed Error Code: " + errorCode);
        }
    };


    private void handleConnect() {
        scanLeDevice(false);//Stop scanning
        Intent intent = new Intent(this, OTADFUActivity.class);
        intent.putExtra("Address", mSelectedDevice.getAddress());
        intent.putExtra("Name", mSelectedDevice.getName());
        startActivity(intent);
        mSelectedDevice = null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otadevice_scan);
        setTitle("OTA Devices");

        mHandler = new Handler();
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getApplicationContext().getSystemService(Context.BLUETOOTH_SERVICE);
        mBTAdapter = bluetoothManager.getAdapter();

        if (mBTAdapter == null) {
            Toast.makeText(getApplicationContext(), "Bluetooth Adapter is Null", Toast.LENGTH_SHORT).show();
            finish();
        }

        settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        filters = new ArrayList<>();
        mDevicelist = new ArrayList<>();

        ListView list = (ListView) findViewById(R.id.otadevices);
        mAdapter = new OTADeviceListAdapter(this, mDevicelist);
        list.setAdapter(mAdapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mSelectedDevice = mDevicelist.get(position);
                handleConnect();
            }
        });


        //Scan dialog
        mScanDialog = new ProgressDialog(this);
        mScanDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mScanDialog.setMessage(getString(R.string.scanning_dialog_message));
        mScanDialog.setIndeterminate(true);
        mScanDialog.setCancelable(true);
        mScanDialog.setCanceledOnTouchOutside(false);
        mScanDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mScanDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                scanLeDevice(false);
                mAdapter.notifyDataSetChanged();

            }
        });

        BLELog.d(TAG, "Scan LE device is calling here");
        //scanLeDevice(true);
    }


    @Override
    protected void onPause() {
        BLELog.d(TAG, "On Pause Called");
        scanLeDevice(false);
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        mDevicelist.clear();
        mAdapter.notifyDataSetChanged();

        try {
            Thread.sleep(1000);

        } catch (java.lang.InterruptedException e) {
            e.printStackTrace();
        }

        scanLeDevice(true);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_ota, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.scan_option:
                scanLeDevice(true);
                return (true);
        }
        return (super.onOptionsItemSelected(item));
    }

    private void dismissScanning() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mScanDialog != null && mScanDialog.isShowing()) {
                    mScanDialog.dismiss();
                }
            }
        });
    }

    private void displayScanning() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mScanDialog != null)
                    mScanDialog.show();
            }
        });
    }

    private void scanLeDevice(final boolean enable) {
        BLELog.d(TAG, "scanLeDevice");
        if (enable) {
            if (isScanning)
                return;
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    BLELog.d(TAG, "Scan finished");
                    isScanning = false;
                    stopScan(mScanCallback);
                    dismissScanning();
                }
            }, SCAN_PERIOD);
            if (!isScanning) {
                isScanning = true;
                BLELog.d(TAG, "Scan Started");
                displayScanning();
                startScan(filters, settings, mScanCallback);
            }
        } else {
            isScanning = false;
            stopScan(mScanCallback);
            mHandler.removeCallbacksAndMessages(null);
            dismissScanning();
        }

    }

    public void startScan(List<ScanFilter> filters, ScanSettings settings, ScanCallback clbk) {

        mBTAdapter.getBluetoothLeScanner().startScan(filters, settings, clbk);
    }

    public void stopScan(ScanCallback clbk) {

        mBTAdapter.getBluetoothLeScanner().stopScan(clbk);
    }


    public static class OTADeviceListAdapter extends BaseAdapter {

        private static LayoutInflater inflater = null;
        private Activity activity;
        private ArrayList<BluetoothDevice> data;

        public OTADeviceListAdapter(Activity a, ArrayList<BluetoothDevice> d) {
            activity = a;
            data = d;
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        public int getCount() {
            return data.size();
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            View vi = convertView;
            if (convertView == null)
                vi = inflater.inflate(android.R.layout.simple_list_item_2, null);

            TextView deviceName = (TextView) vi.findViewById(android.R.id.text1);
            TextView deviceMac = (TextView) vi.findViewById(android.R.id.text2);

            BluetoothDevice dev = data.get(position);

            // Setting all values in listview
            deviceName.setText(dev.getName());
            deviceMac.setText(dev.getAddress());
            return vi;
        }
    }
}
