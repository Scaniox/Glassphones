package com.app.microchip.wstearbuds.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.wstearbuds.managers.EarbudsTransparentServiceManager;

public class EarbudsEqualizerModesActivity extends AppCompatActivity {
    private static final String TAG = EarbudsEqualizerModesActivity.class.getSimpleName();
    private final static String UART_CMD_EQ_MODE_SETTING = "1C ";
    private final static String UART_CMD_MMI_ACTION_GET_EQ_MODE = "2 0 3F";
    private final static int UART_CURRENT_EQ_MODE_EVENT = 16;//0x10
    private final static int READ_EVT_BTM_STATUS = 1;
    private final static int AVC_VENDOR_DEPENDENT_RESPONSE = 26; //0x1A
    private final static int READ_LINK_STATUS_REPLAY = 30; //0x1E
    private final static String UART_CMD_READ_LINK_STATUS = "0D 0";
    private ListView lv;
    private EarbudsTransparentServiceManager mainActivity;
   // private Button manualSettingsBtn;

    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver eqmodeInfoReceiver;

    private int DELAY = 1500;
    private Handler mHandler;
    private ProgressDialog mUpdateStateDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earbuds_equalizer_modes);
        setTitle("Equalizer Settings");
        mainActivity = EarbudsTransparentServiceManager.getInstance();
        InitializeUI();
        transRxIntentFilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_DISCONNECTED);
        eqmodeInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                Message msg = Message.obtain();
                String action = intent.getAction();
                if (EarbudsTransparentServiceManager.BLE_DISCONNECTED.equals(action)) {
                    handleBLEDisconnection();
                }
                if (EarbudsTransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (EarbudsTransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(EarbudsTransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i;
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Received Data byte[" + i + "]=" + (rxBytes[i] & 0xff));

                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            switch (rxBytes[3] & 0xff) {
                                case UART_CURRENT_EQ_MODE_EVENT:
                                    BLELog.d(TAG, "Current EQ mode =" + (rxBytes[4] & 0xff));
                                    lv.setItemChecked(rxBytes[4] & 0xff, true);
                                    break;

                                case AVC_VENDOR_DEPENDENT_RESPONSE:
                                    BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE");
                                    if ((rxBytes[11] & 0xff) == 0x31 && (rxBytes[15] & 0xff) == 0x01) {
                                        switch (rxBytes[16] & 0xff) {
                                            case 0x00:
                                                BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE isA2dpPlaying = false");
                                                Toast.makeText(getApplicationContext(), "Stream BT Audio to use EQ",
                                                        Toast.LENGTH_LONG).show();
                                                finish();
                                                break;//STOPPED
                                            case 0x01:

                                                BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE isA2dpPlaying = true");
                                                break;// PLAYING
                                            case 0x02:

                                                BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE isA2dpPlaying = false");
                                                Toast.makeText(getApplicationContext(), "Stream BT Audio to use EQ",
                                                        Toast.LENGTH_LONG).show();
                                                finish();
                                                break;// PAUSED
                                            case 0x03:
                                                break;//FWD_SEEK
                                            case 0x04:
                                                break;//REV_SEEK
                                            case 0xFF:
                                                break;//ERROR
                                        }
                                    }
                                    break;

                                case READ_LINK_STATUS_REPLAY: {
                                    BLELog.d(TAG, "Reply for LINK STATUS" + (rxBytes[4] & 0xff) + "a2dp play status=" + (rxBytes[7] & 0xff));


                                    //Parse streaming status
                                    switch (rxBytes[7] & 0xff) {
                                        case 1: //playing
                                            break;
                                        default:
                                            BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE isA2dpPlaying = false");
                                            Toast.makeText(getApplicationContext(), "Stream BT Audio to use EQ",
                                                    Toast.LENGTH_LONG).show();
                                            finish();
                                            break;
                                    }
                                }
                                case READ_EVT_BTM_STATUS: {
                                    BLELog.d(TAG, "Event for BTM STATUS");
                                   /* if ((rxBytes[4] & 0xff) == 0x00) {
                                        BLELog.d(TAG, "Power OFF state");
                                        powerValue.setChecked(false);
                                        powerStateChanged(false);
                                    } else if ((rxBytes[4] & 0xff) == 0x02) {
                                        BLELog.d(TAG, "Power ON state");
                                        powerValue.setChecked(true);
                                        powerStateChanged(true);
                                    }*/

                                    switch (rxBytes[4] & 0xff) {
                                        case 0x01:
                                            BLELog.d(TAG, "Pairing state (discoverable mode)");

                                            break;
                                        case 0x03:
                                            BLELog.d(TAG, "Pairing successful");
                                            break;
                                        case 0x04:
                                            BLELog.d(TAG, "Pairing failed");
                                            break;
                                        case 0x05:
                                            BLELog.d(TAG, "HF/HS link established");
                                            break;
                                        case 0x06:
                                            BLELog.d(TAG, "A2DP link established");

                                            break;
                                        case 0x07:
                                            BLELog.d(TAG, "HF link disconnected");
                                            break;
                                        case 0x08:
                                            BLELog.d(TAG, "A2DP link disconnected");
                                            break;
                                        case 0x09:
                                            BLELog.d(TAG, "SCO link connected");
                                            finish();
                                            break;
                                        case 0x0A:
                                            BLELog.d(TAG, "SCO link disconnected");
                                            break;
                                        case 0x0B:
                                            BLELog.d(TAG, "AVRCP link established");
                                            break;
                                        case 0x0C:
                                            BLELog.d(TAG, "AVRCP link disconnected");
                                            break;
                                        case 0x0D:
                                            BLELog.d(TAG, "Standard SPP connected");
                                            break;
                                        case 0x0E:
                                            BLELog.d(TAG, "Standard_SPP / iAP disconnected");
                                            break;
                                        case 0x0F:
                                            BLELog.d(TAG, "Standby state");
                                            break;
                                        case 0x10:
                                            BLELog.d(TAG, "iAP connected");
                                            break;
                                        case 0x11:
                                            BLELog.d(TAG, "ACL disconnected");
                                            //onBackPressed();
                                            //dataBaseId = 0;
                                            break;
                                        case 0x12:
                                            BLELog.d(TAG, "MAP connected");
                                            break;
                                        case 0x13:
                                            BLELog.d(TAG, "MAP operation forbidden");
                                            break;
                                        case 0x14:
                                            BLELog.d(TAG, "MAP disconnected");
                                            break;
                                        case 0x15:
                                            BLELog.d(TAG, "ACL connected");
                                            BLELog.d(TAG, "ACL Received Data Hex="+ HexTool.byteArrayToHexString(rxBytes));
                                        {
                                            //dataBaseId = rxBytes[5]& 0xff;
                                        }

                                        break;
                                        case 0x80:
                                            BLELog.d(TAG, "AuxIn Not available");

                                            break;
                                        case 0x81:
                                            BLELog.d(TAG, "AuxIn plugged and Playing AuxIn");

                                            break;
                                        case 0x82:
                                            BLELog.d(TAG, "AuxIn plugged and playing A2DP");

                                            break;
                                        default:
                                            BLELog.d(TAG, "Wrong state");
                                            break;
                                    }

                                }
                                break;

                            }
                        }
                    }
                }
            }
        };
    }

    public void InitializeUI() {
        mHandler = new Handler();
        mUpdateStateDialog = new ProgressDialog(this);
        mUpdateStateDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mUpdateStateDialog.setMessage(getString(R.string.updating_message));
        mUpdateStateDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mUpdateStateDialog.setIndeterminate(true);
        mUpdateStateDialog.setCanceledOnTouchOutside(false);

        String[] modes = getResources().getStringArray(R.array.EqModes_nocustom);
        lv = (ListView) findViewById(R.id.eqModeslist);
        ArrayAdapter<String> ListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_checked, modes);
        lv.setAdapter(ListAdapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BLELog.d(TAG, "Clicked index=" + position);
                if (position < 11) {
                    sendCommand(UART_CMD_EQ_MODE_SETTING + position);
                    showProcessing();
                } /*else if (position == 10) {
                    //  sendCommand(UART_CMD_EQ_MODE_SETTING + "A");
                    //Intent newScreen = new Intent(getApplicationContext(), CustomEqSettingsActivity.class);
                   // startActivity(newScreen);
                }*/
            }
        });

        /*manualSettingsBtn = (Button) findViewById(R.id.manualeqMode);
        manualSettingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO new screen
                Intent newScreen = new Intent(getApplicationContext(), CustomEqSettingsActivity.class);
                startActivity(newScreen);
            }
        });*/
    }


    public void showProcessing() {
        if (mUpdateStateDialog != null)
            mUpdateStateDialog.show();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mUpdateStateDialog != null && mUpdateStateDialog.isShowing())
                    mUpdateStateDialog.dismiss();
            }
        }, DELAY);
    }

    public void sendCommand(String cmd) {
        if (mainActivity.isConnected() == false) {
            handleBLEDisconnection();
        }
        if (mainActivity != null) {
            mainActivity.packAndSendCommand(cmd);
        }
    }

    public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
            }
        });
        builder.show();
    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                Intent home = new Intent(getApplicationContext(), EarbudsControllerActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mainActivity.unregisterFragReceiver(eqmodeInfoReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        EarbudsControllerActivity.getInstance().setmIsWstAppForegroud(false);
        super.onPause();
    }

    @Override
    protected void onResume() {
        EarbudsControllerActivity.getInstance().setmIsWstAppForegroud(true);
        super.onResume();
        mainActivity.registerFragReceiver(eqmodeInfoReceiver, transRxIntentFilter);
        mainActivity.registerFragReceiver(eqmodeInfoReceiver, transReadyIntentFilter);
        mainActivity.registerFragReceiver(eqmodeInfoReceiver, disconnectionfilter);
        sendInitCommands();
    }

    public void sendInitCommands() {
        BLELog.d(TAG, "sendInitCommands called");
        sendCommand(UART_CMD_MMI_ACTION_GET_EQ_MODE);
        sendCommand(UART_CMD_READ_LINK_STATUS);

    }
}
