package com.app.microchip.audiowidget.ota;

import java.util.UUID;

public class BTUUID {
	public static UUID uuidFromString(String uString) {
		String temp = null; 
		if (uString.length() == 4) {
			temp = "0000"+uString+"-0000-1000-8000-00805f9b34fb";
		}
		else {
			temp = uString;
		}
		return UUID.fromString(temp);
	}
}
