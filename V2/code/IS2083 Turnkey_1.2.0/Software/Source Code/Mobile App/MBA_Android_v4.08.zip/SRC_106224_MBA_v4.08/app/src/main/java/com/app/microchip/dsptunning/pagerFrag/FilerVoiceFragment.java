package com.app.microchip.dsptunning.pagerFrag;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;
import com.app.microchip.dsptunning.ui.DspTuningVoicePagerActivity;

import java.util.Arrays;

/**
 * Created by I17163 on 12/12/2019.
 */

public class FilerVoiceFragment extends Fragment implements DSPTuningDelegate{

    private static final String TAG = FilerVoiceFragment.class.getSimpleName();

    private Spinner SPK_Filter;
    private Spinner MIC_Filter;
    private Button TuneDSP;
    TextView DSPState;
    private DspTuningVoicePagerActivity mActivity;
    private DspOTATunningBLEService mServie;
    private long fragFocusStartTime = 0;

    byte HPF_Data;
    byte HPF_Prev_Data;


    String[] filter_table = {"Cutoff Freq:50Hz", "Cutoff Freq:80Hz", "Cutoff Freq:120Hz",
            "Cutoff Freq:180Hz", "Cutoff Freq:210Hz", "Cutoff Freq:300Hz", "Cutoff Freq:400Hz"};
    byte[] filter_ids = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06};

    public FilerVoiceFragment() {
        Log.d(TAG, "Constructor");
    }

    DspTuningVoicePagerActivity activity;



    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.filter_voice_fragment, container, false);

        Log.d(TAG, "onCreateView");
        SPK_Filter = (Spinner)view.findViewById(R.id.Spinner3);
        MIC_Filter = (Spinner)view.findViewById(R.id.Spinner4);
        DSPState =(TextView) view.findViewById(R.id.deviceStatus);
        TuneDSP = (Button) view.findViewById(R.id.tuneDspButton);

        initUI();

        fragFocusStartTime = System.currentTimeMillis();

        return view;
                
    }

    private void initUI () {

        Log.d(TAG, "initUI");

        if ((DSPState!= null) )
            DSPState.setText(mServie.DSP_DUT_State);

        if (mServie == null)
            return;

        if (getActivity() == null)
            return;

        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, filter_table);


        SPK_Filter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos,long id) {

                long fragFocusEndTime =  System.currentTimeMillis();

                long fragAutoEventTimeElapsed = fragFocusEndTime - fragFocusStartTime ;

                Log.d(TAG,"SPK_Filter fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

                if (fragAutoEventTimeElapsed > 2000) {
                    enableTuneDspButton();
                }

               // byte data1 = (byte) 0xF0;
                //byte data2 = (byte) (pos << 4);
                HPF_Data &= ~(0xF0);
                HPF_Data |= (byte)(pos << 4) ;
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SPK_Filter.setAdapter(adapter);
        //LineIn_Threshold.setSelection(0);



        ArrayAdapter<String> adapter1;
        adapter1 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, filter_table);

        MIC_Filter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos,long id) {
                long fragFocusEndTime =  System.currentTimeMillis();

                long fragAutoEventTimeElapsed = fragFocusEndTime - fragFocusStartTime ;

                Log.d(TAG,"MIC_Filter fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

                if (fragAutoEventTimeElapsed > 2000) {
                    enableTuneDspButton();
                }

                HPF_Data &= ~(0x0F);
                HPF_Data |= (byte)(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        MIC_Filter.setAdapter(adapter1);


        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DSPTuning();
            }
        });


        Filter_Init(false);

        disableTuneDspButton();
        updateFunctionButtonsState();


    }


    private void  enableTuneDspButton() {
        TuneDSP.setEnabled(true);
        TuneDSP.setTextColor(Color.WHITE);
    }

    private void  disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }

    private synchronized void updateFunctionButtonsState () {

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                if(mServie.dynamicToolMode == mServie.TuneDSPMode_NotSupport || mServie.dynamicToolMode == mServie.TuneDSPMode_Audio){
                    SPK_Filter.setEnabled(false);
                    MIC_Filter.setEnabled(false);
                    disableTuneDspButton();
                }
                else if(mServie.dynamicToolMode == mServie.TuneDSPMode_Voice){
                    SPK_Filter.setEnabled(true) ;
                    MIC_Filter.setEnabled(true);
                }

            }

        }));

    }

    private void DSPTuning() {
        byte[] tuneData = new byte[1];
        tuneData[0]= HPF_Data;

        mServie.DSPTuning((byte) 0x0D, (byte) 0x09, (byte) 0x01, tuneData);
        mActivity.showSpinnerDialog(true);

    }




    public void initModule(DspTuningVoicePagerActivity act) {
        mActivity = act;

        mServie = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        mServie.setListener(FilerVoiceFragment.this);


        if (mServie.ConnectService == false){
            mActivity.showSpinnerDialog(false);
            mServie.GetCapability();
        }else {
            mServie.Get_Voice_DSP_Setting_Filter();

           mServie.Read_Module_Audio_MCU();

           fragFocusStartTime = System.currentTimeMillis();


        }

        initUI();


    }

    public void cleanModule() {

    }
    private byte SPK_MASK_BYT = (byte) 0xf0;
    private byte MIC_MASK_BYT = (byte) 0x0f;

    private int spkSlectIndex = 0;
    private int micSlectIndex = 0;

    void Filter_Init(boolean isReset){


        byte spk_hpf =  (byte) ((HPF_Data & SPK_MASK_BYT) >> 4);
        byte mic_hpf =  (byte) (HPF_Data & MIC_MASK_BYT);

        //print("spk_hpf = \(spk_hpf),mic_hpf = \(mic_hpf)")

        //SPK_Filter.selectedIndex = Int(spk_hpf)
        //MIC_Filter.selectedIndex = Int(mic_hpf)
        spkSlectIndex = (int) spk_hpf;
        micSlectIndex = (int) mic_hpf;
        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                SPK_Filter.setSelection(spkSlectIndex);
                MIC_Filter.setSelection(micSlectIndex);
                Log.d(TAG,"spkSlectIndex"+ spkSlectIndex+  "micSlectIndex="+ micSlectIndex);


            }
        }));


        //MIC_Filter.selectedIndex = Int(mic_hpf)

    }


    @Override
    public void onAttach(Context context) {
        BLELog.d(TAG, " onAttach");
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        BLELog.d(TAG, " onDetach");
        super.onDetach();
    }

    @Override
    public void BLE_ServiceReady() {



        mServie.Read_Module_Audio_MCU();

        mServie.Get_Voice_DSP_Setting_Filter();


    }

    @Override
    public void RefreshModuleData() {
        mActivity.dismissSpinnerDialog();
        fragFocusStartTime = System.currentTimeMillis();

    }

    @Override
    public void RefreshParametersData(byte[] Data) {
        int k = 0;
        byte[] buffer = Data;


        Log.d(TAG,"Parsing configuration data");

        while(k < buffer.length){
            byte len = buffer[k+2];

            //byte[] param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            byte[] param_dat = Arrays.copyOfRange(buffer, k+3, buffer.length );;
            //Log.d(TAG,"Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")

            if(buffer[k] == 13 && buffer[k+1] == 9){
                if(buffer[k+2] == 1){
                    HPF_Data = buffer[k+3];
                    HPF_Prev_Data = HPF_Data;
                    BLELog.d(TAG, "HPF data ="+ String.format("%02x", HPF_Data));
                    Filter_Init(false);
                    break;
                }
            }

            k += (int)(3+len);
        }

        updateFunctionButtonsState();

        Log.d(TAG, "LineInAudioFragment RefreshParametersData");
    }
    private String  dspStatusMsgDialog= "";

    private void showTuneDspDialog(String message) {

        dspStatusMsgDialog = message;

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder ad = new AlertDialog.Builder(getActivity() , R.style.MyDialogTheme);
                ad.setMessage(dspStatusMsgDialog);

                ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
                sendBroadcast(i);
                  mOtaState.setText("Completed");*/
                    }
                });

                final AlertDialog  alert = ad.create();
                alert.setTitle("Tune DSP Status!!");
                alert.show();



                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {

                    }
                });

            }
        }));


    }
    @Override
    public void DSPTuningComplete(byte result) {
        String  status = "";

        mActivity.dismissSpinnerDialog();

        if(result == 0x01){
            status = "Success";
        }
        else{
            status = "Failed " + result;
        }

        showTuneDspDialog(status);

        if(result != 0x01){
            HPF_Data = HPF_Prev_Data;
            Filter_Init(true);
        }

        getActivity().runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                disableTuneDspButton();

            }
        }));


    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {
        Log.d(TAG, " DSPTuningState" + state);
        if (DSPState!= null)
            DSPState.setText(state);

        updateFunctionButtonsState();

    }

    @Override
    public void ExportDSPTuningResult() {

    }
}
