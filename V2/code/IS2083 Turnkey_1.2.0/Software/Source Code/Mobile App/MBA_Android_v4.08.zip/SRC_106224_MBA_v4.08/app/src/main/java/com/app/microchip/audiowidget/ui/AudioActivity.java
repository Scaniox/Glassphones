package com.app.microchip.audiowidget.ui;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.managers.TransparentServiceManager;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;


public class AudioActivity extends AppCompatActivity {
    private static final String TAG = AudioActivity.class.getSimpleName();
    /*5506 Command*/
    private final static String UART_CMD_MMI_ACTION_FAST_PAIR = "2 0 5D";
    private final static String UART_CMD_MMI_ACTION_EXIT_PAIR = "2 0 6B";

    private final static String UART_CMD_MMI_ACTION_PLAY_PAUSE = "2 0 32";
    private final static String UART_CMD_MMI_ACTION_VOL_UP = "2 0 30";
    private final static String UART_CMD_MMI_ACTION_STOP = "2 0 33";
    private final static String UART_CMD_MMI_ACTION_FWD = "2 0 34";
    private final static String UART_CMD_MMI_ACTION_BWD = "2 0 35";
    private final static String UART_CMD_MMI_ACTION_VOL_DN = "2 0 31";
    private final static String UART_CMD_READ_A2DP_NAME = "16 0 0";
    private final static String UART_CMD_READ_A2DP_NAME_PRE = "16 ";
    private final static String UART_CMD_READ_A2DP_NAME_SUF = " 0";
    private final static String UART_CMD_DISCONNECT_A2DP = "18 7";
    private final static String UART_CMD_READ_LINK_STATUS = "0D 0";


    private final static String UART_CMD_AUDIO_SYNC = "2 0 F7";

    private final static String UART_CMD_GET_AUXIN_STATUS = "CC 0 0";
    private final static String UART_CMD_GET_AUXIN_A2DP_TOGGLE = "CC 1 2";

    /* 5506 Reply event*/
    private final static int READ_EVT_BTM_STATUS = 1;
    private final static int READ_EVT_LINKED_DEV_INFO = 23;
    private final static int COMMAND_ACK_EVENT = 0;//0x00
    private final static int READ_LINK_STATUS_REPLAY = 30; //0x1E
    private final static int UART_BTM_UTILITY_REQUEST_EVENT = 27; //0x1B
    private final static int SPEAKER_AUDIO_A2DP_DISCONNECTED = 0;
    private final static int SPEAKER_AUDIO_A2DP_CONNECTED = 1;
    private final static int AVC_VENDOR_DEPENDENT_RESPONSE = 26; //0x1A

    private final static int SOURCE_BT_AUDIO = 1;
    private final static int SOURCE_AUX_IN = 2;

    private ImageView playPauseBtn;
    private ImageView nextBtn;
    private ImageView prevBtn;
    private ImageView volupBtn;
    private ImageView voldownBtn;
    private ImageView stopBtn;
    private Button sourceToggleBtn;

    // private TextView name;
    private TextView changePairingStatus;
    private TextView connStatus;
    private TextView changeConnStatus;
    private TextView editEqSettings;
    private TextView pairinglabel;
    private TextView sourceValue;

    private RelativeLayout pairRow;
    private RelativeLayout connRow;
    private RelativeLayout eqRow;
    private RelativeLayout a2dpcontrols;

    private Button audiosyncBtn;

    private BLESpeaker mSpeaker;
    private TransparentServiceManager mainActivity;
    private boolean mPlaying = false;
    private int playingSource = SOURCE_BT_AUDIO;
    private  int dataBaseId = 0x00;

    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver audioInfoReceiver;
    private String a2dpName = "";
    private int a2dpStatus = -1;
    private boolean mBisPaired = false;

    private BluetoothManager bluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio);
        BLELog.d(TAG, "onCreate called");

        Intent intent = getIntent();
        String deviceId = intent.getStringExtra(Constants.DEVICE_ID);
        BLELog.d(TAG, "Device ID of selected speaker =" + deviceId);
        mSpeaker = HomeScreenActivity.getInstance().getSpeaker(deviceId);
        setTitle(mSpeaker.getName() + " Audio Control");


        bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        initializeUI();

        mainActivity = TransparentServiceManager.getInstance();
        transRxIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(TransparentServiceManager.BLE_DISCONNECTED);
        audioInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                Message msg = Message.obtain();
                String action = intent.getAction();
                if (TransparentServiceManager.BLE_DISCONNECTED.equals(action)) {
                    handleBLEDisconnection();
                }
                if (TransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (TransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(TransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i, byte_cnt;
                        String displayString = "";
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Received Data byte[" + i + "]=" + (rxBytes[i] & 0xff));

                        BLELog.d(TAG, "Received Data Hex="+ HexTool.byteArrayToHexString(rxBytes));

                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            byte_cnt = rxBytes[2] & 0xff;
                            switch (rxBytes[3] & 0xff) {
                                case COMMAND_ACK_EVENT:
                                    String returnValue = "";
                                    switch (rxBytes[5] & 0xff) {
                                        case 0:
                                            returnValue = "Command complete";
                                            break;
                                        case 1:
                                            returnValue = "Command dissallow";
                                            break;
                                        case 2:
                                            returnValue = "Unknown command";
                                            break;
                                        case 3:
                                            returnValue = "Parameters error";
                                            break;
                                        case 4:
                                            returnValue = "BTM is busy";
                                            break;
                                        case 5:
                                            returnValue = "BTM memory is full";
                                            break;
                                        default:
                                            returnValue = "unknown return value";
                                    }
                                    BLELog.d(TAG, "ACK for Command = " + (rxBytes[4] & 0xff) + "  ACK Return value =" + returnValue);
                                    if ((rxBytes[5] & 0xff) != 0) {
                                        commandError(returnValue + " For Command:" + (rxBytes[4] & 0xff));
                                    }
                                    break;
                                case READ_LINK_STATUS_REPLAY: {
                                    BLELog.d(TAG, "Reply for LINK STATUS");
                                    //Parse streaming status
                                    switch (rxBytes[7] & 0xff) {
                                        case 1: //playing
                                            playPauseBtn.setImageDrawable(getResources().getDrawable(R.drawable.pausebtn));
                                            playPauseBtn.setContentDescription("playing");
                                            mPlaying = true;
                                            break;
                                        default:
                                            playPauseBtn.setImageDrawable(getResources().getDrawable(R.drawable.playbtn));
                                            playPauseBtn.setContentDescription("paused");
                                            mPlaying = false;
                                            break;
                                    }
                                    //Parse other status
                                    switch (rxBytes[4] & 0xff) {
                                        case 1:
                                            changePairingStatus.setText("Exit");
                                            mBisPaired = true;
                                            break;
                                        case 2:
                                            a2dpName = "";
                                            setA2dpStatusRelated(SPEAKER_AUDIO_A2DP_DISCONNECTED);
                                            break;
                                        case 4:
                                        case 6:
                                            if (a2dpStatus == SPEAKER_AUDIO_A2DP_DISCONNECTED) {
                                                //sendCommand(UART_CMD_READ_A2DP_NAME);
                                               sendCommand(UART_CMD_READ_A2DP_NAME_PRE +
                                                       dataBaseId +
                                                         UART_CMD_READ_A2DP_NAME_SUF);
                                            }
                                            break;
                                        case 3:
                                            break;
                                        case 5:
                                            break;
                                    }
                                    if ((rxBytes[4] & 0xff) != 0x01) {
                                        changePairingStatus.setText("Enter");
                                        mBisPaired = false;
                                    }
                                    if ((rxBytes[9] & 0xff) == 0x01)
                                        BLELog.d(TAG, "Streaming is on");
                                    else
                                        BLELog.d(TAG, "Streaming is off");
                                }
                                break;
                                case READ_EVT_BTM_STATUS: {
                                    BLELog.d(TAG, "Event for BTM STATUS");

                                    if ((rxBytes[4] & 0xff) == 0) {
                                        BLELog.d(TAG, "Power OFF state");
                                        finish();
                                        return;
                                    } else {
                                        BLELog.d(TAG, "Power ON state");
                                    }

                                    switch (rxBytes[4] & 0xff) {
                                        case 0x01:
                                            BLELog.d(TAG, "Pairing state (discoverable mode)");
                                            changePairingStatus.setText("Exit");
                                            mBisPaired = true;
                                            break;
                                        case 0x03:
                                            BLELog.d(TAG, "Pairing successful");
                                            break;
                                        case 0x04:
                                            BLELog.d(TAG, "Pairing failed");
                                            break;
                                        case 0x05:
                                            BLELog.d(TAG, "HF/HS link established");
                                            break;
                                        case 0x06:
                                            BLELog.d(TAG, "A2DP link established");
                                            //sendCommand(UART_CMD_READ_A2DP_NAME);
                                            sendCommand(UART_CMD_READ_A2DP_NAME_PRE +
                                                    dataBaseId +
                                                    UART_CMD_READ_A2DP_NAME_SUF);
                                            break;
                                        case 0x07:
                                            BLELog.d(TAG, "HF link disconnected");
                                            break;
                                        case 0x08:
                                            BLELog.d(TAG, "A2DP link disconnected");
                                            a2dpName = "";
                                            setA2dpStatusRelated(SPEAKER_AUDIO_A2DP_DISCONNECTED);
                                            break;
                                        case 0x09:
                                            BLELog.d(TAG, "SCO link connected");
                                            break;
                                        case 0x0A:
                                            BLELog.d(TAG, "SCO link disconnected");
                                            break;
                                        case 0x0B:
                                            BLELog.d(TAG, "AVRCP link established");
                                            break;
                                        case 0x0C:
                                            BLELog.d(TAG, "AVRCP link disconnected");
                                            break;
                                        case 0x0D:
                                            BLELog.d(TAG, "Standard SPP connected");
                                            break;
                                        case 0x0E:
                                            BLELog.d(TAG, "Standard_SPP / iAP disconnected");
                                            break;
                                        case 0x0F:
                                            BLELog.d(TAG, "Standby state");
                                            a2dpName = "";
                                            setA2dpStatusRelated(SPEAKER_AUDIO_A2DP_DISCONNECTED);
                                            break;
                                        case 0x10:
                                            BLELog.d(TAG, "iAP connected");
                                            break;
                                        case 0x11:
                                            BLELog.d(TAG, "ACL disconnected");
                                            dataBaseId = 0;
                                            break;
                                        case 0x12:
                                            BLELog.d(TAG, "MAP connected");
                                            break;
                                        case 0x13:
                                            BLELog.d(TAG, "MAP operation forbidden");
                                            break;
                                        case 0x14:
                                            BLELog.d(TAG, "MAP disconnected");
                                            break;
                                        case 0x15:
                                            BLELog.d(TAG, "ACL connected");
                                            BLELog.d(TAG, "ACL Received Data Hex="+ HexTool.byteArrayToHexString(rxBytes));
                                            {
                                                dataBaseId = rxBytes[5]& 0xff;
                                            }

                                            break;
                                        case 0x80:
                                            BLELog.d(TAG, "AuxIn Not available");
                                            sourceValue.setText("BT Audio");
                                            playingSource = SOURCE_BT_AUDIO;
                                            if (a2dpStatus == SPEAKER_AUDIO_A2DP_CONNECTED) {
                                                a2dpcontrols.setVisibility(View.VISIBLE);
                                            } else {
                                                a2dpcontrols.setVisibility(View.INVISIBLE);
                                            }
                                            break;
                                        case 0x81:
                                            BLELog.d(TAG, "AuxIn plugged and Playing AuxIn");
                                            playingSource = SOURCE_AUX_IN;
                                            sourceValue.setText("Aux-In");
                                            a2dpcontrols.setVisibility(View.INVISIBLE);
                                            break;
                                        case 0x82:
                                            BLELog.d(TAG, "AuxIn plugged and playing A2DP");
                                            sourceValue.setText("BT Audio");
                                            playingSource = SOURCE_BT_AUDIO;
                                            if (a2dpStatus == SPEAKER_AUDIO_A2DP_CONNECTED) {
                                                a2dpcontrols.setVisibility(View.VISIBLE);
                                            } else {
                                                a2dpcontrols.setVisibility(View.INVISIBLE);
                                            }
                                            break;
                                        default:
                                            BLELog.d(TAG, "Wrong state");
                                            break;
                                    }
                                    if ((rxBytes[4] & 0xff) != 0x01) {
                                        changePairingStatus.setText("Enter");
                                        mBisPaired = false;
                                    }
                                }
                                break;
                                case READ_EVT_LINKED_DEV_INFO: {
                                    BLELog.d(TAG, "READ_EVT_LINKED_DEV_INFO");
                                    if (rxBytes[4] == 0 && rxBytes[5] == 0) {
                                        a2dpName = "";
                                        for (i = 0; i < byte_cnt - 4; i++)
                                            a2dpName += String.valueOf((char) rxBytes[i + 6]);
                                        setA2dpStatusRelated(SPEAKER_AUDIO_A2DP_CONNECTED);
                                    }
                                }
                                break;
                                case AVC_VENDOR_DEPENDENT_RESPONSE:
                                    BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE");
                                    if ((rxBytes[11] & 0xff) == 0x31 && (rxBytes[15] & 0xff) == 0x01) {
                                        switch (rxBytes[16] & 0xff) {
                                            case 0x00:
                                                playPauseBtn.setImageDrawable(getResources().getDrawable(R.drawable.playbtn));
                                                playPauseBtn.setContentDescription("paused");
                                                mPlaying = false;
                                                break;//STOPPED
                                            case 0x01:
                                                playPauseBtn.setImageDrawable(getResources().getDrawable(R.drawable.pausebtn));
                                                playPauseBtn.setContentDescription("playing");
                                                mPlaying = true;
                                                break;// PLAYING
                                            case 0x02:
                                                playPauseBtn.setImageDrawable(getResources().getDrawable(R.drawable.playbtn));
                                                playPauseBtn.setContentDescription("paused");
                                                mPlaying = false;
                                                break;// PAUSED
                                            case 0x03:
                                                break;//FWD_SEEK
                                            case 0x04:
                                                break;//REV_SEEK
                                            case 0xFF:
                                                break;//ERROR
                                        }
                                    }
                                    break;
                            }
                        }
                    }
                }
            }
        }

        ;

        setA2dpStatusRelated(SPEAKER_AUDIO_A2DP_DISCONNECTED);

    }

    public void initializeUI() {
        BLELog.d(TAG, "initializeUI called");
        playPauseBtn = (ImageView) findViewById(R.id.playBtn);
        nextBtn = (ImageView) findViewById(R.id.nextBtn);
        prevBtn = (ImageView) findViewById(R.id.prevBtn);
        volupBtn = (ImageView) findViewById(R.id.volupBtn);
        voldownBtn = (ImageView) findViewById(R.id.voldownBtn);
        stopBtn = (ImageView) findViewById(R.id.stopBtn);
        sourceToggleBtn = (Button) findViewById(R.id.togglesourcebutton);

        changePairingStatus = (TextView) findViewById(R.id.changepairingstatus);
        connStatus = (TextView) findViewById(R.id.connectionstatus);
        changeConnStatus = (TextView) findViewById(R.id.changeconnstatus);
        editEqSettings = (TextView) findViewById(R.id.editeqsettings);
        pairinglabel = (TextView) findViewById(R.id.pairinglabel);
        audiosyncBtn = (Button) findViewById(R.id.audiosyncbtn);
        sourceValue = (TextView) findViewById(R.id.sourcevalue);


        sourceToggleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand(UART_CMD_GET_AUXIN_A2DP_TOGGLE);
            }
        });
        audiosyncBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand(UART_CMD_AUDIO_SYNC);
            }
        });


        pairRow = (RelativeLayout) findViewById(R.id.pairrow);
        connRow = (RelativeLayout) findViewById(R.id.connrow);
        eqRow = (RelativeLayout) findViewById(R.id.eqrow);
        a2dpcontrols = (RelativeLayout) findViewById(R.id.a2dpControls);

        if (mSpeaker.getGroupStatus() == Constants.UNGROUPED_VALUE)
            audiosyncBtn.setVisibility(View.INVISIBLE);
        else
            audiosyncBtn.setVisibility(View.VISIBLE);


        connRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BLELog.d("TAG", "A2dp connection clicked");
                if (a2dpStatus == SPEAKER_AUDIO_A2DP_DISCONNECTED) {
                    Intent intentOpenBluetoothSettings = new Intent();
                    intentOpenBluetoothSettings.setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                    startActivity(intentOpenBluetoothSettings);
                } else {
                    sendCommand(UART_CMD_DISCONNECT_A2DP);
                }
            }
        });

        eqRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent eqScreen = new Intent(getApplicationContext(), EqualizerModesActivity.class);
                startActivity(eqScreen);
            }
        });

        pairRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBisPaired)
                    sendCommand(UART_CMD_MMI_ACTION_EXIT_PAIR);
                else
                    sendCommand(UART_CMD_MMI_ACTION_FAST_PAIR);

            }
        });

        playPauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand(UART_CMD_MMI_ACTION_PLAY_PAUSE);
            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand(UART_CMD_MMI_ACTION_FWD);

            }
        });

        prevBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand(UART_CMD_MMI_ACTION_BWD);
            }
        });

        volupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand(UART_CMD_MMI_ACTION_VOL_UP);
            }
        });

        voldownBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand(UART_CMD_MMI_ACTION_VOL_DN);
            }
        });

        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand(UART_CMD_MMI_ACTION_STOP);
            }
        });
    }


    public void sendInitCommands() {
        BLELog.d(TAG, "sendInitCommands called");
        sendCommand(UART_CMD_GET_AUXIN_STATUS);
        sendCommand(UART_CMD_READ_LINK_STATUS);
    }

    public void sendCommand(String cmd) {
        BLELog.d(TAG, "sendCommand called cmd =" + cmd);
        if (mainActivity.isConnected() == false) {
            handleBLEDisconnection();
        }
        if (mainActivity != null) {
            mainActivity.packAndSendCommand(cmd);
        }
    }

    public void onStart() {
        BLELog.d(TAG, "onStart called");
        super.onStart();
    }

    public void onResume() {
        BLELog.d(TAG, "onResume called");
        super.onResume();
        mainActivity.registerFragReceiver(audioInfoReceiver, transRxIntentFilter);
        mainActivity.registerFragReceiver(audioInfoReceiver, transReadyIntentFilter);
        mainActivity.registerFragReceiver(audioInfoReceiver, disconnectionfilter);
        sendInitCommands();
    }

    public void setA2dpStatusRelated(int status) {
        BLELog.d(TAG, "setA2dpStatusRelated called = " + status);
        String index = "", value = "";
        if (status == a2dpStatus)
            return;
        switch (status) {
            case SPEAKER_AUDIO_A2DP_CONNECTED:
                a2dpStatus = SPEAKER_AUDIO_A2DP_CONNECTED;
                BLELog.d(TAG, "A2DP Name  " + a2dpName);
                connStatus.setText(a2dpName);
                changeConnStatus.setText("Disconnect");
                if (playingSource == SOURCE_BT_AUDIO)
                    a2dpcontrols.setVisibility(View.VISIBLE);
                break;
            case SPEAKER_AUDIO_A2DP_DISCONNECTED:
                a2dpStatus = SPEAKER_AUDIO_A2DP_DISCONNECTED;
                connStatus.setText("Not Connected");
                changeConnStatus.setText("Connect");
                mPlaying = false;
                a2dpcontrols.setVisibility(View.INVISIBLE);
                playPauseBtn.setImageDrawable(getResources().getDrawable(R.drawable.playbtn));
                playPauseBtn.setContentDescription("paused");
                break;
        }
    }

    public void onStop() {
        BLELog.d(TAG, "onStop called");
        super.onStop();
        BLELog.d(TAG, "Fragment Speaker Audio STOP");

        mainActivity.unregisterFragReceiver(audioInfoReceiver);
    }

    public void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        super.onDestroy();
    }

    private void commandError(final String message) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), message,
                        Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                Intent home = new Intent(getApplicationContext(), HomeScreenActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);
            }
        });
    }

    public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
            }
        });
        builder.show();
    }


}
