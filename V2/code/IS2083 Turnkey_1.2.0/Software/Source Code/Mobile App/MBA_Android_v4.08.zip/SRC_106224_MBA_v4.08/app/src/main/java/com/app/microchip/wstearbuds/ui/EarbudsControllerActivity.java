package com.app.microchip.wstearbuds.ui;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;
import com.app.microchip.wstearbuds.managers.EarbudsBLEManager;
import com.app.microchip.wstearbuds.managers.EarbudsTransparentServiceManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


public class EarbudsControllerActivity extends AppCompatActivity {

    private final static String UART_CMD_MMI_ACTION_POWER_ON_PRESSED = "2 0 51";
    private final static String UART_CMD_MMI_ACTION_POWER_ON_RELEASED = "2 0 52";
    private final static String UART_CMD_MMI_ACTION_POWER_OFF_PRESSED = "2 0 53";
    private final static String UART_CMD_MMI_ACTION_POWER_OFF_RELEASED = "2 0 54";
    private final static int COMMAND_ACK_EVENT = 0;//0x00
    private final static int READ_EVT_BTM_STATUS = 1;
    private final static int READ_LINK_STATUS_REPLAY = 30; //0x1E
    private final static int AVC_VENDOR_DEPENDENT_RESPONSE = 26; //0x1A

    private final static int UART_CMD_WST_GET_STATUS_RSP_EVT = 51; //0x33
    private final static int UART_CMD_WST_GET_EB_POS_STATUS_RSP_EVT = 87; //0x57
    private final static int UART_CMD_WST_GET_PRIM_BATT_INFO_RSP_EVT = 12; //0x0C
    private final static int UART_CMD_WST_GET_SECD_BATT_INFO_RSP_EVT = 88; //0x58

    private final static String UART_CMD_READ_LINK_STATUS = "0D 0";

    private final static String UART_CMD_WST_GET_STATUS = "2B 00";
    private final static String UART_CMD_WST_GET_EB_POS_STATUS = "40 03" ;

    private final static String UART_CMD_WST_GET_PRIM_BATT_INFO = "25 00";
    private final static String UART_CMD_WST_GET_SECD_BATT_INFO = "40 04";

    private final static String UART_CMD_DISCONNECT = "32 0 0";
    private static final String TAG = EarbudsControllerActivity.class.getSimpleName();
    private BLESpeaker mSpeaker;
    private EarBudsInfo earBudsInfo;
    private EarbudsBLEManager mBleManager = null;
    //private ArrayList<BLESpeaker> currentList;
  //  private EarbudsSpeakerControlAdapter adapter;
    //private ListView list;
    public static String mDevId = "";
  //  private Switch powerValue;
    private EarbudsTransparentServiceManager mTraspService;
    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver speakerInfoReceiver;
    private File mTempLogFile;
    private boolean mBackPressed = false;
    private boolean mBackPressedImmitate = false;
    private ProgressDialog mDisConnectDialog;
    private Timer progressBarCancelTimer;

    private boolean mAskedForUserPairing = false;

    private int a2dpStatus =  -1;
    private final static int SPEAKER_AUDIO_A2DP_DISCONNECTED = 0;
    private final static int SPEAKER_AUDIO_A2DP_CONNECTED = 1;

    private void dismissDisConnect() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mDisConnectDialog != null && mDisConnectDialog.isShowing()) {
                    mDisConnectDialog.dismiss();
                }
            }
        });
    }

    private void displayDisConnecting() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mDisConnectDialog != null)
                    mDisConnectDialog.show();
            }
        });
    }


    public static void setViewGroupEnabled(ViewGroup view, boolean enabled) {
        int childern = view.getChildCount();

        for (int i = 0; i < childern; i++) {
            View child = view.getChildAt(i);
            if (child instanceof ViewGroup) {
                setViewGroupEnabled((ViewGroup) child, enabled);
            }
            child.setEnabled(enabled);
        }
        view.setEnabled(enabled);
    }

    private static EarbudsControllerActivity INSTANCE = null;

    public BLESpeaker getSpeaker() {
        return  mSpeaker;
    }

    public  void setSpeaker(BLESpeaker speaker) {
          mSpeaker = speaker;
          mIsAddNewEarbudAdded = true;
          mDevId = mSpeaker.getDeviceId();
    }

    public void clearEarpdodStatusData () {
        earBudsInfo = new EarBudsInfo();

        if (!isTryRetryOnce)
            clearRecentConnetionInfo();

    }

    public void clearRecentConnetionInfo () {
        mDevId = null;
        mSpeaker = null;
        mRecentBtAddress = "";
        mAskedForUserPairing = false;
        isBleConnected = false;
        connRetryCount = 0;

    }

    public void  updateSpeakerName(String deviceName) {
          mSpeaker.setName(deviceName);
    }
    public static synchronized EarbudsControllerActivity getInstance() {
        return INSTANCE;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earbuds_controller);

        INSTANCE = this;

        clearEarpdodStatusData();

        if(isScoActive()) {
            Toast.makeText(getApplicationContext(), "App cannot be launched during BT Call, as it will may affect audio quality ",
                    Toast.LENGTH_LONG).show();
            finish();
        }

        mHandler = new Handler();

        mBleManager = EarbudsBLEManager.getBLEManager(this);

        mRecentBtAddress = getRecentConnectedDeviceAddress();

        InitializeUI();

        if(mRecentBtAddress.equals("")) {

            isReconnection = false;

        } else {
            BLELog.d(TAG, "Device ID of Scaning speaker =" + mDevId);
            mDevId = mRecentBtAddress;
            isReconnection = true;

            displayScanning();
            scanLeDevice(true);

        }

    }

    synchronized public  void  checkAndReconnectDeviceAfterSco () {



        BLELog.d(TAG, "Call ended link disconnected");

        earBudsInfo.isSCOConnected = false;

        if (isSetScoReconnnectMode && isWstAppForegroud()) {

            mRecentBtAddress = getRecentConnectedDeviceAddress();

            mDevId = mRecentBtAddress;

            BLELog.d(TAG, "reconnectDeviceAfterSco =" + mDevId + "isScanning="+ isScanning);

            isReconnection = true;

            displayScanning();
            scanLeDevice(true);

            isSetScoReconnnectMode = false;
        }

    }

    private boolean isScoActive() {

        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        BLELog.d(TAG, "isBluetoothScoOn =" + audioManager.isBluetoothScoOn());

        return  audioManager.isBluetoothScoOn();
    }

    private void commandError(final String message) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), message,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onPause() {
        BLELog.d(TAG, "onPause called");

        if (isScanning) {
            // Stop scan
           //scanLeDevice(false);
        }

        mHandler.removeCallbacksAndMessages(null);

       // if(mBackPressed){
            //mTraspService.cleanupTransparentService();
            //mBleManager.disconnect(mSpeaker.getBtDevice());
            //mBleManager.closeGatt(mSpeaker.getBtDevice());
       // }
        //mTraspService.unregisterFragReceiver(speakerInfoReceiver);
        setmIsWstAppForegroud(false);
        super.onPause();
    }

    @Override
    protected void onResume() {
        BLELog.d(TAG, "onResume called" + "isScanning="+ isScanning+ " isSetScoReconnnectMode"+ isSetScoReconnnectMode);
        setmIsWstAppForegroud(true);
        super.onResume();

        if(isSetScoReconnnectMode) {
            try {
                Thread.sleep(500);

            } catch (java.lang.InterruptedException e) {
                e.printStackTrace();
            }
        }


        if(isScoActive() ) {

            Toast.makeText(getApplicationContext(), "App cannot be used during BT Call, as it will may affect audio quality ",
                    Toast.LENGTH_LONG).show();
        } else if(isSetScoReconnnectMode) {
            checkAndReconnectDeviceAfterSco();

        } else{


            if (mIsAddNewEarbudAdded && (mSpeaker != null)) {
                initiateConnect(true);
                mIsAddNewEarbudAdded = false;
            } else if ((mSpeaker == null) && (isReconnection == false)) {
//            /showNoConnnectedDeviceAlertDialog();
                BLELog.d(TAG, "No earbuds connected ");
            }

            updateEarbudStatusUI();

            // if( (mTraspService != null) && (true == isBleConnected))
            if ((mTraspService != null) && (mTraspService.isTransSupported() == true) && (true == isBleConnected))
                sendInitCommands();
        }


    }

    @Override
    protected void onStart() {
        BLELog.d(TAG, "onStart called");
        super.onStart();
    }

    @Override
    protected void onStop() {
        BLELog.d(TAG, "onStop called");
        super.onStop();
    }

    protected void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        super.onDestroy();

        mConectTimeoutHandler.removeCallbacksAndMessages(null);

        clearEarpdodStatusData();

        if (mTraspService != null) {
            mTraspService.unregisterFragReceiver(speakerInfoReceiver);

            mTraspService.cleanupTransparentService();
            if (mTempLogFile.exists())
                mTempLogFile.delete();
        }

        if (mBleManager != null) {
            mBleManager.removeListener(gattCallback);
            mBleManager.cleanup();
        }

        INSTANCE = null;
        /*if (mBleManager != null) {
            mBleManager.disconnect(mSpeaker.getBtDevice());
            mBleManager.closeGatt(mSpeaker.getBtDevice());
        }*/

        //Intent intent1 = new Intent(EarbudsControllerActivity.this, HomeLaunchDashboard.class);
        //startActivity(intent1);

    }

    public boolean isWstAppForegroud() {
        return mIsWstAppForegroud;
    }

    public void setmIsWstAppForegroud(boolean mIsWstAppForegroud) {
        this.mIsWstAppForegroud = mIsWstAppForegroud;
    }

    private boolean mIsWstAppForegroud = false;
    public void onBackPressed(){

        if ( (isBleConnected == false)) {
            super.onBackPressed();
            //Intent intent1 = new Intent(EarbudsControllerActivity.this, HomeLaunchDashboard.class);
            //startActivity(intent1);
        } else {

            mBackPressed = true;
            //Connect Dialog
            mDisConnectDialog = new ProgressDialog(this);
            mDisConnectDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            mDisConnectDialog.setMessage("Disconnecting...");
            mDisConnectDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
            mDisConnectDialog.setIndeterminate(true);
            mDisConnectDialog.setCancelable(false);
            mDisConnectDialog.setCanceledOnTouchOutside(false);

            if (null != mTraspService) {
                mTraspService.cleanupTransparentService();
            }


            displayDisConnecting();

           try {
                Thread.sleep(500);

            } catch (java.lang.InterruptedException e) {
                e.printStackTrace();
            }


            //sendCommand(UART_CMD_DISCONNECT);


            progressBarCancelTimer = new Timer();
            progressBarCancelTimer.schedule(new TimerTask() {
                public void run() {
                    // when the task active then close the dialog
                   /* dismissDisConnect();
                    progressBarCancelTimer.cancel(); // also just top the timer thread, otherwise, you may receive a crash report
                    launchHomeScreen();*/
                }
            }, 5000); // after 2 second (or 2000 miliseconds), the task will be active.
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_newdevicemenu, menu);
        return true;
    }

    private void readLog() {
        String strLine = "";
        StringBuilder text = new StringBuilder();
        try {
            FileReader fReader = new FileReader(mTempLogFile);
            BufferedReader bReader = new BufferedReader(fReader);

            /** Reading the contents of the file , line by line */
            while ((strLine = bReader.readLine()) != null) {
                text.append(strLine + "\n");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(EarbudsControllerActivity.this, R.style.MyDialogTheme);
        builder.setMessage(text)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.find_new_device:
                //readLog();
                addNewDevice();
                return (true);
        }
        return (super.onOptionsItemSelected(item));
    }

    public  void addNewDevice () {
        if (isBleConnected == true) {
            onBackPressed();
            isLaunchAddNewAfterDisc = true;
            mBackPressedImmitate = true;


        } else {
            isLaunchAddNewAfterDisc = false;
            clearEarpdodStatusData();
            Intent intent = new Intent(EarbudsControllerActivity.this, EarbudsHomeScreenActivity.class);
            startActivity(intent);
        }
    }

    public  void disconnConnecLEForSco () {

        if (isScanning)
        scanLeDevice(false);

        BLELog.d(TAG, "disconnConnecLEForSco ");
        if (isBleConnected == true) {
            onBackPressed();
            isSetScoReconnnectMode = true;
            mBackPressedImmitate = true;

            moveTaskToBack(true);

        }
    }

    public void sendInitCommands() {
        BLELog.d(TAG, "Calling sendInit Commands here");
        sendCommand(UART_CMD_READ_LINK_STATUS);

        sendWstStatusCommands();

    }

    public void sendWstStatusCommands() {
        BLELog.d(TAG, "sendWstStatusCommands");
        sendCommand(UART_CMD_WST_GET_EB_POS_STATUS);
        sendCommand(UART_CMD_WST_GET_PRIM_BATT_INFO);
        sendCommand(UART_CMD_WST_GET_STATUS);

    }


    public void sendSecondaryWstCommands() {
        BLELog.d(TAG, "sendSecondaryWstCommands");
        sendCommand(UART_CMD_WST_GET_SECD_BATT_INFO);

    }

    public void InitializeUI() {




        RelativeLayout equlizerSettinngs = (RelativeLayout) findViewById(R.id.earbudEquilizerSettings);
        equlizerSettinngs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isBleConnected == false) {
                    //showNoConnnectedDeviceAlertDialog();
                    Toast.makeText(getApplicationContext(), "No bundled devices , Add new earbuds",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                if (earBudsInfo.isA2dpConnected && earBudsInfo.isA2dpPlaying) {
                    Intent intent = new Intent(getApplicationContext(), EarbudsEqualizerModesActivity.class);
                    intent.putExtra(Constants.DEVICE_ID, mSpeaker.getDeviceId());
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Stream BT Audio to use EQ",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        RelativeLayout earBudSettinngs = (RelativeLayout) findViewById(R.id.earbudSettings);
        earBudSettinngs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isBleConnected == false) {
                    //showNoConnnectedDeviceAlertDialog();
                    Toast.makeText(getApplicationContext(), "No bundled devices , Add new earbuds",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                if (earBudsInfo.isWSTConnected) {
                    Intent intent = new Intent(getApplicationContext(), EarbudsSettingsActivity.class);
                    intent.putExtra(Constants.DEVICE_ID, mSpeaker.getDeviceId());
                    startActivity(intent);
                }else {
                    Toast.makeText(getApplicationContext(), "Connect both earbuds to use Settings",
                            Toast.LENGTH_LONG).show();
                }
            }
        });




        RelativeLayout findMe = (RelativeLayout) findViewById(R.id.findme);
        findMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isBleConnected == false) {
                    //showNoConnnectedDeviceAlertDialog();
                    Toast.makeText(getApplicationContext(), "No connected devices , Add new earbuds",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                //Intent intent = new Intent(getApplicationContext(), EarbudCommandWindow.class);
                Intent intent = new Intent(getApplicationContext(), EarbudsFindMeActivity.class);
                intent.putExtra(Constants.DEVICE_ID, mSpeaker.getDeviceId());
                startActivity(intent);


            }
        });


        RelativeLayout commandWindow = (RelativeLayout) findViewById(R.id.earbudcommandWindow);
        commandWindow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isBleConnected == false) {
                    //showNoConnnectedDeviceAlertDialog();
                    Toast.makeText(getApplicationContext(), "No connected devices , Add new earbuds",
                            Toast.LENGTH_LONG).show();
                    return;
                }


               ///Intent intent = new Intent(getApplicationContext(), EarbudCommandWindow.class);


                //if (earBudsInfo.isWSTConnected) {
                    Intent intent = new Intent(getApplicationContext(), EarbudsTouchSettingsActivity.class);
                    intent.putExtra(Constants.DEVICE_ID, mSpeaker.getDeviceId());
                    startActivity(intent);
                /*}else {
                    Toast.makeText(getApplicationContext(), "Connect both earbuds to use Settings",
                            Toast.LENGTH_LONG).show();
                }*/

            }
        });

        //Scan dialog
        mScanDialog = new ProgressDialog(this);
        mScanDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        if (isReconnection) {
            mScanDialog.setMessage("Searching for recently connected device.. ");
        }else {
            mScanDialog.setMessage(getString(R.string.scanning_dialog_message));
        }
        mScanDialog.setIndeterminate(true);
        mScanDialog.setCancelable(true);
        mScanDialog.setCanceledOnTouchOutside(true);
        mScanDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mScanDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                scanLeDevice(false);
                mHandler.removeCallbacksAndMessages(null);
            }
        });


        mConnectDialog = new ProgressDialog(this);
        mConnectDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mConnectDialog.setMessage("Connecting. Please wait...");
        mConnectDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mConnectDialog.setIndeterminate(true);
        mConnectDialog.setCancelable(true);
        mConnectDialog.setCanceledOnTouchOutside(false);
        mConnectDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                               @Override
                                               public void onCancel(DialogInterface dialog) {
                                                   BLELog.d(TAG, "Cancelling Connection");
                                                   stopConnect();
                                               }
                                           }
        );


        updateEarbudStatusUI();

    }

    private void updateEarbudStatusUI () {

        if(null != mSpeaker)
        setTitle(mSpeaker.getName());

        setTitle("WST");

        ImageView connectedLineImageV = (ImageView) findViewById(R.id.earbudsConnectedDotsImage);
        ImageView leftEarbudImage = (ImageView) findViewById(R.id.earbudsLeftImage);
        ImageView rightEarbudImage = (ImageView) findViewById(R.id.earbudsRightImage);
        ImageView leftBatteryImage = (ImageView) findViewById(R.id.batterryLeftImage);
        ImageView rightBatteryImage = (ImageView) findViewById(R.id.batterryRightImage);
        TextView leftBatteryStaus = (TextView) findViewById(R.id.batterryLeftstatusText);
        TextView rightBatteryStaus = (TextView) findViewById(R.id.batterrystatusTextRight);


        if(earBudsInfo.isWSTConnected) {


            String leftEarbudBattrey;
            String rightEarbudBattrey;




            if(earBudsInfo.isPrimaryLeft) {
                leftEarbudBattrey= getNormalizeBattaryValue(earBudsInfo.primaryBatteryStatus)+"%" ;
                rightEarbudBattrey = getNormalizeBattaryValue(earBudsInfo.secondaryBatteryStaus)+"%";

                leftBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.primaryBatteryStatus)));
                leftBatteryImage.setVisibility(View.VISIBLE);

                rightBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.secondaryBatteryStaus)));
                rightBatteryImage.setVisibility(View.VISIBLE);

            } else {
                leftEarbudBattrey= getNormalizeBattaryValue(earBudsInfo.secondaryBatteryStaus)+"%" ;
                rightEarbudBattrey = getNormalizeBattaryValue(earBudsInfo.primaryBatteryStatus)+"%";

                leftBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.secondaryBatteryStaus)));
                leftBatteryImage.setVisibility(View.VISIBLE);

                rightBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.primaryBatteryStatus)));
                rightBatteryImage.setVisibility(View.VISIBLE);

            }

            connectedLineImageV.setImageResource(R.drawable.dots11);
            connectedLineImageV.setVisibility(View.VISIBLE);

            leftEarbudImage.setImageResource(R.drawable.left_eabud_blk);
            leftEarbudImage.setVisibility(View.VISIBLE);

            leftBatteryStaus.setText(leftEarbudBattrey);
            leftBatteryStaus.setVisibility(View.VISIBLE);

            rightEarbudImage.setImageResource(R.drawable.right_eabud_blk);
            rightEarbudImage.setVisibility(View.VISIBLE);

            rightBatteryStaus.setText(rightEarbudBattrey);
            rightBatteryStaus.setVisibility(View.VISIBLE);



        } else {


            String leftEarbudBattrey;
            String rightEarbudBattrey;


            if(earBudsInfo.isPrimaryLeft) {
                leftEarbudBattrey= getNormalizeBattaryValue(earBudsInfo.primaryBatteryStatus)+"%" ;
                rightEarbudBattrey = " ! ";

                leftBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.primaryBatteryStatus)));
                leftBatteryImage.setVisibility(View.VISIBLE);

                rightBatteryImage.setImageDrawable(getDrawable(R.drawable.battery0));
                rightBatteryImage.setVisibility(View.VISIBLE);

            } else {
                rightEarbudBattrey = getNormalizeBattaryValue(earBudsInfo.primaryBatteryStatus)+"%";
                leftEarbudBattrey= " ! " ;

                leftBatteryImage.setImageDrawable(getDrawable(R.drawable.battery0));
                leftBatteryImage.setVisibility(View.VISIBLE);

                rightBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.primaryBatteryStatus)));
                rightBatteryImage.setVisibility(View.VISIBLE);
            }


            connectedLineImageV.setVisibility(View.INVISIBLE);

            leftEarbudImage.setImageResource(R.drawable.left_earbud_white);
            leftEarbudImage.setVisibility(View.VISIBLE);

            leftBatteryStaus.setText(leftEarbudBattrey);
            leftBatteryStaus.setVisibility(View.VISIBLE);

            rightEarbudImage.setImageResource(R.drawable.right_eabud_white);
            rightEarbudImage.setVisibility(View.VISIBLE);

            rightBatteryStaus.setText(rightEarbudBattrey);
            rightBatteryStaus.setVisibility(View.VISIBLE);

        }



    }

    public void sendCommand(String cmd) {
        if (mTraspService.isConnected() == false) {
            //showNoConnnectedDeviceAlertDialog();
            Toast.makeText(getApplicationContext(), "No bundled devices , Add new earbuds",
                    Toast.LENGTH_LONG).show();
        }
        if (mTraspService != null) {
            mTraspService.packAndSendCommand(cmd);
        }
    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                Intent home = new Intent(getApplicationContext(), EarbudsControllerActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }


    /*public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                launchHomeScreen();
            }
        });
        builder.show();
    }*/



    private void launchPainAndConnect() {

        if (mAskedForUserPairing == false) {
            runOnUiThread(new Runnable() {
                public void run() {

                    Toast.makeText(getApplicationContext(), "Pair and connect Audio for earbuds",
                            Toast.LENGTH_LONG).show();
                }
            });

            Thread thread = new Thread(new Runnable() {

                @Override
                public void run() {

                    try {
                        Thread.sleep(500);

                    } catch (java.lang.InterruptedException e) {
                        e.printStackTrace();
                    }


                    Intent intentOpenBluetoothSettings = new Intent();
                    intentOpenBluetoothSettings.setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                    startActivity(intentOpenBluetoothSettings);

                }

            });
            thread.start();
            mAskedForUserPairing = true;
        }
    }

    private int getBatteryResource(int wstBatteryStatus) {
        int batterImgId = -1;
        if (wstBatteryStatus == 0x00) batterImgId = R.drawable.battery0;
        else if (wstBatteryStatus == 0x01 || wstBatteryStatus == 0x02 || wstBatteryStatus == 0x03) batterImgId = R.drawable.battery1;
        else if (wstBatteryStatus == 0x04 || wstBatteryStatus == 0x05 || wstBatteryStatus == 0x06) batterImgId = R.drawable.battery2;
        else if (wstBatteryStatus == 0x07 || wstBatteryStatus == 0x08 || wstBatteryStatus == 0x09) batterImgId = R.drawable.battery3;
        else if (wstBatteryStatus == 0x0A || wstBatteryStatus == 0x0B) batterImgId = R.drawable.battery4;
        else if (wstBatteryStatus == 0x0C) batterImgId = R.drawable.battery5;

        return batterImgId;
    }

    private String getNormalizeBattaryValue (int wstBatteryStatus){

        int battValInt;


        if (wstBatteryStatus == 0x00)
            battValInt = 0;

        else if (wstBatteryStatus == 0x0C)
            battValInt = 100;

        else
            battValInt = (((100/12) * wstBatteryStatus))+ 11;

        return Integer.toString(battValInt);
    }

    class EarBudsInfo {
        boolean isWSTConnected = false;
         boolean isPrimaryLeft = false;
         boolean isA2dpConnected = false;
        boolean isA2dpPlaying = false;
        boolean isSCOConnected = false;

        int primaryBatteryStatus =  0;
        int secondaryBatteryStaus = 0;

    }

    public void setupTransparentService(String deviceId ){


        mBleManager.removeListener(gattCallback);


        BLELog.d(TAG, "Device ID of selected speaker =" + deviceId);
        mDevId = deviceId;
        try {
            mTempLogFile = File.createTempFile("commandLog", null, this.getCacheDir());
        } catch (IOException e) {
            e.printStackTrace();
        }
        mTraspService = new EarbudsTransparentServiceManager(EarbudsControllerActivity.getInstance(), mDevId, mTempLogFile);
        mTraspService.setDoNothandleGattClose(false);



        transRxIntentFilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_DISCONNECTED);
        speakerInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (EarbudsTransparentServiceManager.BLE_DISCONNECTED.equals(action)) {

                    handleDisconnectConnect();

                }
                if (EarbudsTransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    isBleConnected = true;
                    dismissConnect();
                    sendInitCommands();
                }
                if (EarbudsTransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(EarbudsTransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i;
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Received Data byte[" + i + "]=" + (rxBytes[i] & 0xff));
                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            switch (rxBytes[3] & 0xff) {
                                case COMMAND_ACK_EVENT:
                                    String returnValue = "";
                                    switch (rxBytes[5] & 0xff) {
                                        case 0:
                                            returnValue = "Command complete";
                                            if ((rxBytes[4] & 0xff) == 0x32) {
                                                BLELog.d(TAG, "Disconnnet command found");
                                                mTraspService.cleanupTransparentService ();
                                                //SpeakerControllerActivity.super.onBackPressed();
                                                //launchHomeScreen();
                                            }
                                            break;
                                        case 1:
                                            returnValue = "Command dissallow";
                                            break;
                                        case 2:
                                            returnValue = "Unknown command";
                                            break;
                                        case 3:
                                            returnValue = "Parameters error";
                                            break;
                                        case 4:
                                            returnValue = "BTM is busy";
                                            break;
                                        case 5:
                                            returnValue = "BTM memory is full";
                                            break;
                                        default:
                                            returnValue = "unknown return value";
                                    }
                                    BLELog.d(TAG, "ACK for Command = " + (rxBytes[4] & 0xff) + "  ACK Return value =" + returnValue);
                                    if ((rxBytes[5] & 0xff) != 0) {
                                        commandError(returnValue + " For Command:" + (rxBytes[4] & 0xff));
                                    }
                                    break;
                                case READ_LINK_STATUS_REPLAY: {
                                    BLELog.d(TAG, "Reply for LINK STATUS" +  (rxBytes[4] & 0xff)+ "a2dp play status="+ (rxBytes[7] & 0xff));
                                    /* if ((rxBytes[4] & 0xff) == 0) {
                                        BLELog.d(TAG, "Power OFF state");
                                        powerValue.setChecked(false);
                                        powerStateChanged(false);
                                    } else {
                                        BLELog.d(TAG, "Power ON state");
                                        powerValue.setChecked(true);
                                        powerStateChanged(true);
                                    }*/
                                    if ((rxBytes[4] & 0xff) == 0x01) {
                                        BLELog.d(TAG, " WST READ_LINK_STATUS_REPLAY status Pairing mode");
                                        earBudsInfo.isA2dpConnected = false;
                                        launchPainAndConnect();

                                    } else if ((rxBytes[4] & 0xff) == 0x02) {
                                        BLELog.d(TAG, " WST READ_LINK_STATUS_REPLAY status A2DP NOT link established");
                                        earBudsInfo.isA2dpConnected = false;
                                        launchPainAndConnect();

                                    } else  if (((rxBytes[4] & 0xff) == 0x06) || (( rxBytes[4] & 0xff) == 0x04)) {
                                        BLELog.d(TAG, " WST READ_LINK_STATUS_REPLAY  status A2DP link established");
                                        earBudsInfo.isA2dpConnected = true;

                                    } else {
                                        BLELog.d(TAG, " WST READ_LINK_STATUS_REPLAY status UNKNOWN mode so A@DP disconnected");
                                        earBudsInfo.isA2dpConnected = false;
                                        launchPainAndConnect();
                                    }

                                    //Parse streaming status
                                    switch (rxBytes[7] & 0xff) {
                                        case 1: //playing
                                            earBudsInfo.isA2dpPlaying = true;
                                            break;
                                        default:
                                            earBudsInfo.isA2dpPlaying = false;
                                            break;
                                    }

                                }
                                break;
                                case UART_CMD_WST_GET_STATUS_RSP_EVT: {
                                    BLELog.d(TAG, "WST connection STATUS EVT");

                                    if ((rxBytes[5] & 0xff) == 0x03) {
                                        BLELog.d(TAG, " WST connected");
                                        earBudsInfo.isWSTConnected = true;
                                        sendSecondaryWstCommands();
                                    } else {
                                        BLELog.d(TAG, " WST NOT connected");
                                        earBudsInfo.isWSTConnected = false;
                                        updateEarbudStatusUI();
                                    }



                                }
                                break;

                                case UART_CMD_WST_GET_EB_POS_STATUS_RSP_EVT: {
                                    BLELog.d(TAG, "WST  EARBUD POS EVT");
                                    earBudsInfo.isPrimaryLeft = true;
                                    if ((rxBytes[4] & 0xff) == 0x02) {
                                        BLELog.d(TAG, " WST primary earbud RIGHT");
                                        earBudsInfo.isPrimaryLeft = false;
                                    } else  if ((rxBytes[4] & 0xff) == 0x01) {
                                        BLELog.d(TAG, " WST primary earbud LEFT");
                                        earBudsInfo.isPrimaryLeft = true;
                                    }


                                }
                                break;

                                case UART_CMD_WST_GET_PRIM_BATT_INFO_RSP_EVT: {
                                    BLELog.d(TAG, "WST  PRIM battery  EVT"+ (rxBytes[5]& 0xff));
                                    ;
                                    earBudsInfo.primaryBatteryStatus = rxBytes[5]& 0xff;

                                    // if(earBudsInfo.isWSTConnected)
                                    //sendSecondaryWstCommands();
                                    updateEarbudStatusUI();

                                }
                                break;

                                case UART_CMD_WST_GET_SECD_BATT_INFO_RSP_EVT: {
                                    BLELog.d(TAG, "WST  SEC battery  EVT"+ (rxBytes[4]& 0xff));
                                    earBudsInfo.secondaryBatteryStaus = rxBytes[4]& 0xff;
                                    updateEarbudStatusUI();

                                }
                                break;

                                case AVC_VENDOR_DEPENDENT_RESPONSE:
                                    BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE");
                                    if ((rxBytes[11] & 0xff) == 0x31 && (rxBytes[15] & 0xff) == 0x01) {
                                        switch (rxBytes[16] & 0xff) {
                                            case 0x00:
                                                earBudsInfo.isA2dpPlaying = false;
                                                BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE isA2dpPlaying = false");
                                                break;//STOPPED
                                            case 0x01:
                                                earBudsInfo.isA2dpPlaying = true;
                                                BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE isA2dpPlaying = true");
                                                break;// PLAYING
                                            case 0x02:
                                                earBudsInfo.isA2dpPlaying = false;
                                                BLELog.d(TAG, "AVC_VENDOR_DEPENDENT_RESPONSE isA2dpPlaying = false");
                                                break;// PAUSED
                                            case 0x03:
                                                break;//FWD_SEEK
                                            case 0x04:
                                                break;//REV_SEEK
                                            case 0xFF:
                                                break;//ERROR
                                        }
                                    }
                                    break;
                                case READ_EVT_BTM_STATUS: {
                                    BLELog.d(TAG, "Event for BTM STATUS");
                                   /* if ((rxBytes[4] & 0xff) == 0x00) {
                                        BLELog.d(TAG, "Power OFF state");
                                        powerValue.setChecked(false);
                                        powerStateChanged(false);
                                    } else if ((rxBytes[4] & 0xff) == 0x02) {
                                        BLELog.d(TAG, "Power ON state");
                                        powerValue.setChecked(true);
                                        powerStateChanged(true);
                                    }*/

                                    switch (rxBytes[4] & 0xff) {
                                        case 0x01:
                                            BLELog.d(TAG, "Pairing state (discoverable mode)");

                                            break;
                                        case 0x03:
                                            BLELog.d(TAG, "Pairing successful");
                                            break;
                                        case 0x04:
                                            BLELog.d(TAG, "Pairing failed");
                                            break;
                                        case 0x05:
                                            BLELog.d(TAG, "HF/HS link established");
                                            break;
                                        case 0x06:
                                            BLELog.d(TAG, "A2DP link established");
                                            earBudsInfo.isA2dpConnected = true;
                                            updateEarbudStatusUI();
                                            break;
                                        case 0x07:
                                            BLELog.d(TAG, "HF link disconnected");
                                            break;
                                        case 0x08:
                                            BLELog.d(TAG, "A2DP link disconnected");
                                            earBudsInfo.isA2dpConnected = false;
                                            updateEarbudStatusUI();
                                            break;
                                        case 0x09:
                                            BLELog.d(TAG, "SCO link connected");
                                            earBudsInfo.isSCOConnected = true;
                                            isSetScoReconnnectMode = true;
                                            disconnConnecLEForSco();


                                            break;
                                        case 0x0A:
                                            BLELog.d(TAG, "SCO link disconnected");
                                            earBudsInfo.isSCOConnected = false;

                                            break;
                                        case 0x0B:
                                            BLELog.d(TAG, "AVRCP link established");
                                            break;
                                        case 0x0C:
                                            BLELog.d(TAG, "AVRCP link disconnected");
                                            break;
                                        case 0x0D:
                                            BLELog.d(TAG, "Standard SPP connected");
                                            break;
                                        case 0x0E:
                                            BLELog.d(TAG, "Standard_SPP / iAP disconnected");
                                            break;
                                        case 0x0F:
                                            BLELog.d(TAG, "Standby state");
                                            break;
                                        case 0x10:
                                            BLELog.d(TAG, "iAP connected");
                                            break;
                                        case 0x11:
                                            BLELog.d(TAG, "ACL disconnected FOREGROUND " + isWstAppForegroud());
                                            if (!isWstAppForegroud())
                                                finish();
                                            earBudsInfo.isA2dpConnected = false;
                                            //dataBaseId = 0;
                                            break;
                                        case 0x12:
                                            BLELog.d(TAG, "MAP connected");
                                            break;
                                        case 0x13:
                                            BLELog.d(TAG, "MAP operation forbidden");
                                            break;
                                        case 0x14:
                                            BLELog.d(TAG, "MAP disconnected");
                                            break;
                                        case 0x15:
                                            BLELog.d(TAG, "ACL connected");
                                            BLELog.d(TAG, "ACL Received Data Hex="+ HexTool.byteArrayToHexString(rxBytes));
                                        {
                                            //dataBaseId = rxBytes[5]& 0xff;
                                        }

                                        break;
                                        case 0x80:
                                            BLELog.d(TAG, "AuxIn Not available");

                                            break;
                                        case 0x81:
                                            BLELog.d(TAG, "AuxIn plugged and Playing AuxIn");

                                            break;
                                        case 0x82:
                                            BLELog.d(TAG, "AuxIn plugged and playing A2DP");

                                            break;
                                        default:
                                            BLELog.d(TAG, "Wrong state");
                                            break;
                                    }

                                }
                                break;
                            }
                        }
                    }
                }
            }

        };

        mTraspService.registerFragReceiver(speakerInfoReceiver, transRxIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, transReadyIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, disconnectionfilter);

    }

    private void handleConnect() {

     //   if (null == mSpeaker)
         //   return;

        isReconnection = false;
        mBleManager.setConnectedSpeaker(mSpeaker);
        //scanLeDevice(false);//Stop scanning

       // isBleConnected = true;
        // Cached data
        saveRecentConnectedDevGroup(mSpeaker.getDeviceId(),
                mSpeaker.getGroupAddress(),
                mSpeaker.getName());



       /* Woeking runOnUiThread(new Runnable() {
            @Override
            public void run() {

                try {
                    Thread.sleep(500);

                } catch (java.lang.InterruptedException e) {
                    e.printStackTrace();
                }
                setupTransparentService(mSpeaker.getDeviceId());
            }
        });*/

        Handler mainHandler = new Handler(getApplicationContext().getMainLooper());

        Runnable myRunnable = new Runnable() {
            @Override
            public void run() {

                mBleManager.removeAllListener(gattCallback);

                try {
                    Thread.sleep(1000);

                } catch (java.lang.InterruptedException e) {
                    e.printStackTrace();
                }
                setupTransparentService(mSpeaker.getDeviceId());
            } // This is your code
        };

        mainHandler.post(myRunnable);

    }


    private void handleDisconnectConnect() {

        clearEarpdodStatusData();
        updateEarbudStatusUI();

        if (mBackPressed) {
            progressBarCancelTimer.cancel();
            dismissDisConnect();
            if(mBackPressedImmitate == false) {
                EarbudsControllerActivity.super.onBackPressed();
                //Intent intent1 = new Intent(EarbudsControllerActivity.this, HomeLaunchDashboard.class);
                //startActivity(intent1);
               // finish();
            }
            if (isLaunchAddNewAfterDisc == true) {
                clearEarpdodStatusData();
                Intent intent2 = new Intent(EarbudsControllerActivity.this, EarbudsHomeScreenActivity.class);
                startActivity(intent2);
            }

            if (isSetScoReconnnectMode == true) {
                Toast.makeText(getApplicationContext(), "Earbuds Disconnected for SCO.",
                        Toast.LENGTH_LONG).show();
            }


            isLaunchAddNewAfterDisc = false;
            mBackPressed = false;
            mBackPressedImmitate = false;
        } else {
            //handleBLEDisconnection();
            //showNoConnnectedDeviceAlertDialog();
            if(!isTryRetryOnce)
            Toast.makeText(getApplicationContext(), "Earbuds Disconnected.",
                    Toast.LENGTH_LONG).show();
        }

        if ((null != speakerInfoReceiver) && (null != mTraspService)) {
            mTraspService.unregisterFragReceiver(speakerInfoReceiver);
            BLELog.d(TAG, "mTraspService.unregisterFragReceiver ");

        }

        speakerInfoReceiver = null;
        mTraspService = null;

        if (isTryRetryOnce)
            handleRetryOnce();




    }

    private boolean mIsAddNewEarbudAdded = false;

    private void backgroundScan(boolean enable) {
        scanLeDevice(enable);
    }

    private boolean isScanning = false;

  //  private String mSelectedSpeakerId;
    private Handler mHandler;
    private Handler mConectTimeoutHandler = new Handler();
    private BLESpeaker currentEarpod;
    private synchronized  void scanLeDevice(final boolean enable) {
        BLELog.d(TAG, "scanLeDevice");

        if (enable) {
            if (isScanning) {
                BLELog.d(TAG, "Balaji Already scanning");
                return;
            }
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    BLELog.d(TAG, "Scan finished");
                    isScanning = false;
                    mBleManager.stopScan(mScanCallback);
                    dismissScanning();
                    isReconnection = false;
                    Toast.makeText(getApplicationContext(), "No bundled devices . Add new earbuds",
                            Toast.LENGTH_LONG).show();


                }
            }, SCAN_PERIOD);
            if (!isScanning) {
                isScanning = true;
                BLELog.d(TAG, "Scan Started");
                if(mBleManager!=null)
                {
                    List<BluetoothDevice> connectedDevices = mBleManager.getConnectedDevices();
                    for (BluetoothDevice dev : connectedDevices) {
                        BLELog.d(TAG, " Already connected device" + dev.getAddress());
                        //mBleManager.disconnect(dev);
                        mBleManager.closeGatt(dev);

                        try {
                            Thread.sleep(500);

                        } catch (java.lang.InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }

                ScanSettings scanSettings = new ScanSettings.Builder()
                        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                        .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
                        .setMatchMode(ScanSettings.MATCH_MODE_AGGRESSIVE)
                        .setNumOfMatches(ScanSettings.MATCH_NUM_ONE_ADVERTISEMENT)
                        .setReportDelay(0L)
                        .build();

                mBleManager.startScan(null, scanSettings, mScanCallback);
            }
        } else {
            isScanning = false;
            mBleManager.stopScan(mScanCallback);
        }

    }

    private synchronized  void setConnectionTimeoutHandler() {

        mConectTimeoutHandler.removeCallbacksAndMessages(null);

        mConectTimeoutHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                BLELog.d(TAG, "Connection Timeout");

        handleRetryOnce();

            }
        }, 22000);

    }
    private static final long SCAN_PERIOD = 30000;
    private boolean isReconnection = false;
    private  boolean isBleConnected = false;
    private  boolean isLaunchAddNewAfterDisc = false;

    synchronized public boolean isSetScoReconnnectMode() {
        return isSetScoReconnnectMode;
    }

    public   boolean isSetScoReconnnectMode = false;



    synchronized public void setTryRetryOnce(boolean tryRetryOnce) {
        isTryRetryOnce = tryRetryOnce;
    }

    public   boolean isTryRetryOnce = false;
   // public Map<String, BLESpeaker> mSpeakers = new ConcurrentHashMap<String, BLESpeaker>();

    private  String mRecentBtAddress = "" ;
    private ProgressDialog mConnectDialog;
    private ProgressDialog mScanDialog;
    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BLELog.d(TAG, "onScanResult: callbackType = " + callbackType + " result=" + result.toString()+ "isScanning ="+isScanning);
           // addEarbuds(result.getDevice(), result.getScanRecord(), result.getRssi());
            if (isScanning = true)
             checkForRecentEarbuds(result.getDevice(), result.getScanRecord(), result.getRssi());
        };


        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            BLELog.d(TAG, "onBatchScanResults:" + results.toString());
            for (ScanResult sr : results) {
                System.out.println("ScanResult - Results" + sr.toString());

                //addEarbuds(sr.getDevice(), sr.getScanRecord(), sr.getRssi());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            BLELog.d(TAG, "Scan Failed Error Code: " + errorCode);
        }
    };

    private  int connRetryCount = 0;
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public synchronized void  onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            BLELog.d(TAG, "onConnectionStateChange Status: " + status+"B ST="+gatt.getDevice().getBondState());
            switch (newState) {
                case BluetoothProfile.STATE_CONNECTED:
                    BLELog.d(TAG, "STATE_CONNECTED status= "+ status + "B ST="+gatt.getDevice().getBondState());
                    //dismissConnect();
                   //handleConnect();
                    mConectTimeoutHandler.removeCallbacksAndMessages(null);
                    handleMTUAfterConnect();

                    break;
                case BluetoothProfile.STATE_DISCONNECTED:
                    BLELog.d(TAG, "STATE_DISCONNECTED status= "+ status + "B ST="+gatt.getDevice().getBondState());
                    mConectTimeoutHandler.removeCallbacksAndMessages(null);
                    mBleManager.setConnectedSpeaker(null);
                    if(mConnectDialog!=null && mConnectDialog.isShowing())
                        dismissConnect();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {


                                if (mTraspService != null )
                                    mTraspService.cleanupTransparentService();


                                mBleManager.removeListener(gattCallback);
                                mBleManager.closeGatt(mSpeaker.getBtDevice());

                                if(connRetryCount < 5) {
                                    connRetryCount++;
                                    initiateConnect(false);
                                    BLELog.d(TAG, "Connection failed Retrying "+ connRetryCount);
                                    //Toast.makeText(EarbudsControllerActivity.getInstance(), "Connection Retrying "+ connRetryCount,
                                           /// Toast.LENGTH_LONG).show();
                                } else {
                                    connRetryCount = 0;

                                    if (isReconnection) {

                                        Toast.makeText(EarbudsControllerActivity.getInstance(), "No bundeled device ! Add New Earbuds !  ",
                                                Toast.LENGTH_LONG).show();
                                    } else {
                                        Toast.makeText(EarbudsControllerActivity.getInstance(), "Earbuds Disconnected",
                                                Toast.LENGTH_LONG).show();
                                    }
                                }


                            }
                        });

                    BLELog.d(TAG, "STATE_DISCONNECTED");
                    break;
                default:
                    BLELog.d(TAG, "STATE_OTHER");
            }

        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            BLELog.d(TAG, "EarbudsControllerActivity onMtuChanged called mtu=" + mtu+ "status="+ status + "B state="+ gatt.getDevice().getBondState()) ;

            handleConnect();
        }
    };

    private synchronized  void handleRetryOnce () {
        mBleManager.setConnectedSpeaker(null);
        if(mConnectDialog!=null && mConnectDialog.isShowing())
            dismissConnect();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {


                if (mTraspService != null )
                    mTraspService.cleanupTransparentService();


                if (mBleManager != null) {
                    mBleManager.removeListener(gattCallback);
                    mBleManager.closeGatt(mSpeaker.getBtDevice());
                }



                initiateConnect(false);

                isTryRetryOnce = false;


            }
        });

    }

    private boolean handleRecentAddress() {
        return  true;
    }

  /*  private boolean handleRecentAddress() {
        BLELog.d(TAG, "handleRecentAddress");
        Iterator<String> keyIterator = mSpeakers.keySet().iterator();
        int i = 0;
        while (keyIterator.hasNext()) {
            String key = (String) keyIterator.next();
            BLESpeaker speaker = mSpeakers.get(key);
            BLELog.d(TAG, speaker.getDeviceId() + " mRecentBtAddress= " + mRecentBtAddress);

            if (speaker.getDeviceId() .equalsIgnoreCase(mRecentBtAddress) ) {

                BLELog.d(TAG, speaker.getDeviceId() + " Auto connect" );

                mSelectedSpeakerId = speaker.getDeviceId();


                if (mBleManager.getConnectionState(speaker.getBtDevice()) == BluetoothProfile.STATE_CONNECTED) {
                    BLELog.d(TAG, " Its already connected" +  speaker.getBtDevice().getAddress() + speaker.getDeviceId());
                    handleConnect();

                } else {
                    List<BluetoothDevice> connectedDevices = mBleManager.getConnectedDevices();
                    for (BluetoothDevice dev : connectedDevices) {
                        BLELog.d(TAG, "Disconnecting Already connected device" + dev.getName() + dev.getAddress());
                        // mBleManager.disconnect(dev);
                        mBleManager.closeGatt(dev);
                    }
                    displayConnecting();
                    scanLeDevice(false);
                    // timer.cancel();
                    BLELog.d(TAG, " Connnectiong  NEW  device" + speaker.getName() + speaker.getBtDevice().getAddress());
                    mBleManager.connectGatt(getApplicationContext(), false, speaker.getBtDevice(), Constants.TRANSPORT_LE);


                }

                return true;

            }


        }

        return false;
    }*/


    public boolean saveRecentBundleId(String bundleId, String  bundleGroupAddress) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor mEdit1 = sp.edit();

        mEdit1.putString("RecentBundleId" , bundleId);
        mEdit1.putString("RecentBundleGroupAddress" , bundleGroupAddress);

        BLELog.d(TAG, "saveRecentBundleId  " + bundleId+" bundleGroupAddress " + bundleGroupAddress);

        return mEdit1.commit();
    }

    public boolean saveRecentConnectedDevGroup(String deviceBtAddress, String  groupAddress,String btName) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor mEdit1 = sp.edit();

        mEdit1.putString("RecentBtAddress" , deviceBtAddress);
        mEdit1.putString("RecentGroupAddress" , groupAddress);
        mEdit1.putString("RecentBtName" , btName);

        return mEdit1.commit();
    }

    public String getRecentConnectedDeviceAddress() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String value = sp.getString("RecentBtAddress" , "");
        return value;
    }

    public String getRecentConnectedGroupAddress() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String value = sp.getString("RecentGroupAddress" , "");
        return value;
    }

    public String getRecentConnectedDeviceName() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String value = sp.getString("RecentBtName" , "");
        return value;
    }

    Runnable discoverServicesRunnable;
    private Handler bleHandler = new Handler();


    private void  handleMTUAfterConnect() {

                mBleManager.setMtuSize();
    }

    private void dismissConnect() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mConnectDialog != null && mConnectDialog.isShowing()) {
                    mConnectDialog.dismiss();
                }
            }
        });
    }

    private void displayConnecting() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mConnectDialog != null)
                    mConnectDialog.show();
            }
        });
    }

    private void dismissScanning() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mScanDialog != null && mScanDialog.isShowing()) {
                    mScanDialog.setMessage(getString(R.string.scanning_dialog_message));
                    mScanDialog.dismiss();
                }
            }
        });
    }

    private void displayScanning() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mScanDialog != null)
                    mScanDialog.show();
            }
        });
    }


    private void stopConnect() {

        mHandler.removeCallbacksAndMessages(null);

        if (mBleManager != null && (mSpeaker!= null)) {
            mBleManager.disconnect(mSpeaker.getBtDevice());
            mBleManager.closeGatt(mSpeaker.getBtDevice());
            //mBleManager.removeListener(gattCallback);

        }
    }

    private void initiateConnect (boolean setConnectionTimeoutTImer) {

        //if (mSpeaker == null)
           // return;

        mBleManager.addListener(gattCallback);


        if (mBleManager.getConnectionState(mSpeaker.getBtDevice()) == BluetoothProfile.STATE_CONNECTED) {
            BLELog.d(TAG, " Its already connected" + mSpeaker.getBtDevice().getAddress() + mSpeaker.getDeviceId());
            handleConnect();
        } else {
            List<BluetoothDevice> connectedDevices = mBleManager.getConnectedDevices();
            for (BluetoothDevice dev : connectedDevices) {
                BLELog.d(TAG, "Disconnecting Already connected device" + dev.getName() + dev.getAddress());
                // mBleManager.disconnect(dev);
               // mBleManager.closeGatt(dev);
            }

            displayConnecting();

            if (isScanning)
            scanLeDevice(false);

            try {
                Thread.sleep(500);

            } catch (java.lang.InterruptedException e) {
                e.printStackTrace();
            }
            // timer.cancel();
            BLELog.d(TAG, " Connnectiong  NEW  device" + mSpeaker.getName() + mSpeaker.getBtDevice().getAddress());
            mBleManager.connectGatt(getApplicationContext(), true, mSpeaker.getBtDevice(), Constants.TRANSPORT_LE);

            if (setConnectionTimeoutTImer) {
                setConnectionTimeoutHandler();
            } else  {
                BLELog.d(TAG, "Not settings Connection timeout");
            }
        }
    }

    public void checkForRecentEarbuds(BluetoothDevice btDevice, ScanRecord record, int rssi) {
        {
            {


                byte[] beacon = new byte[20];
                BLELog.d(TAG, "SCAN RECORD:" + record.toString());
                Map<ParcelUuid, byte[]> data = new HashMap<>();
                data = record.getServiceData();
                boolean isMchpSpeaker = false;
                for (Map.Entry<ParcelUuid, byte[]> entry : data.entrySet()) {
                    ParcelUuid uuid = entry.getKey();
                    //compare to ISSC uuid and copy to beacon
                    beacon = entry.getValue();
                    System.out.println("key:" + uuid.toString());
                    StringBuilder sb = new StringBuilder();
                    for (byte b : beacon) {
                        sb.append(String.format("%02X ", b));
                    }
                    BLELog.d(TAG, "HEX VALUE " + sb.toString());
                    String uuidStr = uuid.toString();
                    if (uuidStr.startsWith("0000feda")) {
                        isMchpSpeaker = true;
                    }
                }
                if (isMchpSpeaker == false) {
                    BLELog.d(TAG, "Its not WST Earbud");
                    return;
                }

                BLELog.d(TAG, "Becon Received Data Hex=" + HexTool.byteArrayToHexString(beacon));

                // BLELog.d(TAG, "Beacon Length=" + beacon.length);
                BLESpeaker speaker = new BLESpeaker();
                if (beacon.length == 2) {//category 2, 104/105 Embedded mode Generic Headset
                    speaker.setDeviceId(btDevice.getAddress());
                    speaker.setName(btDevice.getName());
                    speaker.setBtDevice(btDevice);
                    speaker.setRssi(rssi);
                    speaker.setGroupAddress("");
                    speaker.setGroupStatus(Constants.UNGROUPED_VALUE);
                    speaker.setFeatureValue((byte) 4);
                    speaker.setBeaconCategory(2);
                } else if (beacon.length == 10) {
                    BLELog.d(TAG, "WST Earbud device");
            /*  Example
            uuid: 0000feda-0000-1000-8000-00805f9b34fb
            value: 00 02 00 00 C4 2B AE ED 00 00 00 00

            New HEX value : HEX VALUE 1F 02 00 00 A8 01 0A F4 81 34 00 00 00 00 00 00 03

            00 battery level [0th byte]
            02 BTM Status     [1st byte]
            00 multispk role [2nd byte]
            00 multi spk state [3rd byte]
            C4 2B AE ED Device address [4th byte]
            00 00 00 00 group address [10th byte]
            00 supported feature [16th byte]
            */


                    //Battery Level
                    int batteryVal = Constants.UNKNOWN_VALUE;
                    if (beacon[0] == 0x00) batteryVal = 0;
                    else if (beacon[0] == 0x01 || beacon[0] == 0x02 || beacon[0] == 0x03)
                        batteryVal = 1;
                    else if (beacon[0] == 0x04 || beacon[0] == 0x05 || beacon[0] == 0x06)
                        batteryVal = 2;
                    else if (beacon[0] == 0x07 || beacon[0] == 0x08 || beacon[0] == 0x09)
                        batteryVal = 3;
                    else if (beacon[0] == 0x0A || beacon[0] == 0x0B) batteryVal = 4;
                    else if (beacon[0] == 0x0C) batteryVal = 5;
                    BLELog.d(TAG, "battery Level=" + batteryVal);

                    //BTM Status
                    int btmStatus = Constants.UNKNOWN_VALUE;
                    if (beacon[1] == 0x00) btmStatus = Constants.POWER_OFF_STATE;
                    else if (beacon[1] == 0x01) btmStatus = Constants.PAIRING_STATE;
                    else if (beacon[1] == 0x02) btmStatus = Constants.STANDBY_STATE;
                    else if (beacon[1] == 0x03) btmStatus = Constants.HF_CONN_STATE;
                    else if (beacon[1] == 0x04) btmStatus = Constants.A2DP_CONN_STATE;
                    else if (beacon[1] == 0x05) btmStatus = Constants.SPP_CONN_STATE;
                    else if (beacon[1] == 0x06) btmStatus = Constants.MULTIPLE_CONN_STATE;
                    BLELog.d(TAG, "WST BTM Status=" + btmStatus);


                    //WST Primary ear bud status
                    int groupStatus = Constants.UNKNOWN_VALUE;
                    if (beacon[2] == 0x00) groupStatus = Constants.UNGROUPED_VALUE;
                    else if (beacon[2] == 0x01) groupStatus = Constants.STEREO_MASTER_VALUE;
                    else if (beacon[2] == 0x04) groupStatus = Constants.STEREO_SLAVE_VALUE;
                    else if (beacon[2] == 0x05) groupStatus = Constants.CONCERT_MASTER_VALUE;
                    else if (beacon[2] == 0x06) groupStatus = Constants.CONCERT_SLAVE_VALUE;
                    else if (beacon[2] == 0x07) groupStatus = Constants.CONCERT_MASTER_VALUE;
                    BLELog.d(TAG, "Primary ear bud status=" + Constants.getSpeakerTypeString(groupStatus));


                    //WST Secondary ear bud battery
                    int multispkState = Constants.UNKNOWN_VALUE;
                    if (beacon[3] == 0x00) multispkState = Constants.MULTISPK_STANDBY;
                    else if (beacon[3] == 0x01) multispkState = Constants.MULTISPK_BTM_BUSY;
                    else if (beacon[3] == 0x02) multispkState = Constants.MULTISPK_CONNECTING;
                    else if (beacon[3] == 0x03) multispkState = Constants.MULTISPK_CONNECTED;
                    else if (beacon[3] == 0x09) multispkState = Constants.MULTISPK_MORE_SLAVE_CONN;
                    BLELog.d(TAG, "Multi-SPK state=" + Constants.getMultiSPKstate(multispkState));


                    if (groupStatus == Constants.UNGROUPED_VALUE && multispkState == Constants.MULTISPK_CONNECTING) {
                        groupStatus = Constants.GROUPING_PROGRESS_VALUE;
                    }
                    if (groupStatus == Constants.CONCERT_MASTER_VALUE && multispkState == Constants.MULTISPK_MORE_SLAVE_CONN) {
                        groupStatus = Constants.CONCERT_MASTER_TRANSITION_VALUE;
                    }
                    StringBuilder devId = new StringBuilder();
                    StringBuilder grpId = new StringBuilder();

                    {
                        //Device ID
                        devId.append(String.format("%02X", beacon[4]));
                        devId.append(String.format("%02X", beacon[5]));
                        devId.append(String.format("%02X", beacon[6]));
                        devId.append(String.format("%02X", beacon[7]));
                        devId.append(String.format("%02X", beacon[8]));
                        devId.append(String.format("%02X", beacon[9]));

                        if (devId.toString().equals("000000000000")) {
                            devId.replace(0, devId.length(), "UNKNOWN_");
                            devId.append(btDevice.getAddress());
                        }
                        BLELog.d(TAG, "Device Id=" + devId.toString());

                        //Group ID
                        grpId.append(String.format("%02X", beacon[4]));
                        grpId.append(String.format("%02X", beacon[5]));
                        grpId.append(String.format("%02X", beacon[6]));
                        grpId.append(String.format("%02X", beacon[7]));
                        grpId.append(String.format("%02X", beacon[8]));
                        grpId.append(String.format("%02X", beacon[9]));
                        BLELog.d(TAG, "Group Id=" + grpId.toString());


                        byte[] addr = new byte[6];
                        addr[0] = beacon[4];
                        addr[1] = beacon[5];
                        addr[2] = beacon[6];
                        addr[3] = beacon[7];
                        addr[4] = beacon[8];
                        addr[5] = beacon[9];
                        speaker.setmAddress(addr);
                        speaker.setBeaconCategory(3);
                    }

                    speaker.setDeviceId(devId.toString());
                    speaker.setName(btDevice.getName());
                    speaker.setBtDevice(btDevice);
                    speaker.setRssi(rssi);
                    speaker.setGroupAddress(grpId.toString());
                    speaker.setBatteryValue(batteryVal);
                    speaker.setGroupStatus(groupStatus);

                } else {
                    BLELog.d(TAG, "WST BEACON length mismatch device");
                    return;
                }

                if (btDevice.getName() == null)
                    speaker.setName("unknown");

                String deviceId = speaker.getDeviceId();

                if (deviceId.equals(mRecentBtAddress)) {
                    mSpeaker = speaker;
                    mHandler.removeCallbacksAndMessages(null);


                    dismissScanning();
                    initiateConnect(true);

                }

            }
        }
    }

 /*
    public BluetoothDevice getBtDeviceForDeviceId (String deviceID) {

        String formatedBtAddress = insertPeriodically(deviceID,":",2);
        BLELog.d(TAG, " formatedBtAddress" + formatedBtAddress);
        return BluetoothAdapter.getDefaultAdapter().getRemoteDevice(formatedBtAddress);

    }

   public BLESpeaker getBleSpeakerForDeviceId (String deviceID,BluetoothDevice btDevice) {

        BLESpeaker speaker  = new BLESpeaker();

        speaker.setDeviceId(deviceID);
        speaker.setName(btDevice.getName());
        speaker.setBtDevice(btDevice);
        speaker.setRssi(10);
        speaker.setGroupAddress(deviceID);
        speaker.setBatteryValue(10);
        speaker.setGroupStatus(Constants.UNGROUPED_VALUE);

        return speaker;

    }


    public static String insertPeriodically(
            String text, String insert, int period)
    {
        StringBuilder builder = new StringBuilder(
                text.length() + insert.length() * (text.length()/period)+1);

        int index = 0;
        String prefix = "";
        while (index < text.length())
        {
            // Don't put the insert in the very first iteration.
            // This is easier than appending it *after* each substring
            builder.append(prefix);
            prefix = insert;
            builder.append(text.substring(index,
                    Math.min(index + period, text.length())));
            index += period;
        }
        return builder.toString();
    }*/

    public void clearRecentConnectedDevice () {


        saveRecentConnectedDevGroup("","","");
        mRecentBtAddress = "";
        // Clear bundle information
        saveRecentBundleId("","");

    }

    private void showNoConnnectedDeviceAlertDialog() {
       // runOnUiThread(new Runnable() {

          //  public void run() {

                if (isBleConnected == false) {
                    final android.app.AlertDialog.Builder ad = new android.app.AlertDialog.Builder(EarbudsControllerActivity.this, R.style.MyDialogTheme);
                    ad.setMessage("No earbuds connected. Press OK to add new earbuds");

                    ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (isBleConnected == false) {
                                addNewDevice();
                            }
                        }
                    });

                    final android.app.AlertDialog alert = ad.create();
                    alert.setTitle("No earbuds Connected");
                    alert.show();

                    // Hide after some seconds

                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            /*if (isBleConnected == false) {
                                addNewDevice();
                            }*/

                        }
                    });
               // }
            //}


           }
        //);
    }
}
