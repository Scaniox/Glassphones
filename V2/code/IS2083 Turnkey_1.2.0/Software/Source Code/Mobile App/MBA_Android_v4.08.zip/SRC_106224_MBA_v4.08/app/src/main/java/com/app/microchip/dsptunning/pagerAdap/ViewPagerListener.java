package com.app.microchip.dsptunning.pagerAdap;

import android.support.v4.view.ViewPager;

/**
 * Created by I17163 on 12/12/2019.
 */

public  class ViewPagerListener implements ViewPager.OnPageChangeListener {


    ViewPagerListener(int  closure) {

    }
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
