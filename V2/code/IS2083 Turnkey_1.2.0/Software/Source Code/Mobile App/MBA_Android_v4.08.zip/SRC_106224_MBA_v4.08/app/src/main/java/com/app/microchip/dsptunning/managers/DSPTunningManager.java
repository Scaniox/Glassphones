package com.app.microchip.dsptunning.managers;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

/**
 * Created by I17163 on 8/13/2019.
 */

public class DSPTunningManager {
    public static final String TAG = DSPTunningManager.class.getSimpleName();



    private ByteBuffer prepareOutputBuffer(byte commend, int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        tempBuffer.put(commend);
        return tempBuffer;
    }

    private ByteBuffer prepareOutputBuffer(int len) {
        ByteBuffer tempBuffer = ByteBuffer.allocate(len);
        tempBuffer.order(ByteOrder.LITTLE_ENDIAN);
        return tempBuffer;
    }



}
