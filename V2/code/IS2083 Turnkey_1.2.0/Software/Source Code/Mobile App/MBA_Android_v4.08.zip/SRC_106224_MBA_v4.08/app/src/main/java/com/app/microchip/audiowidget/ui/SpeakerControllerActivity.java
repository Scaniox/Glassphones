package com.app.microchip.audiowidget.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.adapter.SpeakerControlAdapter;
import com.app.microchip.audiowidget.managers.BLEManager;
import com.app.microchip.audiowidget.managers.TransparentServiceManager;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


public class SpeakerControllerActivity extends AppCompatActivity {

    private final static String UART_CMD_MMI_ACTION_POWER_ON_PRESSED = "2 0 51";
    private final static String UART_CMD_MMI_ACTION_POWER_ON_RELEASED = "2 0 52";
    private final static String UART_CMD_MMI_ACTION_POWER_OFF_PRESSED = "2 0 53";
    private final static String UART_CMD_MMI_ACTION_POWER_OFF_RELEASED = "2 0 54";
    private final static int COMMAND_ACK_EVENT = 0;//0x00
    private final static int READ_EVT_BTM_STATUS = 1;
    private final static int READ_LINK_STATUS_REPLAY = 30; //0x1E
    private final static int READ_IC_VERSION_REPLAY = 56; //0x38
    private final static String UART_CMD_READ_LINK_STATUS = "0D 0";
    private final static String UART_CMD_READ_IC_VERSION = "32 0";
    private final static String UART_CMD_DISCONNECT = "32 0 0";
    private static final String TAG = SpeakerControllerActivity.class.getSimpleName();
    private BLESpeaker mSpeaker;
    private BLESpeaker mMasterSpeaker;
    private BLEManager mBleManager;
    private ArrayList<BLESpeaker> currentList;
    private SpeakerControlAdapter adapter;
    private ListView list;
    private String mDevId = "";
    private Switch powerValue;
    private TransparentServiceManager mTraspService;
    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver speakerInfoReceiver;
    private File mTempLogFile;
    private boolean mBackPressed = false;
    private ProgressDialog mDisConnectDialog;
    private Timer progressBarCancelTimer;

    private void dismissDisConnect() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mDisConnectDialog != null && mDisConnectDialog.isShowing()) {
                    mDisConnectDialog.dismiss();
                }
            }
        });
    }

    private void displayDisConnecting() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mDisConnectDialog != null)
                    mDisConnectDialog.show();
            }
        });
    }


    public static void setViewGroupEnabled(ViewGroup view, boolean enabled) {
        int childern = view.getChildCount();

        for (int i = 0; i < childern; i++) {
            View child = view.getChildAt(i);
            if (child instanceof ViewGroup) {
                setViewGroupEnabled((ViewGroup) child, enabled);
            }
            child.setEnabled(enabled);
        }
        view.setEnabled(enabled);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speaker_controller);

       // mBleManager = BLEManager.getBLEManager(HomeScreenActivity.getInstance());
        Intent intent = getIntent();
        String deviceId = intent.getStringExtra(Constants.DEVICE_ID);
        BLELog.d(TAG, "Device ID of selected speaker =" + deviceId);
        mDevId = deviceId;
        try {
            mTempLogFile = File.createTempFile("commandLog", null, this.getCacheDir());
        } catch (IOException e) {
            e.printStackTrace();
        }
        mTraspService = new TransparentServiceManager(HomeScreenActivity.getInstance(), mDevId, mTempLogFile);
        mTraspService.setDoNothandleGattClose(false);
        InitializeUI();

        transRxIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(TransparentServiceManager.BLE_DISCONNECTED);
        speakerInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (TransparentServiceManager.BLE_DISCONNECTED.equals(action)) {
                    if (mBackPressed) {
                        progressBarCancelTimer.cancel();
                        dismissDisConnect();
                        SpeakerControllerActivity.super.onBackPressed();
                        mBackPressed = false;
                        launchHomeScreen();
                    } else {
                        handleBLEDisconnection();
                    }
                }
                if (TransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (TransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(TransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i;
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Received Data byte[" + i + "]=" + (rxBytes[i] & 0xff));
                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            switch (rxBytes[3] & 0xff) {
                                case COMMAND_ACK_EVENT:
                                    String returnValue = "";
                                    switch (rxBytes[5] & 0xff) {
                                        case 0:
                                            returnValue = "Command complete";
                                            if ((rxBytes[4] & 0xff) == 0x32) {
                                                BLELog.d(TAG, "Disconnnet command found");
                                                mTraspService.cleanupTransparentService ();
                                                //SpeakerControllerActivity.super.onBackPressed();
                                                //launchHomeScreen();
                                            }
                                            break;
                                        case 1:
                                            returnValue = "Command dissallow";
                                            break;
                                        case 2:
                                            returnValue = "Unknown command";
                                            break;
                                        case 3:
                                            returnValue = "Parameters error";
                                            break;
                                        case 4:
                                            returnValue = "BTM is busy";
                                            break;
                                        case 5:
                                            returnValue = "BTM memory is full";
                                            break;
                                        default:
                                            returnValue = "unknown return value";
                                    }
                                    BLELog.d(TAG, "ACK for Command = " + (rxBytes[4] & 0xff) + "  ACK Return value =" + returnValue);
                                    if ((rxBytes[5] & 0xff) != 0) {
                                        commandError(returnValue + " For Command:" + (rxBytes[4] & 0xff));
                                    }
                                    break;
                                case READ_LINK_STATUS_REPLAY: {
                                    BLELog.d(TAG, "Reply for LINK STATUS");
                                    if ((rxBytes[4] & 0xff) == 0) {
                                        BLELog.d(TAG, "Power OFF state");
                                        powerValue.setChecked(false);
                                        powerStateChanged(false);
                                    } else {
                                        BLELog.d(TAG, "Power ON state");
                                        powerValue.setChecked(true);
                                        powerStateChanged(true);
                                    }
                                }
                                break;
                                case READ_IC_VERSION_REPLAY:
                                    String s = new String(rxBytes);
                                    BLELog.d(TAG, "Reply for READ_IC_VERSION_REPLAY::" + s);
                                    if (s.contains("5506_nSPK")) {
                                        BLELog.d(TAG, "ITS FLASH Device");
                                        mSpeaker.setFeatureValue((byte) 3);
                                        HomeScreenActivity.getInstance().updateSpeaker(mSpeaker);
                                    } else if (s.contains("5506_ROM_104")) {
                                        BLELog.d(TAG, "ITS ROM Device");
                                        mSpeaker.setFeatureValue((byte) 1);
                                        HomeScreenActivity.getInstance().updateSpeaker(mSpeaker);
                                    }
                                    break;
                                case READ_EVT_BTM_STATUS: {
                                    BLELog.d(TAG, "Event for BTM STATUS");
                                    if ((rxBytes[4] & 0xff) == 0x00) {
                                        BLELog.d(TAG, "Power OFF state");
                                        powerValue.setChecked(false);
                                        powerStateChanged(false);
                                    } else if ((rxBytes[4] & 0xff) == 0x02) {
                                        BLELog.d(TAG, "Power ON state");
                                        powerValue.setChecked(true);
                                        powerStateChanged(true);
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
            }

        };
    }

    private void commandError(final String message) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), message,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onPause() {
        BLELog.d(TAG, "onPause called");
       // if(mBackPressed){
            //mTraspService.cleanupTransparentService();
            //mBleManager.disconnect(mSpeaker.getBtDevice());
            //mBleManager.closeGatt(mSpeaker.getBtDevice());
       // }
        mTraspService.unregisterFragReceiver(speakerInfoReceiver);
        super.onPause();
    }

    @Override
    protected void onResume() {
        BLELog.d(TAG, "onResume called");
        super.onResume();
        mTraspService.registerFragReceiver(speakerInfoReceiver, transRxIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, transReadyIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, disconnectionfilter);
        InitializeUI();

        sendCommand(UART_CMD_READ_LINK_STATUS);


    }

    @Override
    protected void onStart() {
        BLELog.d(TAG, "onStart called");
        super.onStart();
    }

    @Override
    protected void onStop() {
        BLELog.d(TAG, "onStop called");
        super.onStop();
    }

    protected void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        super.onDestroy();



        mTraspService.cleanupTransparentService();
        /*if (mBleManager != null) {
            mBleManager.disconnect(mSpeaker.getBtDevice());
            mBleManager.closeGatt(mSpeaker.getBtDevice());
        }*/
        if (mTempLogFile.exists())
            mTempLogFile.delete();
    }

    public void onBackPressed(){
        mBackPressed=true;
        //super.onBackPressed();
        //Connect Dialog
        mDisConnectDialog = new ProgressDialog(this);
        mDisConnectDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mDisConnectDialog.setMessage("Disconnecting...");
        mDisConnectDialog.getWindow().setBackgroundDrawableResource(R.drawable.list_item_gradient_drawable1);
        mDisConnectDialog.setIndeterminate(true);
        mDisConnectDialog.setCancelable(false);
        mDisConnectDialog.setCanceledOnTouchOutside(false);


        displayDisConnecting();
        mTraspService.cleanupTransparentService ();
        //sendCommand(UART_CMD_DISCONNECT);

        progressBarCancelTimer = new Timer();
        progressBarCancelTimer.schedule(new TimerTask() {
            public void run() {
                 // when the task active then close the dialog
                dismissDisConnect();
                progressBarCancelTimer.cancel(); // also just top the timer thread, otherwise, you may receive a crash report
                launchHomeScreen();
            }
        }, 5000); // after 2 second (or 2000 miliseconds), the task will be active.

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.logmenu, menu);
        return true;
    }

    private void readLog() {
        String strLine = "";
        StringBuilder text = new StringBuilder();
        try {
            FileReader fReader = new FileReader(mTempLogFile);
            BufferedReader bReader = new BufferedReader(fReader);

            /** Reading the contents of the file , line by line */
            while ((strLine = bReader.readLine()) != null) {
                text.append(strLine + "\n");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(SpeakerControllerActivity.this, R.style.MyDialogTheme);
        builder.setMessage(text)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.log_option:
                readLog();
                return (true);
        }
        return (super.onOptionsItemSelected(item));
    }

    public void sendInitCommands() {
        BLELog.d(TAG, "Calling sendInit Commands here");
        sendCommand(UART_CMD_READ_LINK_STATUS);
        if (mSpeaker.getBeaconCategory() == 0)
            sendCommand(UART_CMD_READ_IC_VERSION);
    }

    public void InitializeUI() {
        mSpeaker = HomeScreenActivity.getInstance().getSpeaker(mDevId);
        if (HomeScreenActivity.getInstance().isSlaveMode) {
            mMasterSpeaker = HomeScreenActivity.getInstance().getSpeaker(mSpeaker.getGroupAddress());
        }
        setTitle(mSpeaker.getName());
        currentList = new ArrayList<>();
        currentList = (ArrayList) mSpeaker.getGroupInfo();
        if (HomeScreenActivity.getInstance().isSlaveMode) {
            currentList = (ArrayList) mMasterSpeaker.getGroupInfo();
        }
        adapter = new SpeakerControlAdapter(this, currentList);
        list = (ListView) findViewById(R.id.groupinfolist);
        list.setAdapter(adapter);


        if (mSpeaker.getGroupStatus() == Constants.CONCERT_MASTER_VALUE || mSpeaker.getGroupStatus() == Constants.STEREO_MASTER_VALUE) {
            TextView speakerSettings = (TextView) findViewById(R.id.speakerOrMaster);
            speakerSettings.setText("Master Settings");
        }

        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setCancelable(true);
        builder1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });

        RelativeLayout speakerSettings = (RelativeLayout) findViewById(R.id.speakersettings);
        speakerSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SpeakerSettingsActivity.class);
                intent.putExtra(Constants.DEVICE_ID, mSpeaker.getDeviceId());
                startActivity(intent);
            }
        });

        RelativeLayout groupsettings = (RelativeLayout) findViewById(R.id.groupsettings);
        groupsettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), GroupSettingsActivity.class);
                intent.putExtra(Constants.DEVICE_ID, mSpeaker.getDeviceId());
                startActivity(intent);
            }
        });
        if (mSpeaker.getBeaconCategory() == 2) {
            groupsettings.setVisibility(View.GONE);
            list.setVisibility(View.GONE);
        } else {
            groupsettings.setVisibility(View.VISIBLE);
            list.setVisibility(View.VISIBLE);
        }

        RelativeLayout audiorow = (RelativeLayout) findViewById(R.id.selectaudio);
        audiorow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AudioActivity.class);
                intent.putExtra(Constants.DEVICE_ID, mSpeaker.getDeviceId());
                startActivity(intent);
            }
        });
        powerValue = (Switch) findViewById(R.id.powervalue);
        powerValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (powerValue.isChecked()) {
                    sendCommand(UART_CMD_MMI_ACTION_POWER_ON_PRESSED);
                    sendCommand(UART_CMD_MMI_ACTION_POWER_ON_RELEASED);
                } else {
                    sendCommand(UART_CMD_MMI_ACTION_POWER_OFF_PRESSED);
                    sendCommand(UART_CMD_MMI_ACTION_POWER_OFF_RELEASED);
                }
            }
        });

        RelativeLayout commandWindow = (RelativeLayout) findViewById(R.id.commandWindow);
        commandWindow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CommandWindow.class);
                intent.putExtra(Constants.DEVICE_ID, mSpeaker.getDeviceId());
                startActivity(intent);
            }
        });

    }

    public void sendCommand(String cmd) {
        if (mTraspService.isConnected() == false) {
            handleBLEDisconnection();
        }
        if (mTraspService != null) {
            mTraspService.packAndSendCommand(cmd);
        }
    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                Intent home = new Intent(getApplicationContext(), HomeScreenActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }


    public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
            }
        });
        builder.show();
    }

    public void powerStateChanged(boolean isPowerdOn) {
        LinearLayout v = (LinearLayout) findViewById(R.id.speakerActions);
        if (isPowerdOn) setViewGroupEnabled(v, true);
        else setViewGroupEnabled(v, false);
    }
}
