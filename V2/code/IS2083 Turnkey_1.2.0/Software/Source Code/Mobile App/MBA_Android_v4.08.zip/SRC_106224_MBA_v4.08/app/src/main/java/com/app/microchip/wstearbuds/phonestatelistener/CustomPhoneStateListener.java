package com.app.microchip.wstearbuds.phonestatelistener;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.wstearbuds.ui.EarbudsControllerActivity;

/**
 * Created by I17163 on 11/15/2019.
 */

public  class CustomPhoneStateListener extends PhoneStateListener {

    //private static final String TAG = "PhoneStateChanged";
    Context context; //Context to make Toast if required
    public CustomPhoneStateListener(Context context) {
        super();
        this.context = context;
    }

    @Override
    public void onCallStateChanged(int state, String incomingNumber) {
        super.onCallStateChanged(state, incomingNumber);

        switch (state) {
            case TelephonyManager.CALL_STATE_IDLE:
                //when Idle i.e no call

                BLELog.d("CustomPhoneStateListener", "Phone state Idle");
                //Toast.makeText(context, "Phone state Idle", Toast.LENGTH_SHORT).show();

                if (EarbudsControllerActivity.getInstance() != null) {
                    if(EarbudsControllerActivity.getInstance().isSetScoReconnnectMode) {
                        try {
                            Thread.sleep(500);

                        } catch (java.lang.InterruptedException e) {
                            e.printStackTrace();
                        }

                        EarbudsControllerActivity.getInstance().checkAndReconnectDeviceAfterSco();
                    }


                }

                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                //when Off hook i.e in call
                //Make intent and start your service here
                BLELog.d("CustomPhoneStateListener", "Phone state Off hook");
               // Toast.makeText(context, "Phone state Off hook", Toast.LENGTH_SHORT).show();
                break;
            case TelephonyManager.CALL_STATE_RINGING:
                //when Ringing
                //Toast.makeText(context, "Phone state Ringing", Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }
    }
}