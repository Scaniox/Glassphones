package com.app.microchip.dsptunning.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;

import java.util.Arrays;


public class DspOTATunningMBDRCActivity extends AppCompatActivity  implements DSPTuningDelegate {

    private static final String TAG = DspOTATunningMBDRCActivity.class.getSimpleName();


    private static String[] param_table = {"Knee Th", "Compression Ratio", "Make-Up Gain",
            "Attack Time", "Release Time"};
    private static byte[] param_ids = {1, 2, 3, 4, 5};

    private static String[] Knee_Th_table = {"-6dBov", "-12dBov", "-18dBov", "-24dBov"};
    private static byte[] Knee_Th_ids = {1, 2, 3, 4};
    private static String[] CR_table = {"2/3", "1/2", "1/3", "1/4"}; //Compression Ratio
    private static byte[] CR_ids = {1, 2, 3, 4};
    private static String[] Gain_table = {"0dB", "1dB", "2dB", "3dB", "4dB", "5dB", "6dB",
            "7dB", "8dB", "9dB", "10dB", "11dB"};   //Make-Up Gain
    private static byte[] Gain_ids = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
    private static String[] Attack_time_table = {"10ms", "20ms", "50ms", "100ms"};
    private static byte[] Attack_time_ids = {1, 2, 3, 4};
    private static String[] Release_time_table = {"50ms", "100ms", "200ms", "700ms"};
    private static byte[] Release_time_ids = {1, 2, 3, 4};

    private static String[] Bass_table = {"0x00", "0x01", "0x02", "0x03", "0x04",
            "0x05", "0x06", "0x07"};
    private static byte[] Bass_ids = {1, 2, 3, 4, 5, 6, 7, 8};
    private static String[] Cutoff_freq_table = {"100Hz", "150Hz", "200Hz", "300Hz"};
    private static byte[] Cutoff_freq_ids = {1, 2, 3, 4};

    byte[] self_MBDRC_Data;
    Spinner parameters;
    Spinner Low_band;
    Spinner Middle_band;
    Spinner High_band;
    Spinner Bass_enhancement;
    Spinner Cutoff_Freq;
    private Button TuneDSP;
    TextView DSPState;
    private DspOTATunningBLEService mServie;
    private ProgressDialog mSpinnerDialog;

    private long fragFocusStartTime = 0;

    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            BLELog.d(TAG, "BroadcastReceiver action: " + action);
            if (action.equals(DspOTATunningBLEService.ACTION_GATT_SERVICES_DISCOVERED)) {
                dismissSpinnerDialog();
                Toast.makeText(DspOTATunningMBDRCActivity.this, "Connected", Toast.LENGTH_SHORT).show();


            } else if (action.equals(DspOTATunningBLEService.ACTION_GATT_DISCONNECTED)) {
                Toast.makeText(DspOTATunningMBDRCActivity.this, "Disconnected", Toast.LENGTH_SHORT).show();
                finish();


            } else if (action.equals(DspOTATunningBLEService.ACTION_DATA_AVAILABLE)) {


                BLELog.d(TAG, " ACTION_DATA_AVAILABLE ");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                    }
                });
            }


        }
    };


    private void dismissSpinnerDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSpinnerDialog != null && mSpinnerDialog.isShowing()) {
                    mSpinnerDialog.dismiss();
                }
            }
        });
    }

    private void displaySpinnerDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSpinnerDialog != null)
                    mSpinnerDialog.show();
            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mb_drc_audio_activity);


        mServie = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        mServie.setListener(DspOTATunningMBDRCActivity.this);

        Intent gattServiceIntent = new Intent(this, DspOTATunningBLEService.class);
        registerReceiver(mGattUpdateReceiver, makeIntentFilter());

        fragFocusStartTime = System.currentTimeMillis();

        InitializeUI();

    }

    ArrayAdapter<String> paramAdapter;

    ArrayAdapter<String> lowBbandAdapter;

    ArrayAdapter<String> middleBbandAdapter;

    ArrayAdapter<String> highBbandAdapter;

    ArrayAdapter<String> bassAdapter;

    ArrayAdapter<String> cutOffAdapter;


    public void InitializeUI() {


        paramAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                android.R.layout.simple_spinner_item, param_table);

        lowBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                android.R.layout.simple_spinner_item, param_table);

        middleBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                android.R.layout.simple_spinner_item, param_table);

        highBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                android.R.layout.simple_spinner_item, param_table);

        bassAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                android.R.layout.simple_spinner_item, Bass_table);

        cutOffAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                android.R.layout.simple_spinner_item, Cutoff_freq_table);


        DSPState = (TextView) findViewById(R.id.deviceStatus);
        TuneDSP = (Button) findViewById(R.id.tuneDspButton);

        parameters = (Spinner) findViewById(R.id.Spinner1);
        Low_band = (Spinner) findViewById(R.id.Spinner2);
        Middle_band = (Spinner) findViewById(R.id.Spinner3);
        High_band = (Spinner) findViewById(R.id.Spinner4);
        Bass_enhancement = (Spinner) findViewById(R.id.Spinner5);
        Cutoff_Freq = (Spinner) findViewById(R.id.Spinner6);


        parameters.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                fragFocusStartTime = System.currentTimeMillis();

                if (pos == 0) {//            if(selectedText == "Knee Th"){
                    lowBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Knee_Th_table);
                    lowBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Low_band.setAdapter(lowBbandAdapter);

                    middleBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Knee_Th_table);
                    middleBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Middle_band.setAdapter(middleBbandAdapter);


                    highBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Knee_Th_table);
                    highBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    High_band.setAdapter(highBbandAdapter);


                    BLELog.d(TAG, "MBDRC byte 1" + String.format("%02x", self_MBDRC_Data[0]));


                    int Low_band_selectedIndex = (int) (self_MBDRC_Data[0] & 0x03);
                    BLELog.d(TAG, "bit[0:1 Low_band_selectedIndex =" + Low_band_selectedIndex);

                    int Middle_band_selectedIndex = (int) ((self_MBDRC_Data[0] & 0x0C) >> 2);
                    BLELog.d(TAG, " bit[2:3]Middle_band_selectedIndex =" + Middle_band_selectedIndex);

                    int High_band_selectedIndex = ((int) (self_MBDRC_Data[0] & 0x30)) >> 4;
                    BLELog.d(TAG, " bit[4:5]High_band_selectedIndex =" + High_band_selectedIndex);


                    Low_band.setSelection(Low_band_selectedIndex);
                    Middle_band.setSelection(Middle_band_selectedIndex);
                    High_band.setSelection(High_band_selectedIndex);


                } else if (pos == 1) {// if(selectedText == "Compression Ratio"){

                    lowBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, CR_table);
                    lowBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Low_band.setAdapter(lowBbandAdapter);

                    middleBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, CR_table);
                    middleBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Middle_band.setAdapter(middleBbandAdapter);

                    highBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, CR_table);
                    highBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    High_band.setAdapter(highBbandAdapter);

                    BLELog.d(TAG, "MBDRC byte 2" + String.format("%02x", self_MBDRC_Data[1]));


                    int Low_band_selectedIndex = (int) (self_MBDRC_Data[1] & 0x03);
                    BLELog.d(TAG, "bit[0:1 Low_band_selectedIndex =" + Low_band_selectedIndex);

                    int Middle_band_selectedIndex = (int) ((self_MBDRC_Data[1] & 0x0C) >> 2);
                    BLELog.d(TAG, " bit[2:3]Middle_band_selectedIndex =" + Middle_band_selectedIndex);

                    int High_band_selectedIndex = ((int) (self_MBDRC_Data[1] & 0x30)) >> 4;
                    BLELog.d(TAG, " bit[4:5]High_band_selectedIndex =" + High_band_selectedIndex);


                    Low_band.setSelection(Low_band_selectedIndex);
                    Middle_band.setSelection(Middle_band_selectedIndex);
                    High_band.setSelection(High_band_selectedIndex);

                } else if (pos == 2) {// if(selectedText == "Make-Up Gain"){

                    lowBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Gain_table);
                    lowBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Low_band.setAdapter(lowBbandAdapter);

                    middleBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Gain_table);
                    middleBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Middle_band.setAdapter(middleBbandAdapter);

                    highBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Gain_table);
                    highBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    High_band.setAdapter(highBbandAdapter);

                    BLELog.d(TAG, "MBDRC byte 3" + String.format("%02x", self_MBDRC_Data[2]));


                    int Low_band_selectedIndex = (int) (self_MBDRC_Data[2] & 0x0f);
                    BLELog.d(TAG, "bit[0:3 Low_band_selectedIndex =" + Low_band_selectedIndex);

                    int Middle_band_selectedIndex = (int) ((self_MBDRC_Data[2] & 0xF0) >> 4);
                    BLELog.d(TAG, " bit[4:7]Middle_band_selectedIndex =" + Middle_band_selectedIndex);

                    BLELog.d(TAG, "MBDRC byte 4" + String.format("%02x", self_MBDRC_Data[3]));
                    int High_band_selectedIndex = ((int) (self_MBDRC_Data[3] & 0x0f));
                    BLELog.d(TAG, " bit[0:3]High_band_selectedIndex =" + High_band_selectedIndex);


                    Low_band.setSelection(Low_band_selectedIndex);
                    Middle_band.setSelection(Middle_band_selectedIndex);
                    High_band.setSelection(High_band_selectedIndex);

                } else if (pos == 3) {// if(selectedText == "Attack Time"){


                    lowBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Attack_time_table);
                    lowBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Low_band.setAdapter(lowBbandAdapter);

                    middleBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Attack_time_table);
                    middleBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Middle_band.setAdapter(middleBbandAdapter);

                    highBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Attack_time_table);
                    highBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    High_band.setAdapter(highBbandAdapter);

                    BLELog.d(TAG, "MBDRC byte 7" + String.format("%02x", self_MBDRC_Data[6]));


                    int Low_band_selectedIndex = (int) (self_MBDRC_Data[6] & 0x03);
                    BLELog.d(TAG, "bit[0:1 Low_band_selectedIndex =" + Low_band_selectedIndex);

                    int Middle_band_selectedIndex = (int) ((self_MBDRC_Data[6] & 0x0C) >> 2);
                    BLELog.d(TAG, " bit[2:3]Middle_band_selectedIndex =" + Middle_band_selectedIndex);

                    int High_band_selectedIndex = ((int) (self_MBDRC_Data[6] & 0x30)) >> 4;
                    BLELog.d(TAG, " bit[4:5]High_band_selectedIndex =" + High_band_selectedIndex);


                    Low_band.setSelection(Low_band_selectedIndex);
                    Middle_band.setSelection(Middle_band_selectedIndex);
                    High_band.setSelection(High_band_selectedIndex);

                } else if (pos == 4) {// if(selectedText == "Release Time"){


                    lowBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Release_time_table);
                    lowBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Low_band.setAdapter(lowBbandAdapter);

                    middleBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Release_time_table);
                    middleBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Middle_band.setAdapter(middleBbandAdapter);

                    highBbandAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                            android.R.layout.simple_spinner_item, Release_time_table);
                    highBbandAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    High_band.setAdapter(highBbandAdapter);

                    BLELog.d(TAG, "MBDRC byte 4" + String.format("%02x", self_MBDRC_Data[3]));


                    int Low_band_selectedIndex = ((int) (self_MBDRC_Data[3] & 0x30)) >> 4;
                    ;
                    BLELog.d(TAG, "bit[4:5 Low_band_selectedIndex =" + Low_band_selectedIndex);

                    int Middle_band_selectedIndex = (int) ((self_MBDRC_Data[3] & 0xC0) >> 6);
                    BLELog.d(TAG, " bit[6:7]Middle_band_selectedIndex =" + Middle_band_selectedIndex);

                    BLELog.d(TAG, "MBDRC byte 7" + String.format("%02x", self_MBDRC_Data[6]));
                    int High_band_selectedIndex = (int) ((self_MBDRC_Data[6] & 0xC0) >> 6);
                    BLELog.d(TAG, " bit[6:7]High_band_selectedIndex =" + High_band_selectedIndex);


                    Low_band.setSelection(Low_band_selectedIndex);
                    Middle_band.setSelection(Middle_band_selectedIndex);
                    High_band.setSelection(High_band_selectedIndex);

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        Low_band.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();
                enableTuneDspButton();

                if (parameters.getSelectedItemPosition() == 0) {//            if(selectedText == "Knee Th"){

                    BLELog.d(TAG, "Old MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));
                    self_MBDRC_Data[0] &= ~(0x03);
                    self_MBDRC_Data[0] |= (byte) pos;
                    BLELog.d(TAG, "NEW MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));
                    //Update_MBDRC_Param();

                } else if (parameters.getSelectedItemPosition() == 1) {// if(selectedText == "Compression Ratio"){
                    BLELog.d(TAG, "Old MBDRC_Data[1] =" + String.format("%02x", self_MBDRC_Data[1]));
                    self_MBDRC_Data[1] &= ~(0x03);
                    self_MBDRC_Data[1] |= (byte) pos;
                    BLELog.d(TAG, "NEW MBDRC_Data[1] =" + String.format("%02x", self_MBDRC_Data[1]));
                    //Update_MBDRC_Param();

                } else if (parameters.getSelectedItemPosition() == 2) {// if(selectedText == "Make-Up Gain"){

                    BLELog.d(TAG, "Old MBDRC_Data[2] =" + String.format("%02x", self_MBDRC_Data[2]));
                    self_MBDRC_Data[2] &= ~(0x0f);
                    self_MBDRC_Data[2] |= (byte) pos;
                    BLELog.d(TAG, "NEW MBDRC_Data[2] =" + String.format("%02x", self_MBDRC_Data[2]));
                    //Update_MBDRC_Param();

                } else if (parameters.getSelectedItemPosition() == 3) {// if(selectedText == "Attack Time"){
                    BLELog.d(TAG, "Old MBDRC_Data[6] =" + String.format("%02x", self_MBDRC_Data[6]));
                    self_MBDRC_Data[6] &= ~(0x03);
                    self_MBDRC_Data[6] |= (byte) pos;
                    BLELog.d(TAG, "NEW MBDRC_Data[6] =" + String.format("%02x", self_MBDRC_Data[6]));
                    //Update_MBDRC_Param();

                } else if (parameters.getSelectedItemPosition() == 4) {// if(selectedText == "Release Time"){
                    BLELog.d(TAG, "Old MBDRC_Data[3] =" + String.format("%02x", self_MBDRC_Data[3]));
                    self_MBDRC_Data[3] &= ~(0x30);
                    self_MBDRC_Data[3] |= (byte) (pos << 4);
                    BLELog.d(TAG, "NEW MBDRC_Data[3] =" + String.format("%02x", self_MBDRC_Data[3]));
                    //Update_MBDRC_Param();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        Middle_band.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();
                enableTuneDspButton();

                if (parameters.getSelectedItemPosition() == 0) {//            if(selectedText == "Knee Th"){
                    BLELog.d(TAG, "Old MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));
                    self_MBDRC_Data[0] &= ~(0x0C);
                    self_MBDRC_Data[0] |= (byte) (pos << 2);
                    BLELog.d(TAG, "NEW MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));
                    //Update_MBDRC_Param();
                } else if (parameters.getSelectedItemPosition() == 1) {// if(selectedText == "Compression Ratio"){
                    BLELog.d(TAG, "Old MBDRC_Data[1] =" + String.format("%02x", self_MBDRC_Data[1]));
                    self_MBDRC_Data[1] &= ~(0x0C);
                    self_MBDRC_Data[1] |= (byte) (pos << 2);
                    BLELog.d(TAG, "NEW MBDRC_Data[1] =" + String.format("%02x", self_MBDRC_Data[1]));
                    //Update_MBDRC_Param();

                } else if (parameters.getSelectedItemPosition() == 2) {// if(selectedText == "Make-Up Gain"){
                    BLELog.d(TAG, "Old MBDRC_Data[2] =" + String.format("%02x", self_MBDRC_Data[2]));
                    self_MBDRC_Data[2] &= ~(0xF0);
                    self_MBDRC_Data[2] |= (byte) (pos << 4);
                    BLELog.d(TAG, "NEW MBDRC_Data[2] =" + String.format("%02x", self_MBDRC_Data[2]));

                } else if (parameters.getSelectedItemPosition() == 3) {// if(selectedText == "Attack Time"){
                    BLELog.d(TAG, "Old MBDRC_Data[6] =" + String.format("%02x", self_MBDRC_Data[6]));
                    self_MBDRC_Data[6] &= ~(0x0C);
                    self_MBDRC_Data[6] |= (byte) (pos << 2);
                    BLELog.d(TAG, "NEW MBDRC_Data[6] =" + String.format("%02x", self_MBDRC_Data[6]));
                    //Update_MBDRC_Param();

                } else if (parameters.getSelectedItemPosition() == 4) {// if(selectedText == "Release Time"){

                    BLELog.d(TAG, "Old MBDRC_Data[3] =" + String.format("%02x", self_MBDRC_Data[3]));
                    self_MBDRC_Data[3] &= ~(0x0C);
                    self_MBDRC_Data[3] |= (byte) (pos << 6);
                    BLELog.d(TAG, "NEW MBDRC_Data[3] =" + String.format("%02x", self_MBDRC_Data[3]));
                    //Update_MBDRC_Param();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        High_band.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                enableTuneDspButton();

                if (parameters.getSelectedItemPosition() == 0) {//            if(selectedText == "Knee Th"){
                    BLELog.d(TAG, "Old MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));
                    self_MBDRC_Data[0] &= ~(0x30);
                    self_MBDRC_Data[0] |= (byte) (pos << 4);
                    BLELog.d(TAG, "NEW MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));
                    //Update_MBDRC_Param();;
                } else if (parameters.getSelectedItemPosition() == 1) {// if(selectedText == "Compression Ratio"){
                    BLELog.d(TAG, "Old MBDRC_Data[1] =" + String.format("%02x", self_MBDRC_Data[1]));
                    self_MBDRC_Data[1] &= ~(0x30);
                    self_MBDRC_Data[1] |= (byte) (pos << 4);
                    BLELog.d(TAG, "NEW MBDRC_Data[1] =" + String.format("%02x", self_MBDRC_Data[1]));
                    //Update_MBDRC_Param();;

                } else if (parameters.getSelectedItemPosition() == 2) {// if(selectedText == "Make-Up Gain"){
                    BLELog.d(TAG, "Old MBDRC_Data[3] =" + String.format("%02x", self_MBDRC_Data[3]));
                    self_MBDRC_Data[3] &= ~(0x0f);
                    self_MBDRC_Data[3] |= (byte) pos;
                    BLELog.d(TAG, "NEW MBDRC_Data[3] =" + String.format("%02x", self_MBDRC_Data[3]));
                    //Update_MBDRC_Param();
                } else if (parameters.getSelectedItemPosition() == 3) {// if(selectedText == "Attack Time"){
                    BLELog.d(TAG, "Old MBDRC_Data[6] =" + String.format("%02x", self_MBDRC_Data[6]));
                    self_MBDRC_Data[6] &= ~(0x30);
                    self_MBDRC_Data[6] |= (byte) (pos << 4);
                    BLELog.d(TAG, "NEW MBDRC_Data[06] =" + String.format("%02x", self_MBDRC_Data[6]));
                    //Update_MBDRC_Param();;

                } else if (parameters.getSelectedItemPosition() == 4) {// if(selectedText == "Release Time"){
                    BLELog.d(TAG, "Old MBDRC_Data[6] =" + String.format("%02x", self_MBDRC_Data[6]));
                    self_MBDRC_Data[6] &= ~(0xC0);
                    self_MBDRC_Data[6] |= (byte) (pos << 6);
                    BLELog.d(TAG, "NEW MBDRC_Data[06] =" + String.format("%02x", self_MBDRC_Data[6]));
                    ////Update_MBDRC_Param();;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        Cutoff_Freq.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                enableTuneDspButton();

                BLELog.d(TAG, "Cuttoff Old MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));
                self_MBDRC_Data[0] &= ~(0xC0);
                self_MBDRC_Data[0] |= (byte) (pos << 6);
                BLELog.d(TAG, "Cuttoff NEW MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });


        Bass_enhancement.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                enableTuneDspButton();

                BLELog.d(TAG, "Bass Old MBDRC_Data[7] =" + String.format("%02x", self_MBDRC_Data[7]));
                self_MBDRC_Data[7] = (byte) (0xC0 + pos);
                BLELog.d(TAG, "Bass NEW MBDRC_Data[7] =" + String.format("%02x", self_MBDRC_Data[7]));
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });


        {

            paramAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            parameters.setAdapter(paramAdapter);
        }


        {
            ArrayAdapter<String> bassAdapter;
            bassAdapter = new ArrayAdapter<String>(DspOTATunningMBDRCActivity.this,
                    android.R.layout.simple_spinner_item, Bass_table);
            bassAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            Bass_enhancement.setAdapter(bassAdapter);
        }

        {

            cutOffAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            Cutoff_Freq.setAdapter(cutOffAdapter);
        }


        setTitle("MB-DRC");
        if (DSPState != null)
            DSPState.setText(mServie.DSP_DUT_State);


        MBDRC_Init();

        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (self_MBDRC_Data != null) {

                    mServie.DSPTuning((byte) 0x0C, (byte) 0x02, (byte) self_MBDRC_Data.length, self_MBDRC_Data);

                }
            }
        });

        disableTuneDspButton();
        updateFunctionButtonsState();

    }

    private void enableTuneDspButton() {

        long fragFocucEndTime =  System.currentTimeMillis();

        long fragAutoEventTimeElapsed = fragFocucEndTime - fragFocusStartTime ;

        Log.d(TAG,"LineIn_Threshold fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

        if (fragAutoEventTimeElapsed > 1000) {
            TuneDSP.setEnabled(true);
            TuneDSP.setTextColor(Color.WHITE);
        }

    }

    private void disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }

    private synchronized void updateFunctionButtonsState() {

        runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                if (mServie.dynamicToolMode == mServie.TuneDSPMode_NotSupport || mServie.dynamicToolMode == mServie.TuneDSPMode_Voice) {
                    parameters.setEnabled(false);
                    Low_band.setEnabled(false);
                    Middle_band.setEnabled(false);
                    High_band.setEnabled(false);
                    Cutoff_Freq.setEnabled(false);
                    Bass_enhancement.setEnabled(false);
                    TuneDSP.setEnabled(false);
                } else if (mServie.dynamicToolMode == mServie.TuneDSPMode_Audio) {
                    parameters.setEnabled(true);
                    Low_band.setEnabled(true);
                    Middle_band.setEnabled(true);
                    High_band.setEnabled(true);
                    Cutoff_Freq.setEnabled(true);
                    Bass_enhancement.setEnabled(true);
                }
            }

        }));
    }

    private void Update_MBDRC_Param() {

        if ((self_MBDRC_Data != null) && (mServie.MBDRC_Data != null)) {
            mServie.MBDRC_Data = null;

            mServie.MBDRC_Data = Arrays.copyOfRange(self_MBDRC_Data, 0, self_MBDRC_Data.length);

            BLELog.d(TAG, "MBDRC update data =" + HexTool.byteArrayToHexString(mServie.MBDRC_Data));
        }

    }

    void MBDRC_Init() {

        if (mServie.MBDRC_Data == null)
            return;

        self_MBDRC_Data = Arrays.copyOfRange(mServie.MBDRC_Data, 0, mServie.MBDRC_Data.length);

        BLELog.d(TAG, "(MBDRC_Data.count)" + self_MBDRC_Data.length);
        BLELog.d(TAG, "[MBDRC_Init]MBDRC_Data = " + HexTool.byteArrayToHexString(self_MBDRC_Data));

        if (parameters.getSelectedItemPosition() == 0) {  //Knee Th
            BLELog.d(TAG, " MBDRC_Data[0] =" + String.format("%02x", self_MBDRC_Data[0]));

            int Low_band_electedIndex = (int) (self_MBDRC_Data[0] & 0x03);
            BLELog.d(TAG, "Low_band_electedIndex = " + Low_band_electedIndex);
            Low_band.setSelection(Low_band_electedIndex);


            int Middle_band_selectedIndex = ((int) (self_MBDRC_Data[0] & 0x0C)) >> 2;
            BLELog.d(TAG, "Middle_band_selectedIndex = " + Middle_band_selectedIndex);
            Middle_band.setSelection(Middle_band_selectedIndex);


            int High_band_selectedIndex = ((int) (self_MBDRC_Data[0] & 0x30)) >> 4;
            BLELog.d(TAG, "High_band_selectedIndex = " + High_band_selectedIndex);
            High_band.setSelection(High_band_selectedIndex);


            int Cutoff_Freq_selectedIndex = ((int) (self_MBDRC_Data[0] & 0xC0)) >> 6;
            BLELog.d(TAG, "Cutoff_Freq_selectedIndex = " + Cutoff_Freq_selectedIndex);
            Cutoff_Freq.setSelection(Cutoff_Freq_selectedIndex);

        }


        int Bass_enhancement_selectedIndex = 0;
        if ((self_MBDRC_Data[1] & 0x40) == 0x40) {
            Bass_enhancement_selectedIndex = (int) (self_MBDRC_Data[7] & 0x07);
        }
        BLELog.d(TAG, "Bass_enhancement_selectedIndex = " + Bass_enhancement_selectedIndex);

        Bass_enhancement.setSelection(Bass_enhancement_selectedIndex);


    }


    private static IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(DspOTATunningBLEService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(DspOTATunningBLEService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(DspOTATunningBLEService.ACTION_GATT_SERVICES_DISCOVERED);

        return intentFilter;
    }

    private void commandError(final String message) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), message,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onPause() {
        BLELog.d(TAG, "onPause called");

        super.onPause();
    }

    @Override
    protected void onResume() {
        BLELog.d(TAG, "onResume called");
        super.onResume();

        if (DSPState != null) {
            DSPState.setText(mServie.DSP_DUT_State);

            if (mServie == null)
                updateFunctionButtonsState();
        }

    }

    @Override
    protected void onStart() {
        BLELog.d(TAG, "onStart called");
        super.onStart();
    }

    @Override
    protected void onStop() {
        BLELog.d(TAG, "onStop called");
        super.onStop();
    }

    protected void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        unregisterReceiver(mGattUpdateReceiver);

        super.onDestroy();

    }

    public void onBackPressed(){

        super.onBackPressed();

    }









    public void sendCommand(String cmd) {

    }


    @Override
    public void BLE_ServiceReady() {

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] Data) {

    }

    private void showTuneDspDialog(String message) {


            final android.app.AlertDialog.Builder ad = new android.app.AlertDialog.Builder(DspOTATunningMBDRCActivity.this , R.style.MyDialogTheme);
            ad.setMessage(message);

            ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
            /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
            sendBroadcast(i);
              mOtaState.setText("Completed");*/
                }
            });

            final android.app.AlertDialog alert = ad.create();
            alert.setTitle("Tune DSP Status!!");
            alert.show();



            alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {

                }
            });


    }
String dialogMessage = "";
    @Override
    public void DSPTuningComplete(byte result) {

        String  status = "";

        if(result == 0x01){
            Update_MBDRC_Param();
            status = "Success";
        }
        else{
            status = "Failed " + result;
        }
        dialogMessage = status;

        runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                showTuneDspDialog(dialogMessage);

            }
        }));

        runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                disableTuneDspButton();

            }
        }));


    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {

        Log.d(TAG, "DSPTuningState" + state);
        if (DSPState!= null)
            DSPState.setText(state);

        updateFunctionButtonsState();    }

    @Override
    public void ExportDSPTuningResult() {

    }
}
