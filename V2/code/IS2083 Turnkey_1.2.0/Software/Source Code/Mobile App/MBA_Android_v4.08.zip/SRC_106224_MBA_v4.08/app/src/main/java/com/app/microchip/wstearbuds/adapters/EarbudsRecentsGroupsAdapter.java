package com.app.microchip.wstearbuds.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by I21309 on 6/7/2017.
 */


public class EarbudsRecentsGroupsAdapter extends BaseAdapter {

    private static LayoutInflater inflater = null;
    private Activity activity;
    private ArrayList<HashMap<String, String>> data;

    public EarbudsRecentsGroupsAdapter(Activity a, ArrayList<HashMap<String, String>> d) {
        activity = a;
        data = d;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    public int getCount() {
        return data.size();
    }


    public Object getItem(int position) {
        return position;
    }


    public long getItemId(int position) {
        return position;
    }


    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null)
            vi = inflater.inflate(R.layout.recent_group_list_row, null);

        TextView groupName = (TextView) vi.findViewById(R.id.groupName);
        //    TextView createButton = (TextView) vi.findViewById(R.id.create);


        HashMap<String, String> entry = new HashMap<>();
        entry = data.get(position);
        groupName.setText(entry.get("name"));
        ImageView imageClick = (ImageView) vi.findViewById(R.id.recentGroupOptions);


        return vi;
    }

}