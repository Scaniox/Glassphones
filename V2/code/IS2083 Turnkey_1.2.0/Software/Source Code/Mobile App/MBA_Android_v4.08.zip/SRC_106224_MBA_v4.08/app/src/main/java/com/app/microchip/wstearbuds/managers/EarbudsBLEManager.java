package com.app.microchip.wstearbuds.managers;

/**
 * Created by I17163(Swaminathan Balaji) on 12/29/2016.
 */

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;

import com.app.microchip.audiowidget.models.BLESpeaker;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Bluetooth Low Energy Service Bearer layer
 */
public class EarbudsBLEManager {

    public static final String TAG = EarbudsBLEManager.class.getSimpleName();
    private static EarbudsBLEManager ourInstance = null;
    Context mCtx;
    private BluetoothGattCallback mGattCallback;
    private List<BluetoothGattCallback> mListeners;
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic chrc) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onCharacteristicChanged(gatt, chrc);
                }
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic chrc, int status) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onCharacteristicRead(gatt, chrc, status);
                }
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic chrc, int status) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onCharacteristicWrite(gatt, chrc, status);
                }
            }
        }

        @Override
        public synchronized void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onConnectionStateChange(gatt, status, newState);
                }
            }
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onDescriptorRead(gatt, descriptor, status);
                }
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onDescriptorWrite(gatt, descriptor, status);
                }
            }
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onReadRemoteRssi(gatt, rssi, status);
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onServicesDiscovered(gatt, status);
                }
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            synchronized (mListeners) {
                Iterator<BluetoothGattCallback> it = mListeners.iterator();
                while (it.hasNext()) {
                    it.next().onMtuChanged(gatt, mtu, status);
                }
            }
        }
    };
    private Object mLock;
    private BluetoothGatt mGatt = null;
    private BLESpeaker mConnectedSpeaker = null;
    private BluetoothAdapter mBTAdapter;

    private EarbudsBLEManager(Context context) {
        mCtx = context;
        mLock = new Object();
        mListeners = new ArrayList<BluetoothGattCallback>();
        final BluetoothManager bluetoothManager =
                (BluetoothManager) mCtx.getSystemService(Context.BLUETOOTH_SERVICE);
        mBTAdapter = bluetoothManager.getAdapter();

        if (mBTAdapter == null) {
            // Print errror
            return;
        }


    }

    public synchronized void cleanup() {
        if (mGatt != null) {
            mGatt.close();
            mGatt = null;
        }
        ourInstance = null;

    }

    public static EarbudsBLEManager getBLEManager(Context context) {
        if (null == ourInstance)
            ourInstance = new EarbudsBLEManager(context);

        return ourInstance;
    }

    /**
     * check if BLE Supported device
     */
    public static boolean isLESupported(Context context) {
        return context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE);
    }

    /**
     * get BluetoothManager
     */
    public static BluetoothManager getBluetoothManager(Context context) {
        return (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
    }

    public static boolean refreshDeviceCache(BluetoothGatt gatt) {
        try {
            Method localMethod = gatt.getClass().getMethod("refresh");
            if (localMethod != null) {
                return (Boolean) localMethod.invoke(gatt);
            }
        } catch (Exception localException) {
            Log.v(TAG, "Exeception occured while clearing cache");
        }
        return false;
    }

    public BLESpeaker getConnectedSpeaker() {
        return mConnectedSpeaker;
    }

    public void setConnectedSpeaker(BLESpeaker mConnectedSpeaker) {
        this.mConnectedSpeaker = mConnectedSpeaker;
    }

    public List<BluetoothDevice> getConnectedDevices() {
        BluetoothManager mgr = (BluetoothManager) mCtx.getSystemService(Context.BLUETOOTH_SERVICE);
        return mgr.getConnectedDevices(BluetoothProfile.GATT);
    }

    public boolean isConnected() {
        if (mConnectedSpeaker == null)
            return false;
        else
            return true;
    }

    public BluetoothDevice getConnectedDevice() {
        if (isConnected())
            return mConnectedSpeaker.getBtDevice();
        else
            return null;
    }

    public synchronized void addListener(BluetoothGattCallback l) {
        synchronized (mLock) {
            mListeners.add(l);
        }
    }

    public synchronized boolean  removeListener(BluetoothGattCallback l) {
        synchronized (mLock) {
            return mListeners.remove(l);
        }
    }
    public synchronized boolean  removeAllListener(BluetoothGattCallback l) {
        synchronized (mLock) {
            mListeners.clear();
            return true;
        }
    }

    private void releaseGatt() {
        synchronized (mLock) {
            if (mGatt != null) {
                mGatt.disconnect();
                mGatt.close();
            }
            mGatt = null;
        }
    }

    public synchronized void closeGatt(BluetoothDevice device) {
        /* In general, there should be an activity that close an Gatt when
         * onDestroy. However, if user press-back-key too fast, this Service will
         * release Gatt before destroying the activity, therefore Gatt might be null
         * when activity do closing Gatt.*/
        if (mGatt != null) {
            mGatt.close();
            mGatt = null;
        }
    }

    /**
     * Invoke this method to initialize Gatt before using Gatt.
     * <p>
     * FIXME: right now we support connect to just 1 device.
     */

    public boolean requestMtu(int mtu) {
        return mGatt.requestMtu(mtu);
    }

    public synchronized BluetoothGatt connectGatt(Context ctx, boolean auto, BluetoothDevice dev, int connType) {
        if (mGatt != null) {
            mGatt.close();
            disconnect(dev);
            closeGatt(dev);
            Log.d(TAG, "balaji Previous connection Not closed properly");
        }
        // Todo connect with transport layer. If transport layer is required add here




        mGatt = dev.connectGatt(ctx, auto, gattCallback, connType);
        //refreshDeviceCache(mGatt);
        //Log.d(TAG, "balaji refreshDeviceCache");
        return mGatt;
    }

    public void startScan(List<ScanFilter> filters, ScanSettings settings, ScanCallback clbk) {

        mBTAdapter.getBluetoothLeScanner().startScan(filters, settings, clbk);
    }

   /* public void startScan( ScanCallback clbk) {

        mBTAdapter.getBluetoothLeScanner().startScan( clbk);
    }*/

    public void stopScan(ScanCallback clbk) {

        mBTAdapter.getBluetoothLeScanner().stopScan(clbk);
        Log.d(TAG, "balaji stopScan");
    }

    public boolean connect(BluetoothDevice device, boolean auto) {
        return mGatt.connect();
    }

    public void disconnect(BluetoothDevice device) {

        if (mGatt != null) {
            mGatt.disconnect();
        }
    }

    public BluetoothGatt getGatt() {
        return mGatt;
    }

    public synchronized boolean discoverServices(BluetoothDevice device) {
        if (mGatt != null) {
            return mGatt.discoverServices();
        }else {
            Log.d(TAG, "discoverServices mGatt NULL");
            return false;
        }
    }

    /*  public int getConnectionState(BluetoothDevice device) {
          return mGatt.getConnectionState(device);
      }
      */
    public int getConnectionState(BluetoothDevice device) {
        BluetoothManager mgr = (BluetoothManager) mCtx.getSystemService(Context.BLUETOOTH_SERVICE);
        return mgr.getConnectionState(device, BluetoothProfile.GATT);
    }

    public BluetoothGattService getService(BluetoothDevice device, UUID uuid) {
        return mGatt.getService(uuid);
    }

    public synchronized List<BluetoothGattService> getServices(BluetoothDevice device) {
        if (mGatt != null) {
            return mGatt.getServices();
        } else {
            List<BluetoothGattService> result =
                    new ArrayList<BluetoothGattService>();
            Log.d(TAG, "getServices mGatt NULL");
            return  result;
        }
    }

    public boolean readCharacteristic(BluetoothGattCharacteristic chr) {
        if (mGatt != null && chr != null) {
            return mGatt.readCharacteristic(chr);
        }
        return  false;
    }

    public boolean writeCharacteristic(BluetoothGattCharacteristic chr) {
        if (mGatt != null && chr != null) {
            return mGatt.writeCharacteristic(chr);
        }
        return  false;
    }

    public synchronized void setMtuSize() {
        boolean result = mGatt.requestMtu(96);
        Log.d(TAG,"requestMtu = "+result);

    }

    public boolean readDescriptor(BluetoothGattDescriptor dsc) {
        return mGatt.readDescriptor(dsc);
    }

    public boolean writeDescriptor(BluetoothGattDescriptor dsc) {
        Log.d(TAG, "mGatt.writeDescriptor : LeService");
        return mGatt.writeDescriptor(dsc);
    }

    public boolean setCharacteristicNotification(BluetoothGattCharacteristic chr, boolean enable) {
        if (mGatt != null && chr != null) {
            Log.d(TAG, "mGatt.setCharacteristicNotification : LeService");
            return mGatt.setCharacteristicNotification(chr, enable);
        }
        return false;
    }

    public synchronized void requestMorePriority() {
        if (mGatt != null) {
            boolean result = mGatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH);
            Log.d(TAG, "requestConnectionPriority result="+ result);
        }

    }


}
