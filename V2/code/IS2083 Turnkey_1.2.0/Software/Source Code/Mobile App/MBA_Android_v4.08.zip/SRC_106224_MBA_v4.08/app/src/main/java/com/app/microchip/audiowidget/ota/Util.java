// vim: et sw=4 sts=4 tabstop=4

package com.app.microchip.audiowidget.ota;

import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Iterator;
import java.util.Set;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Settings;
import android.util.Log;

public final class Util {

    private final static SimpleDateFormat sSDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private Util() {
        // this is just a helper class.
    }

    public static Date now() {
        return Calendar.getInstance().getTime();
    }

    public static Date parseDateString(SimpleDateFormat sdf, String date) {
        try {
            return sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static Date parseDateString(String date) {
        try {
            return sSDF.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static String parseDate(Date date) {
        return sSDF.format(date);
    }

    public static boolean isBluetoothSupported() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        return (adapter!= null);
    }

    public static boolean isBluetoothEnabled() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        return (adapter != null) && (adapter.isEnabled());
    }

    public static void discoverBluetooth(Activity act, int code) {
        Intent i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
        act.startActivityForResult(i, code);
    }

    public static void enableBluetooth(Activity act, int code) {
        Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        act.startActivityForResult(i, code);
    }

    public static Set<BluetoothDevice> getBondedDevices() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter != null && adapter.isEnabled()) {
            return adapter.getBondedDevices();
        }

        return null;
    }

    public static String BytesToHex(byte[] data) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < data.length; i++) {
            sb.append(String.format("%02x", data[i]));
        }

        return sb.toString();
    }

    public static void dumpServices(List<BluetoothGattService> list) {
        Iterator<BluetoothGattService> it = list.iterator();
        while (it.hasNext()) {
            dumpService(it.next());
        }
    }

    public static void dumpService(BluetoothGattService srv) {
        Log.d("",String.format("  Service uuid: %s,", srv.getUuid().toString()));
        List<BluetoothGattCharacteristic> list = srv.getCharacteristics();
        if (list == null || list.size() <= 0) {
            Log.d("","    ...without characteristic");
        }

        Iterator<BluetoothGattCharacteristic> it = list.iterator();
        while (it.hasNext()) {
            dumpChr(it.next());
        }
    }

    public static void dumpChr(BluetoothGattCharacteristic chr) {
        Log.d("",String.format("    chr uuid: %s,", chr.getUuid().toString()));
        List<BluetoothGattDescriptor> list = chr.getDescriptors();
        if (list == null || list.size() <= 0) {
            Log.d("","    ...without descriptor");
        }

        Iterator<BluetoothGattDescriptor> it = list.iterator();
        while (it.hasNext()) {
            dumpDesc(it.next());
        }
    }

    public static void dumpDesc(BluetoothGattDescriptor desc) {
        Log.d("",String.format("        desc uuid: %s, permission:0x%x",
                    desc.getUuid().toString(),
                    desc.getPermissions()));

        if (desc.getValue() != null) {
            Log.d("","          value length =" + desc.getValue().length);
        }
    }

    public static byte[] getOffsetBytes(byte[] val, int offset) {
        int size = val.length - offset;
        ByteBuffer buf = ByteBuffer.allocate(size);
        buf.put(val, offset, size);
        return buf.array();
    }

    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    public static String getPath(Context context, Uri uri) throws URISyntaxException {
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            String[] projection = { "_data" };
            Cursor cursor = null;

            try {
                cursor = context.getContentResolver().query(uri, projection, null, null, null);
                int column_index = cursor.getColumnIndexOrThrow("_data");
                if (cursor.moveToFirst()) {
                    return cursor.getString(column_index);
                }
            } catch (Exception e) {
                // Eat it
            }
        }
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    public static String toBinaryString(byte n) {
        StringBuilder sb = new StringBuilder("00000000");
        for (int bit = 0; bit < 8; bit++) {
            if (((n >> bit) & 1) > 0) {
                sb.setCharAt(7 - bit, '1');
            }
        }
        return sb.toString();
    }

}

