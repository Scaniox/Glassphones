package com.app.microchip.dsptunning.pagerFrag;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningEQCoefActivity;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;
import com.app.microchip.dsptunning.ui.DspTuningVoicePagerActivity;

import java.util.Arrays;

/**
 * Created by I17163 on 12/12/2019.
 */

public class EQVoiceFragment extends Fragment implements DSPTuningDelegate{

    private static final String TAG = EQVoiceFragment.class.getSimpleName();

    String[] EQ_table = {"EQ Off", "EQ On-Customized EQ Coeff", "AECFreqShaping", "Custom 2",""};
    byte[]  EQ_ids = {1,2,3,4};

    private Button TuneDSP;
    TextView DSPState;
    private DspTuningVoicePagerActivity mActivity;
    private DspOTATunningBLEService mService;

    byte CVSD_TX_EQ_Mode = 0x0f;
    byte CVSD_RX_EQ_Mode = 0x0f;
    byte MSBC_TX_EQ_Mode = 0x0f;
    byte MSBC_RX_EQ_Mode = 0x0f;

    private Button eqSPKButton;
    private Button eqSPKmSBCButton;
    private Button eqMICButton;
    private Button eqMICmSBCButton;

    Spinner SPK_EQ;
    Spinner MIC_EQ;

    public EQVoiceFragment() {
        Log.d(TAG, "Constructor");
    }

    DspTuningVoicePagerActivity activity;




    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.eq_voice_fragment, container, false);

        DSPState =(TextView) view.findViewById(R.id.deviceStatus);
        TuneDSP = (Button) view.findViewById(R.id.tuneDspButton);

        SPK_EQ = (Spinner)view.findViewById(R.id.Spinner3);
        MIC_EQ = (Spinner)view.findViewById(R.id.Spinner4);

        eqSPKButton = (Button) view.findViewById(R.id.cusomeEQSpk);
        eqSPKmSBCButton = (Button) view.findViewById(R.id.cusomeEQSpkMSBC);
        eqMICButton = (Button) view.findViewById(R.id.cusomeEQMic);
        eqMICmSBCButton = (Button) view.findViewById(R.id.cusomeEQMicMSBC);


        Log.d(TAG, "onCreateView");

        return view;
                
    }

    public void onResume() {
        Log.d(TAG, "onResume of EQAudio Audio Frag");

        if (mService!= null) {
            if (mService.EQ_Data != null) {
                if (mService.EQ_Data.length == 0x54) {
                    enableTuneDspButton();
                }
            }
        }
        super.onResume();
    }


    void initEqModes() {
        byte[] eqModeArr = mService.GetVoiceEQMode();

        CVSD_TX_EQ_Mode = eqModeArr[1];
        CVSD_RX_EQ_Mode = eqModeArr[0];
        MSBC_TX_EQ_Mode = eqModeArr[3];
        MSBC_RX_EQ_Mode = eqModeArr[2];

        BLELog.d(TAG,"CVSD_TX_EQ_Mode="+ CVSD_TX_EQ_Mode+" CVSD_RX_EQ_Mode="+ CVSD_RX_EQ_Mode+
                " MSBC_TX_EQ_Mode="+MSBC_TX_EQ_Mode + " MSBC_RX_EQ_Mode="+MSBC_RX_EQ_Mode);
        if(((int)(CVSD_TX_EQ_Mode)) < EQ_table.length){
            int index_CVSD_TX_EQ_Mode = (int)(CVSD_TX_EQ_Mode);
            SPK_EQ.setSelection(index_CVSD_TX_EQ_Mode);
            BLELog.d(TAG,"index_CVSD_TX_EQ_Mode="+ index_CVSD_TX_EQ_Mode);
        }
        else{
            SPK_EQ.setSelection(4);
        }

        SPK_EQ.setEnabled(false);

        if(((int)(CVSD_RX_EQ_Mode)) < EQ_table.length){
            int index_CVSD_RX_EQ_Mode = (int)(CVSD_RX_EQ_Mode);
            MIC_EQ.setSelection(index_CVSD_RX_EQ_Mode);
            BLELog.d(TAG,"index_CVSD_RX_EQ_Mode="+ index_CVSD_RX_EQ_Mode);
        }
        else{
            MIC_EQ.setSelection(4);
        }

        MIC_EQ.setEnabled(false);

        updateFunctionButtonsState();

    }

    private void initUI () {
        Log.d(TAG, "initUI");

        if (DSPState!= null)
            DSPState.setText(mService.DSP_DUT_State);

        ArrayAdapter<String> adapter1;
        adapter1 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, EQ_table);

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SPK_EQ.setAdapter(adapter1);
        SPK_EQ.setSelection(0);


        ArrayAdapter<String> adapter2;
        adapter2 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, EQ_table);

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        MIC_EQ.setAdapter(adapter2);
        MIC_EQ.setSelection(0);


        if(mService.Audio_Config != null){
            initEqModes();
        }


        eqSPKButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DspOTATunningEQCoefActivity.EQMode = 0x02;
                Intent intent = new Intent(mActivity.getApplicationContext(), DspOTATunningEQCoefActivity.class);
                startActivity(intent);;
            }
        });

        eqSPKmSBCButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DspOTATunningEQCoefActivity.EQMode = 0x04;
                Intent intent = new Intent(mActivity.getApplicationContext(), DspOTATunningEQCoefActivity.class);
                startActivity(intent);;
            }
        });

        eqMICButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DspOTATunningEQCoefActivity.EQMode = 0x03;
                Intent intent = new Intent(mActivity.getApplicationContext(), DspOTATunningEQCoefActivity.class);

                startActivity(intent);;
            }
        });

        eqMICmSBCButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DspOTATunningEQCoefActivity.EQMode = 0x05;
                Intent intent = new Intent(mActivity.getApplicationContext(), DspOTATunningEQCoefActivity.class);
                startActivity(intent);;
            }
        });


        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(mService.EQ_Data == null)
                    return;

                if((DspOTATunningEQCoefActivity.EQMode != 0) && ((mService.EQ_Data.length) == 0x54)){

                    if(DspOTATunningEQCoefActivity.EQMode == 0x02){
                        mActivity.showSpinnerDialog(true);
                        Log.d(TAG, ("SPK EQ Tuning..."));
                        Log.d(TAG, "mService.EQ_Data="+ Arrays.toString(mService.EQ_Data));
                        mService.DSPTuning( (byte) 0x0D,  (byte) 0x0F,  (byte) 0x54, mService.EQ_Data);
                        mService.EQ_Data = null;
                        DspOTATunningEQCoefActivity.EQMode = 0;
                    } else  if(DspOTATunningEQCoefActivity.EQMode == 0x03){
                        mActivity.showSpinnerDialog(true);
                        Log.d(TAG, ("MIC EQ Tuning..."));
                        Log.d(TAG, "mService.EQ_Data="+ Arrays.toString(mService.EQ_Data));
                        mService.DSPTuning( (byte) 0x0D,  (byte) 0x11,  (byte) 0x54, mService.EQ_Data);
                        mService.EQ_Data = null;
                        DspOTATunningEQCoefActivity.EQMode = 0;
                    } else  if(DspOTATunningEQCoefActivity.EQMode == 0x04){
                        mActivity.showSpinnerDialog(true);
                        Log.d(TAG, ("SPK_mSBC EQ Tuning..."));
                        Log.d(TAG, "mService.EQ_Data="+ Arrays.toString(mService.EQ_Data));
                        mService.DSPTuning( (byte) 0x0D,  (byte) 0x10,  (byte) 0x54, mService.EQ_Data);
                        mService.EQ_Data = null;
                        DspOTATunningEQCoefActivity.EQMode = 0;
                    } else  if(DspOTATunningEQCoefActivity.EQMode == 0x05){
                        mActivity.showSpinnerDialog(true);
                        Log.d(TAG, ("MIC_mSBC EQ Tuning..."));
                        Log.d(TAG, "mService.EQ_Data="+ Arrays.toString(mService.EQ_Data));
                        mService.DSPTuning( (byte) 0x0D,  (byte) 0x12,  (byte) 0x54, mService.EQ_Data);
                        mService.EQ_Data = null;
                        DspOTATunningEQCoefActivity.EQMode = 0;
                    }
                }


            }
        });

        disableTuneDspButton();

    }

    private void  enableTuneDspButton() {
        TuneDSP.setEnabled(true);
        TuneDSP.setTextColor(Color.WHITE);
    }

    private void  disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }

    private synchronized void updateFunctionButtonsState () {
        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                if (mService.dynamicToolMode == mService.TuneDSPMode_NotSupport || mService.dynamicToolMode == mService.TuneDSPMode_Audio) {
                    eqSPKButton.setEnabled(false);
                    eqSPKmSBCButton.setEnabled(false);
                    eqMICButton.setEnabled(false);
                    eqMICmSBCButton.setEnabled(false);
                    TuneDSP.setEnabled(false);

                } else if (mService.dynamicToolMode == mService.TuneDSPMode_Voice) {
                    eqSPKButton.setEnabled(false);
                    eqSPKmSBCButton.setEnabled(false);
                    eqMICButton.setEnabled(false);
                    eqMICmSBCButton.setEnabled(false);

                    TuneDSP.setEnabled(true);

                    if(CVSD_TX_EQ_Mode == 0){
                        eqSPKButton.setEnabled(false);
                    }
                    else{
                        eqSPKButton.setEnabled(true);
                    }

                    if(CVSD_RX_EQ_Mode == 0){
                        eqMICButton.setEnabled(false);
                    }
                    else{
                        eqMICButton.setEnabled(true);
                    }

                    if(MSBC_TX_EQ_Mode == 0){
                        eqSPKmSBCButton.setEnabled(false);
                    }
                    else{
                        eqSPKmSBCButton.setEnabled(true);
                    }

                    if(MSBC_RX_EQ_Mode == 0){
                        eqMICmSBCButton.setEnabled(false);
                    }
                    else{
                        eqMICmSBCButton.setEnabled(true);
                    }

                }


            }

        }));
    }


    public void initModule(DspTuningVoicePagerActivity act) {
        mActivity = act;

        mService = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        mService.setListener(EQVoiceFragment.this);

        initUI();

        mService.EQ_Data = null;
    }

    public void cleanModule() {

    }


    @Override
    public void onAttach(Context context) {
        Log.d(TAG, "EQAudioFragment onAttach");
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        Log.d(TAG, "EQAudioFragment onDetach");
        super.onDetach();
    }

    private String  dspStatusMsgDialog= "";
    private void showTuneDspDialog(String message) {

        dspStatusMsgDialog = message;

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder ad = new AlertDialog.Builder(getActivity() , R.style.MyDialogTheme);
                ad.setMessage(dspStatusMsgDialog);

                ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
                sendBroadcast(i);
                  mOtaState.setText("Completed");*/
                    }
                });

                final AlertDialog  alert = ad.create();
                alert.setTitle("Tune DSP Status!!");
                alert.show();



                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {

                    }
                });

            }
        }));


    }


    @Override
    public void BLE_ServiceReady() {

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] Data) {

    }

    @Override
    public void DSPTuningComplete(byte result) {
        String  status = "";

        mActivity.dismissSpinnerDialog();

        if(result == 0x01){
            status = "Success";
        }
        else{
            status = "Failed " + result;
        }

        showTuneDspDialog(status);

        if(result != 0x01){
            //LineIn_Config_Init(null, true);
        }

        mService.EQ_Data = null;
        getActivity().runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                disableTuneDspButton();

            }
        }));

    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {
        Log.d(TAG, " DSPTuningState" + state);
        if (DSPState != null)
            DSPState.setText(state);
        // else
        // return;

        updateFunctionButtonsState();

    }



    @Override
    public void ExportDSPTuningResult() {

    }
}
