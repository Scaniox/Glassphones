package com.app.microchip.audiowidget.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.managers.TransparentServiceManager;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;

public class CommandWindow extends AppCompatActivity {
    private static final String TAG = CommandWindow.class.getSimpleName();
    private final static boolean TRANS_MSG_RX = false;
    private final static boolean TRANS_MSG_TX = true;

    private TransparentServiceManager mainActivity;
    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver speakerCmndsReceiver;
    private BLESpeaker mSpeaker;
    private TextView mMsg;
    private Button sendButton;
    private EditText mInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_command_window);
        Intent intent = getIntent();
        String deviceId = intent.getStringExtra(Constants.DEVICE_ID);
        BLELog.d(TAG, "Device ID of selected speaker =" + deviceId);
        mSpeaker = HomeScreenActivity.getInstance().getSpeaker(deviceId);
        setTitle(mSpeaker.getName() + " Cmd Window");

        mMsg = (TextView) findViewById(R.id.cmdLog);
        mInput = (EditText) findViewById(R.id.cmdEdit);
        sendButton = (Button) findViewById(R.id.cmdSend);
        sendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(
                        Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(mInput.getWindowToken(), 0);
                CharSequence cs = mInput.getText();
                sendCommand(cs.toString());
            }
        });


        mainActivity = TransparentServiceManager.getInstance();
        transRxIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(TransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(TransparentServiceManager.BLE_DISCONNECTED);
        speakerCmndsReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {

                Message msg = Message.obtain();
                String action = intent.getAction();
                if (TransparentServiceManager.BLE_DISCONNECTED.equals(action)) {
                    handleBLEDisconnection();
                }
                if (TransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (TransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(TransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i, byte_cnt;
                        String displayString = "";

                        char rxDataHex[] = new char[rxBytes.length];
                        displayString = "";
                        for (i = 0; i < rxDataHex.length; i++) {
                            rxDataHex[i] = (char) rxBytes[i];
                            displayString += String.format("0x%02X", (int) (rxDataHex[i]) & 0xff) + " ";
                            BLELog.d(TAG, "Commands Fragment Rx data : " + rxBytes[i]);
                        }
                        appendMsg(displayString, TRANS_MSG_RX);
                    }

                }
            }

        };

        mMsg.setMovementMethod(ScrollingMovementMethod.getInstance());
        registerForContextMenu(mMsg);
    }

    private void appendMsg(CharSequence msg, boolean isTx) {
        Spannable word = new SpannableString(msg);
        word.setSpan(new ForegroundColorSpan(isTx ? Color.BLUE : Color.RED), 0, word.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        mMsg.append(word);
        mMsg.append("\n");
    }


    public void sendCommand(String cmd) {
        if (mainActivity.isConnected() == false) {
            handleBLEDisconnection();
        }
        if (mainActivity != null) {
            int i;
            String packedMessage = "";
            char[] packedCmds = mainActivity.packAndSendCommand(cmd);
            for (i = 0; i < packedCmds.length; i++) {
                android.util.Log.d(getClass().getName(), String.format("value = %d", (int) packedCmds[i]));
                packedMessage += String.format("0x%02X", (int) packedCmds[i]) + " ";
            }
            appendMsg(packedMessage, TRANS_MSG_TX);
        }
    }

    public void onStart() {
        super.onStart();
        BLELog.d(TAG, "On Stop");
    }

    public void onResume() {
        super.onResume();
        BLELog.d(TAG, "On Resume");
        mainActivity.registerFragReceiver(speakerCmndsReceiver, transRxIntentFilter);
        mainActivity.registerFragReceiver(speakerCmndsReceiver, transReadyIntentFilter);
        mainActivity.registerFragReceiver(speakerCmndsReceiver, disconnectionfilter);
        sendInitCommands();
    }

    public void onStop() {
        super.onStop();
        BLELog.d(TAG, "On Stop");
        mainActivity.unregisterFragReceiver(speakerCmndsReceiver);
    }


    public void sendInitCommands() {
        BLELog.d(TAG, "SendInitCommands");
    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                Intent home = new Intent(getApplicationContext(), HomeScreenActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }

    public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
            }
        });
        builder.show();
    }
}
