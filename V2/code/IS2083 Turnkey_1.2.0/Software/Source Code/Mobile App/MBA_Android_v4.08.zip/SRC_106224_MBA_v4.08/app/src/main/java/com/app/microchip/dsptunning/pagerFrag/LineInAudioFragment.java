package com.app.microchip.dsptunning.pagerFrag;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;
import com.app.microchip.dsptunning.ui.DspTuningAudioPagerActivity;

import java.util.Arrays;

/**
 * Created by I17163 on 12/12/2019.
 */

public class LineInAudioFragment extends Fragment implements DSPTuningDelegate {

    private static final String TAG = LineInAudioFragment.class.getSimpleName();

    private Spinner LineIn_Threshold;
    private Spinner LineIn_ADCGain;
    private Button TuneDSP;
    TextView DSPState;
    private DspTuningAudioPagerActivity mActivity;
    private DspOTATunningBLEService mServie;
    byte[] LineIn_Data;
    byte[] LineIn_Prev_Data;

    private int lineInSlectIndex = 0;
    private int threholdSlectIndex = 0;
    private int mIterateIndex = 0;
    private long fragFocusStartTime = 0;
    private String  dspStatusMsgDialog= "";


    String[] Threshold_table = {"0x00: -6dBOv", "0x02:-12dBOv", "0x04:-18dBOv", "0x06:-24dBOv",
            "0x08:-30dBOv", "0x0A:-36dBOv", "0x0C:-42dBOv", "0x0E:-48dBOv", "0x10:-54dBOv", "0x12:-60dBOv",
            "0x14:-66dBOv", "0x16:-72dBOv", "0x18:-78dBOv", "0x1A:-84dBOv", "0x1C:-92dBOv", "0x1E:-96dBOv",
            "LineIn Silence Detection Off"};

    byte[] Threshold_table_ids = {0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 31};

    String[] ADC_Gain_table = {"-6dB, 0x00", "-3dB, 0x03", "0dB, 0x06", "3dB, 0x09",
            "6dB, 0x0C", "9dB, 0x0F", "12dB, 0x12", "15dB, 0x15", "18dB, 0x23",
            "21dB, 0x26", "24dB, 0x29", "27dB, 0x2C", "30dB, 0x2F",
            "33dB, 0x32", "36dB, 0x35", "39dB, 0x38", "42dB, 0x3B", "45dB, 0x3E"};

    byte[] ADC_Gain_table_ids = {0, 3, 6, 9, 12, 15, 18, 21, 35, 38, 41, 44, 47, 50, 53, 56, 59, 62};


    public LineInAudioFragment () {
        Log.d(TAG, "LineInAudioFragment Constructor");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.linein_audio_fragment, container, false);
        Log.d(TAG, "LineInAudioFragment onCreateView");


        LineIn_Threshold = (Spinner)view.findViewById(R.id.Spinner3);
        LineIn_ADCGain = (Spinner)view.findViewById(R.id.Spinner4);
        DSPState =(TextView) view.findViewById(R.id.deviceStatus);
        TuneDSP = (Button) view.findViewById(R.id.tuneDspButton);

        initUI();

        fragFocusStartTime = System.currentTimeMillis();

        return view;

    }

    private void initUI () {


        if (LineIn_Threshold == null)
            return;

        if ((DSPState!= null) && (mServie!= null))
            DSPState.setText(mServie.DSP_DUT_State);


        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, Threshold_table);

        LineIn_Threshold.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos,long id) {


                long fragFocucEndTime =  System.currentTimeMillis();

                long fragAutoEventTimeElapsed = fragFocucEndTime - fragFocusStartTime ;

                Log.d(TAG,"LineIn_Threshold fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

                if (fragAutoEventTimeElapsed > 2000) {
                    enableTuneDspButton();
                }

                String displayStr= parent.getItemAtPosition(pos).toString();
               // if(self.LineIn_ADCGain.text != self.ADC_Gain_table[self.LineIn_ADCGain.selectedIndex!]){
                if (LineIn_Data != null)
                LineIn_Data[0] = Threshold_table_ids[pos];
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        LineIn_Threshold.setAdapter(adapter);
        //LineIn_Threshold.setSelection(0);



        ArrayAdapter<String> adapter1;
        adapter1 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, ADC_Gain_table);

        LineIn_ADCGain.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos,long id) {

                Log.d(TAG,"LineIn_ADCGain selectedItemPos="+ pos );

                long fragFocucEndTime =  System.currentTimeMillis();

                long fragAutoEventTimeElapsed = fragFocucEndTime - fragFocusStartTime ;

                Log.d(TAG,"LineIn_ADCGain fragAutoEventTimeElapsed="+ fragAutoEventTimeElapsed );

                if (fragAutoEventTimeElapsed > 2000) {
                    enableTuneDspButton();
                }

                String displayStr= parent.getItemAtPosition(pos).toString();
                // if(self.LineIn_ADCGain.text != self.ADC_Gain_table[self.LineIn_ADCGain.selectedIndex!]){
                if (LineIn_Data != null)
                    LineIn_Data[1] = ADC_Gain_table_ids[pos];
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        LineIn_ADCGain.setAdapter(adapter1);
        //LineIn_ADCGain.setSelection(0);



        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DSPTuning();
            }
        });


        LineIn_Config_Init(LineIn_Data,false);
        disableTuneDspButton();
        updateFunctionButtonsState();

    }


    private void  enableTuneDspButton() {
        TuneDSP.setEnabled(true);
        TuneDSP.setTextColor(Color.WHITE);
    }

    private void  disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }

    private synchronized void updateFunctionButtonsState () {

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                if(mServie.dynamicToolMode == mServie.TuneDSPMode_NotSupport || mServie.dynamicToolMode == mServie.TuneDSPMode_Voice){
                    LineIn_ADCGain.setEnabled(false);
                    LineIn_Threshold.setEnabled(false);
                    disableTuneDspButton();
                }
                else if(mServie.dynamicToolMode == mServie.TuneDSPMode_Audio){
                    LineIn_ADCGain.setEnabled(true) ;
                    LineIn_Threshold.setEnabled(true);
                    //enableTuneDspButton();
                }

            }

        }));
    }


    public void initModule(DspTuningAudioPagerActivity act) {
        mActivity = act;

        mServie = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        mServie.setListener(LineInAudioFragment.this);


        if (mServie.ConnectService == false){
            mServie.GetCapability();

            mActivity.showSpinnerDialog(false);


        }else {
            mServie.Get_Audio_DSP_Setting_LineIn();

            mServie.Read_Module_Audio_MCU();

            fragFocusStartTime = System.currentTimeMillis();

        }


        initUI();



    }

    public void cleanModule() {

    }


    private  void updateLineINSelctionIndex() {

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                LineIn_ADCGain.setSelection(threholdSlectIndex);

            }
        }));
    }


    private  void updateThresholdSelctionIndex() {

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                LineIn_ADCGain.setSelection(threholdSlectIndex);

            }
        }));
    }

    private void DSPTuning() {
        if(LineIn_Data != null) {
            Log.d(TAG,"DSP Tuning,LineIn_Data = "+ HexTool.byteArrayToHexString(LineIn_Data));
            Log.d(TAG,"DSP Tuning,LineIn_Prev_Data = "+ HexTool.byteArrayToHexString(LineIn_Prev_Data));
            boolean change1 = true;
            boolean change2 = false;

            if(change1 == true && change2 == false){
                mServie.DSPTuning((byte) 0x0C, (byte) 0x01, (byte) LineIn_Data.length , LineIn_Data);
                mActivity.showSpinnerDialog(true);
            }


        }
    }


    private void LineIn_Config_Init(byte[] dat, boolean isReset){

        if (dat ==  null)
            return;

        if (!isReset) {
            LineIn_Data = dat;
            LineIn_Prev_Data = Arrays.copyOfRange(LineIn_Data, 0, LineIn_Data.length);
        }

        //int index = 0;

        Log.d(TAG,"LineIn_Data ="+ HexTool.byteArrayToHexString(LineIn_Data));
        Log.d(TAG,"LineIn_Prev_Data ="+ HexTool.byteArrayToHexString(LineIn_Prev_Data));

        for(  mIterateIndex= 0; 0 < Threshold_table_ids.length;mIterateIndex++ ) {
            if(LineIn_Data[0] == Threshold_table_ids[mIterateIndex]) {

                //LineIn_Threshold.setSelection(mIterateIndex);
               //LineIn_Threshold.text = Threshold_table[index];
                threholdSlectIndex = mIterateIndex;

                mActivity.runOnUiThread(new Thread(new Runnable() {
                    @Override
                    public void run() {
                        LineIn_Threshold.setSelection(threholdSlectIndex);
                        Log.d(TAG,"LineIn_Threshold threholdSlectIndex="+ threholdSlectIndex);

                    }
                }));
                break;
            }
        }

        for (  mIterateIndex=0; 0 <ADC_Gain_table_ids.length;mIterateIndex++) {
            if(LineIn_Data[1] == ADC_Gain_table_ids[mIterateIndex]) {

                lineInSlectIndex = mIterateIndex;
                mActivity.runOnUiThread(new Thread(new Runnable() {
                    @Override
                    public void run() {
                        LineIn_ADCGain.setSelection(lineInSlectIndex);
                        Log.d(TAG,"LineIn_ADCGain lineInSlectIndex="+ lineInSlectIndex);

                    }
                }));
                // LineIn_ADCGain.setSelection(index);
                //LineIn_ADCGain.text = ADC_Gain_table[index];
                break;
            }
        }
    }



    @Override
    public void onAttach(Context context) {
        Log.d(TAG, "LineInAudioFragment onAttach");
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        Log.d(TAG, "LineInAudioFragment onDetach");
        super.onDetach();
    }

    private void showTuneDspDialog(String message) {


        dspStatusMsgDialog = message;

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder ad = new AlertDialog.Builder(getActivity() , R.style.MyDialogTheme);
                ad.setMessage(dspStatusMsgDialog);

                ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
                sendBroadcast(i);
                  mOtaState.setText("Completed");*/
                    }
                });

                final AlertDialog  alert = ad.create();
                alert.setTitle("Tune DSP Status!!");
                alert.show();



                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {

                    }
                });

            }
        }));


    }

    @Override
    public void BLE_ServiceReady()  {

        Log.d(TAG, " BLE_ServiceReady");
     //   mServie.DSP_End_Read_Session();


        mServie.Read_Module_Audio_MCU();

        mServie.Get_Audio_DSP_Setting_LineIn();

        try {
            Thread.sleep(800);

        } catch (java.lang.InterruptedException e) {
            e.printStackTrace();
        }

        mActivity.dismissSpinnerDialog();

        fragFocusStartTime = System.currentTimeMillis();

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] dat) {



        int k = 0;
        byte[] buffer = dat;


        Log.d(TAG,"Parsing configuration data");

        while(k < buffer.length){
            byte len = buffer[k+2];

              //byte[] param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))
            byte[] param_dat = Arrays.copyOfRange(buffer, k+3, buffer.length );;
            //Log.d(TAG,"Offset = \(k), module_id = \(buffer[k]), cfg_id = \(buffer[k+1]), data len = \(len), dat = \(param_dat as NSData)")

            if(buffer[k] == 12 && buffer[k+1] == 1){
                LineIn_Config_Init(param_dat,false);
                break;
            }

            k += (int)(3+len);
        }

        updateFunctionButtonsState();

        Log.d(TAG, "LineInAudioFragment RefreshParametersData");

    }

    @Override
    public void DSPTuningComplete(byte result) {


        mActivity.dismissSpinnerDialog();

        String  status = "";

        if(result == 0x01){
            status = "Success";
        }
        else{
            status = "Failed " + result;
        }

        showTuneDspDialog(status);

        if(result != 0x01){
            LineIn_Config_Init(null, true);
        }
        LineIn_Prev_Data = LineIn_Data;


        getActivity().runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                disableTuneDspButton();

            }
        }));



    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {

        Log.d(TAG, "LineInAudioFragment DSPTuningState" + state);
        if (DSPState!= null)
            DSPState.setText(state);

        updateFunctionButtonsState();

    }

    @Override
    public void ExportDSPTuningResult() {

    }
}
