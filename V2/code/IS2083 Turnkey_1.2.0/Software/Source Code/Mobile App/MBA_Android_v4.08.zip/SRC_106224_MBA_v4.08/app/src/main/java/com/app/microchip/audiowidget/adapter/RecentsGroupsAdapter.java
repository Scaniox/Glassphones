package com.app.microchip.audiowidget.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.ui.HomeScreenActivity;
import com.app.microchip.audiowidget.util.Constants;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by I21309 on 6/7/2017.
 */


public class RecentsGroupsAdapter extends BaseAdapter {

    private static LayoutInflater inflater = null;
    private Activity activity;
    private ArrayList<HashMap<String, String>> data;

    public RecentsGroupsAdapter(Activity a, ArrayList<HashMap<String, String>> d) {
        activity = a;
        data = d;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    public int getCount() {
        return data.size();
    }


    public Object getItem(int position) {
        return position;
    }


    public long getItemId(int position) {
        return position;
    }


    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null)
            vi = inflater.inflate(R.layout.recent_group_list_row, null);

        TextView groupName = (TextView) vi.findViewById(R.id.groupName);
        //    TextView createButton = (TextView) vi.findViewById(R.id.create);


        HashMap<String, String> entry = new HashMap<>();
        entry = data.get(position);
        groupName.setText(entry.get("name"));
        ImageView imageClick = (ImageView) vi.findViewById(R.id.recentGroupOptions);

        try {
            imageClick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    switch (v.getId()) {
                        case R.id.recentGroupOptions:

                            PopupMenu popup = new PopupMenu(activity.getApplicationContext(), v);
                            popup.getMenuInflater().inflate(R.menu.cachedgroup_options,
                                    popup.getMenu());
                            popup.show();
                            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                @Override
                                public boolean onMenuItemClick(MenuItem item) {

                                    switch (item.getItemId()) {
                                        case R.id.creategroup:
                                            HomeScreenActivity.getInstance().reCreateCachedgroup(position);
                                            break;
                                        case R.id.deleteGroup:
                                            Toast.makeText(activity.getApplicationContext(), "Group Deleted successfully!! ", Toast.LENGTH_SHORT).show();
                                            HomeScreenActivity.getInstance().deleteCachedGroup(position);
                                            break;
                                        default:
                                            break;
                                    }
                                    return true;
                                }
                            });

                            break;

                        default:
                            break;
                    }
                }
            });

        } catch (Exception e) {

            e.printStackTrace();
        }

        return vi;
    }

}