package com.app.microchip.dsptunning.pagerFrag;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;
import com.app.microchip.dsptunning.ui.DspTuningVoicePagerActivity;

import java.util.Arrays;

/**
 * Created by I17163 on 12/12/2019.
 */

public class AECVoiceFragment extends Fragment implements DSPTuningDelegate{

    private static final String TAG = AECVoiceFragment.class.getSimpleName();

    String[] Stepsize_table = {"0x01: Fast AEC Convergence", "0x02", "0x03", "0x04",
            "0x05", "0x06: Slow AEC Convergence"};

    byte[] Stepsize_ids = {1, 2, 3, 4, 5, 6};

    String[] TapLength_table = {"0x01: 8msec Echo Tail", "0x02: 16msec Echo Tail",
            "0x03: 24msec Echo Tail", "0x04: 32msec Echo Tail", "0x05: 40msec Echo Tail",
            "0x06: 48msec Echo Tail", "0x07: 56msec Echo Tail", "0x08: 64msec Echo Tail",
            "0x09: 72msec Echo Tail", "0x0A: 80msec Echo Tail"};
    byte[] TapLength_ids = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    String[] AEC_Threshold_table = {"0x7F:Worst Linearity", "0x3F:", "0x1F:", "0x0F:",
            "0x07:", "0x03:Best Linearity"};
    byte[] AEC_Threshold_ids = {0x7F, 0x3F, 0x1F, 0x0F, 0x07, 0x03};

    String[] AEC_Threshold_SBC_table = {"0x7F:Worst Linearity-mSBC", "0x3F:-mSBC", "0x1F:-mSBC",
            "0x0F:-mSBC", "0x07:-mSBC", "0x03:Best Linearity-mSBC"};
    byte[] AEC_Threshold_SBC_ids = {0x7F, 0x3F, 0x1F, 0x0F, 0x07, 0x03};

    String[] AES_Suppression_table = {"0x01:Less Echo Suppression", "0x02:", "0x03:", "0x04:",
            "0x05:", "0x06:", "0x07:", "0x08:Medium Echo Suppression", "0x09:", "0x0A:", "0x0B:",
            "0x0C:", "0x0D:", "0x0E:", "0x0F:Most Echo Suppression"};
    byte[] AES_Suppression_ids = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};

    String[] AES_Suppression_SBC_table = {"0x01:Less Echo Supp.-mSBC", "0x02:-mSBC", "0x03:-mSBC",
            "0x04:-mSBC", "0x05:-mSBC", "0x06:-mSBC", "0x07:-mSBC", "0x08:Medium Echo Supp.-mSBC",
            "0x09:-mSBC", "0x0A:-mSBC", "0x0B:-mSBC", "0x0C:-mSBC", "0x0D:-mSBC",
            "0x0E:-mSBC", "0x0F:Most Echo Supp.-mSBC"};
    byte[] AES_Suppression_SBC_ids = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};

    String[] DoubleTalk_Threshold_table = {"0x7F:Better Full-Duplex", "0x72:", "0x65:",
            "0x5A:Medium Full-Duplex", "0x50:", "0x47:", "0x40:", "0x39:", "0x32:", "0x2D:",
            "0x28:", "0x24:", "0x20:", "0x1C:Worse Full-Duplex"};
    byte[] DoubleTalk_Threshold_ids = {0x7F, 0x72, 0x65, 0x5A, 0x50, 0x47, 0x40, 0x39, 0x32,
            0x2D, 0x28, 0x24, 0x20, 0x1C};

    String[] DoubleTalk_Threshold_SBC_table = {"0x7F:Better Full-Duplex-mSBC", "0x72:-mSBC",
            "0x65:-mSBC", "0x5A:Medium Full-Duplex-mSBC", "0x50:-mSBC", "0x47:-mSBC",
            "0x40:-mSBC", "0x39:-mSBC", "0x32:-mSBC", "0x2D:-mSBC", "0x28:-mSBC",
            "0x24:-mSBC", "0x20:-mSBC", "0x1C:Worse Full-Duplex-mSBC"};
    byte[] DoubleTalk_Threshold_SBC_ids = {0x7F, 0x72, 0x65, 0x5A, 0x50, 0x47, 0x40, 0x39,
            0x32, 0x2D, 0x28, 0x24, 0x20, 0x1C};



    private Button TuneDSP;
    TextView DSPState;
    private DspTuningVoicePagerActivity mActivity;
    private DspOTATunningBLEService mService;
    Spinner Stepsize;
    Spinner TapLength;
    Spinner AEC_Threshold;
    Spinner AES_Suppression;
    Spinner DoubleTalk_Threshold;
    CheckBox AES_OnOff_checkbox;
    CheckBox AEC_OnOff_checkbox;
    CheckBox mSBC_checkbox;

    byte[] AEC_Prev_Data;

    byte[] VOICE_Config_Data;
    byte VOICE_Config_Data_Byte2 = 0;

    public AECVoiceFragment() {
        Log.d(TAG, "Constructor");
    }

    DspTuningVoicePagerActivity activity;


    private void updateUI () {
        Log.d(TAG, "cleanup");
    }


    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.aec_voice_fragment, container, false);


        DSPState =(TextView) view.findViewById(R.id.deviceStatus);
        TuneDSP = (Button) view.findViewById(R.id.tuneDspButton);


        AES_OnOff_checkbox = (CheckBox) view.findViewById(R.id.aescheckbox);
        AEC_OnOff_checkbox = (CheckBox) view.findViewById(R.id.aeccheckbox);
        mSBC_checkbox = (CheckBox) view.findViewById(R.id.msbccheckbox);

        Stepsize= (Spinner)view.findViewById(R.id.Spinner2);
        TapLength = (Spinner)view.findViewById(R.id.Spinner3);
        AEC_Threshold= (Spinner)view.findViewById(R.id.Spinner4);
        AES_Suppression = (Spinner)view.findViewById(R.id.Spinner5);
        DoubleTalk_Threshold= (Spinner)view.findViewById(R.id.Spinner6);

        AES_OnOff_checkbox.setEnabled(false);
        AEC_OnOff_checkbox.setEnabled(false);
        mSBC_checkbox.setEnabled(false);

        Stepsize.setEnabled(false);
        TapLength.setEnabled(false);
        AEC_Threshold.setEnabled(false);
        AES_Suppression.setEnabled(false);
        DoubleTalk_Threshold.setEnabled(false);

        TuneDSP.setEnabled(false);


        Log.d(TAG, "onCreateView");

        disableTuneDspButton();

        return view;
                
    }

    private void  enableTuneDspButton() {
        TuneDSP.setEnabled(true);
        TuneDSP.setTextColor(Color.WHITE);
    }

    private void  disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }

    private void initUI () {

        if (DSPState != null)
            DSPState.setText(mService.DSP_DUT_State);


        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, Stepsize_table);

        Stepsize.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                if (mService.AEC_AES_Data != null) {
                    Log.d(TAG, "Before MOD Stepsize AEC_AES_Data[4] =" +
                            String.format("%02x", mService.AEC_AES_Data[4]));

                    mService.AEC_AES_Data[4] &= ~(0xf0);
                    mService.AEC_AES_Data[4] |= (byte)((pos+1) << 4);

                    Log.d(TAG, "After MOD Stepsize AEC_AES_Data[4] =" +
                            String.format("%02x", mService.AEC_AES_Data[4]));
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Stepsize.setAdapter(adapter);
        //LineIn_Threshold.setSelection(0);



        ArrayAdapter<String> adapter1;
        adapter1 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, TapLength_table);

        TapLength.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                if (mService.AEC_AES_Data != null) {

                    Log.d(TAG, "Before MOD TapLength AEC_AES_Data[0] =" +
                            String.format("%02x", mService.AEC_AES_Data[0]));

                    mService.AEC_AES_Data[0] = (byte) (pos+1);

                    Log.d(TAG, "After MOD apLength AEC_AES_Data[0] =" +
                            String.format("%02x", mService.AEC_AES_Data[0]));


                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        TapLength.setAdapter(adapter1);






        ArrayAdapter<String> adapter2;
        adapter2 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, AEC_Threshold_table);

        AEC_Threshold.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                if (mService.AEC_AES_Data  != null) {

                    if(mSBC_checkbox.isChecked()) {

                        Log.d(TAG, "Before MOD mBSC TRUE AEC_Threshold AEC_AES_Data[5] =" +
                                String.format("%02x", mService.AEC_AES_Data[5]));
                        mService.AEC_AES_Data[5] = (byte) (pos);
                        Log.d(TAG, "After MOD apLength AEC_AES_Data[5] =" +
                                String.format("%02x", mService.AEC_AES_Data[5]));

                    }else{

                        Log.d(TAG, "Before MOD BSC FALSE AEC_Threshold AEC_AES_Data[2] =" +
                        String.format("%02x", mService.AEC_AES_Data[2]));
                        mService.AEC_AES_Data[2] = (byte) (pos);
                        Log.d(TAG, "After MOD apLength AEC_AES_Data[2] =" +
                                String.format("%02x", mService.AEC_AES_Data[2]));

                    }
                }

            }



            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        AEC_Threshold.setAdapter(adapter2);
        //LineIn_Threshold.setSelection(0);



        ArrayAdapter<String> adapter3;
        adapter3 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, AES_Suppression_table);

        AES_Suppression.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                if (mService.AEC_AES_Data  != null) {

                    if(mSBC_checkbox.isChecked()) {

                        Log.d(TAG, "Before MOD mBSC TRUE AES_Suppression AEC_AES_Data[1] =" +
                                String.format("%02x", mService.AEC_AES_Data[5]));
                        mService.AEC_AES_Data[1] &= ~(0x0f);
                        mService.AEC_AES_Data[1] =  (byte) (pos+1);
                        Log.d(TAG, "After MOD AES_Suppression AEC_AES_Data[1] =" +
                                String.format("%02x", mService.AEC_AES_Data[1]));

                    }else{

                        Log.d(TAG, "Before MOD BSC FALSE AES_Suppression AEC_AES_Data[1] =" +
                                String.format("%02x", mService.AEC_AES_Data[1]));
                        mService.AEC_AES_Data[1] &= ~(0xf0);
                        mService.AEC_AES_Data[1] =  (byte)((pos+1) << 4);
                        Log.d(TAG, "After MOD AES_Suppression AEC_AES_Data[1] =" +
                                String.format("%02x", mService.AEC_AES_Data[1]));

                    }
                }

            }


            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        AES_Suppression.setAdapter(adapter3);



        ArrayAdapter<String> adapter4;
        adapter4 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, DoubleTalk_Threshold_table);

        DoubleTalk_Threshold.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String displayStr = parent.getItemAtPosition(pos).toString();

                if (mService.AEC_AES_Data  != null) {

                    if(mSBC_checkbox.isChecked()) {

                        Log.d(TAG, "Before MOD mBSC TRUE DoubleTalk_Threshold AEC_AES_Data[6] =" +
                                String.format("%02x", mService.AEC_AES_Data[6]));
                        mService.AEC_AES_Data[6] = (byte) (pos);
                        Log.d(TAG, "After MOD DoubleTalk_Threshold AEC_AES_Data[6] =" +
                                String.format("%02x", mService.AEC_AES_Data[6]));

                    }else{

                        Log.d(TAG, "Before MOD BSC FALSE DoubleTalk_Threshold AEC_AES_Data[3] =" +
                                String.format("%02x", mService.AEC_AES_Data[3]));
                        mService.AEC_AES_Data[3] = (byte) (pos);
                        Log.d(TAG, "After MOD DoubleTalk_Threshold AEC_AES_Data[3] =" +
                                String.format("%02x", mService.AEC_AES_Data[3]));

                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }


        });

        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        DoubleTalk_Threshold.setAdapter(adapter4);



        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    BLELog.d(TAG,"TuneDSP =");

                    mService.DSPTuning( (byte) 0x0D,  (byte)0x05,
                            (byte)mService.AEC_AES_Data.length, mService.AEC_AES_Data);
                    mActivity.showSpinnerDialog(true);
            }
        });

        AEC_AES_Data_Init();

        BLELog.d(TAG, "initUI");



    }

    public void initModule(DspTuningVoicePagerActivity act) {
        mActivity = act;

        mService = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        mService.setListener(AECVoiceFragment.this);


        initUI();

        mService.Get_Voice_DSP_Setting_AEC_AES();

    }

    public void cleanModule() {

    }

    boolean AEC_ON ;


    @Override
    public void onAttach(Context context) {
        Log.d(TAG, "EQAudioFragment onAttach");
        super.onAttach(context);
    }

    public void AEC_AES_Data_Init(){
        if(mService.AEC_AES_Data == null) {
            return;
        }

        if(mService.AEC_AES_Data.length != 16){
            return;
        }

        BLELog.d(TAG, "AEC_AES_Data_Init");

        byte AEC_Mode = mService.GetVoiceAECMode();
        int Stepsize_selectedIndex = 0;
        int TapLength_selectedIndex = 0;
        int AEC_Threshold_selectedIndex = 0;
        int AES_Suppression_selectedIndex = 0;
        int DoubleTalk_Threshold_selectedIndex =0;

        if (AEC_Mode != 0x00);{
            BLELog.d(TAG,"AEC OnOff = "+AEC_Mode);

            if(AEC_Mode == 0x01){
                AEC_OnOff_checkbox.setChecked(true);
                //AES_OnOff_checkbox.isUserInteractionEnabled = true

                AEC_ON = true;
            }
            else{
                AEC_ON = false;

                AEC_OnOff_checkbox.setChecked(false);

            }

        }

        if((VOICE_Config_Data != null)&& (VOICE_Config_Data.length != 0)){
            if((VOICE_Config_Data[1] & 0x04) == 0x04){  //VOICE_DSP_CFG_KEY_CONFIG_WORD, Byte 2 , bit 2
                BLELog.d(TAG,"Set AES On");
                AES_OnOff_checkbox.setEnabled(true);
            }
            else{
                BLELog.d(TAG,"Set AES Off");
                AES_OnOff_checkbox.setChecked(false);
            }
        }

        //Stepsize.selectedIndex = Int((AEC_Data[4] & 0xf0) >> 4) //0x01~0x06
        Stepsize_selectedIndex = (int)((mService.AEC_AES_Data[4] & 0xf0) >> 4) - 1; //0x01~0x06
        Stepsize.setSelection(Stepsize_selectedIndex);
        BLELog.d(TAG, "Stepsize_selectedIndex="+Stepsize_selectedIndex);

        //TapLength.selectedIndex = Int(AEC_Data[0])
        TapLength_selectedIndex = (int)(mService.AEC_AES_Data[0]-1);
        TapLength.setSelection(TapLength_selectedIndex);
        BLELog.d(TAG, "TapLength_selectedIndex="+TapLength_selectedIndex);

        if(mSBC_checkbox.isChecked()){
            int kk1 = 5;
            while(mService.AEC_AES_Data[5] > AEC_Threshold_ids[kk1]){
                kk1 -= 1;
            }
            BLELog.d(TAG,"AEC_Data[5]] kk1 = "+ kk1);
            AEC_Threshold_selectedIndex = kk1;
            AEC_Threshold.setSelection(AEC_Threshold_selectedIndex);
            BLELog.d(TAG, "AEC_Threshold_selectedIndex="+AEC_Threshold_selectedIndex);

            for (int index= 0; index <DoubleTalk_Threshold_SBC_ids.length; index++) {
                if(mService.AEC_AES_Data[6] == DoubleTalk_Threshold_SBC_ids[index]) {
                    DoubleTalk_Threshold_selectedIndex = index;
                    AEC_Threshold.setSelection(AEC_Threshold_selectedIndex);
                    BLELog.d(TAG, "AEC_Threshold_selectedIndex="+AEC_Threshold_selectedIndex);
                    break;
                }
            }

            //AES_Suppression.selectedIndex = Int((AEC_Data[1] & 0x0f))
            AES_Suppression_selectedIndex = (int)((mService.AEC_AES_Data[1] & 0x0f))-1;
            AES_Suppression.setSelection(AES_Suppression_selectedIndex);
            BLELog.d(TAG, "AES_Suppression_selectedIndex="+AES_Suppression_selectedIndex);

        }
        else{
            int kk = 5;
            while(mService.AEC_AES_Data[2] > AEC_Threshold_ids[kk]){
                kk -= 1;
            }

            BLELog.d(TAG,"AEC_Data[3]] kk = "+ kk);
            AEC_Threshold_selectedIndex = kk;
            AEC_Threshold.setSelection(AEC_Threshold_selectedIndex);
            BLELog.d(TAG, "AEC_Threshold_selectedIndex="+AEC_Threshold_selectedIndex);


            for (int index= 0; index <DoubleTalk_Threshold_ids.length;index++ ){
                if(mService.AEC_AES_Data[3] == DoubleTalk_Threshold_ids[index]) {
                    DoubleTalk_Threshold_selectedIndex = index;
                    DoubleTalk_Threshold.setSelection(DoubleTalk_Threshold_selectedIndex);
                    BLELog.d(TAG, "DoubleTalk_Threshold_selectedIndex="+
                            DoubleTalk_Threshold_selectedIndex);
                    break;
                }
            }

            //AES_Suppression.selectedIndex = Int((AEC_Data[1] & 0xf0) >> 4)
            AES_Suppression_selectedIndex = (int)((mService.AEC_AES_Data[1] & 0xf0) >> 4)-1;
            AES_Suppression.setSelection(AES_Suppression_selectedIndex);
            BLELog.d(TAG, "AES_Suppression_selectedIndex="+
                    AES_Suppression_selectedIndex);
        }

        if(!(AEC_OnOff_checkbox.isChecked())){
            /*mSBC_checkbox.isUserInteractionEnabled = false
            Stepsize.isUserInteractionEnabled = false
            TapLength.isUserInteractionEnabled = false
            AEC_Threshold.isUserInteractionEnabled = false
            AES_Suppression.isUserInteractionEnabled = false
            DoubleTalk_Threshold.isUserInteractionEnabled = false*/
        }
    }

    @Override
    public void onDetach() {
        Log.d(TAG, "EQAudioFragment onDetach");
        super.onDetach();
    }

    @Override
    public void BLE_ServiceReady() {

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] Data) {
        int k = 0;
        byte[] buffer = Data;

        //(dat as NSData).getBytes(&buffer, length: (dat as NSData).length)

        Log.d(TAG,"Parsing configuration data");

        while(k < buffer.length){
            byte len = buffer[k+2];
            //let param_dat = (dat as NSData).subdata(with: NSMakeRange(k+3, Int(len)))

            byte[] param_dat = Arrays.copyOfRange(buffer, k+3, k+3+ len);;

            Log.d(TAG,"Offset = "+k+" module_id ="+buffer[k]+ "cfg_id ="+buffer[k+1]+
                    "data len = "+len+" dat = "+ HexTool.byteArrayToHexString(param_dat));

            /*
            if(buffer[k] == 13 && buffer[k+1] == 5){
                if(buffer[k+2] == 16){
                    DSPManager?.AEC_AES_Data.removeAll()
                    for index in 0..<16 {
                        DSPManager?.AEC_AES_Data.append(buffer[k+3+index])
                    }
                    print("AEC_AES_Data = \(DSPManager?.AEC_AES_Data)")
                    //AEC_AES_Data_Init()
                    //break
                }
            }
            else if(buffer[k] == 13 && buffer[k+1] == 1){
                print("VOICE_DSP_CFG_KEY_CONFIG_WORD_byte2 = \(String(format: "0x%02X",buffer[k+4]))")
                if((buffer[k+4] & 0x01) == 0x01){
                    print("AEC is On")
                }
                else{
                    print("AEC is Off")
                }

                if(buffer[k+2] == 4){
                    for index in 0..<4 {
                        VOICE_Config_Data.append(buffer[k+3+index])
                    }
                    print("VOICE_Config_Data = \(VOICE_Config_Data)")
                    VOICE_Config_Data_Byte2 = VOICE_Config_Data[1]
                }*/


            if(buffer[k] == 13 && buffer[k+1] == 5){
                if(buffer[k+2] == 16) {

                    mService.AEC_AES_Data = Arrays.copyOfRange(buffer, k + 3, k + 3 + 16);

                    Log.d(TAG, "mService.AEC_AES_Data len = " + mService.AEC_AES_Data.length + "data =" +
                            HexTool.byteArrayToHexString(mService.AEC_AES_Data));
                }


            }else if(buffer[k] == 13 && buffer[k+1] == 1) {

                if((buffer[k+4] & 0x01) == 0x01){
                    Log.d(TAG,"AEC is On");
                }
                else{
                    Log.d(TAG,"AEC is Off");
                }

                if(buffer[k+2] == 4) {
                    VOICE_Config_Data = Arrays.copyOfRange(buffer, k + 3, k + 3 + 4);

                    Log.d(TAG, "VOICE_Config_Data len = " + VOICE_Config_Data.length + "data =" +
                            HexTool.byteArrayToHexString(VOICE_Config_Data));

                    VOICE_Config_Data_Byte2 = VOICE_Config_Data[1];
                }

            }

            k += (int)(3+len);
        }


        if(mService.AEC_AES_Data.length != 0){
            AEC_Prev_Data = Arrays.copyOfRange(mService.AEC_AES_Data, 0, mService.AEC_AES_Data.length);
        }

        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                AEC_AES_Data_Init();
            }
        });



    }

    @Override
    public void DSPTuningComplete(byte result) {

    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {
        Log.d(TAG, " DSPTuningState" + state);
        if (DSPState!= null)
            DSPState.setText(state);
    }

    @Override
    public void ExportDSPTuningResult() {

    }
}
