package com.app.microchip.wstearbuds.ui;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.microchip.audiowidget.R;
import com.app.microchip.audiowidget.models.BLESpeaker;
import com.app.microchip.audiowidget.ota.HexTool;
import com.app.microchip.audiowidget.util.BLELog;
import com.app.microchip.audiowidget.util.Constants;
import com.app.microchip.wstearbuds.managers.EarbudsBLEManager;
import com.app.microchip.wstearbuds.managers.EarbudsTransparentServiceManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Timer;


public class EarbudsFindMeActivity extends AppCompatActivity {

    private final static String UART_CMD_MMI_ACTION_POWER_ON_PRESSED = "2 0 51";
    private final static String UART_CMD_MMI_ACTION_POWER_ON_RELEASED = "2 0 52";
    private final static String UART_CMD_MMI_ACTION_POWER_OFF_PRESSED = "2 0 53";
    private final static String UART_CMD_MMI_ACTION_POWER_OFF_RELEASED = "2 0 54";
    private final static int COMMAND_ACK_EVENT = 0;//0x00
    private final static int READ_EVT_BTM_STATUS = 1;
    private final static int READ_LINK_STATUS_REPLAY = 30; //0x1E


    private final static int UART_CMD_WST_GET_STATUS_RSP_EVT = 51; //0x33
    private final static int UART_CMD_WST_GET_EB_POS_STATUS_RSP_EVT = 87; //0x57

    private final static int UART_CMD_WST_GET_PRIM_BATT_INFO_RSP_EVT = 12; //0x0C
    private final static int UART_CMD_WST_GET_SECD_BATT_INFO_RSP_EVT = 88; //0x58

    private final static String UART_CMD_READ_LINK_STATUS = "0D 0";

    private final static String UART_CMD_WST_GET_STATUS = "2B 00";
    private final static String UART_CMD_WST_GET_EB_POS_STATUS = "40 03" ;

    private final static String UART_CMD_WST_GET_PRIM_BATT_INFO = "25 00";
    private final static String UART_CMD_WST_GET_SECD_BATT_INFO = "40 04";

    private final static String UART_CMD_WST_FIND_ME_BEEP_1 = "13 02 01";
    private final static String UART_CMD_WST_FIND_ME_BEEP_2 = "13 02 02";

    private final static String UART_CMD_DISCONNECT = "32 0 0";
    private static final String TAG = EarbudsFindMeActivity.class.getSimpleName();
    private BLESpeaker mSpeaker;
    private EarBudsInfo earBudsInfo;
    private EarbudsBLEManager mBleManager;
    //private ArrayList<BLESpeaker> currentList;
  //  private EarbudsSpeakerControlAdapter adapter;
    //private ListView list;
    private String mDevId = "";
  //  private Switch powerValue;
    private EarbudsTransparentServiceManager mTraspService;
    private IntentFilter transRxIntentFilter;
    private IntentFilter transReadyIntentFilter;
    private IntentFilter disconnectionfilter;
    private BroadcastReceiver speakerInfoReceiver;
    private File mTempLogFile;
    private boolean mBackPressed = false;
    private ProgressDialog mDisConnectDialog;
    private Timer progressBarCancelTimer;


    private int a2dpStatus =  -1;
    private final static int SPEAKER_AUDIO_A2DP_DISCONNECTED = 0;
    private final static int SPEAKER_AUDIO_A2DP_CONNECTED = 1;

    private void dismissDisConnect() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mDisConnectDialog != null && mDisConnectDialog.isShowing()) {
                    mDisConnectDialog.dismiss();
                }
            }
        });
    }

    private void displayDisConnecting() {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mDisConnectDialog != null)
                    mDisConnectDialog.show();
            }
        });
    }


    public static void setViewGroupEnabled(ViewGroup view, boolean enabled) {
        int childern = view.getChildCount();

        for (int i = 0; i < childern; i++) {
            View child = view.getChildAt(i);
            if (child instanceof ViewGroup) {
                setViewGroupEnabled((ViewGroup) child, enabled);
            }
            child.setEnabled(enabled);
        }
        view.setEnabled(enabled);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earbuds_findme);
        earBudsInfo = new EarBudsInfo();
       // mBleManager = BLEManager.getBLEManager(HomeScreenActivity.getInstance());
        Intent intent = getIntent();
        String deviceId = intent.getStringExtra(Constants.DEVICE_ID);
        BLELog.d(TAG, "Device ID of selected speaker =" + deviceId);
        mDevId = deviceId;
        try {
            mTempLogFile = File.createTempFile("commandLog", null, this.getCacheDir());
        } catch (IOException e) {
            e.printStackTrace();
        }
        mTraspService = EarbudsTransparentServiceManager.getInstance();
        InitializeUI();


        transRxIntentFilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_TRANS_DATA);
        transReadyIntentFilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_TRANS_READY);
        disconnectionfilter = new IntentFilter(EarbudsTransparentServiceManager.BLE_DISCONNECTED);
        speakerInfoReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (EarbudsTransparentServiceManager.BLE_DISCONNECTED.equals(action)) {
                    if (mBackPressed) {
                        progressBarCancelTimer.cancel();
                        dismissDisConnect();
                        EarbudsFindMeActivity.super.onBackPressed();
                        mBackPressed = false;
                        launchHomeScreen();
                    } else {
                        handleBLEDisconnection();
                    }
                }
                if (EarbudsTransparentServiceManager.BLE_TRANS_READY.equals(action)) {
                    sendInitCommands();
                }
                if (EarbudsTransparentServiceManager.BLE_TRANS_DATA.equals(action)) {
                    byte rxBytes[] = intent.getExtras().getByteArray(EarbudsTransparentServiceManager.BLE_RX_BYTES);
                    if (rxBytes != null) {
                        int i;
                        for (i = 0; i < rxBytes.length; i++)
                            BLELog.d(TAG, "Received Data byte[" + i + "]=" + (rxBytes[i] & 0xff));
                        if (((rxBytes[0] & 0xff) == 0xaa) && ((rxBytes[1] & 0xff) == 0x0)) {
                            BLELog.d(TAG, "header found");
                            switch (rxBytes[3] & 0xff) {
                                case COMMAND_ACK_EVENT:
                                    String returnValue = "";
                                    switch (rxBytes[5] & 0xff) {
                                        case 0:
                                            returnValue = "Command complete";
                                            if ((rxBytes[4] & 0xff) == 0x32) {
                                                BLELog.d(TAG, "Disconnnet command found");
                                                mTraspService.cleanupTransparentService ();
                                                //SpeakerControllerActivity.super.onBackPressed();
                                                //launchHomeScreen();
                                            }
                                            break;
                                        case 1:
                                            returnValue = "Command dissallow";
                                            break;
                                        case 2:
                                            returnValue = "Unknown command";
                                            break;
                                        case 3:
                                            returnValue = "Parameters error";
                                            break;
                                        case 4:
                                            returnValue = "BTM is busy";
                                            break;
                                        case 5:
                                            returnValue = "BTM memory is full";
                                            break;
                                        default:
                                            returnValue = "unknown return value";
                                    }
                                    BLELog.d(TAG, "ACK for Command = " + (rxBytes[4] & 0xff) + "  ACK Return value =" + returnValue);
                                    if ((rxBytes[5] & 0xff) != 0) {
                                        commandError(returnValue + " For Command:" + (rxBytes[4] & 0xff));
                                    }
                                    break;
                                case READ_LINK_STATUS_REPLAY: {
                                    BLELog.d(TAG, "Reply for LINK STATUS");
                                    /* if ((rxBytes[4] & 0xff) == 0) {
                                        BLELog.d(TAG, "Power OFF state");
                                        powerValue.setChecked(false);
                                        powerStateChanged(false);
                                    } else {
                                        BLELog.d(TAG, "Power ON state");
                                        powerValue.setChecked(true);
                                        powerStateChanged(true);
                                    }*/


                                }
                                break;
                                case UART_CMD_WST_GET_STATUS_RSP_EVT: {
                                    BLELog.d(TAG, "WST connection STATUS EVT");

                                    if ((rxBytes[5] & 0xff) == 0x03) {
                                        BLELog.d(TAG, " WST connected");
                                        earBudsInfo.isWSTConnected = true;
                                        sendSecondaryWstCommands();
                                    } else {
                                        BLELog.d(TAG, " WST NOT connected");
                                        earBudsInfo.isWSTConnected = false;
                                        updateEarbudStatusUI();
                                    }



                                }
                                break;

                                case UART_CMD_WST_GET_EB_POS_STATUS_RSP_EVT: {
                                    BLELog.d(TAG, "WST  EARBUD POS EVT");
                                    earBudsInfo.isPrimaryLeft = true;
                                    if ((rxBytes[4] & 0xff) == 0x02) {
                                        BLELog.d(TAG, " WST primary earbud RIGHT");
                                        earBudsInfo.isPrimaryLeft = false;
                                    } else  if ((rxBytes[4] & 0xff) == 0x01) {
                                        BLELog.d(TAG, " WST primary earbud LEFT");
                                        earBudsInfo.isPrimaryLeft = true;
                                    }


                                }
                                break;

                                case UART_CMD_WST_GET_PRIM_BATT_INFO_RSP_EVT: {
                                    BLELog.d(TAG, "WST  PRIM battery  EVT"+ (rxBytes[5]& 0xff));
;
                                    earBudsInfo.primaryBatteryStatus = rxBytes[5]& 0xff;

                                   // if(earBudsInfo.isWSTConnected)
                                        //sendSecondaryWstCommands();

                                }
                                break;

                                case UART_CMD_WST_GET_SECD_BATT_INFO_RSP_EVT: {
                                    BLELog.d(TAG, "WST  SEC battery  EVT");
                                    earBudsInfo.secondaryBatteryStaus = rxBytes[4]& 0xff;
                                    updateEarbudStatusUI();

                                }
                                break;

                                case READ_EVT_BTM_STATUS: {
                                    BLELog.d(TAG, "Event for BTM STATUS");
                                   /* if ((rxBytes[4] & 0xff) == 0x00) {
                                        BLELog.d(TAG, "Power OFF state");
                                        powerValue.setChecked(false);
                                        powerStateChanged(false);
                                    } else if ((rxBytes[4] & 0xff) == 0x02) {
                                        BLELog.d(TAG, "Power ON state");
                                        powerValue.setChecked(true);
                                        powerStateChanged(true);
                                    }*/

                                    switch (rxBytes[4] & 0xff) {
                                        case 0x01:
                                            BLELog.d(TAG, "Pairing state (discoverable mode)");

                                            break;
                                        case 0x03:
                                            BLELog.d(TAG, "Pairing successful");
                                            break;
                                        case 0x04:
                                            BLELog.d(TAG, "Pairing failed");
                                            break;
                                        case 0x05:
                                            BLELog.d(TAG, "HF/HS link established");
                                            break;
                                        case 0x06:
                                            BLELog.d(TAG, "A2DP link established");

                                            break;
                                        case 0x07:
                                            BLELog.d(TAG, "HF link disconnected");
                                            break;
                                        case 0x08:
                                            BLELog.d(TAG, "A2DP link disconnected");
                                            break;
                                        case 0x09:
                                            BLELog.d(TAG, "SCO link connected");
                                            finish();
                                            break;
                                        case 0x0A:
                                            BLELog.d(TAG, "SCO link disconnected");
                                            break;
                                        case 0x0B:
                                            BLELog.d(TAG, "AVRCP link established");
                                            break;
                                        case 0x0C:
                                            BLELog.d(TAG, "AVRCP link disconnected");
                                            break;
                                        case 0x0D:
                                            BLELog.d(TAG, "Standard SPP connected");
                                            break;
                                        case 0x0E:
                                            BLELog.d(TAG, "Standard_SPP / iAP disconnected");
                                            break;
                                        case 0x0F:
                                            BLELog.d(TAG, "Standby state");
                                            break;
                                        case 0x10:
                                            BLELog.d(TAG, "iAP connected");
                                            break;
                                        case 0x11:
                                            BLELog.d(TAG, "ACL disconnected");
                                            //onBackPressed();
                                            //dataBaseId = 0;
                                            break;
                                        case 0x12:
                                            BLELog.d(TAG, "MAP connected");
                                            break;
                                        case 0x13:
                                            BLELog.d(TAG, "MAP operation forbidden");
                                            break;
                                        case 0x14:
                                            BLELog.d(TAG, "MAP disconnected");
                                            break;
                                        case 0x15:
                                            BLELog.d(TAG, "ACL connected");
                                            BLELog.d(TAG, "ACL Received Data Hex="+ HexTool.byteArrayToHexString(rxBytes));
                                        {
                                            //dataBaseId = rxBytes[5]& 0xff;
                                        }

                                        break;
                                        case 0x80:
                                            BLELog.d(TAG, "AuxIn Not available");

                                            break;
                                        case 0x81:
                                            BLELog.d(TAG, "AuxIn plugged and Playing AuxIn");

                                            break;
                                        case 0x82:
                                            BLELog.d(TAG, "AuxIn plugged and playing A2DP");

                                            break;
                                        default:
                                            BLELog.d(TAG, "Wrong state");
                                            break;
                                    }

                                }
                                break;
                            }
                        }
                    }
                }
            }

        };

        mTraspService.registerFragReceiver(speakerInfoReceiver, transRxIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, transReadyIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, disconnectionfilter);
    }

    private void commandError(final String message) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), message,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onPause() {
        BLELog.d(TAG, "onPause called");
       // if(mBackPressed){
            //mTraspService.cleanupTransparentService();
            //mBleManager.disconnect(mSpeaker.getBtDevice());
            //mBleManager.closeGatt(mSpeaker.getBtDevice());
       // }
       // mTraspService.unregisterFragReceiver(speakerInfoReceiver);
        EarbudsControllerActivity.getInstance().setmIsWstAppForegroud(false);
        super.onPause();
    }

    @Override
    protected void onResume() {
        BLELog.d(TAG, "onResume called");
        EarbudsControllerActivity.getInstance().setmIsWstAppForegroud(true);
        super.onResume();
        /*mTraspService.registerFragReceiver(speakerInfoReceiver, transRxIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, transReadyIntentFilter);
        mTraspService.registerFragReceiver(speakerInfoReceiver, disconnectionfilter);*/
        InitializeUI();
        updateEarbudStatusUI();
        sendInitCommands();
    }

    @Override
    protected void onStart() {
        BLELog.d(TAG, "onStart called");
        super.onStart();
    }

    @Override
    protected void onStop() {
        BLELog.d(TAG, "onStop called");
        mTraspService.unregisterFragReceiver(speakerInfoReceiver);
        super.onStop();
    }

    protected void onDestroy() {
        BLELog.d(TAG, "onDestroy called");
        super.onDestroy();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.;
        //getMenuInflater().inflate(R.menu.add_newdevicemenu, menu);
        return true;
    }

    private void readLog() {
        String strLine = "";
        StringBuilder text = new StringBuilder();
        try {
            FileReader fReader = new FileReader(mTempLogFile);
            BufferedReader bReader = new BufferedReader(fReader);

            /** Reading the contents of the file , line by line */
            while ((strLine = bReader.readLine()) != null) {
                text.append(strLine + "\n");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(EarbudsFindMeActivity.this, R.style.MyDialogTheme);
        builder.setMessage(text)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.find_new_device:
                //readLog();
                onBackPressed();
                return (true);
        }
        return (super.onOptionsItemSelected(item));
    }

    public void sendInitCommands() {
        BLELog.d(TAG, "Calling sendInit Commands here");
        //sendCommand(UART_CMD_READ_LINK_STATUS);

        sendWstStatusCommands();

    }

    public void sendWstStatusCommands() {
        BLELog.d(TAG, "sendWstStatusCommands");
        sendCommand(UART_CMD_WST_GET_EB_POS_STATUS);
        sendCommand(UART_CMD_WST_GET_PRIM_BATT_INFO);
        sendCommand(UART_CMD_WST_GET_STATUS);

    }


    public void sendSecondaryWstCommands() {
        BLELog.d(TAG, "sendPrimaryWstCommands");
        sendCommand(UART_CMD_WST_GET_SECD_BATT_INFO);

    }

    public void InitializeUI() {
        mSpeaker = EarbudsControllerActivity.getInstance().getSpeaker();
        setTitle("Find My Earbuds");
        //currentList = new ArrayList<>();
        //currentList = (ArrayList) mSpeaker.getGroupInfo();
        //adapter = new EarbudsSpeakerControlAdapter(this, currentList);
        //list = (ListView) findViewById(R.id.groupinfolist);
       // list.setAdapter(adapter);
        //list.setVisibility(View.GONE);


        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setCancelable(true);
        builder1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });





        ImageView findImage = (ImageView) findViewById(R.id.findmeImage);
        findImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Look for the earbuds beeping !!",
                        Toast.LENGTH_LONG).show();
                view.setClickable(false);
                startFindMe();
                view.setClickable(true);         }
        });

        TextView findStartText = (TextView) findViewById(R.id.findmeText);
        findStartText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                        Toast.makeText(getApplicationContext(), "Look for the earbuds beeping !!",
                                Toast.LENGTH_LONG).show();

                view.setClickable(false);
                startFindMe();
                view.setClickable(false);


            }
        });





        //updateEarbudStatusUI();

    }

    private  void startFindMe () {

        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {

                sendCommand(UART_CMD_WST_FIND_ME_BEEP_1);


                try {
                    Thread.sleep(1000);

                } catch (java.lang.InterruptedException e) {
                    e.printStackTrace();
                }


                sendCommand(UART_CMD_WST_FIND_ME_BEEP_2);



            }

        });
        thread.start();

    }

    private void updateEarbudStatusUI () {

        ImageView connectedLineImageV = (ImageView) findViewById(R.id.earbudsConnectedDotsImage);
        ImageView leftEarbudImage = (ImageView) findViewById(R.id.earbudsLeftImage);
        ImageView rightEarbudImage = (ImageView) findViewById(R.id.earbudsRightImage);
        ImageView leftBatteryImage = (ImageView) findViewById(R.id.batterryLeftImage);
        ImageView rightBatteryImage = (ImageView) findViewById(R.id.batterryRightImage);
        TextView leftBatteryStaus = (TextView) findViewById(R.id.batterryLeftstatusText);
        TextView rightBatteryStaus = (TextView) findViewById(R.id.batterrystatusTextRight);


       /* ImageView connectedLineImageV = (ImageView) convertView.findViewById(R.id.earbudsConnectedDotsImage);
        ImageView leftEarbudImage = (ImageView) convertView.findViewById(R.id.earbudsLeftImage);
        ImageView rightEarbudImage = (ImageView) convertView.findViewById(R.id.earbudsRightImage);
        ImageView leftBatteryImage = (ImageView) convertView.findViewById(R.id.batterryLeftImage);
        ImageView rightBatteryImage = (ImageView) convertView.findViewById(R.id.batterryRightImage);
        TextView leftBatteryStaus = (TextView) convertView.findViewById(R.id.batterryLeftstatusText);
        TextView rightBatteryStaus = (TextView) convertView.findViewById(R.id.batterrystatusTextRight);*/

        if(earBudsInfo.isWSTConnected) {


            String leftEarbudBattrey;
            String rightEarbudBattrey;




            if(earBudsInfo.isPrimaryLeft) {
                leftEarbudBattrey= getNormalizeBattaryValue(earBudsInfo.primaryBatteryStatus)+"%" ;
                rightEarbudBattrey = getNormalizeBattaryValue(earBudsInfo.secondaryBatteryStaus)+"%";

                leftBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.primaryBatteryStatus)));
                leftBatteryImage.setVisibility(View.VISIBLE);

                rightBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.secondaryBatteryStaus)));
                rightBatteryImage.setVisibility(View.VISIBLE);

            } else {
                leftEarbudBattrey= getNormalizeBattaryValue(earBudsInfo.secondaryBatteryStaus)+"%" ;
                rightEarbudBattrey = getNormalizeBattaryValue(earBudsInfo.primaryBatteryStatus)+"%";

                leftBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.secondaryBatteryStaus)));
                leftBatteryImage.setVisibility(View.VISIBLE);

                rightBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.primaryBatteryStatus)));
                rightBatteryImage.setVisibility(View.VISIBLE);

            }

            connectedLineImageV.setImageResource(R.drawable.dots11);
            connectedLineImageV.setVisibility(View.VISIBLE);

            leftEarbudImage.setImageResource(R.drawable.left_eabud_blk);
            leftEarbudImage.setVisibility(View.VISIBLE);

            leftBatteryStaus.setText(leftEarbudBattrey);
            leftBatteryStaus.setVisibility(View.VISIBLE);

            rightEarbudImage.setImageResource(R.drawable.right_eabud_blk);
            rightEarbudImage.setVisibility(View.VISIBLE);

            rightBatteryStaus.setText(rightEarbudBattrey);
            rightBatteryStaus.setVisibility(View.VISIBLE);



        } else {


            String leftEarbudBattrey;
            String rightEarbudBattrey;


            if(earBudsInfo.isPrimaryLeft) {
                leftEarbudBattrey= getNormalizeBattaryValue(earBudsInfo.primaryBatteryStatus)+"%" ;
                rightEarbudBattrey = " ! ";

                leftBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.primaryBatteryStatus)));
                leftBatteryImage.setVisibility(View.VISIBLE);

                rightBatteryImage.setImageDrawable(getDrawable(R.drawable.battery0));
                rightBatteryImage.setVisibility(View.VISIBLE);

            } else {
                rightEarbudBattrey = getNormalizeBattaryValue(earBudsInfo.primaryBatteryStatus)+"%";
                leftEarbudBattrey= " ! " ;

                leftBatteryImage.setImageDrawable(getDrawable(R.drawable.battery0));
                leftBatteryImage.setVisibility(View.VISIBLE);

                rightBatteryImage.setImageDrawable(getDrawable(getBatteryResource(earBudsInfo.primaryBatteryStatus)));
                rightBatteryImage.setVisibility(View.VISIBLE);
            }


            connectedLineImageV.setVisibility(View.INVISIBLE);

            leftEarbudImage.setImageResource(R.drawable.left_earbud_white);
            leftEarbudImage.setVisibility(View.VISIBLE);

            leftBatteryStaus.setText(leftEarbudBattrey);
            leftBatteryStaus.setVisibility(View.VISIBLE);

            rightEarbudImage.setImageResource(R.drawable.right_eabud_white);
            rightEarbudImage.setVisibility(View.VISIBLE);

            rightBatteryStaus.setText(rightEarbudBattrey);
            rightBatteryStaus.setVisibility(View.VISIBLE);

        }

        leftBatteryStaus.setVisibility(View.INVISIBLE);
        rightBatteryStaus.setVisibility(View.INVISIBLE);


    }

    public void sendCommand(String cmd) {
        if (mTraspService.isConnected() == false) {
            handleBLEDisconnection();
        }
        if (mTraspService != null) {
            mTraspService.packAndSendCommand(cmd);
        }
    }

    private void launchHomeScreen() {
        runOnUiThread(new Runnable() {
            public void run() {
                Intent home = new Intent(getApplicationContext(), EarbudsControllerActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                home.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(home);

            }
        });
    }


    public void handleBLEDisconnection() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("BLE Disconnected");
        builder.setMessage("BLE is disconnected, Please connect again");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                launchHomeScreen();
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
            }
        });
        builder.show();
    }

    /*public void powerStateChanged(boolean isPowerdOn) {
        LinearLayout v = (LinearLayout) findViewById(R.id.speakerActions);
        if (isPowerdOn) setViewGroupEnabled(v, true);
        else setViewGroupEnabled(v, false);
    }*/



    private int getBatteryResource(int wstBatteryStatus) {
        int batterImgId = -1;
        if (wstBatteryStatus == 0x00) batterImgId = R.drawable.battery0;
        else if (wstBatteryStatus == 0x01 || wstBatteryStatus == 0x02 || wstBatteryStatus == 0x03) batterImgId = R.drawable.battery1;
        else if (wstBatteryStatus == 0x04 || wstBatteryStatus == 0x05 || wstBatteryStatus == 0x06) batterImgId = R.drawable.battery2;
        else if (wstBatteryStatus == 0x07 || wstBatteryStatus == 0x08 || wstBatteryStatus == 0x09) batterImgId = R.drawable.battery3;
        else if (wstBatteryStatus == 0x0A || wstBatteryStatus == 0x0B) batterImgId = R.drawable.battery4;
        else if (wstBatteryStatus == 0x0C) batterImgId = R.drawable.battery5;

        return batterImgId;
    }

    private String getNormalizeBattaryValue (int wstBatteryStatus){

        int battValInt;


        if (wstBatteryStatus == 0x00)
            battValInt = 0;

        else if (wstBatteryStatus == 0x0C)
            battValInt = 100;

        else
            battValInt = ((100/12) * wstBatteryStatus);

        return Integer.toString(battValInt);
    }

    class EarBudsInfo {
        boolean isWSTConnected = false;
         boolean isPrimaryLeft = false;
         boolean isA2dpConnected = false;

        int primaryBatteryStatus =  0;
        int secondaryBatteryStaus = 0;

    }
}
