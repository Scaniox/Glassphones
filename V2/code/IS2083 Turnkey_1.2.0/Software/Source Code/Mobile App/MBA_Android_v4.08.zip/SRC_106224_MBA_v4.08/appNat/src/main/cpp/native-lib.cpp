#include <jni.h>
#include <string>
//#include "EQ_Calculate.h"
#include <stdio.h>
#import <math.h>

int* getEqualizerParameters(double Gain[5],double freq[5],double q[5]);
//int* BM83_getEqualizerParameters(double Gain[5],double freq[5],double q[5],double global_gain,int stage);
int* BM83_getEqualizerParameters(double Gain[5],double freq[5],double q[5],double global_gain,int stage,double new_freq);
double GTodB(double in);
int BM83_GetErrorCode(void);

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_myapplication_EqualizerCalculate_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    //getEqualizerParameters(jdouble [],2,2,2);
    jdouble val  = 5.0;
    double retVal;
    BM83_GetErrorCode();
    // retVal = GTodB(val);


    return env->NewStringUTF(hello.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_mynatapplication_EqualizerCalculate_stringFromJNI
(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    //getEqualizerParameters(jdouble [],2,2,2);
    jdouble val  = 5.0;
    double retVal;
    BM83_GetErrorCode();
    // retVal = GTodB(val);


    return env->NewStringUTF(hello.c_str());
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_example_mynatapplication_EqualizerCalculate_bm83getEqualizerParameters(
        JNIEnv* env,jobject /* this */,
        jdoubleArray jArrGain,jdoubleArray jArrFreq,jdoubleArray jArrQ,
        jdouble global_gain,jint stage,jdouble new_freq) {

    jintArray jEqData;
    int* eqData;
    jdouble *jDoubleArrGain, *jDoubleArrFreq,*jDoubleArrQ;
    jboolean result = JNI_FALSE;

    jDoubleArrGain = (env)->GetDoubleArrayElements( jArrGain, NULL);
    jDoubleArrFreq = (env)->GetDoubleArrayElements( jArrFreq, NULL);
    jDoubleArrQ = (env)->GetDoubleArrayElements( jArrQ, NULL);

    eqData = BM83_getEqualizerParameters(jDoubleArrGain,jDoubleArrFreq,jDoubleArrQ,
                                         global_gain, stage,new_freq);

    printf("balaji %s", __FUNCTION__);

    jEqData = env->NewIntArray (84);

    env->SetIntArrayRegion ( jEqData, 0, 84, (jint *)(eqData));

    return jEqData;

}

/*

jbyteArray
Java_com_microchip_android_mesh_sdk_MeshSecurity_aesEncrypt( JNIEnv* env,
                                                  jobject thiz , jbyteArray pData, jbyteArray pKey,
                                                    jint dataLen)
{


jbyteArray encryptedData;
jbyte *jByteData, *jByteKey;
jboolean result = JNI_FALSE;

uint_8t *pOutData;

if (!pData && !pKey) {
printf("data is null in %s", __FUNCTION__);
return NULL ;
}

// Balaji check boolean param
jByteData = (*env)->GetByteArrayElements(env, pData, NULL);
if (jByteData == NULL) {
//jniThrowIOException(env, EINVAL);
return NULL;
}

jByteKey = (*env)->GetByteArrayElements(env, pKey, NULL);
if (jByteKey == NULL) {
(*env)->ReleaseByteArrayElements(env, pData, jByteData, 0);
//jniThrowIOException(env, EINVAL);
return NULL;
}

pOutData = mesh_aes_encrypt_128(jByteKey,jByteData,dataLen);

encryptedData = (*env)->NewByteArray (env,dataLen);

(*env)->SetByteArrayRegion (env, encryptedData, 0, dataLen, (jbyte*)(pOutData));


return  encryptedData;

}

jstring
Java_com_microchip_android_mesh_sdk_MeshSecurity_ECDHCompressKey( JNIEnv* env, jobject thiz , jbyteArray publickey) {

    jbyteArray NewKey;
    jbyte *jByteKey;
    uint_8t *pOutData;

    jByteKey = (*env)->GetByteArrayElements(env, publickey, NULL);
    if (jByteKey == NULL) {
        //jniThrowIOException(env, EINVAL);
        return NULL;
    }

    pOutData = mesh_ecdh_CompressKey(jByteKey);

    NewKey = (*env)->NewByteArray (env,33);

    (*env)->SetByteArrayRegion (env, NewKey, 0, 33, (jbyte*)(pOutData));

    return  NewKey;
}

 */

#define BM83_DSPTuning  1

#define Max_Stage   5

#define MAX_FREQUENCY_BANDS 5
#define Max_dB 12
#define Min_dB 40
#define Quanti_LSB 30
#define Quanti_MSB 14
#define Sim_Bit_Drop 0
#define Max_Eq_Calculated_Bytes 84
#define m_AccuracyNum 16384

//int eqCalByteIndex;
//int Frequency_default[] = {300, 500, 1000, 2000, 5000};
//int Q_default[] = {1, 1, 1, 1, 1};
//int Gain_default[] = {0, 0, 0, 0, 0};
//double Response[m_AccuracyNum] = {0};

typedef struct
{
    int Stage;
    double Gain;
    double Num[100];// = new double [100];
    double Den[100];// = new double [100];
}__attribute__((packed)) FilterCoeff;


// Debugging
//private static final String TAG = "EqActivity";
//private static final boolean D = true;

// ALL EQ SETTINGS HERE !!!

//private ActivitySpeakerTab mainActivity;
//private View layoutView;

int min_level = 0;
int max_level = 100;
int eqCalByteIndex =0;
int count = 0;
int m_StageNum = MAX_FREQUENCY_BANDS;

int MAX_SLIDERS = MAX_FREQUENCY_BANDS; // Must match the XML layout
//SeekBar sliders[] = new SeekBar[MAX_SLIDERS];
//EditText editTextFreq[] = new EditText[MAX_FREQUENCY_BANDS];
//EditText editTextQ[] = new EditText[MAX_FREQUENCY_BANDS];
int eqCalculatedBytes[84];// = new int[Max_Eq_Calculated_Bytes];
int IIR_Coeff_Buff[42]; //BM83 DSPTuning
int EQ_Calculation_Error;

//private Handler mSendHandler = new Handler();
//int eqSendPressed = 0;
//private Runnable eqSendRunObj;
//int EQ_SEND_DELAY = 1100;


FilterCoeff pFilter[MAX_FREQUENCY_BANDS];// = new FilterCoeff[MAX_FREQUENCY_BANDS];
double pGain[MAX_FREQUENCY_BANDS];// = new double [MAX_FREQUENCY_BANDS];
double pFreq[MAX_FREQUENCY_BANDS];// = new double [MAX_FREQUENCY_BANDS];
double pQ[MAX_FREQUENCY_BANDS];// = new double [MAX_FREQUENCY_BANDS];
double m_SampleFreq = 48000;
//double m_SampleFreq = 8000;

double m_GlobalGain = 0;


void FilterFixQuantize(FilterCoeff In,int Bits)
{
    int i;
    double tmp;

    for (i=1;i<=In.Stage;i++)
    {
        tmp=In.Den[i]*pow(2.0,Bits);
        tmp=round(tmp);
        In.Den[i]=tmp/pow(2.0,Bits);

        tmp=In.Num[i]*pow(2.0,Bits);
        tmp=round(tmp);
        In.Num[i]=tmp/pow(2.0,Bits);
    }
}

double GTodB(double in)
{
    double out;
    out=20.0*log10(in);
    return out;
};
double dBToG(double in)
{
    double out;
    out=pow(10.0,in/(20.0));
    return out;
};

double round(double in)
{
    double tmp;
    tmp=floor(in);
    in=in-tmp;
    in=in*2;
    if (in>=1)
        tmp++;
    return tmp;
}

int boost(FilterCoeff *in,double gain,double fc,double Q,double fs)
{
    printf("gain=%f,fc=%f,Q=%f,fs=%f\n",gain,fc,Q,fs);
    double PI=3.1415926535898,wcT,K,V;
    V=fs/2-fc;
    if(V<=0){
        return 0;
    }

    in->Stage=2;
    if (gain==1)
    {
        in->Stage=0;
        in->Gain=1;
        in->Den[0]=1;
        in->Num[0]=1;
        in->Den[1]=0;
        in->Num[1]=0;
        in->Den[2]=0;
        in->Num[2]=0;
        return 1;
    }
    wcT=2*PI*fc/fs;

    K = tan(wcT/2);
    V=gain;


    in->Num[0]=1+V*K/Q+K*K;
    in->Num[1]=2*(K*K - 1);
    in->Num[2]=1 - V*K/Q + K*K;
    in->Den[0]=1 + K/Q + K*K;
    in->Den[1]=2*(K*K - 1);
    in->Den[2]=1 - K/Q + K*K;

    V=in->Num[0];
    K=in->Den[0];
    for (int i=0;i<3;i++)
    {
        in->Num[i]=in->Num[i]/V;
        in->Den[i]=in->Den[i]/K;
    }
    in->Gain=V/K;
    return 1;
}

void FreqResponse(FilterCoeff In,int N,double *result)
{
    double realNum=0,imagNum=0,realDen=0,imagDen=0,realRes,imagRes,tmpDen;
    double PI=3.1415926535898,wcT,NwcT;
    int i,j;
    for (i=0;i<N;i++)
    {
        realNum=1;
        imagNum=0;
        realDen=1;
        imagDen=0;
        wcT=PI/(double)N*(double)i;


        for (j=1;j<=In.Stage;j++)
        {
            NwcT=(-1)*wcT*(double)j;
            realNum=realNum+In.Num[j]*cos(NwcT);
            imagNum=imagNum+In.Num[j]*sin(NwcT);
            realDen=realDen+In.Den[j]*cos(NwcT);
            imagDen=imagDen+In.Den[j]*sin(NwcT);

        }
        tmpDen=realDen*realDen+imagDen*imagDen;
        realRes=realNum*realDen+imagNum*imagDen;
        imagRes=realDen*imagNum-imagDen*realNum;
        realRes=realRes/tmpDen;
        imagRes=imagRes/tmpDen;
        tmpDen=realRes*realRes+imagRes*imagRes;
        result[i]=In.Gain*sqrt(tmpDen);
    }
}

int BM83_eqCalculate(double global_gain, int stage)
{
    int i;
    eqCalByteIndex = 0;
    count = 0;

    //for (i=0;i<m_StageNum;i++)
    for (i=0;i<stage;i++)
    {
        if(boost(&pFilter[i],dBToG(pGain[i]),pFreq[i],pQ[i],m_SampleFreq)==0)
        {
            printf("Filter%d central frequency incorrect!\n",i+1);
            //return (i+2);
            EQ_Calculation_Error = 1;
            return 0;
        }
        FilterFixQuantize(pFilter[i],Quanti_LSB-Sim_Bit_Drop);
    }

    //Calculate response for each separate filters then combine the response
    //Response ResponseResult = new Response();
    //Response ResponseTemp = new Response();
    double ResponseResult[m_AccuracyNum] = {0};
    double ResponseTemp[m_AccuracyNum] = {0};

    FreqResponse(pFilter[0],m_AccuracyNum, ResponseResult);

    //for(i=1;i<m_StageNum;i++)
    for(i=1;i<stage;i++)
    {
        FreqResponse(pFilter[i],m_AccuracyNum,ResponseTemp);
        for(int j=0;j<m_AccuracyNum;j++)
        {
            ResponseResult[j]=ResponseResult[j]*ResponseTemp[j];
        }
    }
    for(int j=0;j<m_AccuracyNum;j++)
    {
        //ResponseResult[j]=ResponseResult[j]*dBToG(m_GlobalGain);
        ResponseResult[j]=ResponseResult[j]*dBToG(global_gain);
    }

    printf("Check Maximum Gain..\n");
    double tmpscale;
    long Max_Response = 0;
    for(i=0;i<m_AccuracyNum;i++)
    {
        tmpscale = (double)i / (double)m_AccuracyNum*(double)m_SampleFreq / 2;
        if(ResponseResult[i]>Max_Response)
            Max_Response = ResponseResult[i];
    }
    if(Max_Response >= 4)
    {
        EQ_Calculation_Error = 2;
        printf("The Maximum Gain cannot over 12 dB!\n");
    }
    //==================================================================================================
    double GGain,tmp;
    double tmpG[MAX_FREQUENCY_BANDS] = {0};// = new double[MAX_FREQUENCY_BANDS];
    FilterCoeff tmpFilter[MAX_FREQUENCY_BANDS] = {0};// = new FilterCoeff[MAX_FREQUENCY_BANDS];

    int MSB,LSB;
    //GGain=dBToG(m_GlobalGain);
    GGain=dBToG(global_gain);
    int j;

    //for(i=0;i<m_StageNum;i++)
    for(i=0;i<stage;i++)
    {
        tmpFilter[i]=pFilter[i];
        tmpG[i]=dBToG(pGain[i]);
    }

    //Bubble minmax sort
    //drop gain=1 filtet to buttom to remove redundant filter
    FilterCoeff tmpFilterCoeff = {0};// = new FilterCoeff();
    //for (i=0;i<m_StageNum-1;i++)
    for (i=0;i<stage-1;i++)
    {
        for (j=0;j<stage-1;j++)
        {

            if (((tmpG[j]>tmpG[j+1])||(tmpG[j]==1))&&(tmpG[j+1]!=1))
            {
                tmp=tmpG[j];
                tmpG[j]=tmpG[j+1];
                tmpG[j+1]=tmp;

                tmpFilterCoeff=tmpFilter[j];
                tmpFilter[j]=tmpFilter[j+1];
                tmpFilter[j+1]=tmpFilterCoeff;
            }
        }
    }
    //int count=0;

    //Need to sort the output sequence of filters by the value of gains
    //Output all coefficients as unsigned mode
    //for(i=0;i<m_StageNum;i++)
    for(i=0;i<stage;i++)
    {
        for (j=2;j>0;j--)
        {
            //tmp=pow(2.0,Quanti_MSB)*pFilter[i]->Num[j];
            tmp=pow(2.0,Quanti_MSB)*tmpFilter[i].Num[j];
            MSB=floor(tmp);
            LSB=((tmp-(double)MSB)*pow(2.0,16));
            if (MSB<0)
                MSB=(MSB+pow(2.0,16));

            eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff00) >> 8;
            eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff);
            eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff00) >> 8;
            eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff);

#if BM83_DSPTuning
            IIR_Coeff_Buff[count++]=MSB;
            IIR_Coeff_Buff[count++]=LSB;
            printf("MSB = %d, LSB = %d\n",MSB,LSB);
#endif
        }

        for (j=2;j>0;j--)
        {
            //tmp=pow(2.0,Quanti_MSB)*pFilter[i]->Den[j];
            tmp=pow(2.0,Quanti_MSB)*tmpFilter[i].Den[j];
            MSB=(floor(tmp));
            LSB=((tmp-(double)MSB)*pow(2.0,16));
            if (MSB<0)
                MSB=(MSB+pow(2.0,16));

            eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff00) >> 8;
            eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff);
            eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff00) >> 8;
            eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff);

#if BM83_DSPTuning
            IIR_Coeff_Buff[count++]=MSB;
            IIR_Coeff_Buff[count++]=LSB;
            printf("MSB = %d, LSB = %d\n",MSB,LSB);
#endif

        }
        GGain=GGain*pFilter[i].Gain;
    }

//#if 0
    //for (i=m_StageNum;i<Max_Stage;i++)
    for (i=stage;i<Max_Stage;i++)
    {
        printf("stage < 5\n");
        IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;
        IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;
    }
//#endif

    GGain=pow(2.0,Quanti_LSB)*GGain;
    GGain=round(GGain);
    GGain=GGain/pow(2.0,Quanti_LSB);

    tmp=pow(2.0,Quanti_MSB)*GGain;
    MSB=(floor(tmp));
    LSB=((tmp-(double)MSB)*pow(2.0,16));
    if (MSB<0)
        MSB=(MSB+pow(2.0,16));

    /*printf("MSB = %X\n",MSB);
     char aa = ((MSB>>8) & 0xff00);
     char bb = (MSB & 0xff);
     char tt = (MSB & 0xff00) >> 8;
     printf("aa = %02X\n,bb = %02X,tt = %02X\n",aa,bb,tt);*/
    eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff00) >> 8;
    eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff);
    eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff00) >> 8;
    eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff);

#if BM83_DSPTuning
    IIR_Coeff_Buff[count++]=MSB;
    IIR_Coeff_Buff[count++]=LSB;
    printf("MSB = %d, LSB = %d\n",MSB,LSB);
#endif

    return 1;
}

int eqCalculate()
{
    int i;
    eqCalByteIndex = 0;
    count = 0;

    for (i=0;i<m_StageNum;i++)
    {
        if(boost(&pFilter[i],dBToG(pGain[i]),pFreq[i],pQ[i],m_SampleFreq)==0)
        {
            printf("Filter%d central frequency incorrect!\n",i+1);
            //return (i+2);
            return 0;
        }
        FilterFixQuantize(pFilter[i],Quanti_LSB-Sim_Bit_Drop);
    }

    //Calculate response for each separate filters then combine the response
    //Response ResponseResult = new Response();
    //Response ResponseTemp = new Response();
    double ResponseResult[m_AccuracyNum] = {0};
    double ResponseTemp[m_AccuracyNum] = {0};

    FreqResponse(pFilter[0],m_AccuracyNum, ResponseResult);

    for(i=1;i<m_StageNum;i++)
    {
        FreqResponse(pFilter[i],m_AccuracyNum,ResponseTemp);
        for(int j=0;j<m_AccuracyNum;j++)
        {
            ResponseResult[j]=ResponseResult[j]*ResponseTemp[j];
        }
    }
    for(int j=0;j<m_AccuracyNum;j++)
    {
        ResponseResult[j]=ResponseResult[j]*dBToG(m_GlobalGain);
    }
    //==================================================================================================
    double GGain,tmp;
    double tmpG[MAX_FREQUENCY_BANDS] = {0};// = new double[MAX_FREQUENCY_BANDS];
    FilterCoeff tmpFilter[MAX_FREQUENCY_BANDS] = {0};// = new FilterCoeff[MAX_FREQUENCY_BANDS];

    int MSB,LSB;
    GGain=dBToG(m_GlobalGain);
    int j;

    for(i=0;i<m_StageNum;i++)
    {
        tmpFilter[i]=pFilter[i];
        tmpG[i]=dBToG(pGain[i]);
    }

    //Bubble minmax sort
    //drop gain=1 filtet to buttom to remove redundant filter
    FilterCoeff tmpFilterCoeff = {0};// = new FilterCoeff();
    for (i=0;i<m_StageNum-1;i++)
    {
        for (j=0;j<m_StageNum-1;j++)
        {

            if (((tmpG[j]>tmpG[j+1])||(tmpG[j]==1))&&(tmpG[j+1]!=1))
            {
                tmp=tmpG[j];
                tmpG[j]=tmpG[j+1];
                tmpG[j+1]=tmp;

                tmpFilterCoeff=tmpFilter[j];
                tmpFilter[j]=tmpFilter[j+1];
                tmpFilter[j+1]=tmpFilterCoeff;
            }
        }
    }
    //int count=0;

    //Need to sort the output sequence of filters by the value of gains
    //Output all coefficients as unsigned mode
    for(i=0;i<m_StageNum;i++)
    {
        for (j=2;j>0;j--)
        {
            //tmp=pow(2.0,Quanti_MSB)*pFilter[i]->Num[j];
            tmp=pow(2.0,Quanti_MSB)*tmpFilter[i].Num[j];
            MSB=floor(tmp);
            LSB=((tmp-(double)MSB)*pow(2.0,16));
            if (MSB<0)
                MSB=(MSB+pow(2.0,16));

            eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff00) >> 8;
            eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff);
            eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff00) >> 8;
            eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff);

        }

        for (j=2;j>0;j--)
        {
            //tmp=pow(2.0,Quanti_MSB)*pFilter[i]->Den[j];
            tmp=pow(2.0,Quanti_MSB)*tmpFilter[i].Den[j];
            MSB=(floor(tmp));
            LSB=((tmp-(double)MSB)*pow(2.0,16));
            if (MSB<0)
                MSB=(MSB+pow(2.0,16));

            eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff00) >> 8;
            eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff);
            eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff00) >> 8;
            eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff);

        }
        GGain=GGain*pFilter[i].Gain;
    }

    for (i=m_StageNum;i<Max_Stage;i++)
    {
        //out<<"0"<<endl<<"0"<<endl<<"0"<<endl<<"0"<<endl;
        //out<<"0"<<endl<<"0"<<endl<<"0"<<endl<<"0"<<endl;
        IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;
        IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;  IIR_Coeff_Buff[count++]=0;
    }

    GGain=pow(2.0,Quanti_LSB)*GGain;
    GGain=round(GGain);
    GGain=GGain/pow(2.0,Quanti_LSB);

    tmp=pow(2.0,Quanti_MSB)*GGain;
    MSB=(floor(tmp));
    LSB=((tmp-(double)MSB)*pow(2.0,16));
    if (MSB<0)
        MSB=(MSB+pow(2.0,16));

    /*printf("MSB = %X\n",MSB);
    char aa = ((MSB>>8) & 0xff00);
    char bb = (MSB & 0xff);
    char tt = (MSB & 0xff00) >> 8;
    printf("aa = %02X\n,bb = %02X,tt = %02X\n",aa,bb,tt);*/
    eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff00) >> 8;
    eqCalculatedBytes[eqCalByteIndex++] = (MSB & 0xff);
    eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff00) >> 8;
    eqCalculatedBytes[eqCalByteIndex++] = (LSB & 0xff);

    return 1;
}

int BM83_GetErrorCode(void){
    printf("BM83_GetErrorCode\n");
    return EQ_Calculation_Error;
}

int* BM83_getEqualizerParameters(double Gain[5],double freq[5],double q[5],double global_gain,int stage,double new_freq){

#if BM83_DSPTuning
    for (int i=0; i<42; i++) {
        IIR_Coeff_Buff[i] = 0x00;
    }
    printf("BM83 DSPTuning, %f,%d\n",global_gain,stage);

    m_SampleFreq = new_freq;

    printf("m_SampleFreq = %f\n",m_SampleFreq);
#endif

    double tmpFreq;

    EQ_Calculation_Error = 0;

    //printf("Initial global gain = %f\n",GTodB(1.0));

    for (int i=0; i<5; i++) {
        pGain[i] = Gain[i];

#if BM83_DSPTuning
        //BM83 DSP Tuning
        pFreq[i] = freq[i];
#else
        if (freq[i]>23999) {
            tmpFreq = 23999;
        }else if (freq[i] <1)
            tmpFreq = 1;
        else
            tmpFreq = freq[i];

        pFreq[i] = tmpFreq;
#endif
        pQ[i] = q[i];

        pFilter[i].Stage = 0;
        pFilter[i].Gain = 0;
        for (int j=0; j<100; j++) {
            pFilter[i].Den[j] = 0;
            pFilter[i].Num[j] = 0;
        }
    }
    //m_GlobalGain = GTodB(1.0);
    int k = BM83_eqCalculate(global_gain,stage);

    //memcpy()
    //result = eqCalculatedBytes;

#if BM83_DSPTuning
    int buf;
    int output[84];
    for (int i=0; i<84; i++) {
        output[i] = 0x00;
    }
    for(int i= 0;i<42;i++){
        buf = IIR_Coeff_Buff[i];

        output[i*2+1] = buf & 0xff;
        buf = buf >> 8;
        output[i*2] = buf & 0xff;
    }
    printf("PUT_IIR_Val\n");

    for (int i=0; i<84; i++) {
        printf(" %x",output[i]);
        eqCalculatedBytes[i] = output[i];
    }
    printf("\n");
#endif

    if(k == 0){
        return NULL;
    }
    else{
        return eqCalculatedBytes;
    }
}

int* getEqualizerParameters(double Gain[5],double freq[5],double q[5]){
    for (int i=0; i<84; i++) {
        eqCalculatedBytes[i] = 0x00;
    }

    double tmpFreq;

    printf("Initial global gain = %f\n",GTodB(1.0));

    for (int i=0; i<5; i++) {
        pGain[i] = Gain[i];

        if (freq[i]>23999) {
            tmpFreq = 23999;
        }else if (freq[i] <1)
            tmpFreq = 1;
        else
            tmpFreq = freq[i];

        pFreq[i] = tmpFreq;

        pQ[i] = q[i];

        pFilter[i].Stage = 0;
        pFilter[i].Gain = 0;
        for (int j=0; j<100; j++) {
            pFilter[i].Den[j] = 0;
            pFilter[i].Num[j] = 0;
        }
    }
    //m_GlobalGain = GTodB(1.0);
    int k = eqCalculate();
    //memcpy()
    //result = eqCalculatedBytes;

    if(k == 0)
        return NULL;
    else
        return eqCalculatedBytes;
}







