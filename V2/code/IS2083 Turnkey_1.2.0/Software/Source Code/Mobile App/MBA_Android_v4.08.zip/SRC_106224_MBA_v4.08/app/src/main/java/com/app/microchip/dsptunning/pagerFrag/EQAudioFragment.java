package com.app.microchip.dsptunning.pagerFrag;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.microchip.audiowidget.R;
import com.app.microchip.dsptunning.DspOTATunningBLEService;
import com.app.microchip.dsptunning.managers.DSPTuningDelegate;
import com.app.microchip.dsptunning.ui.DspOTATunningEQCoefActivity;
import com.app.microchip.dsptunning.ui.DspOTATunningMainActivity;
import com.app.microchip.dsptunning.ui.DspTuningAudioPagerActivity;

import java.util.Arrays;

/**
 * Created by I17163 on 12/12/2019.
 */

public class EQAudioFragment extends Fragment implements DSPTuningDelegate {

    private static final String TAG = EQAudioFragment.class.getSimpleName();

    String[] EQ_table = {"Off", "SOFT", "BASS", "TREBLE", "CLASSICAL", "ROCK",
            "JAZZ", "POP", "DANCE", "Rhythm and Blues", "Custom EQ"};

    private Button TuneDSP;
    private TextView DSPState;
    private DspTuningAudioPagerActivity mActivity;
    private DspOTATunningBLEService mService;

    private long fragFocusStartTime = 0;

    CheckBox EqualizerCheck;
    Spinner EQ_SettingSpinner;
    Button CustomEQ_Button;
    ListView EQListView;

    public EQAudioFragment () {
        Log.d(TAG, "Constructor");
    }

    DspTuningAudioPagerActivity activity;

    public void cleanModule() {
        Log.d(TAG, "cleanModule");
        activity = null;
    }




    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.eq_audio_fragment, container, false);

        Log.d(TAG, "onCreateView");


        DSPState =(TextView) view.findViewById(R.id.deviceStatus);
        TuneDSP = (Button) view.findViewById(R.id.tuneDspButton);
        CustomEQ_Button = (Button) view.findViewById(R.id.cusomeqSettingbutton1);

        EqualizerCheck = (CheckBox) view.findViewById(R.id.eqCheckbox);

        EQ_SettingSpinner = (Spinner)view.findViewById(R.id.Spinner1);


        return view;
                
    }

    public void onResume() {
        Log.d(TAG, "onResume of EQAudio Audio Frag");

        if (mService!= null) {
            if (mService.EQ_Data != null) {
                if (mService.EQ_Data.length == 0x54) {
                    enableTuneDspButton();
                }
            }
        }

        super.onResume();
    }


    private void initUI () {
        Log.d(TAG, "initUI");

        if (DSPState!= null)
            DSPState.setText(mService.DSP_DUT_State);

        ArrayAdapter<String> adapter1;
        adapter1 = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, EQ_table);

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        EQ_SettingSpinner.setAdapter(adapter1);
        EQ_SettingSpinner.setSelection(10);
        EQ_SettingSpinner.setEnabled(false);

        String[] modes = getResources().getStringArray(R.array.EqModes);
        EQListView = (ListView) getActivity().findViewById(R.id.eqModeslist);
        ArrayAdapter<String> ListAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_checked, modes);
        EQListView.setAdapter(ListAdapter);



        for (int i=0; i < modes.length; i++) {
            EQListView.setItemChecked(i, true);
         }

        EQListView.setClickable(false);

      //  EQListView.setEnabled(false);

        CustomEQ_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DspOTATunningEQCoefActivity.EQMode = 0x01;
                Intent intent = new Intent(mActivity.getApplicationContext(), DspOTATunningEQCoefActivity.class);
                startActivity(intent);;
            }
        });

        TuneDSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if((DspOTATunningEQCoefActivity.EQMode != 0) && ((mService.EQ_Data.length) == 0x54)){

                    if(DspOTATunningEQCoefActivity.EQMode == 0x01){
                        mActivity.showSpinnerDialog(true);
                        Log.d(TAG, ("Audio EQ]DSP Tuning..."));
                        Log.d(TAG, "mService.EQ_Data="+Arrays.toString(mService.EQ_Data));
                        mService.DSPTuning( (byte) 0x0C,  (byte) 0x04,  (byte) 0x54, mService.EQ_Data);
                        DspOTATunningEQCoefActivity.EQMode = 0;
                    }
                }


            }
        });


        Audio_EQ_Init();

        disableTuneDspButton();

        updateFunctionButtonsState();


    }

    private void  enableTuneDspButton() {
        TuneDSP.setEnabled(true);
        TuneDSP.setTextColor(Color.WHITE);
    }

    private void  disableTuneDspButton() {
        TuneDSP.setEnabled(false);
        TuneDSP.setTextColor(Color.LTGRAY);
    }

    private synchronized void updateFunctionButtonsState () {
        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                if(mService.dynamicToolMode == mService.TuneDSPMode_NotSupport || mService.dynamicToolMode == mService.TuneDSPMode_Voice){
                    CustomEQ_Button.setEnabled(false);
                    CustomEQ_Button.setTextColor(Color.LTGRAY);
                    disableTuneDspButton();
                }
                else if(mService.dynamicToolMode == mService.TuneDSPMode_Audio){
                    CustomEQ_Button.setEnabled(true) ;
                    CustomEQ_Button.setTextColor(Color.WHITE);

                }

            }

        }));


    }

    void Audio_EQ_Init() {
        Log.d(TAG,"Audio_EQ_Init");

        byte[] eqDef = mService.GetDefaultEqualizerMode();

        if (eqDef[0] == 0x20) {
            EqualizerCheck.setChecked(true);
            Log.d(TAG,"EqualizerCheck.setChecked(true)");
        } else {
            EqualizerCheck.setChecked(false);
        }
    }



    public void initModule(DspTuningAudioPagerActivity act) {
        mActivity = act;

        mService = DspOTATunningMainActivity.getINSTANCE().getmBLEService();

        mService.setListener(EQAudioFragment.this);

        initUI();

        mService.EQ_Data = null;


    }


    private String  dspStatusMsgDialog= "";
    private void showTuneDspDialog(String message) {

        dspStatusMsgDialog = message;

        mActivity.runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder ad = new AlertDialog.Builder(getActivity() , R.style.MyDialogTheme);
                ad.setMessage(dspStatusMsgDialog);

                ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                /*Intent i = new Intent(BLEService.OTA_ACTION_RESET_REQUEST);
                sendBroadcast(i);
                  mOtaState.setText("Completed");*/
                    }
                });

                final AlertDialog  alert = ad.create();
                alert.setTitle("Tune DSP Status!!");
                alert.show();



                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {

                    }
                });

            }
        }));


    }


    @Override
    public void onAttach(Context context) {
        Log.d(TAG, "EQAudioFragment onAttach");
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        Log.d(TAG, "EQAudioFragment onDetach");
        super.onDetach();
    }

    @Override
    public void BLE_ServiceReady() {

    }

    @Override
    public void RefreshModuleData() {

    }

    @Override
    public void RefreshParametersData(byte[] Data) {

    }

    @Override
    public void DSPTuningComplete(byte result) {
        String  status = "";

        mActivity.dismissSpinnerDialog();

        if(result == 0x01){
            status = "Success";
        }
        else{
            status = "Failed " + result;
        }

        showTuneDspDialog(status);

        if(result != 0x01){
            //LineIn_Config_Init(null, true);
        }

        mService.EQ_Data = null;
        getActivity().runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {
                disableTuneDspButton();

            }
        }));


    }

    @Override
    public void BLE_ConnectionStatus(boolean status) {

    }

    @Override
    public void DSPTuningState(String state) {
        Log.d(TAG, " DSPTuningState" + state);
        if (DSPState!= null)
            DSPState.setText(state);

        updateFunctionButtonsState();

    }


    @Override
    public void ExportDSPTuningResult() {

    }
}
